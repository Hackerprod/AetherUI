"""V21 readonly custody. Static materialization; no subprocesses or input writes."""
import hashlib,json,math,os,re,stat,time
from pathlib import Path
P=Path('/RELOCATE/verification')
R=Path('/RELOCATE/preparation')
E=Path('/RELOCATE/reference-1')
RH='413fa35254344f55b087364e6e9bbb38ec70010b7c2cc7706409238711dcee4f'
EH='30def72e2a21e3d12269f472114a12557f8edcef69c4bc96ceb576396e750336'
RT='12f2b901664651a49ab79061c9c1855e1976f2fd50608dc8fb15dd15f4503dba'
class CustodyError(RuntimeError):pass
def need(ok,code):
    if not ok:raise CustodyError(code)
def unique(items):
    result={}
    for k,v in items:need(k not in result,'DUPLICATE_JSON_KEY');result[k]=v
    return result
def decode(raw):return json.loads(raw,object_pairs_hook=unique,parse_constant=lambda _:(_ for _ in ()).throw(CustodyError('NONFINITE_JSON')))
def relative(name):
    need(type(name) is str and name and not name.startswith('/') and '\\' not in name and '\x00' not in name and all(x not in ('','.','..') for x in name.split('/')),'RELATIVE_PATH')
    return name
def hash_ok(value):return type(value) is str and re.fullmatch('[0-9a-f]{64}',value) is not None

class Custody:
    def __init__(self,H,t0,U,deadline,persist,checkpoint):
        need(hash_ok(H) and type(t0) in (float,int) and math.isfinite(t0) and math.isfinite(deadline) and deadline<=t0+180 and re.fullmatch('[0-9a-f]{32}',U),'CONSTRUCTOR')
        self.H=H;self.t0=t0;self.U=U;self.deadline=deadline;self.phase_deadline=deadline;self.persist=persist;self.checkpoint=checkpoint
        self.expected={};self.baseline={};self.initial_dirs=None;self.file_sets={};self.used=set();self.before_gate=None;self.revalidate_callback=None
        self.before_report=None;self.after_report=None;self.failure=None;self.phase='NEW';self.locations={};self.negative=[];self.policy=None;self.concurrency=None
    def budget(self):
        self.checkpoint();need(time.monotonic()<min(self.deadline,self.phase_deadline),'CUSTODY_WORK_DEADLINE')
    def _root_plain(self,path):
        path=Path(path)
        for p in (path,*path.parents):need(not p.is_symlink(),'UNAPPROVED_LINK')
        need(stat.S_ISREG(path.lstat().st_mode),'REGULAR_REQUIRED')
        return path
    def _hash(self,path):
        self.budget();h=hashlib.sha256();n=0
        with open(path,'rb') as stream:
            while True:
                self.budget();chunk=stream.read(1024*1024)
                if not chunk:break
                h.update(chunk);n+=len(chunk)
        self.budget();return n,h.hexdigest()
    def _read_plain(self,path,expected=None):
        path=self._root_plain(path);before=self._location(path);self.budget();raw=path.read_bytes();self.budget();need(self._location(path)==before,'READ_LOCATION_DRIFT')
        if expected is not None:need(hashlib.sha256(raw).hexdigest()==expected,'REFERENCE_HASH')
        return raw
    def _location(self,path):
        self.budget();path=Path(path);s=path.lstat();kind=stat.S_IFMT(s.st_mode)
        need(kind in (stat.S_IFREG,stat.S_IFLNK),'UNAPPROVED_INPUT_TYPE')
        value=dict(type='symlink' if kind==stat.S_IFLNK else 'regular',device=s.st_dev,inode=s.st_ino,mode=s.st_mode,size=s.st_size,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
        if kind==stat.S_IFLNK:value.update(target=os.readlink(path),resolved=str(path.resolve(strict=True)))
        return value
    def _add(self,path,digest,size=None,kind='regular',target=None,resolved=None,mandatory=True):
        path=str(Path(path));need(Path(path).is_absolute() and str(Path(path))==path and hash_ok(digest),'AUTHORITY_RECORD')
        value=dict(sha256=digest,bytes=size,type=kind,mandatory=mandatory)
        if kind=='symlink':value.update(target=target,resolved=resolved)
        prior=self.expected.get(path)
        if prior:
            need(prior['sha256']==digest and prior['type']==kind and (prior['bytes'] is None or size is None or prior['bytes']==size),'CONFLICTING_AUTHORITY')
            if kind=='symlink':need(prior['target']==target and prior['resolved']==resolved,'CONFLICTING_LINK_AUTHORITY')
            prior['mandatory']=prior['mandatory'] or mandatory
            if prior['bytes'] is None:prior['bytes']=size
        else:self.expected[path]=value
    def _list_manifest(self,root,digest,expected_count=None):
        path=root/'evidence.sha256.json';raw=self._read_plain(path,digest);rows=decode(raw);need(type(rows) is list,'LIST_MANIFEST')
        if expected_count is not None:need(len(rows)==expected_count,'MANIFEST_COUNT')
        self._add(path,digest,len(raw));names=set()
        for row in rows:
            need(type(row) is dict and set(row)=={'path','bytes','sha256'} and type(row['bytes']) is int and row['bytes']>=0,'MANIFEST_ROW')
            name=relative(row['path']);need(name not in names,'MANIFEST_DUPLICATE');names.add(name);self._add(root/name,row['sha256'],row['bytes'])
        return names|{'evidence.sha256.json'}
    def _policy_location(self,path,digest,size=None,mandatory=True):
        path=str(Path(path));location=self.locations.get(path)
        if location:
            kind=location.get('type')
            need(kind in ('regular','symlink'),'LOCATION_TYPE')
            if kind=='symlink':
                need(type(location.get('target')) is str and type(location.get('resolved')) is str and Path(location['resolved']).is_absolute(),'LOCATION_SCHEMA')
                self._add(path,digest,size,'symlink',location['target'],location['resolved'],mandatory)
                self._add(location['resolved'],digest,size,mandatory=mandatory);return
            need(location.get('target') is None and location.get('resolved')==path,'REGULAR_LOCATION_AUTHORITY')
        # A regular hash authority is not permission to follow a new symlink.
        self._add(path,digest,size,mandatory=mandatory)
    def _bootstrap(self):
        self.file_sets[str(P)]=self._list_manifest(P,self.H)
        self.file_sets[str(R)]=self._list_manifest(R,RH,2925)
        self.file_sets[str(E)]=self._list_manifest(E,EH,70)
        references=self._authorized_json(P/'references-authority.json')
        need(references['source_root']==str(R) and references['result_root']==str(E),'REFERENCE_ROOTS')
        for path,row in references['references'].items():
            raw=self._read_plain(path,row['sha256']);need(len(raw)==row['bytes'],'REFERENCE_BYTES')
            copy=P/relative(row['copy']);need(self._read_plain(copy)==raw,'REFERENCE_COPY_MISMATCH');self._add(path,row['sha256'],row['bytes'])
        self.policy=self._authorized_json(R/'policy.json')
        readonly_policy=self._authorized_json(P/'readonly-policy.json')
        self.locations={}
        for collection in ('tools','tool_aliases'):
            for tool in readonly_policy[collection].values():
                location=tool.get('location')
                need(type(location) is dict and set(location)=={'type','resolved','link'} and location['type'] in (stat.S_IFREG,stat.S_IFLNK),'TOOL_LOCATION_AUTHORITY')
                normalized=dict(type='symlink' if location['type']==stat.S_IFLNK else 'regular',resolved=location['resolved'],target=location['link'])
                if tool['path'] in self.locations:need(self.locations[tool['path']]==normalized,'TOOL_LOCATION_CONFLICT')
                self.locations[tool['path']]=normalized
        runtime=decode(self._read_plain(E/'runtime-artifacts.sha256.json',RT));need(runtime['root']==str(R) and type(runtime['artifacts']) is list and len(runtime['artifacts'])==5939,'RUNTIME_MANIFEST')
        runtime_rows={}
        for row in runtime['artifacts']:
            rel=relative(row['path']);need(rel not in runtime_rows,'RUNTIME_DUPLICATE');runtime_rows[rel]=row
        for rel,row in runtime_rows.items():
            need(row['type'] in ('regular','symlink'),'RUNTIME_TYPE')
            if row['type']=='regular':self._add(R/rel,row['sha256'],row['bytes'])
            else:
                target=row['resolved'];target_rel=str(Path(target).relative_to(R));target_row=runtime_rows.get(target_rel)
                need(target_row is not None and target_row['type']=='regular','LINK_TARGET_AUTHORITY')
                self._add(R/rel,target_row['sha256'],target_row['bytes'],'symlink',row['target'],target)
        self.file_sets[str(R)] |= set(runtime_rows)
        union=self._authorized_json(P/'external-header-authority-362.json')['headers']
        base=self._authorized_json(P/'references/headers-348.json')['headers'];delta=self._authorized_json(P/'references/headers-delta-14.json')['headers']
        need(len(base)==348 and len(delta)==14 and not(set(base)&set(delta)) and len(union)==362 and union=={**base,**delta},'HEADER_UNION')
        for path,row in union.items():self._policy_location(path,row['sha256'],row['bytes'])
        for path,digest in self.policy['references'].items():self._add(path,digest)
        for tool in self.policy['tools'].values():self._policy_location(tool['path'],tool['sha256'])
        for alias in self.policy['tool_aliases'].values():
            self._policy_location(alias['path'],alias['sha256']);self._policy_location(alias['resolved'],alias['sha256'])
        # Historical manifests are approved references, not fresh inferred inputs.
        old=Path(self.policy['source_root']);oldsha=self.policy['references'][str(old/'evidence.sha256.json')]
        oldrows=decode(self._read_plain(old/'evidence.sha256.json',oldsha));need(type(oldrows) is dict,'HIST_SOURCE_MANIFEST')
        for rel,digest in oldrows.items():self._add(old/relative(rel),digest,mandatory=False)
        histroot=Path(self.policy['historical_run_root']);histpath=Path(self.policy['historical_runtime_manifest']);hh=self.policy['historical_runtime_manifest_sha256']
        self._add(histpath,hh);histrows=decode(self._read_plain(histpath,hh));need(type(histrows) is dict,'HIST_RUNTIME_MANIFEST')
        for rel,row in histrows.items():self._add(histroot.parent/relative(rel),row['sha256'],row['size'],mandatory=False)
        histreport_path=histroot/'run/comparability.json';histreport=self._authorized_json(histreport_path)
        need(histreport.get('status')=='PASS','HIST_REPORT_NOT_PASS')
        for path,digest in histreport['inputs'].items():self._policy_location(path,digest,mandatory=False)
        # Baseline original source trees relevant to this comparison are complete.
        for tree in ('Hc','J'):
            manifest=old/('manifest-'+tree+'.json');mapping=self._authorized_json(manifest)
            for rel,digest in mapping.items():self._add(old/tree/relative(rel),digest)
        preserved=self._authorized_json(R/'run/comparability.json')
        rows=preserved.get('negative_path_assertions');need(type(rows) is list and len(rows)==2,'NEGATIVE_AUTHORITY')
        for tree,row in zip(('Hc','J'),rows):
            need(row['path']==str(R/('build-'+tree)/'glibc-hwcaps') and row['expected']=='ABSENT' and row['method']=='lstat' and row['parent']['path']==str(R/('build-'+tree)) and row['parent']['canonical_path']==row['parent']['path'] and row['parent']['type']=='directory','NEGATIVE_SCHEMA')
        self.negative=rows
    def _authorized_json(self,path):
        path=str(Path(path));need(path in self.expected,'UNAPPROVED_JSON');self.check_path(path);return decode(self._read_plain(path,self.expected[path]['sha256']))
    def check_path(self,path):
        self.budget();path=str(Path(path));need(path in self.expected,'PATH_NOT_PREAUTHORIZED');row=self.expected[path]
        first=self._location(path);need(first['type']==row['type'],'INPUT_TYPE_DRIFT')
        if row['type']=='symlink':
            need(first['target']==row['target'] and first['resolved']==row['resolved'],'LINK_DRIFT');target=Path(row['resolved']);self._root_plain(target)
            targetfirst=self._location(target);size,digest=self._hash(target);need(self._location(target)==targetfirst,'TARGET_DRIFT')
        else:
            self._root_plain(path);size,digest=self._hash(path)
        need(digest==row['sha256'] and (row['bytes'] is None or size==row['bytes']),'INPUT_HASH_OR_SIZE')
        need(self._location(path)==first,'INPUT_CHANGED_DURING_READ')
        observed=dict(first,content_bytes=size,sha256=digest)
        if path in self.baseline:need(self.baseline[path]==observed,'BASELINE_IDENTITY_DRIFT')
        else:self.baseline[path]=observed
        self.used.add(path);return observed
    def _tree(self,root,exclude_run=False):
        self.budget();files=set();dirs={}
        def walk_error(exc):raise exc
        for current,children,names in os.walk(root,followlinks=False,onerror=walk_error):
            self.budget();base=Path(current)
            if exclude_run and base==root:
                output=root/'run';need(not output.is_symlink() and stat.S_ISDIR(output.lstat().st_mode),'OUTPUT_DIRECTORY_TYPE')
                children[:]=[x for x in children if x!='run']
            for name in list(children):
                p=base/name;s=p.lstat();need(stat.S_ISDIR(s.st_mode) and not p.is_symlink(),'DIRECTORY_LINK_OR_TYPE');dirs[str(p.relative_to(root))]=dict(device=s.st_dev,inode=s.st_ino,mode=s.st_mode,mtime_ns=s.st_mtime_ns,ctime_ns=s.st_ctime_ns)
            for name in names:
                p=base/name;kind=stat.S_IFMT(p.lstat().st_mode);need(kind in (stat.S_IFREG,stat.S_IFLNK),'TREE_INPUT_TYPE');files.add(str(p.relative_to(root)))
        self.budget();return files,dirs
    def _negative_check(self):
        observations=[]
        for row in self.negative:
            self.budget();parent=Path(row['parent']['path'])
            for p in (parent,*parent.parents):need(not p.is_symlink(),'NEGATIVE_PARENT_SYMLINK')
            before=parent.lstat();need(stat.S_ISDIR(before.st_mode) and str(parent.resolve(strict=True))==row['parent']['canonical_path'] and before.st_dev==row['parent']['device'] and before.st_ino==row['parent']['inode'],'NEGATIVE_PARENT_DRIFT')
            try:Path(row['path']).lstat()
            except FileNotFoundError:pass
            else:raise CustodyError('GLIBC_HWCAPS_PRESENT')
            after=parent.lstat();need((before.st_dev,before.st_ino,before.st_mode)==(after.st_dev,after.st_ino,after.st_mode),'NEGATIVE_PARENT_RACE')
            observations.append(dict(path=row['path'],parent=row['parent'],expected='ABSENT',method='lstat',observed_monotonic=time.monotonic()))
        return observations
    def _complete(self,after=False):
        current_dirs={}
        for root in (P,R,E):
            files,dirs=self._tree(root,root==P);need(files==self.file_sets[str(root)],'EXACT_FILE_SET_DRIFT');current_dirs[str(root)]=dirs
        if self.initial_dirs is None:self.initial_dirs=current_dirs
        else:need(current_dirs==self.initial_dirs,'DIRECTORY_BASELINE_DRIFT')
        targets=sorted(set(self.used)|{p for p,r in self.expected.items() if r['mandatory']})
        for path in targets:self.check_path(path)
        negatives=self._negative_check();self.budget()
        return dict(status='VERIFIED',manifest_sha256=self.H,run_id=self.U,t0=self.t0,phase='after' if after else 'before',R_manifest_sha256=RH,E_manifest_sha256=EH,runtime_manifest_sha256=RT,runtime_artifacts_count=5939,external_headers_count=362,files_verified=len(targets),fileset_sizes={p:len(x) for p,x in self.file_sets.items()},inputs={p:self.baseline[p] for p in targets},directories=current_dirs,negative_path_assertions=negatives,directory_scope='Current baseline of this new verification, not retrospective directory authority',not_proven=['atomic snapshot','hostile transient input modification','physical durability'])
    def _persist(self,name,report):
        self.budget();raw=json.dumps(report,separators=(',',':'),allow_nan=False).encode();need(len(raw)<=16777216,'CUSTODY_REPORT_QUOTA');self.persist(name,report);self.budget()
    def before(self):
        need(self.phase=='NEW','BEFORE_ONCE');self.phase='BEFORE';self.phase_deadline=min(self.deadline,self.t0+60)
        try:
            self._bootstrap();self.before_report=self._complete();self._persist('custody-before.json',self.before_report);self.phase='READY'
            if self.before_gate is not None:self.before_gate()
            self.budget();self.phase_deadline=self.deadline
            return self.before_report
        except BaseException:
            self.failure=self.failure or 'CUSTODY_BEFORE_FAILED';self.phase='REJECTED'
            report=dict(self.before_report) if self.before_report is not None else dict(manifest_sha256=self.H,run_id=self.U,verified_inputs=len(self.baseline))
            report.update(status='UNVERIFIED',error_code=self.failure)
            try:self._persist('custody-before.json',report)
            except BaseException:pass
            raise
    def revalidate_roles(self):
        need(self.phase=='READY' and self.revalidate_callback is not None,'CONCURRENCY_REVALIDATION_STATE');self.budget();self.revalidate_callback();self.budget()
    def record_concurrency(self,report):
        need(self.before_report is not None and self.phase=='READY','CONCURRENCY_PHASE');self.before_report['concurrency']=report;self._persist('custody-before.json',self.before_report)
    def after(self):
        need(self.phase in ('READY','REJECTED'),'AFTER_PHASE');self.phase_deadline=self.deadline
        try:
            report=self._complete(after=True)
            if self.failure is not None:report['status']='UNVERIFIED';report['error_code']=self.failure
            self.after_report=report;self._persist('custody-after.json',report);self.phase='CLOSED'
            need(report['status']=='VERIFIED','PREVIOUS_CUSTODY_FAILURE');return report
        except BaseException:
            self.failure=self.failure or 'CUSTODY_AFTER_FAILED';self.phase='REJECTED'
            report=dict(status='UNVERIFIED',error_code=self.failure,manifest_sha256=self.H,run_id=self.U,verified_inputs=len(self.baseline));self.after_report=report
            try:self._persist('custody-after.json',report)
            except BaseException:pass
            raise

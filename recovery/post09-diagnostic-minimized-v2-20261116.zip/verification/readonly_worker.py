"""V21 readonly worker. Static materialization, no execution approval."""
import os,sys,time,json,hashlib,stat,re,math,struct,select,signal,subprocess,ctypes
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
EXPECTED=Path('/RELOCATE/verification')
SOURCE=Path('/RELOCATE/preparation')
EVIDENCE=Path('/RELOCATE/reference-1')
R_SHA='413fa35254344f55b087364e6e9bbb38ec70010b7c2cc7706409238711dcee4f'
E_SHA='30def72e2a21e3d12269f472114a12557f8edcef69c4bc96ceb576396e750336'
PYTHON='/RELOCATE/python3'
FILES={'custody-before.json','custody-after.json','comparability-readonly.json','tools.json','worker.stdout','worker.stderr','supervisor.json','output-manifest.json'}
LIMIT=16777216

def need(ok,code):
    if not ok:raise ValueError(code)
def unique(pairs):
    out={}
    for k,v in pairs:need(k not in out,'DUPLICATE');out[k]=v
    return out
def parse(raw):return json.loads(raw,object_pairs_hook=unique,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('NONFINITE')))
def plain(path):
    for p in [path,*path.parents]:need(not p.is_symlink(),'SYMLINK')
    need(stat.S_ISREG(path.lstat().st_mode),'REGULAR');return path
def digest(path):
    h=hashlib.sha256()
    with plain(path).open('rb') as f:
        for part in iter(lambda:f.read(1048576),b''):h.update(part)
    return h.hexdigest()
def authenticate(approved,deadline):
    need(ROOT==EXPECTED and re.fullmatch('[0-9a-f]{64}',approved),'ROOT_OR_SHA')
    need(digest(ROOT/'evidence.sha256.json')==approved,'MANIFEST_HASH')
    rows=parse(plain(ROOT/'evidence.sha256.json').read_bytes());need(type(rows) is list,'MANIFEST_SCHEMA');seen=set()
    for row in rows:
        need(time.monotonic()<deadline,'BOOTSTRAP_CAP')
        need(type(row) is dict and set(row)=={'path','bytes','sha256'},'MANIFEST_RECORD');name=row['path']
        need(type(name) is str and name and not name.startswith('/') and '\\' not in name and '\x00' not in name and all(x not in ('','.','..') for x in name.split('/')) and name not in seen and name.split('/')[0]!='run','MANIFEST_PATH')
        need(type(row['bytes']) is int and row['bytes']>=0 and type(row['sha256']) is str and re.fullmatch('[0-9a-f]{64}',row['sha256']),'MANIFEST_TYPES')
        seen.add(name);p=plain(ROOT/name);need(p.stat().st_size==row['bytes'] and digest(p)==row['sha256'],'INPUT_HASH')
    need({'readonly_supervisor.py','readonly_worker.py','references-authority.json','references/source-policy.json','readonly-policy.json','readonly_concurrency.py'}<=seen,'MISSING_MODULE')
    actual=set()
    for base,dirs,names in os.walk(ROOT,followlinks=False):
        if Path(base)==ROOT and 'run' in dirs:
            need(not (ROOT/'run').is_symlink() and stat.S_ISDIR((ROOT/'run').lstat().st_mode),'OUTPUT_ROOT_TYPE');dirs.remove('run')
        for name in dirs:need(not (Path(base)/name).is_symlink(),'DIRECTORY_SYMLINK')
        for name in names:
            relative=str((Path(base)/name).relative_to(ROOT))
            if relative!='evidence.sha256.json':actual.add(relative)
    need(actual==seen,'INPUT_FILE_SET')
    refs=parse((ROOT/'references-authority.json').read_bytes())
    need(refs['source_root']==str(SOURCE) and refs['result_root']==str(EVIDENCE),'REFERENCE_ROOTS')
    need(refs['references'][str(SOURCE/'evidence.sha256.json')]['sha256']==R_SHA and refs['references'][str(EVIDENCE/'evidence.sha256.json')]['sha256']==E_SHA,'REFERENCE_MANIFESTS')
    for name,record in refs['references'].items():
        need(time.monotonic()<deadline,'BOOTSTRAP_CAP');p=plain(Path(name))
        need(p.stat().st_size==record['bytes'] and digest(p)==record['sha256'] and digest(ROOT/record['copy'])==record['sha256'],'REFERENCE_DRIFT')
    policy=parse((ROOT/'readonly-policy.json').read_bytes());need(policy['root']==str(ROOT),'POLICY_ROOT');tool=policy['tools']['python3'];real=Path(tool['path']).resolve(strict=True)
    need(tool['path']==PYTHON and real==Path(sys.executable).resolve(strict=True) and real==Path('/proc/self/exe').resolve(strict=True) and digest(real)==tool['sha256'],'INTERPRETER')
    return rows


def runtime_main():
    import argparse
    a=argparse.ArgumentParser();a.add_argument('--manifest-sha256',required=True);a.add_argument('--origin-monotonic',required=True,type=float);a.add_argument('--run-id',required=True);a.add_argument('--deadline',required=True,type=float);a.add_argument('--ready-fd',required=True,type=int);a.add_argument('--final-fd',required=True,type=int);args=a.parse_args()
    H=args.manifest_sha256;T=args.origin_monotonic;U=args.run_id;D=args.deadline;RF=args.ready_fd;FF=args.final_fd
    need(math.isfinite(T) and math.isfinite(D) and D==T+180 and 0<=time.monotonic()-T<180 and re.fullmatch('[0-9a-f]{32}',U),'ORIGIN')
    need(RF!=FF and RF>2 and FF>2,'FD_ALIAS')
    for fd in (RF,FF):
        need(stat.S_ISFIFO(os.fstat(fd).st_mode) and os.fpathconf(fd,'PC_PIPE_BUF')>=4096,'PIPE_REQUIRED');os.set_blocking(fd,False);os.set_inheritable(fd,False)
    frame=dict(schema_version=1,type='READONLY_WORKER_RESULT',manifest_sha256=H,source_manifest_sha256=R_SHA,result_manifest_sha256=E_SHA,runtime_manifest_sha256='12f2b901664651a49ab79061c9c1855e1976f2fd50608dc8fb15dd15f4503dba',run_id=U,t0=T,deadline=D,comparison_status='BLOCKED',custody_status='UNVERIFIED',identified_work_closure='UNVERIFIED',tools_reaped=True,tools_streams_eof=True,remaining_identities_count=0,capture_truncated=False,first_error_code=None,outputs=[],worker_self_reaped=False)
    first=None;known={};tool_logs=[];aggregate_captured_bytes=0;tool_log_bytes=0;tool_failed=False;overflow=False;all_reaped=True;all_eof=True;run_pin=None;written={};written_locations={};custody=None;phase='bootstrap';cancelled=[]
    def fail(code):
        nonlocal first
        if first is None:first=code
        raise RuntimeError(code)
    try:
        authenticate(H,D)
        # These modules were verified against externally approved P manifest.
        from readonly_supervisor import identity,public,same,inventory,signal_verified,reap
        from readonly_custody import Custody
        from readonly_concurrency import capture_role,scan,revalidate
        from readonly_comparability import verify
        policy=parse(plain(ROOT/'readonly-policy.json').read_bytes())
        parent=identity(os.getppid());need(parent is not None and parent['namespace'] is not None,'PARENT_IDENTITY');parentfd=os.pidfd_open(parent['pid'])
        need(ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)==0,'SUBREAPER')
        for signum in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):signal.signal(signum,lambda n,f:cancelled.append(n))
        def checkpoint():
            if time.monotonic()>=D:fail('WORK_DEADLINE')
            if cancelled:fail('PROTOCOL_FAILED')
            if not same(parent) or os.getppid()!=parent['pid'] or select.select([parentfd],[],[],0)[0]:fail('PARENT_LOST')
            if run_pin is not None:
                st=(ROOT/'run').lstat()
                if (ROOT/'run').is_symlink() or not stat.S_ISDIR(st.st_mode) or dict(canonical=str((ROOT/'run').resolve(strict=True)),device=st.st_dev,inode=st.st_ino,type='directory')!=run_pin:fail('PROTOCOL_FAILED')
        raw=bytearray();eof=False
        while time.monotonic()<D:
            checkpoint();rr,_,_=select.select([RF],[],[],min(.02,max(0,D-time.monotonic())))
            if rr:
                try:part=os.read(RF,4097-len(raw))
                except (BlockingIOError,InterruptedError):continue
                if not part:eof=True;break
                raw.extend(part);need(len(raw)<=4096,'READY_QUOTA')
                if len(raw)>=4:need(2<=int.from_bytes(raw[:4],'little')<=4092,'READY_LENGTH')
        need(eof and len(raw)>=4 and len(raw)==4+int.from_bytes(raw[:4],'little'),'READY_FRAME');ready=parse(bytes(raw[4:]));os.close(RF)
        keys={'schema_version','type','manifest_sha256','run_id','t0','deadline','parent','run','concurrency_roles'}
        need(type(ready) is dict and set(ready)==keys and type(ready['schema_version']) is int and ready['schema_version']==1 and ready['type']=='READONLY_PARENT_READY' and ready['manifest_sha256']==H and ready['run_id']==U and type(ready['t0']) is float and ready['t0']==T and type(ready['deadline']) is float and ready['deadline']==D and ready['parent']==public(parent),'READY_CORRELATION')
        run_pin=ready['run'];need(type(run_pin) is dict and set(run_pin)=={'canonical','device','inode','type'} and run_pin['canonical']==str(ROOT/'run') and type(run_pin['device']) is int and type(run_pin['inode']) is int and run_pin['type']=='directory','RUN_PIN');checkpoint()
        registry=ready['concurrency_roles'];need(type(registry) is dict and set(registry)=={'namespaces','roles'} and type(registry['roles']) is list and len(registry['roles'])==1 and registry['roles'][0].get('role')=='supervisor','REGISTRY')
        registry=dict(namespaces=dict(registry['namespaces']),roles=[dict(r) for r in registry['roles']])
        workerargv=[policy['tools']['python3']['path'],'-B',str(ROOT/'readonly_worker.py'),'--manifest-sha256',H,'--origin-monotonic',repr(T),'--run-id',U,'--deadline',repr(D),'--ready-fd',str(RF),'--final-fd',str(FF)]
        registry['roles'].append(capture_role(policy,H,'worker',os.getpid(),workerargv))
        def persist(name,report):
            checkpoint();need(name in {'custody-before.json','custody-after.json','comparability-readonly.json','tools.json'},'OUTPUT_WHITELIST')
            dest=ROOT/'run'/name;temp=Path(str(dest)+'.tmp');data=json.dumps(report,separators=(',',':'),allow_nan=False).encode();need(len(data)<=LIMIT,'REPORT_QUOTA')
            if dest.exists() or dest.is_symlink():
                st=dest.lstat();need(name in written and (st.st_dev,st.st_ino,stat.S_IFMT(st.st_mode))==written_locations[name] and digest(dest)==written[name]['sha256'] and st.st_size==written[name]['bytes'],'OUTPUT_CHANGED')
            fd=os.open(temp,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
            try:
                offset=0
                while offset<len(data):
                    checkpoint();n=os.write(fd,data[offset:]);need(n>0,'OUTPUT_WRITE');offset+=n
                os.fsync(fd)
            finally:os.close(fd)
            checkpoint();os.replace(temp,dest);checkpoint();need(digest(dest)==hashlib.sha256(data).hexdigest(),'OUTPUT_VERIFY')
            st=dest.lstat();written_locations[name]=(st.st_dev,st.st_ino,stat.S_IFMT(st.st_mode));written[name]=dict(name=name,bytes=len(data),sha256=hashlib.sha256(data).hexdigest());checkpoint()
        custody=Custody(H,T,U,D,persist,checkpoint)
        concurrency_context=None
        def before_gate():
            nonlocal concurrency_context
            context=scan(policy,H,registry,custody.record_concurrency,'before-gate',T,U)
            revalidate(context);checkpoint();concurrency_context=context
        def revalidate_roles():
            need(concurrency_context is not None,'CONCURRENCY_CONTEXT_MISSING');revalidate(concurrency_context);checkpoint()
        custody.before_gate=before_gate;custody.revalidate_callback=revalidate_roles
        def run_tool(argv,deadline):
            nonlocal tool_failed,overflow,all_reaped,all_eof,aggregate_captured_bytes,tool_log_bytes
            checkpoint();need(not tool_failed,'PRIOR_TOOL_FAILURE');need(type(argv) is list and all(type(x) is str for x in argv) and type(deadline) in (float,int) and math.isfinite(deadline) and time.monotonic()<deadline<=min(time.monotonic()+15,D),'TOOL_DEADLINE')
            readelf=policy['tools']['readelf']['path'];ldconfig=policy['tools']['ldconfig']['path']
            if argv[:1]==[readelf]:
                need(argv[1:-1] in (['-h'],['-d'],['-l'],['--dyn-syms','--wide'],['--dyn-syms','--wide','--demangle']) and len(argv)>=3 and Path(argv[-1]).is_absolute(),'READELF_ARGV');objects=[argv[-1]]
            else:need(argv==[ldconfig,'-p'],'TOOL_ARGV');objects=[]
            for path in [argv[0],*objects]:custody.check_path(path)
            checkpoint();need(time.monotonic()<deadline,'TOOL_PRE_SPAWN_DEADLINE')
            child=None;row=None;pidfd=None;streams={};buffers={'stdout':bytearray(),'stderr':bytearray()};eofs={'stdout':False,'stderr':False};rc=None;start=time.monotonic();error=None;toolrow=dict(ordinal=len(tool_logs)+1,argv=argv,start=start,deadline=deadline,rc=None,reaped=False,streams_eof=False,remaining_count=None,truncated=False,error_code=None)
            try:
                child=subprocess.Popen(argv,cwd=ROOT,env=dict(policy['auxiliary_environment']),stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,close_fds=True,start_new_session=True)
                # Store identity after Popen even if a signal flag arrived inside.
                row=identity(child.pid);need(row is not None and row['namespace'] is not None,'TOOL_IDENTITY');known[(row['pid'],row['start'])]=row;pidfd=os.pidfd_open(child.pid);toolrow['identity']=public(row)
                streams={child.stdout.fileno():'stdout',child.stderr.fileno():'stderr'}
                for fd in streams:os.set_blocking(fd,False)
                checkpoint();need(time.monotonic()<deadline,'TOOL_POST_SPAWN_DEADLINE')
                while True:
                    checkpoint();need(time.monotonic()<deadline,'TOOL_CAP');rc=child.poll();rows=inventory(known);reap(rows,child)
                    if rc is not None and not streams and not inventory(known):break
                    rr,_,_=select.select(list(streams),[],[],min(.02,max(0,deadline-time.monotonic())))
                    for fd in rr:
                        name=streams[fd]
                        try:data=os.read(fd,8192)
                        except (BlockingIOError,InterruptedError):continue
                        if not data:eofs[name]=True;streams.pop(fd);continue
                        aggregate_captured_bytes+=len(data)
                        if len(buffers[name])+len(data)>LIMIT or aggregate_captured_bytes>LIMIT:overflow=True;toolrow['truncated']=True;fail('TOOL_FAILED')
                        buffers[name].extend(data)
                checkpoint();need(time.monotonic()<deadline,'TOOL_DRAIN_CAP')
                for path in [argv[0],*objects]:custody.check_path(path)
                checkpoint();need(time.monotonic()<deadline,'TOOL_POST_CUSTODY_CAP')
                result=dict(returncode=rc,stdout=bytes(buffers['stdout']).decode('utf-8'),stderr=bytes(buffers['stderr']).decode('utf-8'))
                toolrow.update(rc=rc,reaped=True,streams_eof=True,remaining_count=0)
                if rc!=0:tool_failed=True
                return result
            except BaseException as exc:
                tool_failed=True;error=type(exc).__name__;toolrow['error_code']='TOOL_FAILED'
                if first is None:
                    # Callback failure remains the first failure, never cleared by
                    # later custody or cleanup success.
                    try:fail('WORK_DEADLINE' if time.monotonic()>=D else 'TOOL_FAILED')
                    except RuntimeError:pass
                stop=time.monotonic();kill_at=min(stop+1,T+240)
                while time.monotonic()<T+240:
                    rows=inventory(known)
                    for owned in rows:signal_verified(owned,signal.SIGTERM if time.monotonic()<kill_at else signal.SIGKILL)
                    if child is not None:rc=child.poll();reap(rows,child)
                    for fd in list(streams):
                        try:
                            part=os.read(fd,8192)
                            if not part:eofs[streams[fd]]=True;streams.pop(fd)
                        except BlockingIOError:pass
                        except OSError:streams.pop(fd)
                    if (child is None or child.poll() is not None) and not streams and not inventory(known):break
                    time.sleep(min(.02,max(0,T+240-time.monotonic())))
                toolrow.update(rc=rc,reaped=child is None or child.poll() is not None,streams_eof=all(eofs.values()) if child else True,remaining_count=len(inventory(known)))
                all_reaped=all_reaped and toolrow['reaped'];all_eof=all_eof and toolrow['streams_eof']
                raise
            finally:
                if pidfd is not None:os.close(pidfd)
                toolrow.update(end=time.monotonic(),stdout_bytes=len(buffers['stdout']),stdout_sha256=hashlib.sha256(buffers['stdout']).hexdigest(),stderr_bytes=len(buffers['stderr']),stderr_sha256=hashlib.sha256(buffers['stderr']).hexdigest())
                row_bytes=len(json.dumps(toolrow,separators=(',',':'),allow_nan=False).encode())
                if tool_log_bytes+row_bytes>LIMIT:overflow=True;tool_failed=True;fail('TOOL_FAILED')
                tool_log_bytes+=row_bytes;tool_logs.append(toolrow)
        phase='verification'
        report=verify(H,T,U,custody,persist,run_tool)
        frame['comparison_status']='PASS' if report.get('status')=='PASS' else 'BLOCKED'
        if frame['comparison_status']=='BLOCKED' and first is None:first='COMPARISON_BLOCKED'
        phase='persistence';checkpoint()
        persist('tools.json',dict(schema_version=1,manifest_sha256=H,run_id=U,t0=T,tools=tool_logs,aggregate_captured_bytes=aggregate_captured_bytes,tool_log_metadata_bytes=tool_log_bytes,first_error_code=first,all_reaped=all_reaped,streams_eof=all_eof,scope='readelf and ldconfig only; no product execution'))
        after=parse(plain(ROOT/'run/custody-after.json').read_bytes())
        frame['custody_status']='VERIFIED' if after.get('status')=='VERIFIED' else 'UNVERIFIED'
        if frame['custody_status']!='VERIFIED' and first is None:first='CUSTODY_FAILED'
        # No hidden report completion in the close reserve.
        checkpoint();frame['outputs']=[written[n] for n in sorted(written)]
    except BaseException:
        if first is None:first='BOOTSTRAP_FAILED' if phase=='bootstrap' else ('PERSISTENCE_FAILED' if phase=='persistence' else 'CUSTODY_FAILED')
        frame['comparison_status']='BLOCKED';frame['custody_status']='UNVERIFIED'
        if 'persist' in locals() and time.monotonic()<D:
            try:persist('tools.json',dict(schema_version=1,manifest_sha256=H,run_id=U,t0=T,tools=tool_logs,aggregate_captured_bytes=aggregate_captured_bytes,tool_log_metadata_bytes=tool_log_bytes,first_error_code=first,all_reaped=all_reaped,streams_eof=all_eof,scope='failed readonly verification'))
            except BaseException:pass
        frame['outputs']=[written[n] for n in sorted(written)]
    # Any remaining known/adopted work is cleanup, not extra verification time.
    remaining=[]
    if 'inventory' in locals():
        remaining=inventory(known)
        if remaining:
            stop=time.monotonic()
            while remaining and time.monotonic()<T+240:
                for row in remaining:signal_verified(row,signal.SIGTERM if time.monotonic()<stop+1 else signal.SIGKILL)
                reap(remaining,None);remaining=inventory(known)
                if remaining:time.sleep(min(.02,max(0,T+240-time.monotonic())))
    frame.update(tools_reaped=all_reaped,tools_streams_eof=all_eof,remaining_identities_count=len(remaining),capture_truncated=overflow,identified_work_closure='OBSERVED' if all_reaped and all_eof and not remaining and not overflow else 'UNVERIFIED',first_error_code=first)
    payload=json.dumps(frame,separators=(',',':'),allow_nan=False).encode();need(len(payload)<=4092,'FINAL_QUOTA');wire=len(payload).to_bytes(4,'little')+payload;offset=0;end=min(time.monotonic()+2,T+240)
    while offset<len(wire) and time.monotonic()<end:
        _,ww,_=select.select([],[FF],[],min(.02,max(0,end-time.monotonic())))
        if ww:
            try:offset+=os.write(FF,wire[offset:])
            except (BlockingIOError,InterruptedError):pass
            except OSError:break
    os.close(FF)
    return 0 if offset==len(wire) and frame['comparison_status']=='PASS' and frame['custody_status']=='VERIFIED' and frame['identified_work_closure']=='OBSERVED' and first is None else 2
if __name__=='__main__':sys.exit(runtime_main())

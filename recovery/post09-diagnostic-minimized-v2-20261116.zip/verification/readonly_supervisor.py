"""V21 two-role readonly supervisor. Static materialization, not execution approval."""
import os,sys,time,json,hashlib,stat,re,math,struct,select,signal,subprocess,ctypes
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
EXPECTED=Path('/RELOCATE/verification')
SOURCE=Path('/RELOCATE/preparation')
EVIDENCE=Path('/RELOCATE/reference-1')
R_SHA='413fa35254344f55b087364e6e9bbb38ec70010b7c2cc7706409238711dcee4f'
E_SHA='30def72e2a21e3d12269f472114a12557f8edcef69c4bc96ceb576396e750336'
PYTHON='/RELOCATE/python3'
FILES={'custody-before.json','custody-after.json','comparability-readonly.json','tools.json','worker.stdout','worker.stderr','supervisor.json','output-manifest.json'}
LIMIT=16777216

def need(ok,code):
    if not ok:raise ValueError(code)
def unique(pairs):
    out={}
    for k,v in pairs:need(k not in out,'DUPLICATE');out[k]=v
    return out
def parse(raw):return json.loads(raw,object_pairs_hook=unique,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('NONFINITE')))
def plain(path):
    for p in [path,*path.parents]:need(not p.is_symlink(),'SYMLINK')
    need(stat.S_ISREG(path.lstat().st_mode),'REGULAR');return path
def digest(path):
    h=hashlib.sha256()
    with plain(path).open('rb') as f:
        for part in iter(lambda:f.read(1048576),b''):h.update(part)
    return h.hexdigest()
def authenticate(approved,deadline):
    need(ROOT==EXPECTED and re.fullmatch('[0-9a-f]{64}',approved),'ROOT_OR_SHA')
    need(digest(ROOT/'evidence.sha256.json')==approved,'MANIFEST_HASH')
    rows=parse(plain(ROOT/'evidence.sha256.json').read_bytes());need(type(rows) is list,'MANIFEST_SCHEMA');seen=set()
    for row in rows:
        need(time.monotonic()<deadline,'BOOTSTRAP_CAP')
        need(type(row) is dict and set(row)=={'path','bytes','sha256'},'MANIFEST_RECORD');name=row['path']
        need(type(name) is str and name and not name.startswith('/') and '\\' not in name and '\x00' not in name and all(x not in ('','.','..') for x in name.split('/')) and name not in seen and name.split('/')[0]!='run','MANIFEST_PATH')
        need(type(row['bytes']) is int and row['bytes']>=0 and type(row['sha256']) is str and re.fullmatch('[0-9a-f]{64}',row['sha256']),'MANIFEST_TYPES')
        seen.add(name);p=plain(ROOT/name);need(p.stat().st_size==row['bytes'] and digest(p)==row['sha256'],'INPUT_HASH')
    need({'readonly_supervisor.py','readonly_worker.py','references-authority.json','references/source-policy.json','readonly-policy.json','readonly_concurrency.py'}<=seen,'MISSING_MODULE')
    actual=set()
    for base,dirs,names in os.walk(ROOT,followlinks=False):
        for name in dirs:need(not (Path(base)/name).is_symlink(),'DIRECTORY_SYMLINK')
        for name in names:
            relative=str((Path(base)/name).relative_to(ROOT))
            if relative!='evidence.sha256.json':actual.add(relative)
    need(actual==seen,'INPUT_FILE_SET')
    refs=parse((ROOT/'references-authority.json').read_bytes())
    need(refs['source_root']==str(SOURCE) and refs['result_root']==str(EVIDENCE),'REFERENCE_ROOTS')
    need(refs['references'][str(SOURCE/'evidence.sha256.json')]['sha256']==R_SHA and refs['references'][str(EVIDENCE/'evidence.sha256.json')]['sha256']==E_SHA,'REFERENCE_MANIFESTS')
    for name,record in refs['references'].items():
        need(time.monotonic()<deadline,'BOOTSTRAP_CAP');p=plain(Path(name))
        need(p.stat().st_size==record['bytes'] and digest(p)==record['sha256'] and digest(ROOT/record['copy'])==record['sha256'],'REFERENCE_DRIFT')
    policy=parse((ROOT/'readonly-policy.json').read_bytes());need(policy['root']==str(ROOT),'POLICY_ROOT');tool=policy['tools']['python3'];real=Path(tool['path']).resolve(strict=True)
    need(tool['path']==PYTHON and real==Path(sys.executable).resolve(strict=True) and real==Path('/proc/self/exe').resolve(strict=True) and digest(real)==tool['sha256'],'INTERPRETER')
    return rows

def identity(pid):
    try:
        text=Path('/proc',str(pid),'stat').read_text();row=text[text.rfind(')')+2:].split()
    except (FileNotFoundError,ProcessLookupError):return None
    try:ns=os.readlink('/proc/'+str(pid)+'/ns/pid')
    except (FileNotFoundError,ProcessLookupError):ns=None
    return dict(pid=pid,start=row[19],namespace=ns,ppid=int(row[1]),state=row[0])
def public(row):return {k:row[k] for k in ('pid','start','namespace')} if row else None
def same(row):
    current=identity(row['pid']);return current is not None and current['start']==row['start'] and (current['namespace']==row['namespace'] or current['namespace'] is None and current['state'] in ('Z','X','x'))
def inventory(known):
    rows={}
    for p in Path('/proc').iterdir():
        if p.name.isdigit():
            row=identity(int(p.name))
            if row:rows[row['pid']]=row
    children={os.getpid()}|{r['pid'] for r in known.values() if same(r)};again=True
    while again:
        again=False
        for pid,row in rows.items():
            if row['ppid'] in children and pid not in children:children.add(pid);again=True
    for pid in children-{os.getpid()}:
        row=rows.get(pid)
        if row:
            key=(pid,row['start'])
            if key not in known or row['namespace'] is not None:known[key]=row
    return [r for r in known.values() if same(r)]
def signal_verified(row,sig):
    if not same(row):return 'IDENTITY_GONE'
    try:fd=os.pidfd_open(row['pid'])
    except ProcessLookupError:return 'IDENTITY_GONE'
    try:
        if not same(row):return 'IDENTITY_GONE'
        signal.pidfd_send_signal(fd,sig,None,0);return 'SENT'
    except ProcessLookupError:return 'IDENTITY_GONE'
    except OSError:return 'ERROR'
    finally:os.close(fd)
def reap(rows,worker):
    for row in rows:
        if worker and row['pid']==worker.pid:continue
        now=identity(row['pid'])
        if now and same(row) and now['ppid']==os.getpid():
            try:os.waitpid(row['pid'],os.WNOHANG)
            except ChildProcessError:pass

def pipe(fd):
    need(stat.S_ISFIFO(os.fstat(fd).st_mode) and os.fpathconf(fd,'PC_PIPE_BUF')>=4096,'PIPE_REQUIRED')
    os.set_blocking(fd,False);os.set_inheritable(fd,False)
def send(fd,value,deadline,ascii_frame=False):
    raw=json.dumps(value,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()
    need(len(raw)<=(4086 if ascii_frame else 4092),'FRAME_QUOTA')
    wire=('%08x:'%len(raw)).encode()+raw+b'\n' if ascii_frame else struct.pack('<I',len(raw))+raw
    offset=0;end=min(time.monotonic()+2,deadline)
    while offset<len(wire) and time.monotonic()<end:
        try:
            n=os.write(fd,wire[offset:]);need(n>0,'WRITE_ZERO');offset+=n
        except (BlockingIOError,InterruptedError):select.select([],[fd],[],min(.01,max(0,end-time.monotonic())))
        except OSError:return False
    return offset==len(wire)
def run_identity():
    p=ROOT/'run';need(str(p.resolve(strict=True))==str(p),'RUN_CANONICAL')
    for x in [p,*p.parents]:need(not x.is_symlink(),'RUN_SYMLINK')
    s=p.lstat();need(stat.S_ISDIR(s.st_mode),'RUN_TYPE')
    return dict(canonical=str(p),device=s.st_dev,inode=s.st_ino,type='directory')
def persist(name,value,deadline,pin,previous_sha=None):
    need(name in FILES and name.endswith('.json'),'OUTPUT_NAME');need(time.monotonic()<deadline and run_identity()==pin,'PERSISTENCE_CAP_OR_IDENTITY')
    raw=json.dumps(value,separators=(',',':'),allow_nan=False).encode();need(len(raw)<=LIMIT,'REPORT_QUOTA')
    out=ROOT/'run'/name;temp=Path(str(out)+'.tmp')
    try:out.lstat()
    except FileNotFoundError:pass
    else:need(name=='supervisor.json' and previous_sha is not None and digest(out)==previous_sha,'OUTPUT_EXISTS_OR_CHANGED')
    fd=os.open(temp,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    try:
        offset=0
        while offset<len(raw):
            need(time.monotonic()<deadline,'PERSISTENCE_CAP');n=os.write(fd,raw[offset:]);need(n>0,'PERSISTENCE_WRITE');offset+=n
        os.fsync(fd)
    finally:os.close(fd)
    need(time.monotonic()<deadline and run_identity()==pin and digest(temp)==hashlib.sha256(raw).hexdigest(),'PERSISTENCE_VERIFY')
    if previous_sha is not None:need(name=='supervisor.json' and digest(out)==previous_sha,'OUTPUT_CHANGED_BEFORE_REPLACE')
    os.rename(temp,out);need(time.monotonic()<deadline,'PERSISTENCE_CAP')
    return dict(path=name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

# Closed worker schema is supplied by the paired worker, not stdout text.
def validate_worker(raw,approved,runid,t0,deadline,rc):
    need(len(raw)>=4,'MISSING_WORKER_FRAME');size=struct.unpack('<I',raw[:4])[0]
    need(2<=size<=4092 and len(raw)==size+4,'FRAME_LENGTH_OR_EXTRA');v=parse(raw[4:])
    keys={'schema_version','type','manifest_sha256','source_manifest_sha256','result_manifest_sha256','runtime_manifest_sha256','run_id','t0','deadline','comparison_status','custody_status','identified_work_closure','tools_reaped','tools_streams_eof','remaining_identities_count','capture_truncated','first_error_code','outputs','worker_self_reaped'}
    need(type(v) is dict and set(v)==keys,'WORKER_KEYS')
    need(type(v['schema_version']) is int and v['schema_version']==1 and v['type']=='READONLY_WORKER_RESULT' and v['manifest_sha256']==approved and v['source_manifest_sha256']==R_SHA and v['result_manifest_sha256']==E_SHA and v['runtime_manifest_sha256']=='12f2b901664651a49ab79061c9c1855e1976f2fd50608dc8fb15dd15f4503dba' and v['run_id']==runid,'WORKER_CORRELATION')
    need(type(v['t0']) is float and v['t0']==t0 and type(v['deadline']) is float and v['deadline']==deadline,'WORKER_TIME')
    for k in ('tools_reaped','tools_streams_eof','capture_truncated','worker_self_reaped'):need(type(v[k]) is bool,'WORKER_BOOL')
    need(v['worker_self_reaped'] is False,'WORKER_SELF_REAP')
    need(type(v['remaining_identities_count']) is int and v['remaining_identities_count']>=0,'WORKER_COUNT')
    need(v['comparison_status'] in ('PASS','BLOCKED') and v['custody_status'] in ('VERIFIED','UNVERIFIED') and v['identified_work_closure'] in ('OBSERVED','UNVERIFIED'),'WORKER_STATUS')
    need(v['first_error_code'] in (None,'BOOTSTRAP_FAILED','CUSTODY_FAILED','COMPARISON_BLOCKED','TOOL_FAILED','PERSISTENCE_FAILED','PARENT_LOST','WORK_DEADLINE','PROTOCOL_FAILED'),'WORKER_ERROR')
    need(type(v['outputs']) is list,'WORKER_OUTPUTS');names=set()
    for row in v['outputs']:
        need(type(row) is dict and set(row)=={'name','bytes','sha256'} and row['name'] in {'custody-before.json','custody-after.json','comparability-readonly.json','tools.json'} and row['name'] not in names,'WORKER_OUTPUT_SCHEMA')
        need(type(row['bytes']) is int and 0<=row['bytes']<=LIMIT and type(row['sha256']) is str and re.fullmatch('[0-9a-f]{64}',row['sha256']),'WORKER_OUTPUT_TYPES');names.add(row['name'])
    if v['comparison_status']=='PASS':need(len(names)==4,'PASS_OUTPUTS_REQUIRED')
    if v['identified_work_closure']=='OBSERVED':need(v['tools_reaped'] and v['tools_streams_eof'] and v['remaining_identities_count']==0 and not v['capture_truncated'],'TOOLS_CLOSURE_CONFLICT')
    good=v['comparison_status']=='PASS' and v['custody_status']=='VERIFIED' and v['identified_work_closure']=='OBSERVED'
    need(type(rc) is int and rc==(0 if good else 2),'WORKER_RC_CONFLICT')
    if good:need(v['first_error_code'] is None,'WORKER_ERROR_CONFLICT')
    return v

def main():
    t0=time.monotonic();work=t0+180;absolute=t0+240
    need(len(sys.argv)==3 and sys.argv[1]=='--manifest-sha256','ARGV');approved=sys.argv[2]
    pipe(1);authenticate(approved,min(t0+60,work))
    policy=parse(plain(ROOT/'readonly-policy.json').read_bytes());need(policy['root']==str(ROOT),'POLICY_ROOT')
    # Only authenticated local imports occur below.
    from readonly_concurrency import capture_role,scan,revalidate,ns
    out=ROOT/'run'
    try:out.lstat()
    except FileNotFoundError:pass
    else:raise ValueError('OUTPUT_EXISTS')
    out.mkdir(mode=0o700);pin=run_identity()
    need(ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)==0,'SUBREAPER')
    signals=[]
    for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):signal.signal(sig,lambda n,f:signals.append(n))
    runid=os.urandom(16).hex();known={};worker=None;initial=None;workerfd=None;rc=None;state={};logs={};closed_logs=False
    first_error=None;stop_time=None;deadline_reached=False;identity_match=True;signal_counts={'term_sent':0,'kill_sent':0,'errors':0};concurrency=None;supervisor_hash=None
    def reject(code):
        nonlocal first_error,stop_time
        if first_error is None:first_error=code
        if stop_time is None:stop_time=time.monotonic()
    def checkpoint():
        need(time.monotonic()<work and not signals and run_identity()==pin,'WORK_CAP_SIGNAL_OR_RUN_DRIFT')
    def supervisor_save(value):
        nonlocal supervisor_hash
        supervisor_hash=persist('supervisor.json',value,work,pin,supervisor_hash)['sha256']
    try:
        parent_argv=[PYTHON,'-B',str(ROOT/'readonly_supervisor.py'),'--manifest-sha256',approved]
        role=capture_role(policy,approved,'supervisor',os.getpid(),parent_argv)
        registry={'namespaces':ns(os.getpid()),'roles':[role]}
        def persist_scan(report):
            nonlocal concurrency
            concurrency=report
            supervisor_save(dict(schema_version=1,stage='PRE_SPAWN',manifest_sha256=approved,run_id=runid,t0=t0,concurrency=report,identified_work_closure='UNVERIFIED',outer_return='NOT_SELF_OBSERVED',independent_outer_termination_guarantee=False))
        context=scan(policy,approved,registry,persist_scan,'supervisor',t0,runid)
        checkpoint();revalidate(context)
        ready_r,ready_w=os.pipe2(os.O_CLOEXEC|os.O_NONBLOCK);final_r,final_w=os.pipe2(os.O_CLOEXEC|os.O_NONBLOCK)
        for fd in (ready_r,ready_w,final_r,final_w):pipe(fd)
        # Worker includes both custody phases; its single prearmed window ends
        # at t0+180. The worker arms its auxiliary gate<=120 within this window.
        deadline=work
        ready=dict(schema_version=1,type='READONLY_PARENT_READY',manifest_sha256=approved,run_id=runid,t0=t0,deadline=deadline,parent=public(identity(os.getpid())),run=pin,concurrency_roles=registry)
        need(send(ready_w,ready,min(time.monotonic()+2,deadline)),'READY_SEND');os.close(ready_w)
        for name in ('stdout','stderr'):logs[name]=os.open(out/('worker.'+name),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        argv=[PYTHON,'-B',str(ROOT/'readonly_worker.py'),'--manifest-sha256',approved,'--origin-monotonic',repr(t0),'--run-id',runid,'--deadline',repr(deadline),'--ready-fd',str(ready_r),'--final-fd',str(final_w)]
        checkpoint();revalidate(context);need(time.monotonic()<deadline,'PRE_SPAWN_CAP')
        worker=subprocess.Popen(argv,cwd=ROOT,env={'PATH':'/usr/bin:/bin','LANG':'C','LC_ALL':'C','TZ':'UTC','PYTHONDONTWRITEBYTECODE':'1'},stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,pass_fds=(ready_r,final_w),close_fds=True,start_new_session=True)
        initial=identity(worker.pid)
        if initial:known[(initial['pid'],initial['start'])]=initial
        os.close(ready_r);os.close(final_w)
        workerfd=os.pidfd_open(worker.pid)
        for name,fd,quota in [('final',final_r,4096),('stdout',worker.stdout.fileno(),LIMIT),('stderr',worker.stderr.fileno(),LIMIT)]:
            pipe(fd);state[name]=dict(fd=fd,quota=quota,total=0,retained=0,hash=hashlib.sha256(),data=bytearray(),eof=False,truncated=False)
        if initial is None or initial['namespace'] is None:reject('WORKER_IDENTITY_UNVERIFIED')
        if time.monotonic()>=deadline:deadline_reached=True;reject('WORK_DEADLINE')
        while time.monotonic()<absolute:
            now=time.monotonic();rows=inventory(known);current=identity(worker.pid)
            if current and initial and (current['start']!=initial['start'] or current['namespace'] is not None and current['namespace']!=initial['namespace']):identity_match=False;reject('WORKER_IDENTITY_CHANGED')
            rc=worker.poll();reap(rows,worker)
            if rc is not None and rc!=0 and stop_time is None:stop_time=now
            pending=rc is None or bool(inventory(known)) or not all(v['eof'] for v in state.values())
            if pending and now>=deadline:deadline_reached=True;reject('WORK_DEADLINE')
            if signals:reject('CANCELLED')
            if run_identity()!=pin:reject('RUN_IDENTITY_CHANGED')
            if stop_time is not None:
                sig=signal.SIGKILL if now>=min(stop_time+1,absolute) else signal.SIGTERM
                for row in rows:
                    result=signal_verified(row,sig)
                    if result=='SENT':signal_counts['kill_sent' if sig==signal.SIGKILL else 'term_sent']=min(1000000,signal_counts['kill_sent' if sig==signal.SIGKILL else 'term_sent']+1)
                    elif result=='ERROR':signal_counts['errors']=min(1000000,signal_counts['errors']+1)
            byfd={v['fd']:(name,v) for name,v in state.items() if not v['eof']}
            readyfds,_,_=select.select(list(byfd),[],[],min(.01,max(0,absolute-time.monotonic())))
            for fd in readyfds:
                name,v=byfd[fd]
                for _ in range(8):
                    if time.monotonic()>=absolute:break
                    try:chunk=os.read(fd,8192)
                    except (BlockingIOError,InterruptedError):break
                    if not chunk:v['eof']=True;break
                    v['total']+=len(chunk);v['hash'].update(chunk)
                    room=max(0,v['quota']-v['retained']);keep=chunk[:room];v['retained']+=len(keep)
                    if len(chunk)>room:v['truncated']=True;reject('CAPTURE_OVERFLOW')
                    if name=='final':v['data'].extend(keep)
                    elif keep:
                        # All mandatory output persistence is work-budget bounded.
                        if time.monotonic()>=work:v['truncated']=True;deadline_reached=True;reject('WORK_DEADLINE')
                        else:
                            offset=0
                            while offset<len(keep):
                                if time.monotonic()>=work:v['truncated']=True;deadline_reached=True;reject('WORK_DEADLINE');break
                                n=os.write(logs[name],keep[offset:]);need(n>0,'LOG_WRITE');offset+=n
            if rc is not None and not inventory(known) and all(v['eof'] for v in state.values()):break
    except BaseException:
        reject('SUPERVISOR_OPERATION_FAILED')
    # Failure cleanup has no new child and continues draining captured pipes.
    if worker is not None and (worker.poll() is None or inventory(known) or any(not v['eof'] for v in state.values())):
        if stop_time is None:reject('CLEANUP_REQUIRED')
        while time.monotonic()<absolute:
            rows=inventory(known);sig=signal.SIGKILL if time.monotonic()>=min(stop_time+1,absolute) else signal.SIGTERM
            for row in rows:
                result=signal_verified(row,sig)
                if result=='SENT':
                    key='kill_sent' if sig==signal.SIGKILL else 'term_sent';signal_counts[key]=min(1000000,signal_counts[key]+1)
                elif result=='ERROR':signal_counts['errors']=min(1000000,signal_counts['errors']+1)
            rc=worker.poll();reap(rows,worker)
            for name,v in state.items():
                if v['eof']:continue
                try:chunk=os.read(v['fd'],8192)
                except (BlockingIOError,InterruptedError):continue
                except OSError:reject('CAPTURE_READ_FAILED');v['eof']=True;continue
                if not chunk:v['eof']=True
                else:
                    v['total']+=len(chunk);v['hash'].update(chunk)
                    room=max(0,v['quota']-v['retained']);keep=chunk[:room];v['retained']+=len(keep)
                    if len(chunk)>room:v['truncated']=True;reject('CAPTURE_OVERFLOW')
                    if name=='final':v['data'].extend(keep)
                    # Cleanup discard never claims a complete retained stream.
                    elif keep:v['truncated']=True;reject('CLEANUP_CAPTURE_DISCARDED')
            if rc is not None and not inventory(known) and all(v['eof'] for v in state.values()):break
            time.sleep(min(.01,max(0,absolute-time.monotonic())))
    closed_logs=True
    for fd in logs.values():
        try:
            if time.monotonic()<work:os.fsync(fd)
            os.close(fd)
        except OSError:closed_logs=False;reject('LOG_CLOSE_FAILED')
    if time.monotonic()>=work:deadline_reached=True;reject('WORK_DEADLINE')
    if worker is not None:rc=worker.poll()
    remaining=inventory(known);reap(remaining,worker);remaining=inventory(known)
    worker_frame=None;valid=False
    try:
        worker_frame=validate_worker(bytes(state['final']['data']),approved,runid,t0,work,rc);valid=True
    except BaseException:reject('WORKER_FRAME_INVALID')
    streams_complete=len(state)==3 and all(v['eof'] and not v['truncated'] for v in state.values())
    closure=bool(valid and worker_frame['identified_work_closure']=='OBSERVED' and rc is not None and initial is not None and initial['namespace'] is not None and identity_match and not remaining and streams_complete and not deadline_reached and closed_logs)
    comparison=worker_frame['comparison_status'] if valid else 'BLOCKED';custody=worker_frame['custody_status'] if valid else 'UNVERIFIED'
    if first_error is None and valid and worker_frame['first_error_code'] is not None:first_error=worker_frame['first_error_code']
    output_records=[];manifest_record=None
    try:
        checkpoint();need(valid,'WORKER_FRAME_REQUIRED')
        for item in worker_frame['outputs']:
            p=plain(out/item['name']);need(p.stat().st_size==item['bytes'] and digest(p)==item['sha256'],'WORKER_OUTPUT_HASH')
        report=dict(schema_version=1,manifest_sha256=approved,source_manifest_sha256=R_SHA,result_manifest_sha256=E_SHA,run_id=runid,t0=t0,deadline=work,comparison_status=comparison,custody_status=custody,identified_work_closure='OBSERVED' if closure else 'UNVERIFIED',worker_identity=public(initial),worker_rc=rc,worker_reaped=rc is not None,worker_frame=worker_frame,first_error_code=first_error,deadline_reached=deadline_reached,signal_counts=signal_counts,concurrency=concurrency,outer_return='NOT_SELF_OBSERVED',independent_outer_termination_guarantee=False)
        supervisor_save(report)
        actual={p.name for p in out.iterdir()};expected={x['name'] for x in worker_frame['outputs']}|{'worker.stdout','worker.stderr','supervisor.json'}
        need(actual==expected and actual<=FILES,'OUTPUT_SET_OR_TEMP')
        for name in sorted(actual-{'supervisor.json'}):
            p=plain(out/name);need(p.stat().st_size<=LIMIT,'OUTPUT_QUOTA');output_records.append(dict(name=name,bytes=p.stat().st_size,sha256=digest(p)))
        manifest_record=persist('output-manifest.json',dict(schema_version=1,manifest_sha256=approved,run_id=runid,excluded=['output-manifest.json','supervisor.json'],files=output_records),work,pin)
        checkpoint();need({p.name for p in out.iterdir()}==actual|{'output-manifest.json'},'OUTPUT_SET_AFTER')
    except BaseException:
        # Closure records the earlier observed worker reap/EOF independently.
        # A later persistence overrun cannot erase it, nor admit a PASS: the
        # deadline latch and custody rejection remain irreversible in the frame.
        if time.monotonic()>=work:deadline_reached=True
        reject('FINAL_PERSISTENCE_FAILED');custody='UNVERIFIED'
    # Recheck after all final persistence, including the successful branch.
    # No repair IO is attempted once the work budget has elapsed.
    if time.monotonic()>=work:
        deadline_reached=True;reject('WORK_DEADLINE');custody='UNVERIFIED'
    final=dict(schema_version=1,type='READONLY_SUPERVISOR_RESULT',manifest_sha256=approved,source_manifest_sha256=R_SHA,result_manifest_sha256=E_SHA,runtime_manifest_sha256='12f2b901664651a49ab79061c9c1855e1976f2fd50608dc8fb15dd15f4503dba',run_id=runid,t0=t0,comparison_status=comparison,custody_status=custody,identified_work_closure='OBSERVED' if closure else 'UNVERIFIED',worker_identity=public(initial),worker_rc=rc,worker_reaped=rc is not None,worker_frame_valid=valid,worker_frame_sha256=state['final']['hash'].hexdigest() if 'final' in state else None,capture_truncated=any(v['truncated'] for v in state.values()),deadline_reached=deadline_reached,signal_counts=signal_counts,signal_counts_saturated=any(v==1000000 for v in signal_counts.values()),remaining_identities_count=len(remaining),first_error_code=first_error,output_manifest=manifest_record,supervisor_sha256=supervisor_hash,supervisor_self_reaped=False,outer_return='NOT_SELF_OBSERVED',independent_outer_termination_guarantee=False,monotonic_emission_start=time.monotonic())
    sent=send(1,final,absolute,ascii_frame=True)
    return 0 if comparison=='PASS' and custody=='VERIFIED' and closure and not deadline_reached and first_error is None and manifest_record is not None and sent else 2
if __name__=='__main__':sys.exit(main())

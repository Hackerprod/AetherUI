"""Static-prepared, not executed/imported during preparation.
Closed concurrency classifier; no shell evaluation or process mutation.
Readonly two-role derivation. Public API capture_role(policy,H,role,pid,expected_argv),
scan(policy,H,registry,persist,stage,t0,run_id)->context, revalidate(context).
Original classifier preserved separately byte-for-byte; no runtime tests performed.
"""
import hashlib
import json
import os
from pathlib import Path
import shlex
import time
import math

WRAPPER_EXE='/RELOCATE/host-wrapper'
WRAPPER_SHA256='57c94ea520df28beb76955316c5c48f672550fe42c6cff7003badb76e1ee10d8'
# Fixed ordering, arity and separator. Data values never interpreted as commands.
WRAPPER_OPTION_NAMES=['--sandbox-policy-cwd','--command-cwd','--permission-profile',
                      '--apply-seccomp-then-exec','--managed-network','--proxy-route-spec']
PYTHON_SINGLE_OPTIONS={'-B','-E','-I','-O','-OO','-s','-S','-u','-q','-b','-bb'}
PYTHON_VALUE_OPTIONS={'-W':{'default','error','ignore','always','module','once'},
                      '-X':{'dev','utf8','utf8=0','utf8=1','faulthandler'}}
CAMPAIGN_NAMES={'cmake','ctest','make','gmake','ninja','cc','c++','gcc','g++',
                'cc1','cc1plus','clang','clang++','collect2','ld','ld.bfd','ld.gold'}
CAMPAIGN_SCRIPTS={'supervisor.py','execute.py','synthetic_harness.py',
                  'concurrency_synthetic.py','observe_orders.py','guard_deadlines.py','fixture.py','fixtures.py'}
MARKERS=('/aether_','supervisor.py','execute.py','synthetic_harness.py',
         'concurrency_synthetic.py','observe_orders.py','guard_deadlines.py','--fixture')
DECISION_TABLE={
 'identity':'EXITED only after verified disappearance; inconsistent/read failure -> UNKNOWN',
 'own':'exact captured pid/start/ns + approved Python exe/hash + role script',
 'campaign':'real exe basename/comm campaign names or aether_ prefix; supported Python program slot script',
 'python':'only enumerated switches, optional --, one program slot; -c/-m/unknown -> UNKNOWN',
 'transport':'only exact codex hash/layout, real ancestor chain and independently derived entry payload',
 'data':'only approved known-data executable hash; arguments are data, never searched as programs',
 'other':'UNKNOWN, not generic name/uid/pid allowlisting'}

class ConcurrencyBlocked(RuntimeError):
    def __init__(self,report):self.report=report;super().__init__('CONCURRENT_CAMPAIGN_OR_UNKNOWN')
class EvidencePersistenceError(RuntimeError):pass
class ContractError(RuntimeError):
    def __init__(self,code,snapshot=None,ancestry=None):
        self.snapshot=snapshot;self.ancestry=ancestry;super().__init__(code)

def digest_bytes(data):return hashlib.sha256(data).hexdigest()
def file_hash(path):
    h=hashlib.sha256()
    with open(path,'rb') as stream:
        for chunk in iter(lambda:stream.read(1048576),b''):h.update(chunk)
    return h.hexdigest()
def identity(pid):
    data=Path('/proc',str(pid),'stat').read_text();v=data[data.rfind(')')+2:].split()
    return dict(pid=int(pid),ppid=int(v[1]),start=v[19])
def ns(pid):return {n:os.readlink('/proc/'+str(pid)+'/ns/'+n) for n in ('pid','mnt','user')}

def collect_snapshot(pid):
    """Raw argv remains memory-only. Capture identity, namespace and path twice."""
    result={'pid':int(pid),'status':'UNKNOWN','consistent':False}
    before=None
    try:
        before=identity(pid);result.update(before)
        namespace=ns(pid)
        root=Path('/proc',str(pid))
        exe=os.readlink(root/'exe');cwd=os.readlink(root/'cwd')
        argv_raw=(root/'cmdline').read_bytes()
        if not argv_raw or not argv_raw.endswith(b'\0'):raise ContractError('EMPTY_OR_UNTERMINATED_ARGV')
        argv=[x.decode('utf-8','strict') for x in argv_raw[:-1].split(b'\0')]
        # Open /proc/pid/exe, not an argv-supplied path; process identity checked again.
        exe_hash=file_hash(root/'exe');comm=(root/'comm').read_text().rstrip('\n')
        after=identity(pid);after_ns=ns(pid)
        if before!=after or namespace!=after_ns or exe!=os.readlink(root/'exe') or cwd!=os.readlink(root/'cwd') or argv_raw!=(root/'cmdline').read_bytes():
            raise ContractError('INCOHERENT_OR_REUSED_PROCESS')
        result.update(status='OK',consistent=True,namespaces=namespace,exe=exe,
                      exe_sha256=exe_hash,comm=comm,argv=argv,cwd=cwd)
    except (FileNotFoundError,ProcessLookupError):
        # A failed read is not itself proof of exit; verify /proc identity is gone.
        try:
            again=identity(pid)
            result.update(error='READ_FAILED_PROCESS_PRESENT',after_identity=again)
        except (FileNotFoundError,ProcessLookupError):
            if not Path('/proc',str(pid)).exists():result.update(status='EXITED',consistent=True,error='VERIFIED_DISAPPEARANCE')
            else:result.update(error='DISAPPEARANCE_NOT_VERIFIED')
        except Exception as exc:result.update(error=type(exc).__name__,errno=getattr(exc,'errno',None))
    except Exception as exc:
        result.update(error=type(exc).__name__+(':'+str(exc) if isinstance(exc,ContractError) else ''),errno=getattr(exc,'errno',None))
    return result

def same_identity(actual,expected,with_exe=False):
    keys=('pid','start','ppid','namespaces')+ (('exe','exe_sha256') if with_exe else ())
    return all(actual.get(k)==expected.get(k) for k in keys)

def verified_json(path,h):
    raw=Path(path).read_bytes()
    if digest_bytes(raw)!=h:raise ContractError('APPROVED_FILE_CHANGED')
    return strict_json(raw)

def strict_json(raw):
    def unique(pairs):
        d={}
        for key,value in pairs:
            if key in d:raise ContractError('DUPLICATE_KEY')
            d[key]=value
        return d
    def bad(value):raise ContractError('NONFINITE_JSON')
    return json.loads(raw,object_pairs_hook=unique,parse_constant=bad)

def load_package(root,H):
    import stat
    need(type(H) is str and len(H)==64 and all(c in '0123456789abcdef' for c in H),'MANIFEST_DIGEST')
    def plain(path):
        need(not any(q.is_symlink() for q in (path,*path.parents)) and stat.S_ISREG(path.lstat().st_mode),'PACKAGE_FILE_TYPE')
        return path.read_bytes()
    raw=plain(root/'evidence.sha256.json');need(digest_bytes(raw)==H,'PACKAGE_MANIFEST')
    records=strict_json(raw);need(type(records) is list,'PACKAGE_SCHEMA');out={}
    for row in records:
        need(type(row) is dict and set(row)=={'path','bytes','sha256'},'PACKAGE_RECORD')
        name=row['path']
        need(not any(name==q or name.startswith(q+'/') for q in ('run','home','tmp','harness-Hc/Testing','harness-J/Testing')),'OUTPUT_IN_INPUT_MANIFEST')
        need(type(name) is str and name not in out and not name.startswith('/') and '\\' not in name and '\x00' not in name and all(p not in ('','.','..') for p in name.split('/')),'PACKAGE_PATH')
        need(type(row['bytes']) is int and row['bytes']>=0 and type(row['sha256']) is str and len(row['sha256'])==64 and all(c in '0123456789abcdef' for c in row['sha256']),'PACKAGE_RECORD_TYPE')
        data=plain(root/name);need(len(data)==row['bytes'] and digest_bytes(data)==row['sha256'],'PACKAGE_CHANGED');out[name]=row['sha256']
    need({'readonly-policy.json','readonly_concurrency.py','readonly_supervisor.py','readonly_worker.py'}<=set(out),'PACKAGE_MISSING_ROLE')
    return out

# V3 closed roles: CTest/parser/products only under verified jobs, never pre-excluded in scans.
ROLES=('supervisor','worker')
PARENTS={'worker':'supervisor'}
FD_NAMES={'supervisor':(),'worker':('ready','final')}
SCRIPTS={'supervisor':'readonly_supervisor.py','worker':'readonly_worker.py'}
EXPECTED_ROOT=Path('/RELOCATE/diagnostic')
ROW_KEYS={'role','pid','ppid','start','argv_sha256','fds'}

def argv_hash(argv):return digest_bytes(json.dumps(argv,separators=(',',':'),ensure_ascii=True).encode())
def need(ok,code):
    if not ok:raise ContractError(code)
def decimal(value,minimum=0):return isinstance(value,str) and value.isascii() and value.isdecimal() and str(int(value))==value and int(value)>=minimum

def decode_argv(policy,H,role,argv):
    """Only fixed two-role argv; no auxiliary owns a classification exemption."""
    need(role in ROLES and type(argv) is list and all(type(x) is str for x in argv),'ROLE_ARGV')
    prefix=[policy['tools']['python3']['path'],'-B',str(Path(policy['root'])/SCRIPTS[role])]
    need(argv[:3]==prefix,'ROLE_PREFIX')
    if role=='supervisor':
        need(argv[3:]==['--manifest-sha256',H],'SUPERVISOR_ARGV');return {}
    need(len(argv)==15,'WORKER_ARITY')
    need(argv[3:5]==['--manifest-sha256',H] and argv[5]=='--origin-monotonic' and argv[7]=='--run-id' and argv[9]=='--deadline' and argv[11]=='--ready-fd' and argv[13]=='--final-fd','WORKER_FLAGS')
    T=float(argv[6]);D=float(argv[10]);U=argv[8]
    need(math.isfinite(T) and T>=0 and argv[6]==repr(T) and math.isfinite(D) and D==T+900 and argv[10]==repr(D),'WORKER_CLOCK')
    need(len(U)==32 and all(c in '0123456789abcdef' for c in U),'WORKER_RUN_ID')
    values=[argv[12],argv[14]]
    need(all(decimal(v,3) for v in values) and len(set(values))==2,'ROLE_FDS')
    return dict(zip(FD_NAMES[role],map(int,values)))

def capture_role(policy,H,role,pid,expected_argv):
    """Called only with argv from verified Popen/handshake, never unknown /proc argv."""
    fds=decode_argv(policy,H,role,expected_argv);s=collect_snapshot(pid)
    need(s['status']=='OK' and s['argv']==expected_argv and s['cwd']==policy['root'],'CAPTURE_ROLE_ARGV')
    need(s['exe']==str(Path(policy['tools']['python3']['path']).resolve()) and s['exe_sha256']==policy['tools']['python3']['sha256'],'CAPTURE_ROLE_EXE')
    need(s['namespaces']==ns(os.getpid()),'CAPTURE_ROLE_NS')
    return dict(role=role,pid=s['pid'],ppid=s['ppid'],start=s['start'],argv_sha256=argv_hash(expected_argv),fds=fds)

def role_argv(policy,H,row,rows,t0,U):
    role=row['role'];fds=row['fds'];root=Path(policy['root'])
    need(type(fds) is dict and set(fds)==set(FD_NAMES[role]) and all(type(v) is int and v>=3 for v in fds.values()) and len(set(fds.values()))==len(fds),'REGISTRY_FDS')
    a=[policy['tools']['python3']['path'],'-B',str(root/SCRIPTS[role]),'--manifest-sha256',H]
    if role=='supervisor':return a
    return a+['--origin-monotonic',repr(t0),'--run-id',U,'--deadline',repr(t0+900),'--ready-fd',str(fds['ready']),'--final-fd',str(fds['final'])]

def revalidate(context):
    """Raises on any change; invoke again immediately before spawning worker or entering the one auxiliary gate."""
    need(time.monotonic()<context['deadline'],'CONCURRENCY_DEADLINE')
    for expected in context['own']+context['ancestors']:
        s=collect_snapshot(expected['pid'])
        need(s['status']=='OK' and same_identity(s,expected,True) and s['argv']==expected['argv'] and s['cwd']==expected['cwd'],'ROLE_OR_ANCESTRY_CHANGED')
    need(time.monotonic()<context['deadline'],'CONCURRENCY_DEADLINE')

def build_context(policy,manifest_digest,registry,stage,t0,run_id):
    root=Path(policy['root'])
    need(root==EXPECTED_ROOT and not root.is_symlink() and root.resolve()==root,'ROOT_LOCATION')
    need(type(t0) is float and math.isfinite(t0) and t0>=0 and time.monotonic()<t0+900,'ORIGIN_DEADLINE')
    need(isinstance(run_id,str) and len(run_id)==32 and all(c in '0123456789abcdef' for c in run_id),'RUN_ID')
    manifest=load_package(root,manifest_digest)
    need(policy==verified_json(root/'readonly-policy.json',manifest['readonly-policy.json']),'CALLER_POLICY_NOT_APPROVED')
    need(stage in ('supervisor','before-gate'),'SCAN_STAGE')
    need(isinstance(registry,dict) and set(registry)=={'namespaces','roles'} and set(registry['namespaces'])=={'pid','mnt','user'} and registry['namespaces']==ns(os.getpid()),'REGISTRY_SCHEMA')
    need(type(registry['roles']) is list,'REGISTRY_ROLES_TYPE')
    rows={}
    for row in registry['roles']:
        need(isinstance(row,dict) and set(row)==ROW_KEYS and row['role'] in ROLES and row['role'] not in rows,'REGISTRY_ROLE')
        need(type(row['pid']) is int and row['pid']>0 and type(row['ppid']) is int and row['ppid']>=0 and decimal(row['start']),'REGISTRY_IDENTITY')
        need(type(row['argv_sha256']) is str and len(row['argv_sha256'])==64 and all(c in '0123456789abcdef' for c in row['argv_sha256']),'REGISTRY_HASH')
        rows[row['role']]=row
    need(set(rows)==({'supervisor'} if stage=='supervisor' else set(ROLES)) and len({r['pid'] for r in rows.values()})==len(rows),'ROLE_SET')
    need(rows['supervisor' if stage=='supervisor' else 'worker']['pid']==os.getpid(),'SCANNER_ROLE')
    own=[]
    for role,row in rows.items():
        if role!='supervisor':need(row['ppid']==rows[PARENTS[role]]['pid'],'ROLE_PARENT')
        argv=role_argv(policy,manifest_digest,row,rows,t0,run_id)
        need(row['argv_sha256']==argv_hash(argv),'REGISTERED_ARGV_HASH')
        need(file_hash(root/SCRIPTS[role])==manifest[SCRIPTS[role]],'ROLE_SCRIPT_CHANGED')
        own.append(dict(role=role,pid=row['pid'],ppid=row['ppid'],start=row['start'],namespaces=dict(registry['namespaces']),exe=str(Path(policy['tools']['python3']['path']).resolve()),exe_sha256=policy['tools']['python3']['sha256'],argv=argv,cwd=str(root)))
    outer=next(r for r in own if r['role']=='supervisor');chain=[];last=outer;seen={r['pid'] for r in own}
    while last['ppid']:
        parent=collect_snapshot(last['ppid'])
        need(parent['status']=='OK' and parent['pid'] not in seen and parent['namespaces']==registry['namespaces'],'ANCESTRY_UNPROVABLE')
        chain.append({k:parent[k] for k in ('pid','ppid','start','namespaces','exe','exe_sha256','argv','cwd')});seen.add(parent['pid']);last=parent
    context=dict(root=str(root),workspace_root=str(root.parent),own=own,ancestors=chain,launch=dict(coordinator=outer,argv=outer['argv'],cwd=str(root),payload='exec '+shlex.join(outer['argv'])),python=dict(exe=outer['exe'],sha256=outer['exe_sha256']),known_data_executables=dict(policy.get('concurrency_known_data_executables',{})),campaign_executables=[str(Path(policy['tools'][n]['path']).resolve()) for n in ('cc','c++','cmake','ctest','make') if n in policy['tools']],manifest_digest=manifest_digest,deadline=t0+900)
    revalidate(context)
    return context

def campaign_name(name):
    return name in CAMPAIGN_NAMES or name.startswith('aether_') or any(name.startswith(x+'-') for x in ('gcc','g++','clang','clang++','cmake','ctest'))

def python_program(argv):
    index=1
    while index<len(argv):
        arg=argv[index]
        if arg=='--':return index+1 if index+1<len(argv) else None,'SCRIPT_AFTER_SEPARATOR'
        if arg in PYTHON_SINGLE_OPTIONS:index+=1;continue
        if arg in PYTHON_VALUE_OPTIONS:
            if index+1>=len(argv) or argv[index+1] not in PYTHON_VALUE_OPTIONS[arg]:return None,'UNSUPPORTED_PYTHON_OPTION_VALUE'
            index+=2;continue
        if arg.startswith('-'):return None,'UNSUPPORTED_PYTHON_OPTION'
        return index,'PYTHON_PROGRAM_SLOT'
    return None,'NO_PYTHON_PROGRAM'

def classify(snapshot,context):
    """Pure classifier: no /proc, hashing, persistence, environment or file reads.
    Raw synthetic snapshots must be explicitly labelled by their harness externally.
    """
    argv=snapshot.get('argv',[])
    argv_valid=isinstance(argv,list) and all(isinstance(x,str) for x in argv)
    hits=[i for i,v in enumerate(argv) if any(m in v for m in MARKERS)] if argv_valid else []
    def answer(verdict,rule,reason,**extra):return dict(verdict=verdict,rule=rule,reason=reason,matched_indices=hits,**extra)
    if snapshot.get('status')=='EXITED' and snapshot.get('consistent') is True:return answer('EXITED','identity','Verified disappearance')
    if snapshot.get('status')!='OK' or snapshot.get('consistent') is not True:return answer('UNKNOWN','identity','Incomplete or inconsistent observation')
    if not argv_valid or not argv:return answer('UNKNOWN','argv','Missing or invalid argv')
    if not all(k in snapshot for k in ('pid','start','ppid','namespaces','exe','exe_sha256','cwd','comm')):
        return answer('UNKNOWN','identity','Required observation field missing')
    for own in context['own']:
        if snapshot['pid']==own['pid']:
            if not same_identity(snapshot,own,True):return answer('UNKNOWN','own','Own PID identity differs')
            valid=argv==own['argv'] and snapshot['cwd']==own['cwd']
            return answer('OWN_PROCESS' if valid else 'UNKNOWN','own','Exact captured role contract' if valid else 'Own argv/cwd mismatch')
    exe=snapshot['exe'];base=Path(exe).name;comm=snapshot.get('comm','')
    if exe in context.get('campaign_executables',[]) or campaign_name(base) or campaign_name(comm):return answer('CAMPAIGN','campaign_executable','Executable/comm matches closed campaign rule')
    if exe==WRAPPER_EXE or argv[0]=='codex-linux-sandbox':
        ancestor=next((a for a in context['ancestors'] if a['pid']==snapshot['pid']),None)
        if not ancestor or not same_identity(snapshot,ancestor,True):return answer('UNKNOWN','transport','Not the captured launch ancestor')
        if exe!=WRAPPER_EXE or snapshot['exe_sha256']!=WRAPPER_SHA256:return answer('UNKNOWN','transport','Wrapper executable/hash differs')
        expected_flags={1:'--sandbox-policy-cwd',3:'--command-cwd',5:'--permission-profile',7:'--apply-seccomp-then-exec',8:'--managed-network',10:'--proxy-route-spec',12:'--',13:'/bin/bash',14:'-lc'}
        if len(argv)!=16 or argv[0]!='codex-linux-sandbox' or any(argv[i]!=v for i,v in expected_flags.items()):return answer('UNKNOWN','transport','Unsupported wrapper layout/options')
        if argv[2]!=context['workspace_root'] or argv[4]!=context['launch']['cwd']:return answer('UNKNOWN','transport','Wrapper directories differ from approved entry')
        # Opaque policy/network route parameters are data, never an extra command.
        # Require complete JSON objects. Their contents never appear in evidence.
        try:
            if not all(isinstance(json.loads(argv[i]),dict) for i in (6,9,11)):raise ValueError()
        except (ValueError,TypeError):return answer('UNKNOWN','transport','Unsupported opaque option data')
        match=argv[15]==context['launch']['payload']
        return answer('OWN_LAUNCH_TRANSPORT' if match else 'UNKNOWN','transport','Exact approved payload' if match else 'Payload differs',
                      payload_sha256=digest_bytes(argv[15].encode()),payload_length=len(argv[15].encode()),payload_exact_match=match)
    if exe==context['python']['exe'] or base.startswith('python'):
        if exe!=context['python']['exe'] or snapshot['exe_sha256']!=context['python']['sha256']:return answer('UNKNOWN','python','Unapproved Python executable/hash')
        index,rule=python_program(argv)
        if index is None:return answer('UNKNOWN','python',rule)
        program=argv[index]
        if not program.startswith('/'):
            cwd=snapshot.get('cwd')
            if not cwd or not cwd.startswith('/'):return answer('UNKNOWN','python','Program path cannot resolve')
            program=str(Path(cwd)/program)
        if Path(program).name in CAMPAIGN_SCRIPTS or Path(program).name.startswith('aether_') or '--fixture' in argv[index+1:]:
            return answer('CAMPAIGN','python_program','Campaign script in actual program slot',program_index=index)
        return answer('UNKNOWN','python_program','Script semantics not approved',program_index=index)
    known=context.get('known_data_executables',{})
    if known.get(exe)==snapshot['exe_sha256']:
        # Closed safe data executables, never arbitrary policy-supplied command interpreters.
        if exe in ('/usr/bin/printf','/usr/bin/echo','/usr/bin/cat','/usr/bin/sleep','/usr/bin/true','/usr/bin/false'):
            return answer('NOT_CAMPAIGN','known_data','Approved data-only executable; marker arguments not executed')
    return answer('UNKNOWN','unknown_execution','No approved execution semantics')

def redact(snapshot,verdict):
    clean={k:snapshot.get(k) for k in ('pid','start','ppid','status','consistent','namespaces','exe','exe_sha256','comm','error','errno') if k in snapshot}
    clean['argv_count']=len(snapshot.get('argv',[]))
    # No raw argv, cwd or command payload, including UNKNOWN processes.
    clean['argv_metadata']=[dict(index=i,length=len(arg.encode()),sha256=digest_bytes(arg.encode())) for i,arg in enumerate(snapshot.get('argv',[]))]
    if 'cwd' in snapshot:clean['cwd_sha256']=digest_bytes(snapshot['cwd'].encode())
    clean['decision']=verdict
    return clean

def scan(policy,manifest_digest,registry,persist,stage,t0,run_id):
    """One read-only pass. Evidence failure prevents any PASS/result return.
    persist takes one serializable report, writes it atomically, raises on failure.
    Own identities come from previously captured ready records, not this new scan.
    """
    report=dict(status='BLOCKED',records=[],blockers=[],stage=stage,
                manifest_sha256=manifest_digest,run_id=run_id,origin_monotonic=t0,decision_table=DECISION_TABLE)
    try:
        context=build_context(policy,manifest_digest,registry,stage,t0,run_id)
        report['ancestry']=[{k:r[k] for k in ('pid','ppid','start','namespaces','exe','exe_sha256')} for r in context['ancestors']]
        report['contract']=dict(stage=stage,payload_length=len(context['launch']['payload'].encode()),
                                payload_sha256=digest_bytes(context['launch']['payload'].encode()))
        pids=sorted(int(p.name) for p in Path('/proc').iterdir() if p.name.isdigit())
        for pid in pids:
            need(time.monotonic()<context['deadline'],'CONCURRENCY_DEADLINE')
            snapshot=collect_snapshot(pid)
            decision=classify(snapshot,context)
            row=redact(snapshot,decision);report['records'].append(row)
            if decision['verdict'] in ('UNKNOWN','CAMPAIGN'):report['blockers'].append(dict(pid=pid,rule=decision['rule'],verdict=decision['verdict']))
        # Snapshot must still match captured launch/own identities at decision time.
        for expected in context['own']+context['ancestors']:
            after=collect_snapshot(expected['pid'])
            if after['status']!='OK' or not same_identity(after,expected,True):
                report['blockers'].append(dict(pid=expected['pid'],rule='identity_recheck',verdict='UNKNOWN'))
                report['records'].append(redact(after,dict(verdict='UNKNOWN',rule='identity_recheck',reason='Identity changed before decision',matched_indices=[])))
        final_pids=sorted(int(p.name) for p in Path('/proc').iterdir() if p.name.isdigit())
        if final_pids!=pids:
            report['blockers'].append(dict(rule='process_set_changed',verdict='UNKNOWN'))
            report['process_set_delta']=dict(appeared=sorted(set(final_pids)-set(pids)),disappeared=sorted(set(pids)-set(final_pids)))
        for row in list(report['records']):
            if row.get('status')=='EXITED' and Path('/proc',str(row['pid'])).exists():
                returned=collect_snapshot(row['pid'])
                report['blockers'].append(dict(pid=row['pid'],rule='pid_returned_after_exit',verdict='UNKNOWN'))
                report['records'].append(redact(returned,dict(verdict='UNKNOWN',rule='pid_returned_after_exit',reason='PID present after verified disappearance',matched_indices=[])))
        revalidate(context)
        report['counts']={v:sum(r['decision']['verdict']==v for r in report['records']) for v in ('OWN_PROCESS','OWN_LAUNCH_TRANSPORT','NOT_CAMPAIGN','CAMPAIGN','UNKNOWN','EXITED')}
        report['status']='PASS' if not report['blockers'] else 'BLOCKED'
    except Exception as exc:
        report['status']='BLOCKED';report['error']=dict(type=type(exc).__name__,code=str(exc) if isinstance(exc,ContractError) else 'READ_OR_CLASSIFICATION_FAILURE',errno=getattr(exc,'errno',None))
        if isinstance(exc,ContractError):
            if exc.ancestry is not None:report['ancestry']=exc.ancestry
            if exc.snapshot is not None:
                report['records'].append(redact(exc.snapshot,dict(verdict='UNKNOWN',rule='contract_or_ancestry',reason=str(exc),matched_indices=[])))
    try:persist(report)
    except Exception as exc:raise EvidencePersistenceError('CONCURRENCY_EVIDENCE_NOT_PERSISTED') from exc
    if report['status']!='PASS':raise ConcurrencyBlocked(report)
    revalidate(context)
    return context

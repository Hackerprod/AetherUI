"""V3 diagnostic worker derived from readonly V21. Static materialization, not execution approval."""
import os,sys,time,json,hashlib,stat,re,math,struct,select,signal,subprocess,ctypes,resource
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
EXPECTED=Path('/RELOCATE/diagnostic')
SOURCE=Path('/RELOCATE/preparation')
EVIDENCE=Path('/RELOCATE/reference-1')
R_SHA='413fa35254344f55b087364e6e9bbb38ec70010b7c2cc7706409238711dcee4f'
E_SHA='30def72e2a21e3d12269f472114a12557f8edcef69c4bc96ceb576396e750336'
READONLY_RESULT=Path('/RELOCATE/reference-2/evidence.sha256.json')
READONLY_SHA='f01d024d224dbdab25fe584d855dcbf32410690b1f0aa973c92d484c60e48633'
PYTHON='/RELOCATE/python3'
FILES={'supervisor.json','output-manifest.json'}
LIMIT=16777216

def need(ok,code):
    if not ok:raise ValueError(code)
def unique(pairs):
    out={}
    for k,v in pairs:need(k not in out,'DUPLICATE');out[k]=v
    return out
def parse(raw):return json.loads(raw,object_pairs_hook=unique,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('NONFINITE')))
def plain(path):
    for p in [path,*path.parents]:need(not p.is_symlink(),'SYMLINK')
    need(stat.S_ISREG(path.lstat().st_mode),'REGULAR');return path
def digest(path):
    h=hashlib.sha256()
    with plain(path).open('rb') as f:
        for part in iter(lambda:f.read(1048576),b''):h.update(part)
    return h.hexdigest()
def authenticate(approved,deadline):
    need(ROOT==EXPECTED and re.fullmatch('[0-9a-f]{64}',approved),'ROOT_OR_SHA')
    need(digest(ROOT/'evidence.sha256.json')==approved,'MANIFEST_HASH')
    rows=parse(plain(ROOT/'evidence.sha256.json').read_bytes());need(type(rows) is list,'MANIFEST_SCHEMA');seen=set()
    for row in rows:
        need(time.monotonic()<deadline,'BOOTSTRAP_CAP')
        need(type(row) is dict and set(row)=={'path','bytes','sha256'},'MANIFEST_RECORD');name=row['path']
        need(type(name) is str and name and not name.startswith('/') and '\\' not in name and '\x00' not in name and all(x not in ('','.','..') for x in name.split('/')) and name not in seen and name.split('/')[0]!='run','MANIFEST_PATH')
        need(type(row['bytes']) is int and row['bytes']>=0 and type(row['sha256']) is str and re.fullmatch('[0-9a-f]{64}',row['sha256']),'MANIFEST_TYPES')
        seen.add(name);p=plain(ROOT/name);need(p.stat().st_size==row['bytes'] and digest(p)==row['sha256'],'INPUT_HASH')
    need({'readonly_supervisor.py','readonly_worker.py','readonly_custody.py','v3_diagnostic.py','v3-recipe.json','outputs.json','parse_post09_observer.py','references-authority.json','references/source-policy.json','readonly-policy.json','readonly_concurrency.py','v3_diagnostic.py','outputs.json','v3-recipe.json'}<=seen,'MISSING_MODULE')
    actual=set();root_before=ROOT.lstat();visited_root=False
    need(stat.S_ISDIR(root_before.st_mode) and not ROOT.is_symlink(),'PACKAGE_ROOT_TYPE')
    def walk_error(error):raise error
    for base,dirs,names in os.walk(ROOT,followlinks=False,onerror=walk_error):
        if Path(base)==ROOT:visited_root=True
        relative=str(Path(base).relative_to(ROOT))
        for name in list(dirs):
            rel=name if relative=='.' else relative+'/'+name
            if rel in {'run','home','tmp','harness-Hc/Testing','harness-J/Testing'}:
                need(not (Path(base)/name).is_symlink() and stat.S_ISDIR((Path(base)/name).lstat().st_mode),'OUTPUT_DIR_TYPE');dirs.remove(name)
        for name in dirs:need(not (Path(base)/name).is_symlink(),'DIRECTORY_SYMLINK')
        for name in names:
            relative=str((Path(base)/name).relative_to(ROOT))
            if relative!='evidence.sha256.json':actual.add(relative)
    root_after=ROOT.lstat()
    need(visited_root and (root_before.st_dev,root_before.st_ino,root_before.st_mode)==(root_after.st_dev,root_after.st_ino,root_after.st_mode),'PACKAGE_ROOT_SCAN_CHANGED')
    need(actual==seen,'INPUT_FILE_SET')
    refs=parse((ROOT/'references-authority.json').read_bytes())
    need(refs['source_root']==str(SOURCE) and refs['result_root']==str(EVIDENCE),'REFERENCE_ROOTS')
    need(refs['references'][str(SOURCE/'evidence.sha256.json')]['sha256']==R_SHA and refs['references'][str(EVIDENCE/'evidence.sha256.json')]['sha256']==E_SHA,'REFERENCE_MANIFESTS')
    need(refs['references'][str(READONLY_RESULT)]['sha256']==READONLY_SHA,'READONLY_ACCEPTED_MANIFEST')
    for name,record in refs['references'].items():
        need(time.monotonic()<deadline,'BOOTSTRAP_CAP');p=plain(Path(name))
        need(p.stat().st_size==record['bytes'] and digest(p)==record['sha256'] and digest(ROOT/record['copy'])==record['sha256'],'REFERENCE_DRIFT')
    policy=parse((ROOT/'readonly-policy.json').read_bytes());need(policy['root']==str(ROOT),'POLICY_ROOT');tool=policy['tools']['python3'];real=Path(tool['path']).resolve(strict=True)
    need(tool['path']==PYTHON and real==Path(sys.executable).resolve(strict=True) and real==Path('/proc/self/exe').resolve(strict=True) and digest(real)==tool['sha256'],'INTERPRETER')
    return rows


def runtime_main():
    import argparse,resource
    a=argparse.ArgumentParser();a.add_argument('--manifest-sha256',required=True);a.add_argument('--origin-monotonic',required=True,type=float);a.add_argument('--run-id',required=True);a.add_argument('--deadline',required=True,type=float);a.add_argument('--ready-fd',required=True,type=int);a.add_argument('--final-fd',required=True,type=int);args=a.parse_args()
    H=args.manifest_sha256;T=args.origin_monotonic;U=args.run_id;D=args.deadline;RF=args.ready_fd;FF=args.final_fd
    need(math.isfinite(T) and math.isfinite(D) and D==T+900 and 0<=time.monotonic()-T<900 and re.fullmatch('[0-9a-f]{32}',U),'ORIGIN')
    need(RF!=FF and RF>2 and FF>2,'FD_ALIAS')
    for fd in (RF,FF):
        need(stat.S_ISFIFO(os.fstat(fd).st_mode) and os.fpathconf(fd,'PC_PIPE_BUF')>=4096,'PIPE');os.set_blocking(fd,False);os.set_inheritable(fd,False)
    # Inherited restriction is checked; never use PR_SET_DUMPABLE or sysctl.
    need(resource.getrlimit(resource.RLIMIT_CORE)==(0,0),'CORE_LIMIT_NOT_INHERITED')
    frame=dict(schema_version=1,type='DIAGNOSTIC_WORKER_RESULT',manifest_sha256=H,source_manifest_sha256=R_SHA,result_manifest_sha256=E_SHA,runtime_manifest_sha256='12f2b901664651a49ab79061c9c1855e1976f2fd50608dc8fb15dd15f4503dba',run_id=U,t0=T,deadline=D,campaign_status='REJECTED',causal_gate='CLOSED_REJECTED',test_count=0,parser_count=0,t_tests=None,tests_deadline=None,rlimit_core=dict(soft=0,hard=0),G1='NOT_PASSED',custody_status='UNVERIFIED',identified_work_closure='UNVERIFIED',tools_reaped=True,tools_streams_eof=True,remaining_identities_count=0,capture_truncated=False,first_error_code=None,outputs=[],worker_self_reaped=False)
    first=None;close_started=None;known={};job_logs=[];aggregate=0;metadata_bytes=0;overflow=False;all_reaped=True;all_eof=True;run_pin=None;written={};locations={};phaseD=None;next_job=0;cancelled=[];phase='bootstrap';report=None;admissions=[];role_context=None;job_aborted=False;first_detail=None
    def begin_close():
        nonlocal close_started
        if close_started is None:close_started=time.monotonic()
        return min(close_started+120,T+1200)
    def fail(code):
        nonlocal first
        if first is None:first=code
        begin_close();raise RuntimeError(code)
    try:
        authenticate(H,min(T+60,D))
        from readonly_supervisor import identity,public,same,inventory,signal_verified,reap
        from readonly_custody import Custody
        from readonly_concurrency import capture_role,scan,revalidate
        from v3_diagnostic import run,check_testing,check_outputs,register_output_root,set_phase,violation_detail
        policy=parse(plain(ROOT/'readonly-policy.json').read_bytes());recipe=parse(plain(ROOT/'v3-recipe.json').read_bytes());output_authority=parse(plain(ROOT/'outputs.json').read_bytes())
        need(recipe['root']==str(ROOT) and output_authority['root']==str(ROOT),'RECIPE_ROOT')
        rows=recipe['rows'];need(len(rows)==10 and [r['id'] for r in rows]==['test-'+tree+'-'+str(i).zfill(2) for tree in ('Hc','J') for i in range(1,6)],'RECIPE_ORDER')
        specs=[s for row in rows for s in (row['ctest'],row['parser'])]
        parent=identity(os.getppid());need(parent and parent['namespace'],'PARENT');parentfd=os.pidfd_open(parent['pid'])
        need(ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)==0,'SUBREAPER')
        for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):signal.signal(sig,lambda n,f:cancelled.append(n))
        def checkpoint():
            if close_started is not None and time.monotonic()>=min(close_started+120,T+1200):fail('WORK_DEADLINE')
            if time.monotonic()>=D or phaseD is not None and time.monotonic()>=phaseD:fail('WORK_DEADLINE')
            if cancelled:fail('PROTOCOL_FAILED')
            if not same(parent) or os.getppid()!=parent['pid'] or select.select([parentfd],[],[],0)[0]:fail('PARENT_LOST')
            if resource.getrlimit(resource.RLIMIT_CORE)!=(0,0):fail('PROTOCOL_FAILED')
            if run_pin is not None:
                st=(ROOT/'run').lstat();need(not (ROOT/'run').is_symlink() and stat.S_ISDIR(st.st_mode) and dict(canonical=str((ROOT/'run').resolve(strict=True)),device=st.st_dev,inode=st.st_ino,type='directory')==run_pin,'RUN_IDENTITY')
        raw=bytearray();eof=False
        while time.monotonic()<min(T+60,D):
            checkpoint();rr,_,_=select.select([RF],[],[],min(.02,max(0,min(T+60,D)-time.monotonic())))
            if rr:
                part=os.read(RF,4097-len(raw))
                if not part:eof=True;break
                raw.extend(part);need(len(raw)<=4096,'READY_QUOTA')
                if len(raw)>=4:need(2<=int.from_bytes(raw[:4],'little')<=4092,'READY_LENGTH')
        need(eof and len(raw)>=4 and len(raw)==4+int.from_bytes(raw[:4],'little'),'READY_EOF_FRAME');ready=parse(bytes(raw[4:]));os.close(RF)
        keys={'schema_version','type','manifest_sha256','run_id','t0','deadline','parent','run','concurrency_roles'}
        need(type(ready) is dict and set(ready)==keys and type(ready['schema_version']) is int and ready['schema_version']==1 and ready['type']=='DIAGNOSTIC_PARENT_READY' and ready['manifest_sha256']==H and ready['run_id']==U and type(ready['t0']) is float and ready['t0']==T and type(ready['deadline']) is float and ready['deadline']==D and ready['parent']==public(parent),'READY_CORRELATION')
        run_pin=ready['run'];need(type(run_pin) is dict and set(run_pin)=={'canonical','device','inode','type'} and run_pin['canonical']==str(ROOT/'run') and type(run_pin['device']) is int and type(run_pin['inode']) is int and run_pin['type']=='directory','RUN_PIN');checkpoint()
        for name in ('home','tmp'):
            path=ROOT/name
            try:path.lstat()
            except FileNotFoundError:pass
            else:raise ValueError('PRIVATE_DIRECTORY_ALREADY_EXISTS')
            path.mkdir(mode=0o700);register_output_root(path)
        registry=ready['concurrency_roles'];need(type(registry) is dict and set(registry)=={'namespaces','roles'} and len(registry['roles'])==1 and registry['roles'][0]['role']=='supervisor','REGISTRY')
        registry=dict(namespaces=dict(registry['namespaces']),roles=[dict(x) for x in registry['roles']])
        workerargv=[policy['tools']['python3']['path'],'-B',str(ROOT/'readonly_worker.py'),'--manifest-sha256',H,'--origin-monotonic',repr(T),'--run-id',U,'--deadline',repr(D),'--ready-fd',str(RF),'--final-fd',str(FF)]
        registry['roles'].append(capture_role(policy,H,'worker',os.getpid(),workerargv))
        def persist(name,value):
            checkpoint();rel=name if name.startswith('run/') else 'run/'+name
            need(rel in output_authority['files'] and rel+'.tmp' in output_authority['files'],'OUTPUT_NOT_APPROVED')
            dest=ROOT/rel;temp=Path(str(dest)+'.tmp');raw=json.dumps(value,separators=(',',':'),allow_nan=False).encode();need(len(raw)<=output_authority['files'][rel],'REPORT_QUOTA')
            if dest.exists() or dest.is_symlink():
                st=dest.lstat();need(rel in written and (st.st_dev,st.st_ino,stat.S_IFMT(st.st_mode))==locations[rel] and digest(dest)==written[rel]['sha256'],'OUTPUT_DRIFT')
            fd=os.open(temp,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
            try:
                offset=0
                while offset<len(raw):checkpoint();n=os.write(fd,raw[offset:]);need(n>0,'WRITE_ZERO');offset+=n
                os.fsync(fd)
            finally:os.close(fd)
            checkpoint();os.replace(temp,dest);checkpoint();need(digest(dest)==hashlib.sha256(raw).hexdigest(),'OUTPUT_HASH');st=dest.lstat();locations[rel]=(st.st_dev,st.st_ino,stat.S_IFMT(st.st_mode));written[rel]=dict(name=rel.removeprefix('run/'),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest());checkpoint()
        custody=Custody(H,T,U,D,persist,checkpoint)
        def before_row(row,tests_deadline,t_tests):
            nonlocal phaseD,role_context
            need(type(tests_deadline) is float and math.isfinite(tests_deadline) and time.monotonic()<tests_deadline<=min(time.monotonic()+900,D),'TESTS_DEADLINE')
            if phaseD is None:phaseD=tests_deadline
            else:need(phaseD==tests_deadline,'TESTS_DEADLINE_CHANGED')
            need(type(t_tests) is float and T<=t_tests<tests_deadline,'TESTS_ORIGIN')
            frame['t_tests']=t_tests;frame['tests_deadline']=tests_deadline
            def save_scan(value):
                need(len(admissions)<10,'ADMISSION_QUOTA');admissions.append(dict(row=row['id'],concurrency=value))
                persist('jobs.json',dict(schema_version=1,manifest_sha256=H,run_id=U,admissions=admissions,jobs=job_logs,first_error_code=first))
            checkpoint();role_context=scan(policy,H,registry,save_scan,'before-gate',T,U)
            revalidate(role_context);checkpoint()
        def run_job(spec,deadline):
            nonlocal next_job,aggregate,metadata_bytes,overflow,all_reaped,all_eof,job_aborted,first_detail
            checkpoint();need(next_job<len(specs) and spec==specs[next_job],'JOB_SEQUENCE_OR_RECIPE')
            cap=120 if spec['stage']=='test' else 15
            need(spec['stage'] in ('test','parser') and spec['cap_seconds']==cap and type(deadline) in (int,float) and math.isfinite(deadline) and phaseD is not None and time.monotonic()<deadline<=min(time.monotonic()+cap,phaseD,D),'JOB_DEADLINE')
            need(spec['cwd']==str(ROOT) and all(type(v) is str for v in spec['argv']) and type(spec['env']) is dict,'JOB_ARGV_ENV')
            expectedtool=policy['tools']['ctest']['path'] if spec['stage']=='test' else policy['tools']['python3']['path'];need(spec['argv'][0]==expectedtool,'JOB_TOOL')
            custody.check_path(spec['argv'][0]);checkpoint();need(resource.getrlimit(resource.RLIMIT_CORE)==(0,0),'CORE_LIMIT')
            check_testing(ROOT,recipe,True);check_outputs(ROOT,policy)
            handles={};child=None;pidfd=None;streams={};eofs={'stdout':False,'stderr':False};counts={'stdout':0,'stderr':0};hashes={k:hashlib.sha256() for k in counts};rc=None;started=None;start=time.monotonic();stop_reason=None
            try:
                for name in ('stdout','stderr'):
                    relative='run/'+spec['id']+'.'+name;need(relative in output_authority['files'],'LOG_NOT_APPROVED');handles[name]=os.open(ROOT/relative,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
                checkpoint();need(role_context is not None,'ADMISSION_MISSING');revalidate(role_context);checkpoint();need(time.monotonic()<deadline,'PRE_SPAWN_CAP')
                if spec['stage']=='test':set_phase('CTEST_ACTIVE',spec['id'])
                checkpoint();need(time.monotonic()<deadline,'PRE_SPAWN_CAP')
                child=subprocess.Popen(spec['argv'],cwd=spec['cwd'],env=spec['env'],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,close_fds=True,start_new_session=True)
                streams={child.stdout.fileno():'stdout',child.stderr.fileno():'stderr'}
                for fd in streams:os.set_blocking(fd,False)
                started=identity(child.pid);need(started and started['namespace'],'POST_SPAWN_IDENTITY');known[(started['pid'],started['start'])]=started;pidfd=os.pidfd_open(child.pid)
                checkpoint();need(time.monotonic()<deadline,'POST_SPAWN_CAP')
                while True:
                    checkpoint();need(time.monotonic()<deadline,'JOB_CAP');rc=child.poll();owned=inventory(known);reap(owned,child)
                    check_testing(ROOT,recipe,True);check_outputs(ROOT,policy)
                    if rc is not None and not streams and not inventory(known):break
                    rr,_,_=select.select(list(streams),[],[],min(.02,max(0,deadline-time.monotonic())))
                    for fd in rr:
                        name=streams[fd]
                        try:data=os.read(fd,8192)
                        except (BlockingIOError,InterruptedError):continue
                        if not data:eofs[name]=True;streams.pop(fd);continue
                        counts[name]+=len(data);aggregate+=len(data)
                        if counts[name]>LIMIT or aggregate>LIMIT:overflow=True;fail('TOOL_FAILED')
                        hashes[name].update(data);offset=0
                        while offset<len(data):checkpoint();n=os.write(handles[name],data[offset:]);need(n>0,'LOG_WRITE');offset+=n
                checkpoint();need(time.monotonic()<deadline,'JOB_DRAIN_CAP')
                if spec['stage']=='test':set_phase('POST_REAP',spec['id'])
                checkpoint();need(time.monotonic()<deadline,'JOB_DRAIN_CAP')
                for name,fd in list(handles.items()):os.fsync(fd);os.close(fd);del handles[name];checkpoint()
                custody.check_path(spec['argv'][0]);check_testing(ROOT,recipe,True);check_outputs(ROOT,policy);checkpoint();need(time.monotonic()<deadline,'JOB_POSTCHECK_CAP')
                result=dict(id=spec['id'],stage=spec['stage'],argv=spec['argv'],env=spec['env'],cwd=spec['cwd'],rc=rc,stdout=str(ROOT/'run'/(spec['id']+'.stdout')),stderr=str(ROOT/'run'/(spec['id']+'.stderr')),stdout_bytes=counts['stdout'],stdout_sha256=hashes['stdout'].hexdigest(),stderr_bytes=counts['stderr'],stderr_sha256=hashes['stderr'].hexdigest(),reaped=True,streams_eof=True,remaining_count=0,identity=public(started),start=start,end=time.monotonic(),effective_deadline=deadline,cleanup_verified=True,stop_reason=None,rlimit_core=dict(soft=0,hard=0))
                persist(spec['id']+'.json',result);checkpoint();need(time.monotonic()<deadline,'JOB_RESULT_CAP')
                encoded=json.dumps(result,separators=(',',':')).encode();need(metadata_bytes+len(encoded)<=LIMIT,'JOB_METADATA_QUOTA');metadata_bytes+=len(encoded);job_logs.append(result);next_job+=1
                frame['test_count']+=int(spec['stage']=='test');frame['parser_count']+=int(spec['stage']=='parser')
                return result
            except BaseException as exc:
                job_aborted=True;stop_reason=type(exc).__name__+':'+str(exc);first_detail=first_detail or violation_detail(exc)
                if first is None:
                    try:fail('WORK_DEADLINE' if time.monotonic()>=min(deadline,phaseD,D) else 'TOOL_FAILED')
                    except RuntimeError:pass
                close_end=begin_close();kill_at=min(time.monotonic()+1,close_end)
                while time.monotonic()<close_end:
                    owned=inventory(known)
                    for row in owned:signal_verified(row,signal.SIGTERM if time.monotonic()<kill_at else signal.SIGKILL)
                    if child is not None:rc=child.poll();reap(owned,child)
                    for fd in list(streams):
                        try:
                            data=os.read(fd,8192)
                            if not data:eofs[streams[fd]]=True;streams.pop(fd)
                            else:overflow=True;aggregate+=len(data);counts[streams[fd]]+=len(data)
                        except BlockingIOError:pass
                        except OSError:overflow=True;streams.pop(fd)
                    if (child is None or child.poll() is not None) and not streams and not inventory(known):break
                    time.sleep(min(.02,max(0,close_end-time.monotonic())))
                all_reaped=all_reaped and (child is None or child.poll() is not None);all_eof=all_eof and (all(eofs.values()) if child else True)
                negative=dict(id=spec['id'],stage=spec['stage'],rc=rc,reaped=child is None or child.poll() is not None,streams_eof=all(eofs.values()) if child else True,remaining_count=len(inventory(known)),capture_truncated=overflow,cleanup_verified=False,identified_work_closure='UNVERIFIED',first_error_code=first,first_error_detail=first_detail,start=start,end=time.monotonic(),effective_deadline=deadline,report_persistence='NOT_PERSISTED')
                # Closing time never grants extra report-writing authority.
                if time.monotonic()<min(D,phaseD):
                    try:
                        negative['report_persistence']='PERSISTED';persist(spec['id']+'.json',negative)
                    except BaseException:negative['report_persistence']='NOT_PERSISTED'
                job_logs.append(negative)
                raise
            finally:
                for fd in handles.values():
                    try:os.close(fd)
                    except OSError:pass
                if pidfd is not None:os.close(pidfd)
        phase='diagnostic';report=run(H,T,U,custody,persist,run_job,before_row)
        frame['campaign_status']=report['campaign_status'];frame['causal_gate']=report['causal_gate'];frame['custody_status']=report['custody_status'];frame['t_tests']=report.get('t_tests');frame['tests_deadline']=report.get('tests_deadline')
        if report['campaign_status']!='READY_FOR_D_REVIEW' and first is None:
            detail=report.get('first_error_code');first_detail=detail
            first=detail if detail in {'CUSTODY_FAILED','PRODUCT_SIGNATURE_DIVERGED','CONTROL_FAILED','OBSERVER_FAILED','TESTING_QUOTA','TOOL_FAILED','PERSISTENCE_FAILED','PARENT_LOST','WORK_DEADLINE','PROTOCOL_FAILED'} else 'DIAGNOSTIC_FAILED'
            begin_close()
        phase='persistence';checkpoint();persist('jobs.json',dict(schema_version=1,manifest_sha256=H,run_id=U,t0=T,jobs=job_logs,admissions=admissions,aggregate_captured_bytes=aggregate,first_error_code=first,first_error_detail=first_detail,rlimit_core=dict(soft=0,hard=0)))
        check_outputs(ROOT,policy);checkpoint()
    except BaseException as exc:
        if first is None:
            detail=violation_detail(exc) if 'violation_detail' in locals() else dict(code=type(exc).__name__,path=None)
            first_detail=first_detail or detail
            first=detail['code'] if detail['code'] in {'CUSTODY_FAILED','PRODUCT_SIGNATURE_DIVERGED','CONTROL_FAILED','OBSERVER_FAILED','TESTING_QUOTA','TOOL_FAILED','PERSISTENCE_FAILED','PARENT_LOST','WORK_DEADLINE','PROTOCOL_FAILED'} else ('BOOTSTRAP_FAILED' if phase=='bootstrap' else ('PERSISTENCE_FAILED' if phase=='persistence' else 'DIAGNOSTIC_FAILED'))
        begin_close();frame['campaign_status']='REJECTED';frame['causal_gate']='CLOSED_REJECTED';frame['custody_status']='UNVERIFIED'
    summaries={'custody-before.json','custody-after.json','matrix.json','testing-state.json','campaign.json','jobs.json'}
    frame['outputs']=[row for row in written.values() if row['name'] in summaries]
    remaining=[]
    if 'inventory' in locals():
        remaining=inventory(known)
        if remaining:
            end=begin_close();kill_at=min(time.monotonic()+1,end)
            while remaining and time.monotonic()<end:
                for row in remaining:signal_verified(row,signal.SIGTERM if time.monotonic()<kill_at else signal.SIGKILL)
                reap(remaining,None);remaining=inventory(known)
                if remaining:time.sleep(min(.02,max(0,end-time.monotonic())))
    frame.update(tools_reaped=all_reaped,tools_streams_eof=all_eof,remaining_identities_count=len(remaining),capture_truncated=overflow,identified_work_closure='OBSERVED' if all_reaped and all_eof and not remaining and not overflow and not job_aborted else 'UNVERIFIED',first_error_code=first)
    if first is not None:frame['campaign_status']='REJECTED';frame['causal_gate']='CLOSED_REJECTED'
    payload=json.dumps(frame,separators=(',',':'),allow_nan=False).encode();need(len(payload)<=4092,'FINAL_QUOTA');wire=len(payload).to_bytes(4,'little')+payload;offset=0;end=min(time.monotonic()+2,begin_close())
    while offset<len(wire) and time.monotonic()<end:
        _,ww,_=select.select([],[FF],[],min(.02,max(0,end-time.monotonic())))
        if ww:
            try:offset+=os.write(FF,wire[offset:])
            except (BlockingIOError,InterruptedError):pass
            except OSError:break
    os.close(FF)
    return 0 if offset==len(wire) and frame['campaign_status']=='READY_FOR_D_REVIEW' and frame['custody_status']=='VERIFIED' and frame['identified_work_closure']=='OBSERVED' and first is None else 2
if __name__=='__main__':sys.exit(runtime_main())

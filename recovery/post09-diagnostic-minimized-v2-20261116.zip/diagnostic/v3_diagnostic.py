"""Limited V3 driver. Static-only materialization; no process creation in this module.
run_job owns authenticated Popen, capture, reap and output persistence.
"""
import hashlib,json,os,stat,time,re
from pathlib import Path
import xml.etree.ElementTree as ET
ROOT=Path('/RELOCATE/diagnostic')
LIMIT=16777216
def _bounded_ascii(value,limit):
    text=str(value).encode('ascii','backslashreplace').decode('ascii')
    text=''.join(c if 32<=ord(c)<=126 else '\\x%02x'%ord(c) for c in text)
    return text[:limit]
class Rejected(RuntimeError):
    def __init__(self,code,path=None):
        self.code=_bounded_ascii(code,96);self.path=None if path is None else _bounded_ascii(path,240)
        super().__init__(self.code)
def violation_detail(exc):
    if isinstance(exc,Rejected):code=exc.code
    elif isinstance(exc,ValueError) and re.fullmatch(r'[A-Z][A-Z0-9_:-]{0,127}',str(exc),flags=re.ASCII):code=str(exc)
    elif isinstance(exc,OSError):code=type(exc).__name__+':errno='+str(exc.errno)
    else:code=type(exc).__name__
    path=getattr(exc,'path',None)
    if path is None and isinstance(exc,OSError):path=getattr(exc,'filename',None)
    return {'code':_bounded_ascii(code,96),'path':None if path is None else _bounded_ascii(path,240)}

def violation(code,path=None):raise Rejected(code,path)

def need(value,code):
    if not value:raise Rejected(code)
def unique(pairs):
    result={}
    for k,v in pairs:
        need(k not in result,'DUPLICATE_JSON');result[k]=v
    return result
def decode(raw):
    return json.loads(raw,object_pairs_hook=unique,parse_constant=lambda v: (_ for _ in ()).throw(Rejected('NONFINITE_JSON')))
def read(path,cap=LIMIT):
    path=Path(path)
    need(not any(p.is_symlink() for p in (path,*path.parents)),'SYMLINK')
    a=path.lstat();need(stat.S_ISREG(a.st_mode) and a.st_size<=cap,'FILE_TYPE_QUOTA')
    with path.open('rb') as f:data=f.read(cap+1)
    b=path.lstat();need(len(data)<=cap and (a.st_dev,a.st_ino,a.st_size,a.st_mtime_ns,a.st_ctime_ns)==(b.st_dev,b.st_ino,b.st_size,b.st_mtime_ns,b.st_ctime_ns),'UNSTABLE_READ')
    return data
def record(path,cap=LIMIT):
    data=read(path,cap);return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
# Process-lifetime presence ledger shared by all monitor calls; never cleared.
# Creators register immediately, so a later absence cannot be "not created yet".
_PRESENT_ROOTS={}
def _optional_roots():
    return {ROOT/'home',ROOT/'tmp',ROOT/'harness-Hc/Testing',ROOT/'harness-J/Testing'} | {ROOT/'run'/('ctest-'+t+'-'+str(i).zfill(2)) for t in ('Hc','J') for i in range(1,6)}
def _directory_identity(path):
    info=path.lstat()
    need(stat.S_ISDIR(info.st_mode) and not stat.S_ISLNK(info.st_mode),'OUTPUT_DIRECTORY')
    return (info.st_dev,info.st_ino,stat.S_IFMT(info.st_mode))
def _parent_valid(folder):
    need(folder==ROOT/'run' or folder in _optional_roots(),'UNAUTHORIZED_SCAN_ROOT')
    parent=folder.parent
    while True:
        _directory_identity(parent)
        if parent==ROOT:break
        need(parent!=parent.parent and ROOT in parent.parents,'OUTPUT_PARENT_SCOPE')
        parent=parent.parent
    # ROOT ancestors also must not redirect the authenticated package.
    for parent in ROOT.parents:_directory_identity(parent)
def register_output_root(folder):
    folder=Path(folder);_parent_valid(folder);identity=_directory_identity(folder)
    if folder in _PRESENT_ROOTS:need(_PRESENT_ROOTS[folder]==identity,'OUTPUT_ROOT_REPLACED')
    else:_PRESENT_ROOTS[folder]=identity
    return identity
# Closed V26 phase and per-cycle ledgers. Directory ledger above is never reset.
_PHASE='EXTERNAL';_ROW=None;_NEXT_ROW=0
_TEMP_IDENTITIES={};_EXTERNAL_LIVE={};_FROZEN_FILES={};_TESTING_FINALS={};_TEMP_EVENTS=[];_EVENT_BYTES=0
_SEALED_SNAPSHOTS={};_SNAPSHOT_BUILDING=None
_IDS=tuple('test-'+t+'-'+str(i).zfill(2) for t in ('Hc','J') for i in range(1,6))
_FINAL_NAMES=('LastTest.log','LastTestsFailed.log','CTestCostData.txt')
def temporal_state():
    return {'phase':_PHASE,'row':_ROW,'events':list(_TEMP_EVENTS),'next_row':_NEXT_ROW}
def classify_output(relative,authority):
    """One closed classifier used by walks, snapshots and final manifest enumeration."""
    parts=relative.split('/');result={'class':'ordinary','transient':False,'tree':None,'row':None,'destination':relative}
    if len(parts)==4 and parts[0] in ('harness-Hc','harness-J') and parts[1:3]==['Testing','Temporary']:
        name=parts[3];tree=parts[0][8:];result.update(tree=tree)
        if name in _FINAL_NAMES:result.update(**{'class':'testing-final','cap':8388608})
        elif name=='CTestCostData.txt.tmp':result.update(**{'class':'cost-temp','transient':True,'cap':8388608,'destination':parts[0]+'/cost'})
        elif name=='CTestCheckpoint.txt':result.update(**{'class':'checkpoint','transient':True,'cap':8388608,'destination':parts[0]+'/checkpoint'})
        elif re.fullmatch(r'LastTest[.]log[.]tmp[0-9a-f]{5}',name,flags=re.ASCII):result.update(**{'class':'main-temp','transient':True,'cap':8388608,'destination':parts[0]+'/main'})
        elif re.fullmatch(r'LastTestsFailed[.]log[.]tmp[0-9a-f]{5}',name,flags=re.ASCII):result.update(**{'class':'failure-temp','transient':True,'cap':8388608,'destination':parts[0]+'/failure'})
        else:violation('UNEXPECTED_TESTING_NAME',relative)
    elif len(parts)==2 and parts[0]=='run' and any(parts[1] in (i+'.xml',i+'.xml.tmp') for i in _IDS):
        row=next(i for i in _IDS if parts[1] in (i+'.xml',i+'.xml.tmp'))
        result.update(**{'class':'junit-temp' if parts[1].endswith('.tmp') else 'junit-final','transient':parts[1].endswith('.tmp'),'tree':row.split('-')[1],'row':row,'cap':16777216,'destination':row})
    elif len(parts)==3 and parts[0]=='run' and parts[1] in ('ctest-'+i[5:] for i in _IDS):
        if parts[2] not in _FINAL_NAMES:violation('SNAPSHOT_TRANSIENT_OR_NAME',relative)
        result.update(**{'class':'snapshot','cap':8388608,'row':'test-'+parts[1][6:]})
    else:
        if relative not in authority['files']:violation('UNEXPECTED_OUTPUT',relative)
        result['cap']=authority['files'][relative]
    return result

def _output_metadata(relative,info,authority):
    kind=classify_output(relative,authority)
    if not stat.S_ISREG(info.st_mode) or stat.S_ISLNK(info.st_mode) or info.st_nlink!=1:violation('OUTPUT_TYPE_OR_LINK_COUNT',relative)
    if info.st_size>kind['cap']:violation('OUTPUT_FILE_QUOTA',relative)
    return dict(bytes=info.st_size,device=info.st_dev,inode=info.st_ino,mtime_ns=info.st_mtime_ns,ctime_ns=info.st_ctime_ns,**kind)
def sealed_snapshot_state():
    return {directory:{path:dict(metadata) for path,metadata in files.items()} for directory,files in _SEALED_SNAPSHOTS.items()}
def _snapshot_subset(entries,directory):
    return {path:dict(metadata) for path,metadata in entries.items() if metadata['class']=='snapshot' and str(Path(path).parent)==directory}
def _validate_snapshot_seals(entries):
    # Verify before any monitor ledger updates; never adopt newly observed paths.
    for directory,expected in _SEALED_SNAPSHOTS.items():
        if _snapshot_subset(entries,directory)!=expected:violation('SEALED_SNAPSHOT_CHANGED',directory)
    if _PHASE!='EXTERNAL':
        for path,metadata in entries.items():
            if metadata['class']=='snapshot':
                directory=str(Path(path).parent)
                if directory not in _SEALED_SNAPSHOTS and directory!=_SNAPSHOT_BUILDING:violation('UNSEALED_SNAPSHOT_OUTPUT',path)

def _walk(folder,allowed_dirs,authority,optional=False):
    folder=Path(folder);entries={};total=0;_parent_valid(folder)
    need(type(optional) is bool and (not optional or folder in _optional_roots()),'OPTIONAL_ROOT_AUTHORITY')
    try:initial=_directory_identity(folder)
    except FileNotFoundError:
        need(optional and folder not in _PRESENT_ROOTS,'REQUIRED_OUTPUT_ROOT_MISSING');_parent_valid(folder);return entries,total
    register_output_root(folder);visited=False
    def walk_error(error):raise error
    for current,dirs,files in os.walk(folder,followlinks=False,onerror=walk_error):
        path=Path(current)
        if path==folder:visited=True
        need(str(path.relative_to(ROOT)) in allowed_dirs,'UNEXPECTED_DIRECTORY')
        if path==ROOT/'run' or path in _optional_roots():register_output_root(path)
        for name in dirs:
            child=path/name;need(not child.is_symlink() and stat.S_ISDIR(child.lstat().st_mode) and str(child.relative_to(ROOT)) in allowed_dirs,'UNEXPECTED_DIRECTORY')
            if child in _optional_roots():register_output_root(child)
        for name in files:
            child=path/name;rel=str(child.relative_to(ROOT));info=child.lstat()
            entries[rel]=_output_metadata(rel,info,authority);total+=info.st_size
    need(visited and _directory_identity(folder)==initial,'OUTPUT_ROOT_SCAN_INCOMPLETE_OR_REPLACED');_parent_valid(folder)
    return entries,total

def _validate_table(entries,authority,terminal):
    global _EVENT_BYTES
    _validate_snapshot_seals(entries)
    transients={p:m for p,m in entries.items() if m['transient']};destinations={}
    if len(transients)>5:violation('TRANSIENT_GLOBAL_CARDINALITY')
    for path,row in transients.items():
        key=(row['class'],row['destination']);destinations[key]=destinations.get(key,0)+1
        if destinations[key]>1:violation('TRANSIENT_DESTINATION_CARDINALITY',path)
        if terminal or _PHASE not in ('EXTERNAL','CTEST_ACTIVE'):violation('TRANSIENT_OUTSIDE_ACTIVE',path)
        if _PHASE=='CTEST_ACTIVE' and (row['tree']!=_ROW.split('-')[1] or row['class']=='junit-temp' and row['row']!=_ROW):violation('TRANSIENT_WRONG_ROW',path)
    if sum(x['class']=='junit-temp' for x in transients.values())>1:violation('JUNIT_TEMP_CARDINALITY')
    testing=sum(m['bytes'] for p,m in entries.items() if p.startswith('harness-') or m['class']=='snapshot')
    junit=sum(m['bytes'] for m in entries.values() if m['class'] in ('junit-final','junit-temp'))
    if testing>authority['quotas']['testing_live_and_snapshots_bytes']:violation('TESTING_AGGREGATE_QUOTA')
    if junit>authority['quotas']['junit_final_and_temporary_bytes']:violation('JUNIT_AGGREGATE_QUOTA')
    # Parent has no row channel. Only an observed disappearance retires its
    # temporary cycle. Worker retains same-name identities until next PRE_CTEST.
    ledger=_EXTERNAL_LIVE if _PHASE=='EXTERNAL' else _TEMP_IDENTITIES
    if _PHASE=='EXTERNAL':
        for path in set(ledger)-set(transients):del ledger[path]
    for path,row in transients.items():
        identity=(row['device'],row['inode'])
        if path in ledger and ledger[path]!=identity:violation('TRANSIENT_IDENTITY_CHANGED',path)
        if path not in ledger:
            ledger[path]=identity
            if _PHASE!='EXTERNAL':
                event=dict(row=_ROW,phase=_PHASE,path=path,kind=row['class'],device=row['device'],inode=row['inode'],bytes=row['bytes'])
                size=len(json.dumps(event,separators=(',',':')).encode())
                need(_EVENT_BYTES+size<=LIMIT,'TRANSIENT_EVENT_QUOTA');_EVENT_BYTES+=size;_TEMP_EVENTS.append(event)
    if _PHASE!='EXTERNAL':
        if _ROW is not None:
            for path,row in entries.items():
                if row['class'] in ('junit-final','snapshot') and _IDS.index(row['row'])>_IDS.index(_ROW):violation('FUTURE_ROW_OUTPUT',path)
        active_tree=_ROW.split('-')[1] if _PHASE=='CTEST_ACTIVE' else None
        expected_finals={p:r for p,r in _TESTING_FINALS.items() if r['tree']!=active_tree}
        observed_finals={p:r for p,r in entries.items() if r['class']=='testing-final' and r['tree']!=active_tree}
        if expected_finals!=observed_finals:violation('TESTING_FINAL_CHANGED_OUTSIDE_ACTIVE_ARM')
        for path,pin in _FROZEN_FILES.items():
            if path not in entries or entries[path]!=pin:violation('PREVIOUS_FINAL_MUTATED',path)
    return testing,junit,transients

def check_outputs(P,policy=None,terminal=False):
    need(Path(P)==ROOT and type(terminal) is bool,'ROOT');authority=decode(read(ROOT/'outputs.json'));need(authority['root']==str(ROOT),'OUTPUT_ROOT')
    directories=set(authority['directories']);entries={};total=0
    for rel in authority['mutable_roots']:
        found,size=_walk(ROOT/rel,directories,authority,optional=rel!='run');entries.update(found);total+=size
    if total>authority['quotas']['package_output_bytes']:violation('PACKAGE_OUTPUT_QUOTA')
    testing,junit,transients=_validate_table(entries,authority,terminal)
    if terminal:
        for path in entries:
            if path.endswith('.tmp'):violation('UNFINISHED_METADATA_TEMPORARY',path)
    return dict(bytes=total,files=entries,temporaries=sorted(set(transients)|{p for p in entries if p.endswith('.tmp')}),ctest_transients=sorted(transients),testing_bytes=testing,junit_bytes=junit,phase=_PHASE,row=_ROW)
def check_testing(P,recipe,include_snapshots=True,terminal=False):
    need(Path(P)==ROOT and recipe['root']==str(ROOT),'ROOT')
    # One full scan prevents the Testing and output monitors disagreeing about
    # JUnit, cardinality, identity cycles or global package quota.
    complete=check_outputs(P,terminal=terminal)
    entries={p:m for p,m in complete['files'].items() if p.startswith('harness-') or include_snapshots and m['class']=='snapshot'}
    return dict(bytes=sum(x['bytes'] for x in entries.values()),files=entries,ctest_transients=complete['ctest_transients'],junit_bytes=complete['junit_bytes'],phase=_PHASE,row=_ROW)

def set_phase(phase,row_id=None):
    global _PHASE,_ROW,_NEXT_ROW
    need(phase in ('PRE_CTEST','CTEST_ACTIVE','POST_REAP','PARSER','BETWEEN_ROWS','CLOSING','FINAL'),'PHASE')
    if phase in ('CLOSING','FINAL'):
        check_outputs(ROOT,terminal=True);_PHASE=phase;return
    need(row_id in _IDS,'PHASE_ROW')
    if phase=='PRE_CTEST':
        need(_PHASE in ('EXTERNAL','BETWEEN_ROWS') and _NEXT_ROW<len(_IDS) and row_id==_IDS[_NEXT_ROW],'PHASE_ORDER')
        check_outputs(ROOT,terminal=True);need(not (ROOT/'run'/(row_id+'.xml')).exists(),'CURRENT_JUNIT_EXISTS')
        _TEMP_IDENTITIES.clear();_ROW=row_id;_PHASE=phase;return
    need(row_id==_ROW,'PHASE_ROW_CHANGED')
    allowed={'CTEST_ACTIVE':('PRE_CTEST',),'POST_REAP':('CTEST_ACTIVE','POST_REAP'),'PARSER':('POST_REAP',),'BETWEEN_ROWS':('PARSER',)}
    need(_PHASE in allowed[phase],'PHASE_TRANSITION')
    if phase!='CTEST_ACTIVE':
        current=check_outputs(ROOT,terminal=True)
        if phase=='POST_REAP':
            _TESTING_FINALS.clear();_TESTING_FINALS.update({p:dict(r) for p,r in current['files'].items() if r['class']=='testing-final'})
        if phase in ('PARSER','BETWEEN_ROWS'):
            for path,record in current['files'].items():
                if record['class']=='junit-final' and record['row']==_ROW:_FROZEN_FILES[path]=dict(record)
    _PHASE=phase
    if phase=='BETWEEN_ROWS':_NEXT_ROW+=1

def _live(recipe):
    state={}
    for tree in ('Hc','J'):
        for name in recipe['testing_basenames']:
            p=ROOT/('harness-'+tree)/'Testing/Temporary'/name
            if p.exists() or p.is_symlink():state[str(p.relative_to(ROOT))]=record(p,8388608)
            else:state[str(p.relative_to(ROOT))]=None
    return state
def _snapshot(row,recipe,deadline):
    global _SNAPSHOT_BUILDING
    need(time.monotonic()<deadline,'TESTS_DEADLINE')
    need(_PHASE=='POST_REAP' and _ROW==row['id'] and row['id'] in _IDS,'SNAPSHOT_PHASE')
    destination=Path(row['snapshot_dir']);directory='run/ctest-'+row['id'][5:]
    need(destination==ROOT/directory and _SNAPSHOT_BUILDING is None and directory not in _SEALED_SNAPSHOTS,'SNAPSHOT_CONSTRUCTION_STATE')
    need(not destination.exists() and not destination.is_symlink(),'SNAPSHOT_EXISTS')
    need(tuple(recipe['testing_basenames'])==_FINAL_NAMES,'SNAPSHOT_BASENAMES')
    authority=decode(read(ROOT/'outputs.json'));expected={};result={}
    _SNAPSHOT_BUILDING=directory
    try:
        destination.mkdir(mode=0o700);register_output_root(destination)
        for name in _FINAL_NAMES:
            need(time.monotonic()<deadline,'TESTS_DEADLINE');source=ROOT/('harness-'+row['tree'])/'Testing/Temporary'/name
            if not source.exists():need(not source.is_symlink(),'TESTING_SYMLINK');result[name]=None;continue
            raw=read(source,8388608)
            current=check_testing(ROOT,recipe)['bytes'];need(current+len(raw)<=recipe['quotas']['testing_live_and_snapshots_bytes'],'TESTING_SNAPSHOT_QUOTA')
            target=destination/name;relative=str(target.relative_to(ROOT))
            fd=os.open(target,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600)
            try:
                offset=0
                while offset<len(raw):
                    need(time.monotonic()<deadline,'TESTS_DEADLINE');n=os.write(fd,raw[offset:]);need(n>0,'SNAPSHOT_WRITE');offset+=n
                os.fsync(fd)
                own=_output_metadata(relative,os.fstat(fd),authority)
            finally:os.close(fd)
            need(time.monotonic()<deadline,'TESTS_DEADLINE')
            need(_output_metadata(relative,target.lstat(),authority)==own,'SNAPSHOT_OWN_WRITE_REPLACED')
            copied=read(target,8388608);need(copied==raw,'SNAPSHOT_CONTENT_CHANGED')
            need(_output_metadata(relative,target.lstat(),authority)==own,'SNAPSHOT_OWN_WRITE_CHANGED')
            expected[relative]=dict(own)
            result[name]=dict(bytes=len(copied),sha256=hashlib.sha256(copied).hexdigest())
            need(result[name]==record(source,8388608),'TESTING_CHANGED_DURING_SNAPSHOT')
        need(time.monotonic()<deadline,'TESTS_DEADLINE')
        complete=check_outputs(ROOT)
        need(time.monotonic()<deadline,'TESTS_DEADLINE')
        need(_snapshot_subset(complete['files'],directory)==expected,'SNAPSHOT_EXACT_SET_MISMATCH')
        need(directory not in _SEALED_SNAPSHOTS,'SNAPSHOT_ALREADY_SEALED')
        _SEALED_SNAPSHOTS[directory]={path:dict(metadata) for path,metadata in expected.items()}
        return result
    finally:
        # A failed partial is never sealed, removed or retried. Prior seals survive.
        _SNAPSHOT_BUILDING=None

def observed_job(result):
    need(result.get('reaped') is True and result.get('streams_eof') is True and result.get('cleanup_verified') is True and type(result.get('remaining_count')) is int and result['remaining_count']==0,'JOB_CLOSURE_UNVERIFIED')
    need(type(result.get('rc')) is int,'JOB_RC_TYPE')

def observe_signature(row,result,historical):
    observed_job(result);raw=read(row['junit']);need(b'<!DOCTYPE' not in raw and b'<!ENTITY' not in raw,'XML_DECLARATION')
    root=ET.fromstring(raw);cases=root.findall('.//testcase');need(len(cases)==1 and cases[0].get('name')==row['name'],'TEST_NOT_EXACTLY_ONE');case=cases[0]
    need(case.find('skipped') is None and case.find('error') is None,'SKIP_OR_INFRASTRUCTURE')
    failure=case.find('failure');text='' if failure is None else ET.tostring(failure,encoding='unicode')
    need(case.get('status','run').lower() not in ('notrun','disabled') and not any(s in text for s in ('Not Run','Unable to find executable','Failed to change working directory')),'TEST_NOT_EXECUTED')
    status='PASS' if failure is None else ('TIMEOUT' if 'Timeout' in text else ('ABORT' if 'Subprocess aborted' in text or 'Exception' in text else 'FAIL'))
    need(result['rc'] in (0,8) and (status=='PASS')==(result['rc']==0),'CTEST_RC_STATUS_MISMATCH')
    matches=[x for x in historical if x['name']==row['name'] and ('test-'+row['tree']+'-') in x['path']];need(len(matches)==1,'HISTORICAL_SIGNATURE_NOT_UNIQUE');expected=matches[0]
    output=case.findtext('system-out') or '';attributes=None if failure is None else failure.attrib
    match=output==(expected.get('system_out') or '') and attributes==expected.get('failure') and case.get('status')==expected.get('status')
    return dict(product_status=status,signature_status='MATCH' if match else 'DIVERGED',historical_sha256=expected['sha256'],original_system_out=output,original_failure=attributes,normalization='NONE',junit_sha256=hashlib.sha256(raw).hexdigest(),ctest_rc=result['rc'],ctest_signal=None if result['rc']>=0 else -result['rc'],executable_signal='UNOBSERVED',assertions_not_emitted='UNOBSERVED',stdout=result['stdout'],stderr=result['stderr'])

def observe_parser(row,result):
    observed_job(result);report=decode(read(row['parser_output']))
    need(result['rc']==0 and all(report.get(k) is True for k in ('syntax_valid','protocol_valid','capture_complete','target_correlation_valid','observer_complete','not_a_product_test_verdict')) and report.get('missing_cases')==[],'OBSERVER_INCOMPLETE')
    close=report.get('close_evidence');need(type(close) is dict and close.get('record_valid') is True and close.get('positive') is True and type(close.get('data_close_rc')) is int and close['data_close_rc']==0,'CLOSE_STATUS_INVALID')
    need(type(report.get('test_id')) is int and type(report.get('tree_id')) is int and report['test_id']==row['test_id'] and report['tree_id']==row['tree_id'],'OBSERVER_IDENTITY')
    if row['test_id'] in (4,5):need(all(s['summary']['case_id']==0 for s in report['slots']),'CONTROL_SCOPES')
    return dict(observer_status='COMPLETE',observer_report_sha256=record(row['parser_output'])['sha256'],close_evidence=close,observer_coverage=report['slots'])

def run(H,T,U,custody,persist,run_job,before_row):
    recipe=decode(read(ROOT/'v3-recipe.json'));historical=decode(read(ROOT/'signatures-09.json'))
    need(recipe['root']==str(ROOT) and len(recipe['rows'])==10,'RECIPE')
    matrix=[dict(id=r['id'],tree=r['tree'],name=r['name'],product_status='NOT_RUN',signature_status='NOT_RUN',observer_status='NOT_RUN',post_row_custody='NOT_RUN',testing_snapshot='NOT_RUN',custody_status='UNVERIFIED',identified_work_closure='UNVERIFIED') for r in recipe['rows']]
    report=dict(schema_version=1,manifest_sha256=H,run_id=U,t0=T,campaign_status='REJECTED',causal_gate='CLOSED_AWAITING_D',custody_status='UNVERIFIED',first_error_code=None,matrix=matrix,G1='NOT_PASSED',coverage_complete=False,product_attribution='UNDETERMINED',Hc_is_H_plus_A=True,environment_equivalence_to_09='NOT_PROVEN',V3_followup='CLOSED_AWAITING_D',OFF_ON_G2='CLOSED')
    deadline=T+900;t_tests=None;previous=None;completed=0;first=None;after_attempted=False
    def budget():need(time.monotonic()<deadline,'TESTS_OR_WORK_DEADLINE')
    def save():
        budget();persist('matrix.json',dict(schema_version=1,manifest_sha256=H,run_id=U,matrix=matrix,first_error_code=first,causal_gate=report['causal_gate']));budget()
    try:
        before=custody.before();need(before.get('status')=='VERIFIED','CUSTODY_BEFORE');need(time.monotonic()<T+60,'PREPARATION_DEADLINE')
        check_outputs(ROOT);check_testing(ROOT,recipe);previous=_live(recipe);need(all(v is None for v in previous.values()),'TESTING_NOT_EMPTY_INITIAL')
        t_tests=time.monotonic();deadline=min(t_tests+900,T+900);custody.set_deadline(deadline)
        report.update(t_tests=t_tests,tests_deadline=deadline)
        for row,state in zip(recipe['rows'],matrix):
            budget();need(first is None,'REJECTION_LATCH');set_phase('PRE_CTEST',row['id']);check_outputs(ROOT);check_testing(ROOT,recipe);need(_live(recipe)==previous,'TESTING_STATE_DRIFT')
            custody.before_row(row);before_row(row,deadline,t_tests);budget()
            for path in (row['junit'],row['observer'],row['close_status'],row['parser_output']):need(not Path(path).exists() and not Path(path).is_symlink(),'ROW_OUTPUT_PREEXISTS')
            state['post_row_custody']='NOT_VERIFIED';state['testing_snapshot']='NOT_VERIFIED'
            result=run_job(row['ctest'],min(time.monotonic()+120,deadline));observed_job(result);set_phase('POST_REAP',row['id']);budget()
            state['identified_work_closure']='OBSERVED'
            # Observe preserved inputs immediately after CTest reap, even if signature diverges.
            custody.after_row(row);state['custody_status']='VERIFIED';state['post_row_custody']='VERIFIED';budget()
            snapshots=_snapshot(row,recipe,deadline);state['testing_snapshot']='CAPTURED';previous=_live(recipe)
            persist('testing-state.json',dict(manifest_sha256=H,run_id=U,last_row=row['id'],snapshots=snapshots,live=previous,quota=check_testing(ROOT,recipe),temporal_observations=temporal_state(),sealed_snapshots=sealed_snapshot_state()));budget()
            state.update(observe_signature(row,result,historical))
            need(row['test_id'] not in (4,5) or state['product_status']=='PASS','CONTROL_FAILED')
            need(state['signature_status']=='MATCH','PRODUCT_SIGNATURE_DIVERGED')
            inputs={row['observer']:record(row['observer'],8388608),row['close_status']:record(row['close_status'],80)};need(inputs[row['close_status']]['bytes']==80,'CLOSE_SIZE')
            set_phase('PARSER',row['id'])
            parsed=run_job(row['parser'],min(time.monotonic()+15,deadline));observed_job(parsed);budget()
            for path,pin in inputs.items():need(record(path,8388608 if path==row['observer'] else 80)==pin,'OBSERVER_INPUT_MUTATED')
            state.update(observe_parser(row,parsed));state['observer_inputs']=inputs
            check_outputs(ROOT);check_testing(ROOT,recipe);completed+=1;set_phase('BETWEEN_ROWS',row['id']);state['analysis_eligibility']='ROW_CHECKS_SATISFIED';save()
        set_phase('CLOSING');after_attempted=True;after=custody.after();budget();need(after.get('status')=='VERIFIED','CUSTODY_AFTER');report['custody_status']='VERIFIED'
        state_outputs=check_outputs(ROOT);need(not state_outputs['temporaries'],'UNFINISHED_TEMPORARIES');budget()
        need(completed==10,'MISSING_ROWS');report['campaign_status']='READY_FOR_D_REVIEW'
    except BaseException as exc:
        first=first or (str(exc) if isinstance(exc,Rejected) else type(exc).__name__+':'+str(exc))
        report.update(campaign_status='REJECTED',causal_gate='CLOSED_REJECTED',first_error_code=first)
        report['failure_custody_fallback']='NOT_VERIFIED'
        if not after_attempted and time.monotonic()<deadline:
            after_attempted=True
            try:
                after=custody.after();budget();report['custody_status']='VERIFIED' if after.get('status')=='VERIFIED' else 'UNVERIFIED';report['failure_custody_fallback']=report['custody_status']
            except BaseException:report['custody_status']='UNVERIFIED'
        if time.monotonic()<deadline:
            try:save()
            except BaseException:pass
    report.update(completed=completed,t_tests=t_tests,tests_deadline=deadline,first_error_code=first,temporal_observations=temporal_state(),sealed_snapshots=sealed_snapshot_state())
    # No late successful persistence in the closing reserve.
    try:
        budget();persist('campaign.json',report);budget()
    except BaseException as exc:
        report.update(campaign_status='REJECTED',causal_gate='CLOSED_REJECTED')
        raise Rejected(first or ('FINAL_PERSISTENCE_FAILED:'+type(exc).__name__)) from exc
    return report

# Minimized diagnostic source update

Source templates only: validation, preparation, read-only verification, diagnostic driver and CTest harness definitions. This is an incremental source-only update, not runtime evidence or a complete executable environment.

Internal machine paths are replaced by /RELOCATE placeholders, including numbered reference placeholders. Original environment snapshots, source path mapping, session/process records, policies, recipes, plans, reviews, coordination notes, binary/build artifacts and logs are deliberately excluded. Reconstruct local configuration and reference inputs and independently revalidate all hashes, contracts and permissions before use. These templates must not be treated as ready to run. No product acceptance or gate success is asserted.

Python parsing and archive-integrity checks are packaging checks only, not behavioral validation. Generic environment keys and standard system paths retained within code are programming logic, not captured environment values.

Anonymized source templates:
- validation/mutate_observer_fixture.py
- validation/outer_supervisor.py
- validation/external_supervisor.py
- validation/external_collector.py
- validation/concurrency_preflight.py
- validation/validation_launcher.py
- validation/external_contract.py
- validation/external_writer.py
- validation/closure_observer.py
- preparation/prep_guard.py
- preparation/prep_concurrency.py
- preparation/prep_external_supervisor.py
- preparation/prep_external_contract.py
- preparation/concurrency_preflight.py
- preparation/prep_collector.py
- preparation/prep_watchdog.py
- preparation/prep_closure_observer.py
- preparation/prep_entry.py
- preparation/prep_outer_supervisor.py
- preparation/prep_writer.py
- verification/readonly_comparability.py
- verification/readonly_supervisor.py
- verification/readonly_custody.py
- verification/readonly_worker.py
- verification/readonly_concurrency.py
- diagnostic/readonly_supervisor.py
- diagnostic/readonly_custody.py
- diagnostic/v3_diagnostic.py
- diagnostic/readonly_worker.py
- diagnostic/readonly_concurrency.py
- diagnostic/harness-Hc/CTestTestfile.cmake
- diagnostic/harness-J/CTestTestfile.cmake

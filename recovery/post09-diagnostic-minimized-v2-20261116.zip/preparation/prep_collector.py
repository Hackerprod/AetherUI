import sys, os, json, hashlib, stat, re, time
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
EXPECTED_ROOT=Path('/RELOCATE/preparation')
def authenticate(approved):
    if ROOT!=EXPECTED_ROOT or not re.fullmatch('[0-9a-f]{64}',approved):raise ValueError('ROOT_OR_AUTHORITY')
    def unique(items):
        d={}
        for k,v in items:
            if k in d:raise ValueError('DUPLICATE')
            d[k]=v
        return d
    def plain(p):
        for a in [p,*p.parents]:
            if a.is_symlink():raise ValueError('SYMLINK')
        if not stat.S_ISREG(p.lstat().st_mode):raise ValueError('NOT_REGULAR')
        return p.read_bytes()
    raw=plain(ROOT/'evidence.sha256.json')
    if hashlib.sha256(raw).hexdigest()!=approved:raise ValueError('UNAPPROVED')
    rows=json.loads(raw,object_pairs_hook=unique,parse_constant=lambda value: (_ for _ in ()).throw(ValueError('NONFINITE_JSON'))); seen=set()
    if type(rows) is not list:raise ValueError('MANIFEST_SCHEMA')
    for row in rows:
        if type(row) is not dict or set(row)!={'path','bytes','sha256'} or type(row['bytes']) is not int or row['bytes']<0 or type(row['sha256']) is not str or not re.fullmatch('[0-9a-f]{64}',row['sha256']):raise ValueError('MANIFEST_ROW')
        name=row['path']
        if not isinstance(name,str) or name.startswith('/') or any(s in ('','.','..') for s in name.split('/')) or '\\' in name or '\x00' in name or name in seen:raise ValueError('PATH')
        seen.add(name); data=plain(ROOT/name)
        if len(data)!=row['bytes'] or hashlib.sha256(data).hexdigest()!=row['sha256']:raise ValueError('CONTENT')
    if not {'prep_collector.py','prep_external_supervisor.py','prep_writer.py','prep_external_contract.py','prep-external-recipe.json','prep_entry.py','prep_concurrency.py'}<=seen:raise ValueError('MISSING_MODULE')
    if 'policy.json' not in seen:raise ValueError('MISSING_TOOL_POLICY')
    policy=json.loads(plain(ROOT/'policy.json'),object_pairs_hook=unique,parse_constant=lambda value: (_ for _ in ()).throw(ValueError('NONFINITE_JSON')))
    record=policy['tools']['python3']
    expected='/RELOCATE/python3'
    if record['path']!=expected or not re.fullmatch('[0-9a-f]{64}',record['sha256']):raise ValueError('INTERPRETER_AUTHORITY')
    resolved=Path(expected).resolve(strict=True)
    if Path(sys.executable).resolve(strict=True)!=resolved or Path('/proc/self/exe').resolve(strict=True)!=resolved:raise ValueError('INTERPRETER_IDENTITY')
    executable=plain(resolved)
    if hashlib.sha256(executable).hexdigest()!=record['sha256']:raise ValueError('INTERPRETER_CONTENT')

def validate_frame(raw,approved,runid,t0,rc):
    from prep_external_contract import unique,validate_entry
    if len(raw)<4 or not 2<=int.from_bytes(raw[:4],'little')<=2048 or len(raw)!=4+int.from_bytes(raw[:4],'little'):raise ValueError('FRAME_LENGTH')
    value=json.loads(raw[4:],object_pairs_hook=unique,parse_constant=lambda value: (_ for _ in ()).throw(ValueError('NONFINITE_JSON')))
    validate_entry(value,ROOT,approved,runid,t0,rc)
    return value

def main():
    if len(sys.argv)!=11 or sys.argv[1::2]!=['--manifest-sha256','--origin-monotonic','--run-id','--registration-fd','--registration-ack-fd']:raise ValueError('ARGV')
    approved=sys.argv[2];t0=float(sys.argv[4]);runid=sys.argv[6];registration_fd=int(sys.argv[8]);registration_ack_fd=int(sys.argv[10]);authenticate(approved)
    if not 0<=time.monotonic()-t0<4500 or not re.fullmatch('[0-9a-f]{32}',runid):raise ValueError('EXTERNAL_ORIGIN')
    import subprocess,select,signal,ctypes,base64
    from prep_external_contract import PYTHON,identity,same,discover,kill_verified,reap,spawn_budget,check_spawn,directory_identity,check_directories,validate_directory,namespace_identity,validate_identity
    from prep_concurrency import capture_role,ns
    policy=json.loads((ROOT/'policy.json').read_bytes(),object_pairs_hook=lambda pairs: dict(pairs))
    if time.monotonic()>=t0+4500:raise ValueError('BOOTSTRAP_TOO_SLOW')
    if ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)!=0:raise RuntimeError('SUBREAPER_FAILED')
    directory_identity(ROOT/'run')  # reject symlink before creating either directory
    directory=ROOT/'run'/'external-output'/runid
    owner=identity(os.getpid()); ready_r,ready_w=os.pipe2(os.O_CLOEXEC|os.O_NONBLOCK)
    parent=identity(os.getppid());parentfd=os.pidfd_open(os.getppid());supervisor_deadline=spawn_budget(t0)
    check_spawn(supervisor_deadline,parent)
    supervisor_argv=[PYTHON,'-B',str(ROOT/'prep_external_supervisor.py'),approved,repr(t0),str(owner['pid']),owner['start'],str(ready_w)]
    supervisor=subprocess.Popen(supervisor_argv,pass_fds=(ready_w,),close_fds=True,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    supervisor_initial=identity(supervisor.pid);supervisor_pidfd=os.pidfd_open(supervisor.pid)
    check_spawn(supervisor_deadline,parent)
    if supervisor_initial is None:raise ValueError('SUPERVISOR_IDENTITY')
    known={};children=[]
    guard_state={'external_supervisor_initial_identity':supervisor_initial,
                 'external_guard_lost':False,'external_guard_failure_stage':None,
                 'external_supervisor_rc_observed':None,'external_guard_last_check_monotonic':None}
    class GuardLost(Exception):pass
    def guard_fields():return dict(guard_state)
    def lose_guard(stage):
        if not guard_state['external_guard_lost']:
            guard_state['external_guard_lost']=True
            guard_state['external_guard_failure_stage']=stage
        raise GuardLost('EXTERNAL_GUARD_LOST')
    def check_external_guard(stage):
        if guard_state['external_guard_lost']:raise GuardLost('EXTERNAL_GUARD_LOST')
        now=time.monotonic();rc=supervisor.poll();current=identity(supervisor.pid)
        parent_current=identity(parent['pid']) if parent else None
        if select.select([parentfd],[],[],0)[0] or os.getppid()!=parent['pid'] or parent is None or not same(parent) or parent_current is None or parent_current['state'] in ('Z','X','x'):lose_guard('observer_parent_lost')
        guard_state['external_guard_last_check_monotonic']=now
        guard_state['external_supervisor_rc_observed']=rc
        if select.select([supervisor_pidfd],[],[],0)[0] or rc is not None or supervisor_initial is None or current is None or current['start']!=supervisor_initial['start'] or current['state'] in ('Z','X','x'):
            lose_guard(stage)
    def guarded_run():
        os.close(ready_w); ready=b'';ready_eof=False
        while time.monotonic()<supervisor_deadline:
            check_external_guard('ready_wait')
            r,_,_=select.select([ready_r],[],[],.02)
            if r:
                part=os.read(ready_r,32);ready+=part
                if len(ready)>6:raise ValueError('READY_EXTRA')
                if not part:ready_eof=True;break
            if supervisor.poll() is not None:break
        os.close(ready_r)
        if ready!=b'READY\n' or not ready_eof:
            lose_guard('ready_protocol')
        check_external_guard('ready');check_spawn(supervisor_deadline,parent)
        supervisor_role=capture_role(policy,approved,'external-supervisor',supervisor.pid,supervisor_argv)
        # V14 registration handshake, before launcher/final-pipe creation.
        for fd in (registration_fd,registration_ack_fd):
            if not stat.S_ISFIFO(os.fstat(fd).st_mode) or os.fpathconf(fd,'PC_PIPE_BUF')<4096:raise RuntimeError('REGISTRATION_PIPE')
            os.set_inheritable(fd,False);os.set_blocking(fd,False)
        observer_pid=os.getppid();observer_identity=identity(observer_pid)
        if observer_identity is None:raise RuntimeError('OBSERVER_IDENTITY')
        observer_pidfd=os.pidfd_open(observer_pid)
        def record_identity(pid):
            row=identity(pid)
            if row is None:raise RuntimeError('REGISTRATION_IDENTITY')
            return {'pid':pid,'start':row['start'],'namespace':os.readlink('/proc/'+str(pid)+'/ns/pid')}
        registration={'schema_version':1,'kind':'COLLECTOR_REGISTRATION','manifest_sha256':approved,'run_id':runid,'t0':t0,'collector_identity':record_identity(os.getpid()),'supervisor_identity':record_identity(supervisor.pid),'external_supervisor_role':supervisor_role}
        regraw=json.dumps(registration,separators=(',',':')).encode();wire=len(regraw).to_bytes(4,'little')+regraw
        if len(wire)>4096:raise RuntimeError('REGISTRATION_QUOTA')
        until=min(supervisor_deadline,time.monotonic()+2);offset=0;ackraw=bytearray();ack_eof=False
        while time.monotonic()<until:
            check_external_guard('registration')
            if select.select([observer_pidfd],[],[],0)[0] or not same(observer_identity) or os.getppid()!=observer_pid:raise RuntimeError('OBSERVER_LOST')
            rr,ww,_=select.select([registration_ack_fd],[registration_fd] if offset<len(wire) else [],[],min(.02,max(0,until-time.monotonic())))
            if ww:
                try:offset+=os.write(registration_fd,wire[offset:])
                except (BlockingIOError,InterruptedError):pass
            if rr:
                part=os.read(registration_ack_fd,4097-len(ackraw));ackraw.extend(part)
                if not part:ack_eof=True;break
                if len(ackraw)>4096:raise RuntimeError('REGISTRATION_ACK_QUOTA')
                if len(ackraw)>=4 and int.from_bytes(ackraw[:4],'little')>4092:raise RuntimeError('REGISTRATION_ACK_LENGTH')
        expected_ack={'schema_version':1,'kind':'REGISTRATION_ACK','manifest_sha256':approved,'run_id':runid,'registration_sha256':hashlib.sha256(regraw).hexdigest()}
        from prep_external_contract import unique
        if not ack_eof or offset!=len(wire) or len(ackraw)<4 or len(ackraw)!=4+int.from_bytes(ackraw[:4],'little'):raise RuntimeError('REGISTRATION_ACK_INVALID')
        ack_value=json.loads(bytes(ackraw[4:]),object_pairs_hook=unique,parse_constant=lambda value: (_ for _ in ()).throw(ValueError('NONFINITE_JSON')))
        if type(ack_value) is not dict or set(ack_value)!=set(expected_ack)|{'run','concurrency_roles'}:raise RuntimeError('REGISTRATION_ACK_INVALID')
        run_identity=validate_directory(ack_value['run'],ROOT/'run')
        registry=ack_value['concurrency_roles']
        if type(registry) is not dict or set(registry)!={'namespaces','roles'} or registry['namespaces']!=ns(os.getpid()) or type(registry['roles']) is not list or [r.get('role') for r in registry['roles']]!=['outer','closure-observer','collector','external-supervisor']:raise ValueError('ACK_ROLES')
        own_argv=[PYTHON,'-B',str(ROOT/'prep_collector.py'),*sys.argv[1:]]
        if registry['roles'][2]!=capture_role(policy,approved,'collector',os.getpid(),own_argv) or registry['roles'][3]!=supervisor_role:raise ValueError('ACK_ROLE_PIN')
        expected_ack['run']=run_identity;expected_ack['concurrency_roles']=registry
        if type(ack_value) is not dict or ack_value!=expected_ack or type(ack_value.get('schema_version')) is not int:raise RuntimeError('REGISTRATION_ACK_INVALID')
        os.close(registration_fd);os.close(registration_ack_fd)
        check_spawn(supervisor_deadline,parent)
        (ROOT/'run'/'external-output').mkdir(mode=0o700);directory.mkdir(mode=0o700)
        pinned={str(path):directory_identity(path) for path in (ROOT/'run',ROOT/'run'/'external-output',directory)}
        if pinned[str(ROOT/'run')]!=run_identity:raise ValueError('RUN_CHAIN')
        check_directories(pinned)
        # Final descriptor cannot leak to supervisor: created only now. Popen closes
        # everything except this explicitly inherited descriptor for launcher.
        final_r,final_w=os.pipe2(os.O_CLOEXEC|os.O_NONBLOCK)
        if os.fpathconf(final_w,'PC_PIPE_BUF')<2052:raise RuntimeError('PIPE_BUF')
        entry_deadline=spawn_budget(t0)
        parent_ready_r,parent_ready_w=os.pipe2(os.O_CLOEXEC|os.O_NONBLOCK)
        if os.fpathconf(parent_ready_w,'PC_PIPE_BUF')<4096:raise ValueError('PARENT_READY_PIPE')
        ready_value={'schema_version':1,'type':'PREP_PARENT_READY','manifest_sha256':approved,'run_id':runid,'t0':t0,'spawn_deadline':entry_deadline,'parent':namespace_identity(os.getpid()),'run':run_identity,'concurrency_roles':registry}
        ready_payload=json.dumps(ready_value,separators=(',',':'),allow_nan=False).encode()
        ready_wire=len(ready_payload).to_bytes(4,'little')+ready_payload
        check_external_guard('before_parent_ready');check_spawn(entry_deadline,parent)
        if len(ready_wire)>4096 or os.write(parent_ready_w,ready_wire)!=len(ready_wire):raise ValueError('PARENT_READY_WRITE')
        os.close(parent_ready_w)
        argv=[PYTHON,'-B',str(ROOT/'prep_entry.py'),'--manifest-sha256',approved,'--origin-monotonic',repr(t0),'--run-id',runid,'--final-fd',str(final_w),'--parent-ready-fd',str(parent_ready_r)]
        check_external_guard('before_launcher')
        check_spawn(entry_deadline,parent)
        launcher=subprocess.Popen(argv,pass_fds=(final_w,parent_ready_r),close_fds=True,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        children.append(launcher)
        launch_identity=namespace_identity(launcher.pid);launch_pidfd=os.pidfd_open(launcher.pid);os.close(final_w);os.close(parent_ready_r)
        check_external_guard('after_entry_spawn');check_spawn(entry_deadline,parent)
        if launch_identity is None:raise ValueError('ENTRY_IDENTITY')
        streams={final_r:('final',2052),launcher.stdout.fileno():('stdout',65536),launcher.stderr.fileno():('stderr',65536)}
        for fd in streams:os.set_blocking(fd,False)
        buffers={key:bytearray() for key in ('final','stdout','stderr')};truncated=False;read_error=False;deadline_enforced=False;term=False;killed=False
        while time.monotonic()<t0+4770:
            check_external_guard('capture_loop')
            now=time.monotonic();rows=discover(os.getpid(),known,(supervisor.pid,))
            # poll performs waitpid(WNOHANG), regardless of pipe EOF.
            current_entry=identity(launcher.pid)
            if current_entry is not None and current_entry['start']!=launch_identity['start']:raise ValueError('ENTRY_IDENTITY_CHANGED')
            rc=launcher.poll()
            if now>=t0+4780:
                deadline_enforced=True;term=True
                for row in rows:kill_verified(row,signal.SIGTERM)
            if now>=t0+4790:
                killed=True
                for row in rows:kill_verified(row,signal.SIGKILL)
            if rc is not None:reap([row for row in rows if row['pid']!=launcher.pid])
            if rc is not None and not streams and not discover(os.getpid(),known,(supervisor.pid,)):break
            ready,_,_=select.select(list(streams),[],[],min(.02,max(0,t0+4770-time.monotonic())))
            for fd in ready:
                name,quota=streams[fd]
                try:chunk=os.read(fd,8192)
                except BlockingIOError:continue
                except OSError:read_error=True;streams.pop(fd);continue
                if not chunk:streams.pop(fd);continue
                room=max(0,quota-len(buffers[name]));buffers[name].extend(chunk[:room])
                if len(chunk)>room:truncated=True
        if time.monotonic()>=t0+4770:deadline_enforced=True
        check_external_guard('before_frame_acceptance')
        rc=launcher.poll();remaining=discover(os.getpid(),known,(supervisor.pid,));frame=None;frame_error=None
        try:frame=validate_frame(bytes(buffers['final']),approved,runid,t0,rc)
        except (ValueError,TypeError,KeyError,UnicodeError):frame_error='INVALID_OR_CONTRADICTORY_FRAME'
        raw_final=bytes(buffers['final']); frame_complete=(len(raw_final)>=4 and 2<=int.from_bytes(raw_final[:4],'little')<=2048 and len(raw_final)==4+int.from_bytes(raw_final[:4],'little') and not truncated)
        identity_match=bool(launch_identity and launch_identity['pid']==launcher.pid)
        # Identity was captured before polling; PID reuse never authorizes signalling.
        complete=bool(frame and frame['closure_status']=='INTERNAL_ACK_AND_REAP_OBSERVED' and rc is not None and identity_match and not streams and not remaining and not truncated and not read_error and not deadline_enforced)
        result={'schema_version':1,'manifest_sha256':approved,'run_id':runid,'origin_monotonic':t0,'launcher_rc':rc,'launcher_reaped':rc is not None,'launcher_identity':launch_identity,'directory_identities':pinned,'launcher_identity_match':identity_match,'final_frame_complete':frame_complete,'final_frame_valid':frame is not None,'frame':frame,'frame_error':frame_error,'capture_truncated':truncated,'capture_read_error':read_error,'pipes_eof':not streams,'deadline_enforced':deadline_enforced,'remaining_identities':remaining,'collector_outcome':'CAPTURE_AND_RETURN_OBSERVED' if complete else 'UNVERIFIED','external_closure_status':'CLOSURE_PENDING','stdout_base64':base64.b64encode(buffers['stdout']).decode(),'stderr_base64':base64.b64encode(buffers['stderr']).decode(),'not_tested':['kernel-blocked IO','transient adversarial descendants','physical durability','collector own reap','external supervisor own reap']}
        result.update(guard_fields())
        # Writer gets no final-channel descriptor; closed fd inheritance by default.
        for fd in list(streams):
            try:os.close(fd)
            except OSError:pass
        if time.monotonic()>=t0+4772:return 2
        check_external_guard('before_writer')
        check_directories(pinned)
        writer_deadline=min(spawn_budget(t0,2,4776),t0+4772)
        check_spawn(writer_deadline,parent)
        payload=json.dumps(result,separators=(',',':')).encode()
        if len(payload)>262144:raise ValueError('CAPTURE_QUOTA')
        writer=subprocess.Popen([PYTHON,'-B',str(ROOT/'prep_writer.py'),approved,repr(t0),runid],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,close_fds=True)
        children.append(writer)
        writer_identity=namespace_identity(writer.pid);writer_pidfd=os.pidfd_open(writer.pid)
        check_external_guard('after_writer_spawn');check_spawn(writer_deadline,parent)
        if writer_identity is None:raise ValueError('WRITER_IDENTITY')
        os.set_blocking(writer.stdin.fileno(),False);os.set_blocking(writer.stdout.fileno(),False)
        offset=0;receipt=bytearray();stdin_open=True;stdout_open=True
        while time.monotonic()<writer_deadline:
            check_external_guard('writer_loop')
            reads=[writer.stdout.fileno()] if stdout_open else []
            writes=[writer.stdin.fileno()] if stdin_open else []
            rr,ww,_=select.select(reads,writes,[],min(.02,max(0,writer_deadline-time.monotonic())))
            if ww:
                try:offset+=os.write(writer.stdin.fileno(),payload[offset:])
                except (BlockingIOError,InterruptedError):pass
                except BrokenPipeError:writer.stdin.close();stdin_open=False
                if stdin_open and offset==len(payload):writer.stdin.close();stdin_open=False
            if rr:
                try:part=os.read(writer.stdout.fileno(),4096)
                except BlockingIOError:part=None
                if part==b'':stdout_open=False
                elif part:
                    receipt.extend(part)
                    if len(receipt)>1024:break
            if writer.poll() is not None and not stdout_open:break
        check_external_guard('before_persistence_acceptance')
        check_directories(pinned)
        writer_rc=writer.poll()
        try:
            expected={'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest(),'writer_identity':writer_identity,'directory_identities_sha256':hashlib.sha256(json.dumps(pinned,sort_keys=True,separators=(',',':')).encode()).hexdigest()}
            receipt_value=json.loads(receipt,object_pairs_hook=unique,parse_constant=lambda value: (_ for _ in ()).throw(ValueError('NONFINITE_JSON')))
            receipt_valid=type(receipt_value) is dict and receipt_value==expected and type(receipt_value.get('bytes')) is int
            validate_identity(receipt_value['writer_identity'])
        except (KeyError,TypeError):receipt_valid=False
        except (ValueError,UnicodeError):receipt_valid=False
        persisted=writer_rc==0 and bool(select.select([writer_pidfd],[],[],0)[0]) and not stdout_open and not stdin_open and receipt_valid and offset==len(payload) and time.monotonic()<writer_deadline
        if not persisted:
            row=identity(writer.pid)
            if row:kill_verified(row,signal.SIGTERM)
            while time.monotonic()<t0+4790 and writer.poll() is None:
                check_external_guard('writer_term_wait')
                time.sleep(min(.02,max(0,t0+4790-time.monotonic())))
            row=identity(writer.pid)
            if row and writer.poll() is None:kill_verified(row,signal.SIGKILL)
            while time.monotonic()<t0+4800 and writer.poll() is None:
                check_external_guard('writer_kill_wait')
                time.sleep(min(.02,max(0,t0+4800-time.monotonic())))
        # No file IO after writer exit. stdout is bounded, nonblocking, advisory only.
        check_external_guard('before_summary')
        check_directories(pinned)
        summary={'run_id':runid,'collector_outcome':result['collector_outcome'],'writer_identity':writer_identity,'directory_identities':pinned,'writer_reaped':writer.poll() is not None,'writer_rc':writer.poll(),'writer_receipt_valid':persisted,'external_closure_status':'CLOSURE_PENDING','external_supervisor_identity':supervisor_initial,'external_supervisor_reaped':False,'capture_bytes':len(payload),'capture_sha256':hashlib.sha256(payload).hexdigest()}
        summary.update(guard_fields())
        if time.monotonic()<t0+4772:
            try:os.set_blocking(1,False);os.write(1,json.dumps(summary,separators=(',',':')).encode()+b'\n')
            except OSError:pass
        check_external_guard('before_return')
        return 0 if complete and persisted else 2
    try:return guarded_run()
    except Exception as closure_exception:
        guard_state['external_guard_lost']=True
        if guard_state['external_guard_failure_stage'] is None:guard_state['external_guard_failure_stage']='collector_exception'

        # Irreversible rejection, including loss after capture.json was written.
        # No new child, file IO, retry, or acceptance of earlier capture/receipt.
        lost_at=time.monotonic();kill_at=min(lost_at+1,t0+4790)
        while time.monotonic()<t0+4800:
            rows=discover(os.getpid(),known,(supervisor.pid,))
            for row in rows:kill_verified(row,signal.SIGTERM if time.monotonic()<kill_at else signal.SIGKILL)
            for child in children:child.poll()
            direct={child.pid for child in children}
            reap([row for row in rows if row['pid'] not in direct])
            if not discover(os.getpid(),known,(supervisor.pid,)):break
            time.sleep(min(.02,max(0,t0+4800-time.monotonic())))
        summary={'schema_version':1,'manifest_sha256':approved,'run_id':runid,
                 'collector_outcome':'UNVERIFIED','error_code':'EXTERNAL_GUARD_LOST',
                 'external_closure_status':'UNVERIFIED','prior_capture_valid_for_closure':False,
                 'writer_receipt_valid':False}
        summary.update(guard_fields())
        if time.monotonic()<t0+4772:
            try:
                os.set_blocking(1,False)
                os.write(1,json.dumps(summary,separators=(',',':')).encode()+b'\n')
            except OSError:pass
        return 2

if __name__=='__main__':sys.exit(main())

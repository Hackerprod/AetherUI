"""V19 ZERO_TESTS preparation entry. Static materialization, execution not authorized.
No Coordinator, candidate guard or product module is imported here.
"""
import os,sys,json,hashlib,stat,time,math,select,signal,subprocess,ctypes,re
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
EXPECTED_ROOT=Path('/RELOCATE/preparation')
IDS=('configure-Hc','configure-J','build-Hc','build-J','inventory-Hc','inventory-J','gate-inventory','gate-comparability')
STAGES=('configure','configure','build','build','inventory','inventory','inventory-gate','comparability')
CAPS=(120,120,1800,1800,120,120,120,120)
MODE='PREPARATION_ZERO_TESTS'
class Rejected(RuntimeError):pass

def need(ok,code):
    if not ok:raise Rejected(code)
def unique(items):
    d={}
    for k,v in items:need(k not in d,'DUPLICATE_JSON_KEY');d[k]=v
    return d
def parse(raw):return json.loads(raw,object_pairs_hook=unique,parse_constant=lambda x:(_ for _ in ()).throw(Rejected('NONFINITE_JSON')))
def sha(data):return hashlib.sha256(data).hexdigest()
def plain(path):
    path=Path(path)
    for p in (path,*path.parents):need(not p.is_symlink(),'SYMLINK')
    need(stat.S_ISREG(path.lstat().st_mode),'REGULAR_REQUIRED')
    return path.read_bytes()
def authenticate(approved):
    need(ROOT==EXPECTED_ROOT and isinstance(approved,str) and re.fullmatch('[0-9a-f]{64}',approved),'AUTHORITY')
    raw=plain(ROOT/'evidence.sha256.json');need(sha(raw)==approved,'MANIFEST_HASH');rows=parse(raw);need(type(rows) is list,'MANIFEST_LIST');names=set()
    for row in rows:
        need(type(row) is dict and set(row)=={'path','bytes','sha256'},'MANIFEST_ROW');name=row['path']
        need(type(name) is str and name and not name.startswith('/') and '\\' not in name and '\x00' not in name and all(x not in ('','.','..') for x in name.split('/')) and name not in names,'MANIFEST_PATH')
        names.add(name);data=plain(ROOT/name);need(type(row['bytes']) is int and len(data)==row['bytes'] and sha(data)==row['sha256'],'MEMBER_HASH')
    need({'prep_watchdog.py','prep_guard.py','prep_entry.py','policy.json','argv.json','manifest_contract.py','frozen_custody.py'}<=names,'MISSING_AUTHORITY')
    policy=parse(plain(ROOT/'policy.json'));tool=policy['tools']['python3'];real=Path(tool['path']).resolve(strict=True)
    need(Path(sys.executable).resolve(strict=True)==real and Path('/proc/self/exe').resolve(strict=True)==real and sha(plain(real))==tool['sha256'],'INTERPRETER')
    return policy,parse(plain(ROOT/'argv.json'))


def runtime_main():
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--manifest-sha256',required=True);ap.add_argument('--origin-monotonic',type=float,required=True);ap.add_argument('--run-id',required=True);ap.add_argument('--final-fd',type=int,required=True);ap.add_argument('--parent-ready-fd',type=int,required=True);args=ap.parse_args()
    t0=args.origin_monotonic;approved=args.manifest_sha256;runid=args.run_id;finalfd=args.final_fd;pr=args.parent_ready_fd
    need(math.isfinite(t0) and 0<=time.monotonic()-t0<4500 and re.fullmatch('[0-9a-f]{32}',runid),'ORIGIN')
    need(finalfd!=pr,'FD_ALIAS')
    for fd in (finalfd,pr):
        need(fd>2 and stat.S_ISFIFO(os.fstat(fd).st_mode) and os.fpathconf(fd,'PC_PIPE_BUF')>=4096,'ENTRY_PIPE');os.set_blocking(fd,False);os.set_inheritable(fd,False)
    wd=None;guard=None;parentfd=None;guardfd=None;wdfd=None;gc=None;ga=None;wc=None;wr=None;gt=None
    ack=None;ackvalid=False;guardrc=None;guardreaped=False;success=False;completed=0;closed=None;closure_report=None;known={};signals=[];prepared=False;cleanup=False
    workerror='BOOTSTRAP_FAILED';workstage='bootstrap';closeerror='GUARD_UNAVAILABLE';reasons=[]
    output=dict(schema_version=1,manifest_sha256=approved,run_id=runid,mode=MODE,test_count=0,preparation_status='REJECTED',work_status='REJECTED',work_error_code='BOOTSTRAP_FAILED',work_error_stage='bootstrap',closure_status='FAILED',ack_received=False,ack_valid=False,ack_payload=None,guard_rc=None,guard_reaped=False,pending_work_identities_count=0,cleanup_verified=False,causal_gate='CLOSED_REJECTED',monotonic_emission_start=0.0,closure_error_code='GUARD_UNAVAILABLE')
    try:
        policy,recipe=authenticate(approved)
        need(not any(os.environ.get(k) for k in policy['forbidden_environment']),'INHERITED_FORBIDDEN_ENVIRONMENT')
        from prep_watchdog import identity,same,inventory,signal_pinned,reap_adopted,Channel,save_exclusive,run_identity
        from manifest_contract import load_list
        load_list(ROOT,approved)
        authority=parse(plain(ROOT/'prep_authority.json'));allowed=authority['output_files'];need(authority['root']==str(ROOT) and authority['schema']=='PREP-V2-AUTHORITY-1','OUTPUT_AUTHORITY')
        need(policy['job_log_limits']=={'stdout_bytes':16777216,'stderr_bytes':16777216},'LOG_QUOTAS')
        parent=identity(os.getppid());need(parent and parent['namespace'] and parent['state'] not in ('Z','X','x'),'PARENT');parentfd=os.pidfd_open(parent['pid'])
        def parentcheck():
            need(same(parent) and not select.select([parentfd],[],[],0)[0] and os.getppid()==parent['pid'],'PARENT_LOST')
        def pid_public(row):return {'pid':row['pid'],'start':row['starttime'],'namespace':row['namespace']}
        def read_eof_frame(fd,deadline):
            raw=bytearray();eof=False
            while time.monotonic()<deadline:
                parentcheck();rr,_,_=select.select([fd],[],[],min(.02,max(0,deadline-time.monotonic())))
                if rr:
                    try:part=os.read(fd,4097-len(raw))
                    except (BlockingIOError,InterruptedError):continue
                    if not part:eof=True;break
                    raw.extend(part);need(len(raw)<=4096,'PARENT_FRAME_QUOTA')
                    if len(raw)>=4:need(2<=int.from_bytes(raw[:4],'little')<=4092,'PARENT_FRAME_LENGTH')
            need(eof and len(raw)>=4 and len(raw)==4+int.from_bytes(raw[:4],'little'),'PARENT_FRAME_EOF');return parse(bytes(raw[4:]))
        ready=read_eof_frame(pr,min(time.monotonic()+120,t0+4500));os.close(pr);pr=None
        keys={'schema_version','type','manifest_sha256','run_id','t0','spawn_deadline','parent','run','concurrency_roles'}
        need(type(ready) is dict and set(ready)==keys and type(ready['schema_version']) is int and ready['schema_version']==1 and ready['type']=='PREP_PARENT_READY' and ready['manifest_sha256']==approved and ready['run_id']==runid and type(ready['t0']) is float and ready['t0']==t0 and ready['parent']==pid_public(parent),'PARENT_READY')
        need(type(ready['spawn_deadline']) is float and math.isfinite(ready['spawn_deadline']) and time.monotonic()<ready['spawn_deadline']<=t0+4500,'ENTRY_SPAWN_DEADLINE')
        pin=ready['run'];need(type(pin) is dict and set(pin)=={'canonical','device','inode','type'} and pin['type']=='directory' and type(pin['device']) is int and type(pin['inode']) is int,'RUN_SCHEMA')
        runpin=dict(canonical=pin['canonical'],dev=pin['device'],ino=pin['inode']);need(run_identity()==runpin,'RUN_IDENTITY')
        for directory in ('home','tmp'):
            path=ROOT/directory
            try:path.lstat()
            except FileNotFoundError:pass
            else:raise Rejected('OUTPUT_DIRECTORY_ALREADY_EXISTS')
            path.mkdir(mode=0o700)
        need(policy['fixed_environment']['HOME']==str(ROOT/'home') and policy['fixed_environment']['TMPDIR']==str(ROOT/'tmp'),'PRIVATE_ENV_DIRECTORIES')
        from prep_concurrency import capture_role,scan,revalidate
        registry=ready['concurrency_roles']
        need(type(registry) is dict and set(registry)=={'namespaces','roles'} and type(registry['roles']) is list and {r.get('role') for r in registry['roles']}=={'outer','closure-observer','collector','external-supervisor'} and len(registry['roles'])==4,'CONCURRENCY_REGISTRY')
        need(registry['namespaces']=={n:os.readlink('/proc/self/ns/'+n) for n in ('pid','mnt','user')},'CONCURRENCY_NAMESPACE')
        # Registry is received authority, not discovered anew from process names.
        registry=dict(namespaces=dict(registry['namespaces']),roles=[dict(r) for r in registry['roles']])
        entry_argv=[policy['tools']['python3']['path'],'-B',str(ROOT/'prep_entry.py'),'--manifest-sha256',approved,'--origin-monotonic',repr(t0),'--run-id',runid,'--final-fd',str(finalfd),'--parent-ready-fd',str(args.parent_ready_fd)]
        registry['roles'].append(capture_role(policy,approved,'entry',os.getpid(),entry_argv))
        # A bounded controller boot interval remains under the existing collector's
        # registered external supervisor. It is fixed before either child spawn.
        bootlimit=min(time.monotonic()+120,t0+4500)
        need(ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)==0,'SUBREAPER')
        for signum in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):signal.signal(signum,lambda n,f:signals.append(n))
        def commoncheck(deadline):
            parentcheck();need(not signals and time.monotonic()<deadline,'ENTRY_DEADLINE_OR_SIGNAL');need(run_identity()==runpin,'RUN_CHANGED')
        def protectorcheck(deadline,require_guard=True):
            commoncheck(deadline)
            if require_guard:
                need(guard is not None and guard.poll() is None and same(guard_identity) and not select.select([guardfd],[],[],0)[0],'GUARD_LOST')
        def output_save(relative,value,deadline):
            protectorcheck(deadline);need(relative in allowed,'OUTPUT_NOT_APPROVED');return save_exclusive(ROOT/relative,value,deadline)
        python=policy['tools']['python3']['path'];me=identity(os.getpid())
        cr,wc=os.pipe2(os.O_CLOEXEC|os.O_NONBLOCK);wr,rw=os.pipe2(os.O_CLOEXEC|os.O_NONBLOCK);gr,gc=os.pipe2(os.O_CLOEXEC|os.O_NONBLOCK);ga,gw=os.pipe2(os.O_CLOEXEC|os.O_NONBLOCK);gt,tw=os.pipe2(os.O_CLOEXEC|os.O_NONBLOCK)
        for fd in (cr,wc,wr,rw,gr,gc,ga,gw,gt,tw):need(os.fpathconf(fd,'PC_PIPE_BUF')>=4096,'PIPE_BUF')
        wdargv=[python,'-B',str(ROOT/'prep_watchdog.py'),'--manifest-sha256',approved,'--origin-monotonic',repr(t0),'--run-id',runid,'--parent',str(me['pid']),me['starttime'],'--command-fd',str(cr),'--reply-fd',str(rw),'--guard-fd',str(gc),'--guard-ack-fd',str(ga)]
        commoncheck(bootlimit)
        wd=subprocess.Popen(wdargv,pass_fds=(cr,rw,gc,ga),close_fds=True,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        wd_identity=identity(wd.pid);need(wd_identity and wd_identity['namespace'],'WATCHDOG_POST_SPAWN_IDENTITY');known[(wd.pid,wd_identity['starttime'])]=wd_identity;wdfd=os.pidfd_open(wd.pid)
        os.close(cr);os.close(rw);commoncheck(bootlimit);need(wd.poll() is None,'WATCHDOG_BOOT_EXIT')
        guardargv=[python,'-B',str(ROOT/'prep_guard.py'),'--manifest-sha256',approved,'--origin-monotonic',repr(t0),'--run-id',runid,'--parent',str(me['pid']),me['starttime'],'--watchdog',str(wd.pid),wd_identity['starttime'],'--control-fd',str(gr),'--ack-fd',str(gw),'--telemetry-fd',str(tw)]
        commoncheck(bootlimit)
        guard=subprocess.Popen(guardargv,pass_fds=(gr,gw,tw),close_fds=True,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
        guard_identity=identity(guard.pid);need(guard_identity and guard_identity['namespace'],'GUARD_POST_SPAWN_IDENTITY');known[(guard.pid,guard_identity['starttime'])]=guard_identity;guardfd=os.pidfd_open(guard.pid)
        os.close(gr);os.close(gw);os.close(tw);commoncheck(bootlimit)
        # GT is distinct from GA: no use at all of retained GA/GC until WD reap.
        telemetry=bytearray()
        while time.monotonic()<bootlimit:
            protectorcheck(bootlimit);need(wd.poll() is None,'WATCHDOG_BOOT_EXIT')
            rr,_,_=select.select([gt],[],[],min(.02,max(0,bootlimit-time.monotonic())))
            if rr:
                chunk=os.read(gt,4097-len(telemetry));need(chunk,'GT_READY_EOF');telemetry.extend(chunk);need(len(telemetry)<=4096,'GT_QUOTA')
                if len(telemetry)>=4:
                    n=int.from_bytes(telemetry[:4],'little');need(2<=n<=4092,'GT_LENGTH')
                    if len(telemetry)>=n+4:need(len(telemetry)==n+4,'GT_EXTRA');break
        need(len(telemetry)>=4 and len(telemetry)==4+int.from_bytes(telemetry[:4],'little'),'GT_READY_MISSING')
        gtready=parse(bytes(telemetry[4:]));expected_ready=dict(type='PREP_GUARD_READY',session=str(ROOT),run_id=runid,manifest_sha256=approved,t0=t0,parent_identity=pid_public(me),watchdog_identity=pid_public(wd_identity),guard_identity=pid_public(guard_identity));need(gtready==expected_ready,'GT_READY_IDENTITY');telemetry.clear()
        registry['roles'].append(capture_role(policy,approved,'watchdog',wd.pid,wdargv))
        registry['roles'].append(capture_role(policy,approved,'guard',guard.pid,guardargv))
        control=Channel(wr,wc,lambda:protectorcheck(t0+4500))
        def m(kind,**kw):return dict(type=kind,session=str(ROOT),run_id=runid,**kw)
        def send_command(value,deadline=t0+4500):
            protectorcheck(deadline);need(wd.poll() is None and same(wd_identity),'WATCHDOG_LOST');control.send(value,deadline)
        send_command(m('initialize',manifest_sha256=approved,t0=t0,run=pin,guard_identity=pid_public(guard_identity)),bootlimit)
        need(control.receive(bootlimit)==m('initialized',watchdog_identity=pid_public(wd_identity)),'WATCHDOG_INITIALIZED')
        workerror='PREPARATION_FAILED';workstage='preparation'
        begin=m('prepare_begin',mode=MODE,manifest_sha256=approved,argv_sha256=sha(plain(ROOT/'argv.json')),expected_completed=8,expected_test_count=0)
        send_command(begin);need(control.receive(t0+4500)=={**begin,'type':'prepare_begin_ack'},'BEGIN_ACK')
        workerror='PREPARATION_FAILED';workstage='preparation'
        def persist_scan(ident,report):
            relative='run/concurrency-before-'+ident+'.json';need(relative in allowed and relative+'.tmp' in allowed,'CONCURRENCY_OUTPUT_AUTHORITY')
            protectorcheck(t0+4500);dest=ROOT/relative;temp=Path(str(dest)+'.tmp')
            need(not dest.exists() and not dest.is_symlink(),'CONCURRENCY_OUTPUT_EXISTS')
            save_exclusive(temp,report,t0+4500);protectorcheck(t0+4500);os.replace(temp,dest)
        for ordinal,ident in enumerate(IDS,1):
            protectorcheck(t0+4500);need(wd.poll() is None,'WATCHDOG_LOST_BEFORE_SCAN')
            context=scan(policy,approved,registry,lambda report:persist_scan(ident,report),'before-'+ident,t0,runid)
            revalidate(context)
            send_command(m('run',ordinal=ordinal,id=ident));reply=control.receive(t0+4500)
            if reply.get('type')=='closed':closed=reply;raise Rejected('PREPARATION_REJECTED')
            need(type(reply) is dict and set(reply)=={'type','session','run_id','ordinal','id','result_sha256','rc','cleanup_verified'} and reply['type']=='result' and reply['session']==str(ROOT) and reply['run_id']==runid and type(reply['ordinal']) is int and reply['ordinal']==ordinal and reply['id']==ident and type(reply['rc']) is int and reply['rc']==0 and reply['cleanup_verified'] is True and reply['result_sha256']==sha(plain(ROOT/'run'/(ident+'.json'))),'RESULT_REPLY')
            completed=ordinal
        send_command(m('prepare_end'));reply=control.receive(t0+4500)
        if reply.get('type')=='closed':closed=reply;raise Rejected('PREPARE_END_REJECTED')
        expected=m('prepare_end_ack',completed=8,test_count=0,last_id=IDS[-1],inventory_report_sha256=sha(plain(ROOT/'run/inventory.json')),comparability_report_sha256=sha(plain(ROOT/'run/comparability.json')),result_sha256s=[sha(plain(ROOT/'run'/(ident+'.json'))) for ident in IDS]);need(reply==expected,'PREPARE_END_ACK')
        need(parse(plain(ROOT/'run/prepared-inputs.json'))['status']=='PREPARED_PENDING_D','PREPARED_MANIFEST')
        send_command(m('close_prepare',success=True,completed=8,test_count=0));control.checkpoint=lambda:protectorcheck(t0+4770)
        closed=control.receive(t0+4770);need(closed==m('closed',success=True,completed=8,test_count=0,cleanup_verified=True,guard_closure_ack=True),'CLOSE_ACK');prepared=True
    except BaseException as exc:
        reasons.append(type(exc).__name__)
        prepared=False
    # Closure always uses observed WD closed message + waitpid + reply EOF. No
    # duplicate GC/GA activation while WD lives, including failed preparations.
    try:
        need(wd is not None and guard is not None,'NO_CONTROLLERS')
        closeerror='INTERNAL_CLOSURE_FAILED'
        # If entry rejected while worker is idle, stop its command channel. A
        # blocked/inflight worker remains guarded and cannot admit another job.
        if not prepared and closed is None and wc is not None:
            os.close(wc);wc=None
        while time.monotonic()<t0+4770 and wd.poll() is None:
            protectorcheck(t0+4770)
            time.sleep(min(.02,max(0,t0+4770-time.monotonic())))
        wdrc=wd.poll();need(type(wdrc) is int,'WATCHDOG_NOT_REAPED')
        control.checkpoint=lambda:protectorcheck(t0+4770)
        # Return/reap never substitutes for consuming the already queued frame.
        if closed is None:
            closed=control.receive(t0+4770)
            need(closed.get('type')=='closed','EXPECTED_CLOSED_AFTER_REAP')
        # Popen.poll has performed waitpid. Drain exact EOF, reject extra replies.
        need(control.buffer==b'','PENDING_WATCHDOG_FRAME');reply_eof=False
        while time.monotonic()<t0+4770:
            protectorcheck(t0+4770);rr,_,_=select.select([wr],[],[],min(.02,max(0,t0+4770-time.monotonic())))
            if rr:
                extra=os.read(wr,4096);need(not extra,'EXTRA_WATCHDOG_REPLY');reply_eof=True;break
        need(reply_eof,'WATCHDOG_REPLY_EOF')
        need(type(closed) is dict and closed.get('type')=='closed' and closed.get('session')==str(ROOT) and closed.get('run_id')==runid and type(closed.get('success')) is bool and type(closed.get('completed')) is int and 0<=closed['completed']<=8 and type(closed.get('test_count')) is int and closed['test_count']==0 and closed.get('cleanup_verified') is True and closed.get('guard_closure_ack') is True and set(closed)=={'type','session','run_id','success','completed','test_count','cleanup_verified','guard_closure_ack'},'CLOSED_MESSAGE_REQUIRED')
        need(wdrc==(0 if closed['success'] else 2),'WATCHDOG_RC_CONFLICT');completed=closed['completed'];success=prepared and closed['success'] and completed==8
        need(success==closed['success'],'CLOSE_SUCCESS_CONFLICT')
        rest=[r for r in inventory(known) if r['pid']!=guard.pid];reap_adopted(rest,guard.pid);need(not [r for r in inventory(known) if r['pid']!=guard.pid],'WORK_REMAINS')
        # An unsolicited queued guard message is rejection, never a done ACK.
        need(not select.select([ga],[],[],0)[0],'UNEXPECTED_PENDING_GUARD_ACK')
        protectorcheck(t0+4770)
        closure_report=dict(success=success,completed=completed,test_count=0,watchdog_identity=pid_public(wd_identity),watchdog_rc=wdrc,watchdog_reaped=True,watchdog_reply_eof=True,guard_closure_ack=True)
        output_save('run/prep-watchdog-close.json',closure_report,t0+4770)
        gchannel=Channel(ga,gc,lambda:protectorcheck(t0+4770))
        done=m('done',success=success,completed=completed,test_count=0,watchdog_reaped=True,watchdog_reply_eof=True,watchdog_rc=wdrc)
        gchannel.send(done,t0+4770);ack=gchannel.receive(t0+4770)
        expected={**done,'type':'done_ack','identified_work_exited':True,'reaping':'ENTRY_RESPONSIBILITY'};need(ack==expected,'DONE_ACK');ackvalid=True
        donehash=hashlib.sha256(json.dumps(ack,separators=(',',':'),sort_keys=True,allow_nan=False).encode()).hexdigest()
        persist_hash=output_save('run/guard-done-ack.json',dict(done_ack=ack,done_ack_sha256=donehash),t0+4770)
        report=dict(schema_version=1,preparation_status='PREPARED' if success else 'REJECTED',mode=MODE,test_count=0,completed=completed,closure_status='CLOSURE_PENDING',guard_rc='EXTERNAL_RETURN_REQUIRED',input_manifest_sha256=approved,causal_gate='CLOSED_AWAITING_D' if success else 'CLOSED_REJECTED',G1='NOT_PASSED',V3='BLOCKED',runtime_inputs_sha256=sha(plain(ROOT/'run/prepared-inputs.json')) if success else None,done_ack_sha256=donehash)
        output_save('run/prep-entry-report.json',report,t0+4770)
        persisted=m('ack_persisted',done_ack_sha256=donehash,persistence_sha256=persist_hash)
        gchannel.send(persisted,t0+4770)
        # Guard may exit immediately AFTER its final ACK. Read without requiring
        # it remain alive; still require parent/deadline and validate exact ACK.
        gchannel.checkpoint=lambda:commoncheck(t0+4770)
        need(gchannel.receive(t0+4770)=={**persisted,'type':'ack_persisted_ack'},'ACK_PERSISTED')
        while time.monotonic()<t0+4770 and guard.poll() is None:commoncheck(t0+4770);time.sleep(min(.02,max(0,t0+4770-time.monotonic())))
        guardrc=guard.poll();guardreaped=guardrc is not None;need(guardreaped,'GUARD_REAP_FAILED')
        remaining=inventory(known);reap_adopted(remaining,-1);cleanup=not inventory(known)
        need(cleanup,'CLOSURE_RESTS');need(guardrc==(0 if success else 2),'GUARD_RC')
        closeerror=None if success else 'INTERNAL_CLOSURE_FAILED'
    except BaseException as exc:
        reasons.append(type(exc).__name__);success=False;prepared=False;workerror='PREPARATION_FAILED';workstage='persistence';closeerror='INTERNAL_CLOSURE_FAILED'
        # No persistence or new child after closure failure. Fail-closed cleanup.
        if 'inventory' in locals():
            kill_at=min(time.monotonic()+1,t0+4790)
            while time.monotonic()<t0+4770:
                rows=inventory(known)
                for row in rows:signal_pinned(row,signal.SIGTERM if time.monotonic()<kill_at else signal.SIGKILL)
                if wd:wd.poll()
                if guard:guard.poll()
                reap_adopted([r for r in rows if r['pid'] not in {p.pid for p in (wd,guard) if p}],-1)
                if not inventory(known):break
                time.sleep(min(.02,max(0,t0+4770-time.monotonic())))
            guardrc=guard.poll() if guard else None;guardreaped=guardrc is not None;cleanup=not inventory(known)
    # No required file IO after releasing guard. Entry cannot claim its own reap.
    remaining_count=len(inventory(known)) if 'inventory' in locals() else 0
    output.update(preparation_status='PREPARED' if prepared else 'REJECTED',work_status='COMPLETED' if prepared else 'REJECTED',work_error_code=None if prepared else workerror,work_error_stage=None if prepared else workstage,closure_status='INTERNAL_ACK_AND_REAP_OBSERVED' if success and ackvalid and guardreaped and guardrc==0 and cleanup else 'FAILED',ack_received=ack is not None,ack_valid=ackvalid,ack_payload=ack if ackvalid else None,guard_rc=guardrc,guard_reaped=guardreaped,pending_work_identities_count=remaining_count,cleanup_verified=cleanup,causal_gate='CLOSED_AWAITING_D' if prepared else 'CLOSED_REJECTED',monotonic_emission_start=time.monotonic(),closure_error_code=closeerror)
    wire_payload=json.dumps(output,separators=(',',':'),allow_nan=False).encode();need(len(wire_payload)<=2048,'ENTRY_FINAL_QUOTA');wire=len(wire_payload).to_bytes(4,'little')+wire_payload;offset=0;end=min(t0+4772,time.monotonic()+2)
    while offset<len(wire) and time.monotonic()<end:
        _,ww,_=select.select([],[finalfd],[],min(.02,max(0,end-time.monotonic())))
        if ww:
            try:offset+=os.write(finalfd,wire[offset:])
            except (BlockingIOError,InterruptedError):pass
            except OSError:break
    os.close(finalfd)
    return 0 if prepared and output['closure_status']=='INTERNAL_ACK_AND_REAP_OBSERVED' and offset==len(wire) else 2
if __name__=='__main__':sys.exit(runtime_main())

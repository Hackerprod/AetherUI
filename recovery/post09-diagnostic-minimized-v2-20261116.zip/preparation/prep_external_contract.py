"""V8 stdlib-only observation helpers. No candidate imports."""
import os, signal, json, time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PYTHON='/RELOCATE/python3'
def unique(pairs):
    out={}
    for k,v in pairs:
        if k in out: raise ValueError('DUPLICATE_KEY')
        out[k]=v
    return out
def identity(pid):
    try:
        s=Path('/proc',str(pid),'stat').read_text(); p=s[s.rfind(')')+2:].split()
        return {'pid':pid,'ppid':int(p[1]),'start':p[19],'state':p[0]}
    except (FileNotFoundError,ProcessLookupError): return None
def same(row):
    now=identity(row['pid']); return bool(now and now['start']==row['start'])
def discover(root,known,exclude=()):
    rows={}
    for p in Path('/proc').iterdir():
        if p.name.isdigit():
            row=identity(int(p.name))
            if row: rows[row['pid']]=row
    ids={root}; more=True
    while more:
        more=False
        for pid,row in rows.items():
            if row['ppid'] in ids and pid not in ids and pid not in exclude: ids.add(pid); more=True
    for pid in ids-{root,*exclude}:
        if pid in rows: known[(pid,rows[pid]['start'])]=rows[pid]
    return [r for r in known.values() if same(r)]
def kill_verified(row,sig):
    if not same(row): return
    try: fd=os.pidfd_open(row['pid'])
    except ProcessLookupError:return
    try:
        if same(row):signal.pidfd_send_signal(fd,sig,None,0)
    except ProcessLookupError:pass
    finally:os.close(fd)
def reap(rows):
    for row in rows:
        now=identity(row['pid'])
        if now and same(row) and now['ppid']==os.getpid():
            try: os.waitpid(row['pid'],os.WNOHANG)
            except ChildProcessError:pass

# V18 directory identity is observation, NOT authority for entry to accept run.
def directory_identity(path):
    import stat
    for component in (path,*path.parents):
        if component.is_symlink():raise ValueError('DIRECTORY_SYMLINK')
    info=path.lstat()
    if not stat.S_ISDIR(info.st_mode):raise ValueError('DIRECTORY_TYPE')
    return {'canonical':str(path.resolve(strict=True)),'device':info.st_dev,'inode':info.st_ino,'type':'directory'}
def check_directories(pinned):
    for name,record in pinned.items():
        if directory_identity(Path(name))!=record:raise ValueError('DIRECTORY_IDENTITY_CHANGED')
def spawn_budget(t0,seconds=120,ceiling=4500):
    now=time.monotonic();deadline=min(now+seconds,t0+ceiling)
    if now>=deadline:raise ValueError('SPAWN_DEADLINE')
    return deadline
def check_spawn(deadline,parent=None):
    if time.monotonic()>=deadline:raise ValueError('SPAWN_DEADLINE')
    if parent is not None:
        current=identity(parent['pid'])
        if not same(parent) or current is None or current['state'] in ('Z','X','x'):raise ValueError('SPAWN_PARENT_LOST')


def validate_directory(record,path):
    if type(record) is not dict or set(record)!={'canonical','device','inode','type'} or record['type']!='directory' or type(record['device']) is not int or type(record['inode']) is not int or record['device']<0 or record['inode']<=0 or record['canonical']!=str(path):raise ValueError('DIRECTORY_SCHEMA')
    if directory_identity(path)!=record:raise ValueError('DIRECTORY_PIN')
    return record

def namespace_identity(pid):
    row=identity(pid)
    if row is None:raise ValueError('IDENTITY_MISSING')
    return {'pid':pid,'start':row['start'],'namespace':os.readlink('/proc/'+str(pid)+'/ns/pid')}

def validate_identity(record):
    import re
    if type(record) is not dict or set(record)!={'pid','start','namespace'} or type(record['pid']) is not int or record['pid']<=0 or type(record['start']) is not str or not re.fullmatch('[0-9]+',record['start']) or type(record['namespace']) is not str or not re.fullmatch(r'pid:\[\d+\]',record['namespace']):raise ValueError('IDENTITY_SCHEMA')
    return record

def closed(value,keys):
    if type(value) is not dict or set(value)!=set(keys):raise ValueError('SCHEMA_KEYS')

def boolean(value):
    if type(value) is not bool:raise ValueError('BOOL_TYPE')

def integer(value,minimum=0):
    if type(value) is not int or value<minimum:raise ValueError('INT_TYPE')

def sha(value):
    import re
    if type(value) is not str or not re.fullmatch('[0-9a-f]{64}',value):raise ValueError('HASH_TYPE')

def finite(value):
    import math
    if type(value) not in (int,float) or not math.isfinite(value):raise ValueError('NUMBER_TYPE')

GUARD_KEYS={'external_supervisor_initial_identity','external_guard_lost','external_guard_failure_stage','external_supervisor_rc_observed','external_guard_last_check_monotonic'}
SUMMARY_KEYS={'run_id','collector_outcome','writer_identity','directory_identities','writer_reaped','writer_rc','writer_receipt_valid','external_closure_status','external_supervisor_identity','external_supervisor_reaped','capture_bytes','capture_sha256'}|GUARD_KEYS
CAPTURE_KEYS={'schema_version','manifest_sha256','run_id','origin_monotonic','launcher_rc','launcher_reaped','launcher_identity','launcher_identity_match','final_frame_complete','final_frame_valid','frame','frame_error','capture_truncated','capture_read_error','pipes_eof','deadline_enforced','remaining_identities','collector_outcome','external_closure_status','stdout_base64','stderr_base64','not_tested','directory_identities'}|GUARD_KEYS
NOT_TESTED=['kernel-blocked IO','transient adversarial descendants','physical durability','collector own reap','external supervisor own reap']

def validate_guard(value,pinned,t0):
    initial=value['external_supervisor_initial_identity']
    closed(initial,{'pid','ppid','start','state'})
    if initial['pid']!=pinned['pid'] or initial['start']!=pinned['start']:raise ValueError('GUARD_PIN')
    integer(initial['pid'],1);integer(initial['ppid'],1)
    if initial['state'] not in ('R','S','D','I','T','t','W','P'):raise ValueError('GUARD_STATE')
    if value['external_guard_lost'] is not False or value['external_guard_failure_stage'] is not None or value['external_supervisor_rc_observed'] is not None:raise ValueError('GUARD_LOST')
    finite(value['external_guard_last_check_monotonic'])
    if not t0<=value['external_guard_last_check_monotonic']<=time.monotonic():raise ValueError('GUARD_TIME')

def validate_directory_set(value,root,runid,run):
    expected=[root/'run',root/'run'/'external-output',root/'run'/'external-output'/runid]
    closed(value,{str(path) for path in expected})
    if value[str(root/'run')]!=run:raise ValueError('RUN_CHAIN')
    for path in expected:validate_directory(value[str(path)],path)

def validate_summary(value,root,runid,t0,supervisor,run):
    closed(value,SUMMARY_KEYS)
    if value['run_id']!=runid or value['collector_outcome']!='CAPTURE_AND_RETURN_OBSERVED' or value['external_closure_status']!='CLOSURE_PENDING':raise ValueError('SUMMARY_STATUS')
    validate_guard(value,supervisor,t0)
    if value['external_supervisor_identity']!=value['external_supervisor_initial_identity']:raise ValueError('SUPERVISOR_PIN')
    if value['writer_reaped'] is not True or type(value['writer_rc']) is not int or value['writer_rc']!=0 or value['writer_receipt_valid'] is not True or value['external_supervisor_reaped'] is not False:raise ValueError('WRITER_RESULT')
    validate_identity(value['writer_identity'])
    integer(value['capture_bytes']);sha(value['capture_sha256'])
    if value['capture_bytes']>262144:raise ValueError('CAPTURE_QUOTA')
    validate_directory_set(value['directory_identities'],root,runid,run)

def validate_capture(value,root,approved,runid,t0,supervisor,run):
    import base64
    closed(value,CAPTURE_KEYS)
    if type(value['schema_version']) is not int or value['schema_version']!=1 or value['manifest_sha256']!=approved or value['run_id']!=runid or type(value['origin_monotonic']) is not float or value['origin_monotonic']!=t0:raise ValueError('CAPTURE_CORRELATION')
    validate_guard(value,supervisor,t0);validate_directory_set(value['directory_identities'],root,runid,run)
    validate_identity(value['launcher_identity'])
    if type(value['launcher_rc']) is not int:raise ValueError('LAUNCHER_RC')
    for key in ('launcher_reaped','launcher_identity_match','final_frame_complete','final_frame_valid','pipes_eof'):
        if value[key] is not True:raise ValueError('CAPTURE_INCOMPLETE')
    for key in ('capture_truncated','capture_read_error','deadline_enforced'):
        if value[key] is not False:raise ValueError('CAPTURE_FAILED')
    if value['frame_error'] is not None or value['remaining_identities']!=[] or type(value['remaining_identities']) is not list or value['collector_outcome']!='CAPTURE_AND_RETURN_OBSERVED' or value['external_closure_status']!='CLOSURE_PENDING' or value['not_tested']!=NOT_TESTED:raise ValueError('CAPTURE_STATUS')
    for key in ('stdout_base64','stderr_base64'):
        if type(value[key]) is not str or len(value[key])>87384:raise ValueError('LOG_QUOTA')
        raw=base64.b64decode(value[key],validate=True)
        if len(raw)>65536 or base64.b64encode(raw).decode()!=value[key]:raise ValueError('LOG_ENCODING')

ENTRY_KEYS={'schema_version','manifest_sha256','run_id','work_status','work_error_code','work_error_stage','closure_status','ack_received','ack_valid','ack_payload','guard_rc','guard_reaped','pending_work_identities_count','cleanup_verified','causal_gate','monotonic_emission_start','closure_error_code','mode','test_count','preparation_status'}
def validate_entry(value,root,approved,runid,t0,rc):
    closed(value,ENTRY_KEYS)
    if type(value['schema_version']) is not int or value['schema_version']!=1 or value['manifest_sha256']!=approved or value['run_id']!=runid or value['mode']!='PREPARATION_ZERO_TESTS' or type(value['test_count']) is not int or value['test_count']!=0:raise ValueError('ENTRY_CORRELATION')
    for key in ('ack_received','ack_valid','guard_reaped','cleanup_verified'):boolean(value[key])
    integer(value['pending_work_identities_count'])
    if value['guard_rc'] is not None and type(value['guard_rc']) is not int:raise ValueError('GUARD_RC')
    if type(rc) is not int:raise ValueError('ENTRY_RC')
    finite(value['monotonic_emission_start'])
    if not t0<=value['monotonic_emission_start']<=min(t0+4772,time.monotonic()):raise ValueError('ENTRY_TIME')
    success=value['preparation_status']=='PREPARED'
    if success:
        if value['work_status']!='COMPLETED' or rc!=0 or value['work_error_code'] is not None or value['work_error_stage'] is not None or value['causal_gate']!='CLOSED_AWAITING_D':raise ValueError('PREPARATION_CONFLICT')
    elif value['preparation_status']=='REJECTED':
        if value['work_status']!='REJECTED' or rc==0 or value['work_error_code'] not in ('PREPARATION_FAILED','BOOTSTRAP_FAILED') or value['work_error_stage'] not in ('bootstrap','preparation','persistence') or value['causal_gate']!='CLOSED_REJECTED':raise ValueError('REJECTION_CONFLICT')
    else:raise ValueError('PREPARATION_STATUS')
    ack=value['ack_payload']
    if ack is not None:
        closed(ack,{'type','session','run_id','success','completed','test_count','watchdog_reaped','watchdog_reply_eof','watchdog_rc','identified_work_exited','reaping'})
        if ack['type']!='done_ack' or ack['session']!=str(root) or ack['run_id']!=runid or ack['reaping']!='ENTRY_RESPONSIBILITY':raise ValueError('DONE_CORRELATION')
        boolean(ack['success']);integer(ack['completed']);integer(ack['test_count'])
        if ack['completed']>8 or ack['test_count']!=0 or type(ack['watchdog_rc']) is not int:raise ValueError('DONE_COUNTERS')
        for key in ('watchdog_reaped','watchdog_reply_eof','identified_work_exited'):
            if ack[key] is not True:raise ValueError('DONE_CLOSURE')
        if ack['success'] and (ack['completed']!=8 or ack['watchdog_rc']!=0):raise ValueError('DONE_SUCCESS')
        if ack['success'] and not success and not (value['closure_status']=='FAILED' and value['work_error_code']=='PREPARATION_FAILED' and value['work_error_stage']=='persistence' and rc!=0):raise ValueError('HISTORIC_ACK_CONFLICT')
        if not ack['success'] and (success or rc==0 or ack['watchdog_rc']!=2):raise ValueError('DONE_NEGATIVE')
        if not ack['success'] and value['guard_reaped'] and value['guard_rc']!=2:raise ValueError('NEGATIVE_GUARD_RC')
        if ack['success'] and value['guard_reaped'] and value['guard_rc']!=0:raise ValueError('POSITIVE_GUARD_RC')
    if value['ack_valid'] and (not value['ack_received'] or ack is None):raise ValueError('ACK_CONFLICT')
    if not value['ack_received'] and ack is not None:raise ValueError('ACK_CONFLICT')
    complete=success and value['ack_received'] and value['ack_valid'] and ack is not None and ack['success'] and value['guard_rc']==0 and value['guard_reaped'] and value['cleanup_verified'] and value['pending_work_identities_count']==0
    if value['closure_status']=='INTERNAL_ACK_AND_REAP_OBSERVED':
        if not complete or value['closure_error_code'] is not None:raise ValueError('CLOSURE_CONFLICT')
    elif value['closure_status']=='FAILED':
        if complete or value['closure_error_code'] not in ('INTERNAL_CLOSURE_FAILED','GUARD_UNAVAILABLE','GUARD_REAP_FAILED'):raise ValueError('CLOSURE_FAILED_CONFLICT')
    else:raise ValueError('CLOSURE_STATUS')

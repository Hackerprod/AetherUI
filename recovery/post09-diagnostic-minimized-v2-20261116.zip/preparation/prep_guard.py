"""V19/V20 preparation guard. STATIC MATERIALIZATION ONLY; no product tests."""
import argparse, hashlib, json, math, os, select, signal, stat, struct, sys, time
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
EXPECTED_ROOT=Path('/RELOCATE/preparation')
IDS=('configure-Hc','configure-J','build-Hc','build-J','inventory-Hc','inventory-J','gate-inventory','gate-comparability')
CAPS=(120,120,1800,1800,120,120,120,120)
MODE='PREPARATION_ZERO_TESTS'

def unique(pairs):
    out={}
    for key,value in pairs:
        if key in out:raise ValueError('DUPLICATE_KEY')
        out[key]=value
    return out

def regular(path):
    for p in [path,*path.parents]:
        if p.is_symlink():raise ValueError('SYMLINK')
    if not stat.S_ISREG(path.lstat().st_mode):raise ValueError('REGULAR_REQUIRED')
    return path

def sha(path):
    h=hashlib.sha256()
    with regular(path).open('rb') as f:
        for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
    return h.hexdigest()

def load(path):
    return json.loads(regular(path).read_bytes(),object_pairs_hook=unique,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('NONFINITE_JSON')))

def digest_value(value):
    return hashlib.sha256(json.dumps(value,separators=(',',':'),sort_keys=True,allow_nan=False).encode()).hexdigest()

def identity(pid):
    try:
        text=Path('/proc',str(pid),'stat').read_text();f=text[text.rfind(')')+2:].split()
        try:ns=os.readlink('/proc/'+str(pid)+'/ns/pid')
        except (FileNotFoundError,ProcessLookupError):ns=None
        return {'pid':pid,'start':f[19],'namespace':ns,'ppid':int(f[1]),'pgid':int(f[2]),'state':f[0]}
    except (FileNotFoundError,ProcessLookupError):return None

def same(row):
    now=identity(row['pid'])
    return now is not None and now['start']==row['start'] and (now['namespace']==row['namespace'] or now['namespace'] is None and now['state'] in ('Z','X','x'))

def public(row):return {k:row[k] for k in ('pid','start','namespace')}

def signal_row(row,sig):
    if not same(row):return
    try:fd=os.pidfd_open(row['pid'])
    except ProcessLookupError:return
    try:
        if same(row):signal.pidfd_send_signal(fd,sig,None,0)
    except ProcessLookupError:pass
    finally:os.close(fd)

def pipe(fd):
    if fd<=2 or not stat.S_ISFIFO(os.fstat(fd).st_mode) or os.fpathconf(fd,'PC_PIPE_BUF')<4096:raise ValueError('PIPE')
    os.set_blocking(fd,False);os.set_inheritable(fd,False)

def framed(value):
    raw=json.dumps(value,separators=(',',':'),allow_nan=False).encode()
    if len(raw)>4092:raise ValueError('FRAME_QUOTA')
    return struct.pack('<I',len(raw))+raw

def send(fd,value,deadline):
    wire=framed(value);offset=0;p=select.poll();p.register(fd,select.POLLOUT|select.POLLHUP|select.POLLERR)
    while offset<len(wire):
        if time.monotonic()>=deadline:raise ValueError('SEND_DEADLINE')
        try:
            n=os.write(fd,wire[offset:])
            if n<=0:raise ValueError('SEND_CLOSED')
            offset+=n
        except (BlockingIOError,InterruptedError):p.poll(max(0,int(min(.01,max(0,deadline-time.monotonic()))*1000)))

class Reader:
    def __init__(self,fd):self.fd=fd;self.buffer=bytearray();self.eof=False
    def next(self):
        if len(self.buffer)>=4:
            n=struct.unpack('<I',self.buffer[:4])[0]
            if n<2 or n>4092:raise ValueError('FRAME_LENGTH')
            if len(self.buffer)==n+4:
                value=json.loads(self.buffer[4:],object_pairs_hook=unique,parse_constant=lambda _:(_ for _ in ()).throw(ValueError('NONFINITE_JSON')))
                self.buffer.clear();return value
            if len(self.buffer)>n+4:raise ValueError('EXTRA_FRAME')
        try:data=os.read(self.fd,4097-len(self.buffer))
        except (BlockingIOError,InterruptedError):return None
        if not data:self.eof=True;raise ValueError('CONTROL_EOF')
        self.buffer.extend(data)
        if len(self.buffer)>4096:raise ValueError('FRAME_QUOTA')
        return None

def authenticate(approved):
    import re
    if ROOT!=EXPECTED_ROOT or not re.fullmatch('[0-9a-f]{64}',approved):raise ValueError('ROOT_OR_SHA')
    if sha(ROOT/'evidence.sha256.json')!=approved:raise ValueError('MANIFEST_SHA')
    rows=load(ROOT/'evidence.sha256.json');seen=set()
    if type(rows) is not list:raise ValueError('MANIFEST_SCHEMA')
    for row in rows:
        if type(row) is not dict or set(row)!={'path','bytes','sha256'}:raise ValueError('MANIFEST_RECORD')
        key=row['path']
        if type(key) is not str or key.startswith('/') or '\\' in key or '\x00' in key or any(x in ('','.','..') for x in key.split('/')) or key in seen:raise ValueError('MANIFEST_PATH')
        if type(row['bytes']) is not int or row['bytes']<0 or type(row['sha256']) is not str or not re.fullmatch('[0-9a-f]{64}',row['sha256']):raise ValueError('MANIFEST_TYPES')
        seen.add(key);p=regular(ROOT/key)
        if p.stat().st_size!=row['bytes'] or sha(p)!=row['sha256']:raise ValueError('MANIFEST_CONTENT')
    if not {'prep_guard.py','prep_watchdog.py','prep_entry.py','policy.json','argv.json','frozen_custody.py','manifest_contract.py'}<=seen:raise ValueError('MISSING_AUTHORITY')
    policy=load(ROOT/'policy.json');recipe=load(ROOT/'argv.json')
    quotas=policy.get('job_log_limits')
    if type(quotas) is not dict or set(quotas)!={'stdout_bytes','stderr_bytes'} or any(type(v) is not int or v!=16777216 for v in quotas.values()):raise ValueError('JOB_LOG_QUOTAS')
    if len(recipe)!=8 or [x['id'] for x in recipe]!=list(IDS) or [x['cap_seconds'] for x in recipe]!=list(CAPS):raise ValueError('RECIPE')
    python=policy['tools']['python3']
    actual=Path(sys.executable).resolve(strict=True)
    if actual!=Path(python['path']).resolve(strict=True) or actual!=Path('/proc/self/exe').resolve(strict=True) or sha(actual)!=python['sha256']:raise ValueError('PYTHON_IDENTITY')
    for tool in policy['tools'].values():
        if sha(Path(tool['path']).resolve(strict=True))!=tool['sha256']:raise ValueError('TOOL_CHANGED')
    return policy,recipe

class PreparationGuard:
    """Guard state machine wired to the closed runtime transport.

    Entry and watchdog are the only excluded control roles. Caller must preserve
    GC/GA ownership. Entry takes over only after the expected watchdog exit.
    """
    def __init__(self,approved,t0,run_id,parent,watchdog):
        import re
        self.policy,self.recipe=authenticate(approved)
        if not math.isfinite(t0) or not 0<=time.monotonic()-t0<4500 or not re.fullmatch('[0-9a-f]{32}',run_id):raise ValueError('ORIGIN_OR_RUN')
        self.approved=approved;self.t0=t0;self.run_id=run_id
        self.parent=identity(parent[0]);self.watchdog=identity(watchdog[0]);self.me=identity(os.getpid())
        if self.parent is None or self.watchdog is None or self.parent['start']!=parent[1] or self.watchdog['start']!=watchdog[1] or self.watchdog['ppid']!=self.parent['pid'] or self.me['ppid']!=self.parent['pid']:raise ValueError('ROLE_IDENTITY')
        if any(r['namespace'] is None or r['state'] in ('Z','X','x') for r in (self.parent,self.watchdog,self.me)):raise ValueError('ROLE_NOT_LIVE')
        self.role_pidfds=[os.pidfd_open(r['pid']) for r in (self.parent,self.watchdog)]
        self.state='PREP_READY';self.completed=0;self.pending=None;self.disarmed=None;self.hashes=[]
        self.known={};self.failure=None;self.stop_time=None;self.started_fd=None;self.success_requested=False;self.closure_expected=False;self.done_ack=None;self.ack_persisted=False;self.closure_failed=False
        self.deadline=t0+4500;self.close_deadline=t0+4770
    def fail(self,code):
        if self.stop_time is None:self.stop_time=time.monotonic()
        if self.failure is None:self.failure=code
        self.state='STOPPED'
        raise ValueError(code)
    def check(self,work=True,negative=False):
        if self.failure is not None and not negative:raise ValueError('FAILURE_LATCHED:'+self.failure)
        for row,fd in zip((self.parent,self.watchdog),self.role_pidfds):
            poll=select.poll();poll.register(fd,select.POLLIN|select.POLLHUP|select.POLLERR)
            gone=bool(poll.poll(0)) or not same(row)
            if gone and row is self.watchdog and (self.closure_expected or negative):
                current=identity(row['pid'])
                if current is not None and current['start']!=row['start']:self.fail('WATCHDOG_IDENTITY_CHANGED')
                continue
            if gone:self.fail('PROTECTOR_LOST')
        now=time.monotonic()
        if now>=self.close_deadline:self.fail('CLOSURE_DEADLINE')
        if not negative:
            if work and now>=self.deadline:self.fail('GLOBAL_WORK_DEADLINE')
            if self.pending is not None and now>=self.pending['deadline']:self.fail('ARMED_JOB_DEADLINE')
    def work_inventory(self):
        # A partial /proc read is an exception, never an empty successful scan.
        rows={}
        for path in Path('/proc').iterdir():
            if path.name.isdigit():
                row=identity(int(path.name))
                if row is not None:rows[row['pid']]=row
        ids={self.parent['pid']}|{row['pid'] for row in self.known.values() if same(row)};changed=True
        while changed:
            changed=False
            for pid,row in rows.items():
                if row['ppid'] in ids and pid not in ids:ids.add(pid);changed=True
        roles=(self.parent,self.watchdog,self.me)
        for row in roles:
            if not same(row):
                if row is self.watchdog and (self.closure_expected or self.failure is not None) and identity(row['pid']) is None:continue
                if row is self.parent and self.failure is not None and identity(row['pid']) is None:continue
                self.fail('CONTROLLER_IDENTITY_CHANGED')
        excluded={r['pid'] for r in roles}
        for pid in ids-excluded:
            row=rows.get(pid)
            if row is not None:
                key=(pid,row['start'])
                if key not in self.known or row['namespace'] is not None:self.known[key]=row
        return [row for row in self.known.values() if same(row)]
    def cleanup_tick(self):
        # Latch before signals. Pending spawn deadline is never erased here.
        if self.stop_time is None:self.stop_time=time.monotonic()
        if self.failure is None:self.failure='CLEANUP_REQUESTED'
        if self.state not in ('CLOSING','WAIT_ACK_PERSISTED','CLOSED'):self.state='STOPPED'
        rows=self.work_inventory()
        sig=signal.SIGKILL if time.monotonic()>=min(self.stop_time+1,self.t0+4790) else signal.SIGTERM
        for row in rows:signal_row(row,sig)
        return len(rows)
    def base(self,type_name):return {'type':type_name,'session':str(ROOT),'run_id':self.run_id}
    def closed(self,message,kind,extra):
        if type(message) is not dict or set(message)!=set(self.base(kind))|set(extra) or any(message[k]!=v for k,v in self.base(kind).items()):self.fail('MESSAGE_SCHEMA')
    def exact(self,actual,expected):
        if type(actual)!=type(expected) or actual!=expected:self.fail('MESSAGE_VALUE')
    def reply(self,message,kind):
        result=dict(message);result['type']=kind;return result
    def _handle(self,m):
        kind=m.get('type') if type(m) is dict else None
        negative=kind in ('closure_begin','done','ack_persisted') and self.failure is not None
        self.check(work=kind not in ('closure_begin','done','ack_persisted'),negative=negative)
        if kind=='prepare_begin':
            self.closed(m,kind,('mode','manifest_sha256','argv_sha256','expected_completed','expected_test_count'))
            if self.state!='PREP_READY':self.fail('STATE')
            expected={'mode':MODE,'manifest_sha256':self.approved,'argv_sha256':sha(ROOT/'argv.json'),'expected_completed':8,'expected_test_count':0}
            for k,v in expected.items():self.exact(m[k],v)
            self.state='PREPARING';return self.reply(m,'prepare_begin_ack')
        if kind=='arm':
            self.closed(m,kind,('ordinal','id','deadline'))
            if self.state!='PREPARING' or self.pending is not None or self.disarmed is not None or self.completed>=8:self.fail('ARM_STATE')
            self.exact(m['ordinal'],self.completed+1);self.exact(m['id'],IDS[self.completed])
            deadline=m['deadline'];now=time.monotonic()
            if type(deadline) not in (int,float) or not math.isfinite(deadline) or not now<deadline<=min(now+CAPS[self.completed],self.deadline):self.fail('ARM_DEADLINE')
            if self.work_inventory():self.fail('PREEXISTING_WORK')
            # Mutation PRECEDES returned ACK. Lost ACK does not erase protection.
            self.pending={'ordinal':m['ordinal'],'id':m['id'],'deadline':deadline,'direct':None}
            self.check();return self.reply(m,'arm_ack')
        if kind=='started':
            self.closed(m,kind,('ordinal','id','pid','starttime','namespace','pgid'))
            if self.pending is None or self.pending['direct'] is not None:self.fail('STARTED_STATE')
            for k in ('ordinal','id'):self.exact(m[k],self.pending[k])
            if type(m['pid']) is not int or m['pid']<=0 or type(m['pgid']) is not int or m['pgid']<=0 or type(m['starttime']) is not str or type(m['namespace']) is not str:self.fail('STARTED_TYPES')
            row=identity(m['pid'])
            if row is None or row['start']!=m['starttime'] or row['namespace'] not in (m['namespace'],None) or row['pgid']!=m['pgid'] or row['ppid']!=self.watchdog['pid']:self.fail('STARTED_IDENTITY_UNVERIFIED')
            if row['namespace'] is None and row['state'] not in ('Z','X','x'):self.fail('STARTED_NAMESPACE_UNVERIFIED')
            # Namespace assertion must match the watchdog's known PID namespace.
            if m['namespace']!=self.watchdog['namespace']:self.fail('STARTED_NAMESPACE')
            row['namespace']=m['namespace'];self.pending['direct']=row;self.known[(row['pid'],row['start'])]=row
            self.started_fd=os.pidfd_open(row['pid']);self.check();return self.reply(m,'started_ack')
        if kind=='disarm':
            self.closed(m,kind,('ordinal','id','deadline','result_sha256','direct_reaped','streams_eof','remaining_count'))
            if self.pending is None or self.pending['direct'] is None:self.fail('DISARM_STATE')
            for k in ('ordinal','id','deadline'):self.exact(m[k],self.pending[k])
            for k,v in {'direct_reaped':True,'streams_eof':True,'remaining_count':0}.items():self.exact(m[k],v)
            self.validate_result(m)
            if self.work_inventory():self.fail('WORK_REMAINS_AT_DISARM')
            self.check() # cap still armed throughout result read/hash and fresh scan
            self.disarmed={'ordinal':m['ordinal'],'id':m['id'],'result_sha256':m['result_sha256']}
            self.pending=None
            if self.started_fd is not None:os.close(self.started_fd);self.started_fd=None
            return self.reply(m,'disarm_ack')
        if kind=='prepared_step':
            self.closed(m,kind,('ordinal','id','result_sha256'))
            if self.state!='PREPARING' or self.pending is not None or self.disarmed is None:self.fail('STEP_STATE')
            for k,v in self.disarmed.items():self.exact(m[k],v)
            self.hashes.append(m['result_sha256']);self.completed+=1;self.disarmed=None
            return self.reply(m,'prepared_step_ack')
        if kind=='prepare_end':
            self.closed(m,kind,('completed','test_count','last_id','inventory_report_sha256','comparability_report_sha256','result_sha256s'))
            if self.state!='PREPARING' or self.completed!=8 or self.pending is not None or self.disarmed is not None:self.fail('END_STATE')
            for k,v in {'completed':8,'test_count':0,'last_id':IDS[-1],'result_sha256s':self.hashes}.items():self.exact(m[k],v)
            for key,name in (('inventory_report_sha256','inventory'),('comparability_report_sha256','comparability')):
                path=ROOT/'run'/(name+'.json')
                self.exact(m[key],sha(path));report=load(path)
                if report.get('status')!='PASS':self.fail('GATE_NOT_PASS')
            if self.work_inventory():self.fail('END_WORK_REMAINS')
            self.check();self.state='PREPARED';return self.reply(m,'prepare_end_ack')
        if kind=='closure_begin':
            self.closed(m,kind,('mode','success','completed','test_count'))
            self.exact(m['mode'],MODE);self.exact(m['test_count'],0);self.exact(m['completed'],self.completed)
            if type(m['success']) is not bool:self.fail('SUCCESS_TYPE')
            if m['success'] and (self.state!='PREPARED' or self.completed!=8 or time.monotonic()>=self.deadline):self.fail('SUCCESS_CLOSURE_STATE')
            if self.work_inventory():self.fail('CLOSURE_WORK_REMAINS')
            if m['success'] and self.failure is not None:self.fail('LATCHED_SUCCESS_FORBIDDEN')
            self.success_requested=m['success'];self.state='CLOSING'
            return self.reply(m,'closure_begin_ack')
        if kind=='done':
            self.closed(m,kind,('success','completed','test_count','watchdog_reaped','watchdog_reply_eof','watchdog_rc'))
            if self.state!='CLOSING' or not self.closure_expected:self.fail('DONE_STATE')
            for k,v in {'success':self.success_requested,'completed':self.completed,'test_count':0,'watchdog_reaped':True,'watchdog_reply_eof':True}.items():self.exact(m[k],v)
            if type(m['watchdog_rc']) is not int or m['watchdog_rc']!=(0 if self.success_requested else 2):self.fail('WATCHDOG_RC')
            if identity(self.watchdog['pid']) is not None:self.fail('WATCHDOG_NOT_ABSENT')
            if self.work_inventory():self.fail('DONE_WORK_REMAINS')
            if self.success_requested and (self.failure is not None or self.completed!=8 or self.pending is not None):self.fail('DONE_SUCCESS_CONFLICT')
            # Reap belongs to entry. Guard independently checks absence only.
            response=self.reply(m,'done_ack')
            response.update(identified_work_exited=True,reaping='ENTRY_RESPONSIBILITY')
            self.done_ack=response;self.state='WAIT_ACK_PERSISTED';return response
        if kind=='ack_persisted':
            self.closed(m,kind,('done_ack_sha256','persistence_sha256'))
            if self.state!='WAIT_ACK_PERSISTED' or self.done_ack is None:self.fail('PERSISTED_STATE')
            self.exact(m['done_ack_sha256'],digest_value(self.done_ack))
            path=ROOT/'run/guard-done-ack.json'
            self.exact(m['persistence_sha256'],sha(path))
            self.exact(load(path),{'done_ack':self.done_ack,'done_ack_sha256':digest_value(self.done_ack)})
            if identity(self.watchdog['pid']) is not None or self.work_inventory():self.fail('PERSISTENCE_WORK_REMAINS')
            self.check(work=False,negative=self.failure is not None)
            self.exact(m['persistence_sha256'],sha(path))
            self.ack_persisted=True;self.state='CLOSED';return self.reply(m,'ack_persisted_ack')
        self.fail('UNKNOWN_MESSAGE_OR_TEST_PHASE')
    def handle(self,message):
        try:return self._handle(message)
        except BaseException:
            if self.stop_time is None:self.stop_time=time.monotonic()
            if self.failure is None:self.failure='PROTOCOL_OR_OBSERVATION_FAILURE'
            self.state='STOPPED'
            raise
    def validate_result(self,message):
        import re
        expected_hash=message['result_sha256']
        if type(expected_hash) is not str or not re.fullmatch('[0-9a-f]{64}',expected_hash):self.fail('RESULT_SHA')
        path=ROOT/'run'/(message['id']+'.json')
        if sha(path)!=expected_hash:self.fail('RESULT_HASH_CHANGED')
        r=load(path)
        fields={'ordinal','id','argv','env','cwd','start','end','effective_deadline','pid','starttime','namespace','pgid','rc','reaped','streams_eof','remaining_count','stdout_bytes','stdout_sha256','stderr_bytes','stderr_sha256','stop_reason'}
        if type(r) is not dict or set(r)!=fields:self.fail('RESULT_SCHEMA')
        spec=self.recipe[self.completed];direct=self.pending['direct']
        argv=[self.approved if x=='{APPROVED_MANIFEST_SHA256}' else x for x in spec['argv']]
        for key,value in {'ordinal':message['ordinal'],'id':message['id'],'argv':argv,'cwd':spec['cwd'],'effective_deadline':self.pending['deadline'],'pid':direct['pid'],'starttime':direct['start'],'namespace':direct['namespace'],'pgid':direct['pgid'],'rc':0,'reaped':True,'streams_eof':True,'remaining_count':0,'stop_reason':None}.items():self.exact(r[key],value)
        # Exact policy environment is required; no inherited environment allowed.
        self.exact(r['env'],self.policy['fixed_environment'])
        if any(type(r[k]) not in (int,float) or not math.isfinite(r[k]) for k in ('start','end')) or not self.t0<=r['start']<=r['end']<self.pending['deadline']:self.fail('RESULT_TIME')
        for channel in ('stdout','stderr'):
            p=ROOT/'run'/(message['id']+'.'+channel)
            if type(r[channel+'_bytes']) is not int or not 0<=r[channel+'_bytes']<=16777216 or p.stat().st_size!=r[channel+'_bytes'] or sha(p)!=r[channel+'_sha256']:self.fail('LOG_HASH')
        if sha(path)!=expected_hash:self.fail('RESULT_CHANGED_DURING_READ')

def runtime_main():
    p=argparse.ArgumentParser()
    p.add_argument('--manifest-sha256',required=True)
    p.add_argument('--origin-monotonic',required=True,type=float)
    p.add_argument('--run-id',required=True)
    p.add_argument('--parent',required=True,nargs=2)
    p.add_argument('--watchdog',required=True,nargs=2)
    p.add_argument('--control-fd',required=True,type=int)
    p.add_argument('--ack-fd',required=True,type=int)
    p.add_argument('--telemetry-fd',required=True,type=int)
    args=p.parse_args()
    for pair in (args.parent,args.watchdog):
        if not pair[0].isdigit() or str(int(pair[0]))!=pair[0] or not pair[1].isdigit():raise ValueError('CANONICAL_IDENTITY')
    if len({args.control_fd,args.ack_fd,args.telemetry_fd})!=3:raise ValueError('FD_ALIAS')
    for fd in (args.control_fd,args.ack_fd,args.telemetry_fd):pipe(fd)
    core=PreparationGuard(args.manifest_sha256,args.origin_monotonic,args.run_id,(int(args.parent[0]),args.parent[1]),(int(args.watchdog[0]),args.watchdog[1]))
    cancellation=[]
    for sig in (signal.SIGINT,signal.SIGTERM,signal.SIGHUP):signal.signal(sig,lambda number,frame:cancellation.append(number))
    ready=core.base('PREP_GUARD_READY')
    ready.update(manifest_sha256=core.approved,t0=core.t0,parent_identity=public(core.parent),watchdog_identity=public(core.watchdog),guard_identity=public(core.me))
    ready_deadline=min(time.monotonic()+120,core.deadline)
    core.check();send(args.telemetry_fd,ready,ready_deadline);core.check()
    reader=Reader(args.control_fd);rejection_reported=False;transport_failed=False
    try:
        while time.monotonic()<core.close_deadline:
            try:
                if cancellation:
                    cancellation.clear();core.fail('CANCELLED')
                core.check(work=core.state not in ('CLOSING','WAIT_ACK_PERSISTED','CLOSED'),negative=core.failure is not None)
                if core.failure is not None:core.cleanup_tick()
                message=reader.next()
                if message is None:
                    poll=select.poll();poll.register(args.control_fd,select.POLLIN|select.POLLHUP|select.POLLERR)
                    end=min(core.close_deadline,core.pending['deadline'] if core.pending is not None and core.failure is None else core.close_deadline)
                    poll.poll(max(0,int(min(.01,max(0,end-time.monotonic()))*1000)));continue
                response=core.handle(message)
                end=min(time.monotonic()+2,core.close_deadline,core.pending['deadline'] if core.pending is not None and core.failure is None else core.close_deadline)
                core.check(work=False,negative=core.failure is not None)
                send(args.ack_fd,response,end)
                if response['type']=='closure_begin_ack':core.closure_expected=True
                if response['type']=='ack_persisted_ack':
                    event=core.base('guard_event');event.update(event='CLOSED',completed=core.completed,test_count=0)
                    send(args.telemetry_fd,event,min(time.monotonic()+2,core.close_deadline))
                    return 0 if core.success_requested and core.failure is None else 2
            except BaseException:
                if core.failure is None:core.failure='GUARD_REJECTED'
                if core.state not in ('CLOSING','WAIT_ACK_PERSISTED','CLOSED'):core.state='STOPPED'
                try:core.cleanup_tick()
                except BaseException:transport_failed=True
                if reader.eof or time.monotonic()>=core.close_deadline:transport_failed=True
                if not rejection_reported and not transport_failed:
                    error=core.base('guard_rejected');error.update(error_code='GUARD_REJECTED',completed=core.completed,test_count=0)
                    event=core.base('guard_event');event.update(event='REJECTED',completed=core.completed,test_count=0)
                    try:
                        send(args.ack_fd,error,min(time.monotonic()+2,core.close_deadline))
                        send(args.telemetry_fd,event,min(time.monotonic()+2,core.close_deadline))
                        rejection_reported=True
                    except BaseException:transport_failed=True
                if transport_failed:break
                time.sleep(min(.01,max(0,core.close_deadline-time.monotonic())))
        # No successful release without persisted ACK. Exterior owns later reap.
        if core.stop_time is None:core.stop_time=time.monotonic()
        if core.failure is None:core.failure='CLOSURE_DEADLINE'
        while time.monotonic()<core.t0+4800:
            try:
                rows=core.work_inventory()
                for row in rows:signal_row(row,signal.SIGKILL if time.monotonic()>=min(core.stop_time+1,core.t0+4790) else signal.SIGTERM)
            except BaseException:rows=[None]
            if not rows and time.monotonic()>=core.close_deadline:break
            time.sleep(min(.01,max(0,core.t0+4800-time.monotonic())))
        return 2
    finally:
        for fd in core.role_pidfds+([core.started_fd] if core.started_fd is not None else []):os.close(fd)
        for fd in (args.control_fd,args.ack_fd,args.telemetry_fd):os.close(fd)

def main():
    return runtime_main()
if __name__=='__main__':sys.exit(main())

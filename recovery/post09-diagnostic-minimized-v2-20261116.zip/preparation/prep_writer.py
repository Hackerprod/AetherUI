import sys, os, json, hashlib, stat, re, time
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
EXPECTED_ROOT=Path('/RELOCATE/preparation')
def authenticate(approved):
    if ROOT!=EXPECTED_ROOT or not re.fullmatch('[0-9a-f]{64}',approved):raise ValueError('ROOT_OR_AUTHORITY')
    def unique(items):
        d={}
        for k,v in items:
            if k in d:raise ValueError('DUPLICATE')
            d[k]=v
        return d
    def plain(p):
        for a in [p,*p.parents]:
            if a.is_symlink():raise ValueError('SYMLINK')
        if not stat.S_ISREG(p.lstat().st_mode):raise ValueError('NOT_REGULAR')
        return p.read_bytes()
    raw=plain(ROOT/'evidence.sha256.json')
    if hashlib.sha256(raw).hexdigest()!=approved:raise ValueError('UNAPPROVED')
    rows=json.loads(raw,object_pairs_hook=unique,parse_constant=lambda value: (_ for _ in ()).throw(ValueError('NONFINITE_JSON'))); seen=set()
    if type(rows) is not list:raise ValueError('MANIFEST_SCHEMA')
    for row in rows:
        if type(row) is not dict or set(row)!={'path','bytes','sha256'} or type(row['bytes']) is not int or row['bytes']<0 or type(row['sha256']) is not str or not re.fullmatch('[0-9a-f]{64}',row['sha256']):raise ValueError('MANIFEST_ROW')
        name=row['path']
        if not isinstance(name,str) or name.startswith('/') or any(s in ('','.','..') for s in name.split('/')) or '\\' in name or '\x00' in name or name in seen:raise ValueError('PATH')
        seen.add(name); data=plain(ROOT/name)
        if len(data)!=row['bytes'] or hashlib.sha256(data).hexdigest()!=row['sha256']:raise ValueError('CONTENT')
    if not {'prep_collector.py','prep_external_supervisor.py','prep_writer.py','prep_external_contract.py','prep-external-recipe.json','prep_entry.py'}<=seen:raise ValueError('MISSING_MODULE')
    if 'policy.json' not in seen:raise ValueError('MISSING_TOOL_POLICY')
    policy=json.loads(plain(ROOT/'policy.json'),object_pairs_hook=unique,parse_constant=lambda value: (_ for _ in ()).throw(ValueError('NONFINITE_JSON')))
    record=policy['tools']['python3']
    expected='/RELOCATE/python3'
    if record['path']!=expected or not re.fullmatch('[0-9a-f]{64}',record['sha256']):raise ValueError('INTERPRETER_AUTHORITY')
    resolved=Path(expected).resolve(strict=True)
    if Path(sys.executable).resolve(strict=True)!=resolved or Path('/proc/self/exe').resolve(strict=True)!=resolved:raise ValueError('INTERPRETER_IDENTITY')
    executable=plain(resolved)
    if hashlib.sha256(executable).hexdigest()!=record['sha256']:raise ValueError('INTERPRETER_CONTENT')

def main():
    if len(sys.argv)!=4:raise ValueError('ARGV')
    approved,t0,runid=sys.argv[1:];authenticate(approved);t0=float(t0)
    if not re.fullmatch('[0-9a-f]{32}',runid) or not 0<=time.monotonic()-t0<4776:raise ValueError('ORIGIN')
    from prep_external_contract import directory_identity,check_directories,identity,same,namespace_identity
    import select
    parent=identity(os.getppid());parentfd=os.pidfd_open(os.getppid())
    deadline=min(time.monotonic()+2,t0+4776)
    def check():
        if time.monotonic()>=deadline:raise ValueError('WRITER_DEADLINE')
        current=identity(parent['pid']) if parent else None
        if parent is None or not same(parent) or current is None or current['state'] in ('Z','X','x') or select.select([parentfd],[],[],0)[0]:raise ValueError('WRITER_PARENT_LOST')
    check()
    directory=ROOT/'run'/'external-output'/runid
    pinned={str(path):directory_identity(path) for path in (ROOT/'run',ROOT/'run'/'external-output',directory)}
    # Parent protects bounded blocking input/file operations; this is not a hard IO guarantee.
    raw=sys.stdin.buffer.read(262145);check()
    if len(raw)>262144:raise ValueError('CAPTURE_QUOTA')
    value=json.loads(raw,object_pairs_hook=unique_json,parse_constant=lambda value: (_ for _ in ()).throw(ValueError('NONFINITE_JSON')))
    if type(value) is not dict or value.get('run_id')!=runid or value.get('manifest_sha256')!=approved or value.get('external_closure_status')!='CLOSURE_PENDING':raise ValueError('IDENTITY')
    if value.get('directory_identities')!=pinned:raise ValueError('DIRECTORY_PARENT_PIN')
    check_directories(pinned);check()
    dfd=os.open(directory,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW|os.O_CLOEXEC)
    try:
        for name in ('capture.partial','capture.json'):
            try:os.stat(name,dir_fd=dfd,follow_symlinks=False)
            except FileNotFoundError:pass
            else:raise ValueError('OUTPUT_EXISTS')
        fd=os.open('capture.partial',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC,0o600,dir_fd=dfd)
        try:
            if not stat.S_ISREG(os.fstat(fd).st_mode):raise ValueError('OUTPUT_TYPE')
            offset=0
            while offset<len(raw):
                check();count=os.write(fd,raw[offset:])
                if count<=0:raise ValueError('SHORT_WRITE')
                offset+=count
            check();os.fsync(fd)
        finally:os.close(fd)  # A failing close aborts receipt; do not retry EINTR.
        check();check_directories(pinned)
        # Hard-link exclusive destination avoids rename's overwrite behavior.
        os.link('capture.partial','capture.json',src_dir_fd=dfd,dst_dir_fd=dfd,follow_symlinks=False)
        check();os.unlink('capture.partial',dir_fd=dfd)
        check();check_directories(pinned)
    finally:os.close(dfd)
    check()
    receipt=json.dumps({'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'writer_identity':namespace_identity(os.getpid()),'directory_identities_sha256':hashlib.sha256(json.dumps(pinned,sort_keys=True,separators=(',',':')).encode()).hexdigest()},separators=(',',':')).encode()+b'\n'
    if len(receipt)>1024:raise ValueError('RECEIPT_QUOTA')
    os.set_blocking(1,False)
    if os.write(1,receipt)!=len(receipt):return 2
    return 0

def unique_json(pairs):
    value={}
    for key,item in pairs:
        if key in value:raise ValueError('DUPLICATE_KEY')
        value[key]=item
    return value
if __name__=='__main__':sys.exit(main())

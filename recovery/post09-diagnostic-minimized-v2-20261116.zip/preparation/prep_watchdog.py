"""V19/V20 ZERO_TESTS worker and controller. Runtime requires authenticated parent admission.
No Coordinator, candidate guard or product module is imported here.
"""
import os,sys,json,hashlib,stat,time,math,select,signal,subprocess,ctypes,re
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
EXPECTED_ROOT=Path('/RELOCATE/preparation')
IDS=('configure-Hc','configure-J','build-Hc','build-J','inventory-Hc','inventory-J','gate-inventory','gate-comparability')
STAGES=('configure','configure','build','build','inventory','inventory','inventory-gate','comparability')
CAPS=(120,120,1800,1800,120,120,120,120)
MODE='PREPARATION_ZERO_TESTS'
class Rejected(RuntimeError):pass

def need(ok,code):
    if not ok:raise Rejected(code)
def unique(items):
    d={}
    for k,v in items:need(k not in d,'DUPLICATE_JSON_KEY');d[k]=v
    return d
def parse(raw):return json.loads(raw,object_pairs_hook=unique,parse_constant=lambda x:(_ for _ in ()).throw(Rejected('NONFINITE_JSON')))
def sha(data):return hashlib.sha256(data).hexdigest()
def plain(path):
    path=Path(path)
    for p in (path,*path.parents):need(not p.is_symlink(),'SYMLINK')
    need(stat.S_ISREG(path.lstat().st_mode),'REGULAR_REQUIRED')
    return path.read_bytes()
def authenticate(approved):
    need(ROOT==EXPECTED_ROOT and isinstance(approved,str) and re.fullmatch('[0-9a-f]{64}',approved),'AUTHORITY')
    raw=plain(ROOT/'evidence.sha256.json');need(sha(raw)==approved,'MANIFEST_HASH');rows=parse(raw);need(type(rows) is list,'MANIFEST_LIST');names=set()
    for row in rows:
        need(type(row) is dict and set(row)=={'path','bytes','sha256'},'MANIFEST_ROW');name=row['path']
        need(type(name) is str and name and not name.startswith('/') and '\\' not in name and '\x00' not in name and all(x not in ('','.','..') for x in name.split('/')) and name not in names,'MANIFEST_PATH')
        names.add(name);data=plain(ROOT/name);need(type(row['bytes']) is int and len(data)==row['bytes'] and sha(data)==row['sha256'],'MEMBER_HASH')
    need({'prep_watchdog.py','prep_guard.py','prep_entry.py','policy.json','argv.json','manifest_contract.py','frozen_custody.py'}<=names,'MISSING_AUTHORITY')
    policy=parse(plain(ROOT/'policy.json'));tool=policy['tools']['python3'];real=Path(tool['path']).resolve(strict=True)
    need(Path(sys.executable).resolve(strict=True)==real and Path('/proc/self/exe').resolve(strict=True)==real and sha(plain(real))==tool['sha256'],'INTERPRETER')
    return policy,parse(plain(ROOT/'argv.json'))

def identity(pid):
    try:
        s=Path('/proc',str(pid),'stat').read_text();v=s[s.rfind(')')+2:].split()
    except (FileNotFoundError,ProcessLookupError):return None
    try:namespace=os.readlink('/proc/'+str(pid)+'/ns/pid')
    except (FileNotFoundError,ProcessLookupError):namespace=None
    return dict(pid=pid,starttime=v[19],namespace=namespace,ppid=int(v[1]),pgid=int(v[2]),state=v[0])
def same(row):
    now=identity(row['pid'])
    return bool(now and now['starttime']==row['starttime'] and (now['namespace']==row['namespace'] or (now['namespace'] is None and now['state'] in ('Z','X','x'))))
def inventory(known):
    rows={}
    for p in Path('/proc').iterdir():
        if p.name.isdigit():
            row=identity(int(p.name))
            if row:rows[row['pid']]=row
    descendants={os.getpid()};change=True
    while change:
        change=False
        for pid,row in rows.items():
            if row['ppid'] in descendants and pid not in descendants:descendants.add(pid);change=True
    for pid in descendants-{os.getpid()}:
        row=rows[pid];key=(pid,row['starttime'])
        if key not in known:known[key]=row
    return [r for r in known.values() if same(r)]
def signal_pinned(row,sig):
    if not same(row):return 'IDENTITY_GONE'
    try:
        fd=os.pidfd_open(row['pid'])
        try:
            if not same(row):return 'IDENTITY_GONE'
            signal.pidfd_send_signal(fd,sig,None,0);return 'SENT'
        finally:os.close(fd)
    except ProcessLookupError:return 'IDENTITY_GONE'
    except OSError:return 'SIGNAL_ERROR'
def reap_adopted(rows,direct):
    for row in rows:
        if row['pid']==direct:continue
        now=identity(row['pid'])
        if now and same(row) and now['ppid']==os.getpid():
            try:os.waitpid(row['pid'],os.WNOHANG)
            except ChildProcessError:pass

def run_identity():
    p=ROOT/'run'
    for q in (p,*p.parents):need(not q.is_symlink(),'RUN_SYMLINK')
    st=p.lstat();need(stat.S_ISDIR(st.st_mode) and p.resolve(strict=True)==p,'RUN_DIRECTORY')
    return dict(canonical=str(p),dev=st.st_dev,ino=st.st_ino)
def save_exclusive(path,value,deadline):
    need(time.monotonic()<deadline,'PERSISTENCE_DEADLINE')
    raw=json.dumps(value,separators=(',',':'),allow_nan=False).encode();path=Path(path)
    fd=os.open(path,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
    try:
        off=0
        while off<len(raw):
            need(time.monotonic()<deadline,'PERSISTENCE_DEADLINE');n=os.write(fd,raw[off:]);need(n>0,'SHORT_WRITE');off+=n
        os.fsync(fd)
    finally:os.close(fd)
    need(time.monotonic()<deadline and plain(path)==raw,'PERSISTENCE_INCOMPLETE');return sha(raw)

class Channel:
    """One outstanding request/reply. Calls are bounded and checkpoint protected."""
    def __init__(self,readfd,writefd,checkpoint):
        self.r=readfd;self.w=writefd;self.checkpoint=checkpoint;self.buffer=bytearray();self.negative_queue=False
        for fd in (readfd,writefd):
            need(stat.S_ISFIFO(os.fstat(fd).st_mode) and os.fpathconf(fd,'PC_PIPE_BUF')>=4096,'CONTROL_PIPE')
            os.set_blocking(fd,False);os.set_inheritable(fd,False)
    def send(self,value,deadline):
        raw=json.dumps(value,separators=(',',':'),allow_nan=False).encode();need(len(raw)<=4092,'CONTROL_QUOTA');wire=len(raw).to_bytes(4,'little')+raw;offset=0
        while offset<len(wire):
            self.checkpoint();need(time.monotonic()<deadline,'CONTROL_DEADLINE')
            _,ready,_=select.select([],[self.w],[],min(.02,max(0,deadline-time.monotonic())))
            if ready:
                try:offset+=os.write(self.w,wire[offset:])
                except (BlockingIOError,InterruptedError):pass
    def receive(self,deadline):
        while True:
            self.checkpoint();need(time.monotonic()<deadline,'CONTROL_DEADLINE')
            if len(self.buffer)>=4:
                size=int.from_bytes(self.buffer[:4],'little');need(2<=size<=4092,'FRAME_LENGTH')
                if len(self.buffer)>=size+4:
                    need(self.negative_queue or len(self.buffer)==size+4,'UNEXPECTED_QUEUED_FRAME');raw=bytes(self.buffer[4:size+4]);del self.buffer[:size+4];return parse(raw)
            ready,_,_=select.select([self.r],[],[],min(.02,max(0,deadline-time.monotonic())))
            if ready:
                try:part=os.read(self.r,4097-len(self.buffer))
                except (BlockingIOError,InterruptedError):continue
                need(part,'CONTROL_EOF');self.buffer.extend(part);need(len(self.buffer)<=4096,'CONTROL_QUOTA')
    def exchange(self,message,expected,deadline):
        self.send(message,deadline);need(self.receive(deadline)==expected,'ACK_MISMATCH')

class WorkerCore:
    """Real job machinery, wired by runtime_main after authenticated bootstrap.
    Caller must supply authenticated parent/run identities via approved channels.
    Missing or divergent quota and identity evidence rejects admission.
    """
    def __init__(self,approved,t0,runid,parent,guard,run_pin,guard_channel,custody):
        self.policy,self.rows=authenticate(approved)
        need(type(t0) is float and math.isfinite(t0) and 0<=time.monotonic()-t0<4500,'ORIGIN')
        need(type(runid) is str and re.fullmatch('[0-9a-f]{32}',runid),'RUN_ID')
        need([r['id'] for r in self.rows]==list(IDS) and [r['stage'] for r in self.rows]==list(STAGES) and [r['cap_seconds'] for r in self.rows]==list(CAPS),'EIGHT_JOB_RECIPE')
        need(run_identity()==run_pin,'UNAUTHENTICATED_RUN_IDENTITY')
        quotas=self.policy.get('job_log_limits');need(type(quotas) is dict and set(quotas)=={'stdout_bytes','stderr_bytes'} and all(type(n) is int and n==16777216 for n in quotas.values()),'JOB_LOG_QUOTAS')
        self.quotas=quotas;self.approved=approved;self.t0=t0;self.work=t0+4500;self.absolute=t0+4800;self.runid=runid;self.parent=parent;self.guard=guard;self.runpin=run_pin;self.channel=guard_channel;self.custody=custody
        self.next=1;self.pending=None;self.failure=None;self.results=[];self.known={};self.cancelled=[];self.last_resource=0
        need(ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)==0,'SUBREAPER')
        for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):signal.signal(sig,lambda n,f:self.cancelled.append(n))
    def fail(self,code):
        if self.failure is None:self.failure=code
        raise Rejected(self.failure)
    def checkpoint(self):
        if self.failure:self.fail(self.failure)
        if self.cancelled:self.fail('SIGNAL')
        for row in (self.parent,self.guard):
            now=identity(row['pid'])
            if not same(row) or now is None or now['state'] in ('Z','X','x'):self.fail('PROTECTOR_LOST')
        if run_identity()!=self.runpin:self.fail('RUN_IDENTITY_CHANGED')
        now=time.monotonic()
        if now-self.last_resource>=1:
            self.last_resource=now;mem={a:int(b.split()[0])*1024 for a,b in (line.split(':',1) for line in Path('/proc/meminfo').read_text().splitlines())};disk=os.statvfs(ROOT)
            if disk.f_bavail*disk.f_frsize<12*1024**3 or mem['MemAvailable']<4*1024**3:self.fail('RESOURCE_PRESSURE')
        if time.monotonic()>=self.work:self.fail('GLOBAL_WORK_CAP')
        if self.pending and time.monotonic()>=self.pending['deadline']:self.fail('JOB_CAP')
    def message(self,kind,**fields):return dict(type=kind,session=str(ROOT),run_id=self.runid,**fields)
    def exchange(self,kind,fields,deadline):
        self.channel.exchange(self.message(kind,**fields),self.message(kind+'_ack',**fields),deadline)
    def execute_job(self,ordinal):
        need(type(ordinal) is int and ordinal==self.next and 1<=ordinal<=8,'SEQUENCE')
        self.checkpoint();spec=self.rows[ordinal-1]
        # No dynamic command supplied by entry: only authenticated recipe ordinal.
        argv=[self.approved if a=='{APPROVED_MANIFEST_SHA256}' else a for a in spec['argv']]
        env=dict(self.policy['fixed_environment']);cwd=spec['cwd'];need(spec['stage'] not in ('test','observer'),'ZERO_TESTS')
        self.custody.check('before-'+spec['id'],self.work);self.custody.check_negative_paths('before-'+spec['id'],self.work)
        self.checkpoint();logs={};process=None;pidfd=None;streams={};eof={'stdout':False,'stderr':False};counts={'stdout':0,'stderr':0};hashes={k:hashlib.sha256() for k in counts};reaped=False;rc=None;started=None
        try:
            for name in ('stdout','stderr'):
                logs[name]=os.open(ROOT/'run'/(spec['id']+'.'+name),os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
            start=time.monotonic();deadline=min(start+CAPS[ordinal-1],self.work)
            self.pending=dict(ordinal=ordinal,id=spec['id'],deadline=deadline)
            # Pending is set BEFORE arm. Guard's ACK proves deadline stored first.
            self.exchange('arm',self.pending,deadline);self.checkpoint()
            need(time.monotonic()<deadline,'PRE_SPAWN_DEADLINE')
            process=subprocess.Popen(argv,cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,close_fds=True,start_new_session=True)
            # Handlers only set flags: identity registration is never skipped.
            started=identity(process.pid)
            need(started is not None and started['namespace'] is not None,'POST_SPAWN_IDENTITY_UNAVAILABLE')
            self.known[(started['pid'],started['starttime'])]=started;pidfd=os.pidfd_open(process.pid)
            fields=dict(ordinal=ordinal,id=spec['id'],pid=started['pid'],starttime=started['starttime'],namespace=started['namespace'],pgid=started['pgid'])
            self.checkpoint();self.exchange('started',fields,deadline)
            streams={process.stdout.fileno():'stdout',process.stderr.fileno():'stderr'}
            for fd in streams:os.set_blocking(fd,False)
            while True:
                self.checkpoint();rc=process.poll();reaped=rc is not None
                rows=inventory(self.known);reap_adopted(rows,process.pid);remaining=inventory(self.known)
                if reaped and not streams and not remaining:break
                ready,_,_=select.select(list(streams),[],[],min(.02,max(0,deadline-time.monotonic())))
                for fd in ready:
                    name=streams[fd]
                    try:data=os.read(fd,8192)
                    except (BlockingIOError,InterruptedError):continue
                    if not data:eof[name]=True;streams.pop(fd);continue
                    counts[name]+=len(data)
                    if counts[name]>self.quotas[name+'_bytes']:self.fail('LOG_QUOTA')
                    hashes[name].update(data);offset=0
                    while offset<len(data):
                        self.checkpoint();n=os.write(logs[name],data[offset:]);need(n>0,'LOG_WRITE');offset+=n
            need(rc==0,'WORK_RC');self.checkpoint()
            for name,fd in list(logs.items()):
                os.fsync(fd);os.close(fd);del logs[name];self.checkpoint()
            self.custody.check('after-'+spec['id'],deadline);self.custody.check_negative_paths('after-'+spec['id'],deadline)
            self.checkpoint();need(not inventory(self.known),'RESTS_AFTER_CUSTODY')
            result=dict(ordinal=ordinal,id=spec['id'],argv=argv,env=env,cwd=cwd,start=start,end=time.monotonic(),effective_deadline=deadline,pid=started['pid'],starttime=started['starttime'],namespace=started['namespace'],pgid=started['pgid'],rc=rc,reaped=reaped,streams_eof=all(eof.values()),remaining_count=0,stdout_bytes=counts['stdout'],stdout_sha256=hashes['stdout'].hexdigest(),stderr_bytes=counts['stderr'],stderr_sha256=hashes['stderr'].hexdigest(),stop_reason=None)
            result_hash=save_exclusive(ROOT/'run'/(spec['id']+'.json'),result,deadline)
            self.checkpoint();need(not inventory(self.known),'RESTS_BEFORE_DISARM')
            fields=dict(self.pending,result_sha256=result_hash,direct_reaped=True,streams_eof=True,remaining_count=0)
            self.exchange('disarm',fields,deadline)
            self.checkpoint();self.exchange('prepared_step',dict(ordinal=ordinal,id=spec['id'],result_sha256=result_hash),deadline)
            self.pending=None;self.results.append(result_hash);self.next+=1;return result
        except BaseException as exc:
            if self.failure is None:self.failure='JOB_REJECTED:'+type(exc).__name__
            # No disarm/next ordinal on any failure. Own and guard protection stay.
            stopped=time.monotonic();kill_at=min(stopped+1,self.t0+4790)
            while time.monotonic()<self.absolute:
                rows=inventory(self.known)
                for row in rows:signal_pinned(row,signal.SIGTERM if time.monotonic()<kill_at else signal.SIGKILL)
                if process is not None:rc=process.poll();reap_adopted(rows,process.pid)
                for fd in list(streams):
                    try:
                        data=os.read(fd,8192)
                        if not data:streams.pop(fd)
                    except BlockingIOError:pass
                    except OSError:streams.pop(fd)
                if (process is None or process.poll() is not None) and not inventory(self.known) and not streams:break
                time.sleep(min(.02,max(0,self.absolute-time.monotonic())))
            raise
        finally:
            for fd in logs.values():
                try:os.close(fd)
                except OSError:pass
            if pidfd is not None:os.close(pidfd)


def runtime_main():
    import argparse
    a=argparse.ArgumentParser();a.add_argument('--manifest-sha256',required=True);a.add_argument('--origin-monotonic',required=True,type=float);a.add_argument('--run-id',required=True);a.add_argument('--parent',required=True,nargs=2);a.add_argument('--command-fd',required=True,type=int);a.add_argument('--reply-fd',required=True,type=int);a.add_argument('--guard-fd',required=True,type=int);a.add_argument('--guard-ack-fd',required=True,type=int);args=a.parse_args()
    need(len({args.command_fd,args.reply_fd,args.guard_fd,args.guard_ack_fd})==4 and all(x>2 for x in (args.command_fd,args.reply_fd,args.guard_fd,args.guard_ack_fd)),'FD_ALIAS_OR_RESERVED')
    policy,rows=authenticate(args.manifest_sha256);t0=args.origin_monotonic;need(math.isfinite(t0) and 0<=time.monotonic()-t0<4500,'ORIGIN');need(re.fullmatch('[0-9a-f]{32}',args.run_id),'RUN_ID')
    parent=identity(int(args.parent[0]));need(parent and parent['pid']==os.getppid() and parent['starttime']==args.parent[1] and parent['state'] not in ('Z','X','x'),'PARENT')
    startup=min(time.monotonic()+120,t0+4500);parentfd=os.pidfd_open(parent['pid'])
    def bootcheck():
        need(same(parent) and not select.select([parentfd],[],[],0)[0] and time.monotonic()<startup,'BOOTSTRAP_PROTECTOR_OR_DEADLINE')
    control=Channel(args.command_fd,args.reply_fd,bootcheck)
    def msg(kind,**kw):return dict(type=kind,session=str(ROOT),run_id=args.run_id,**kw)
    initial=control.receive(startup)
    need(type(initial) is dict and set(initial)=={'type','session','run_id','manifest_sha256','t0','run','guard_identity'} and initial['type']=='initialize' and initial['session']==str(ROOT) and initial['run_id']==args.run_id and initial['manifest_sha256']==args.manifest_sha256 and initial['t0']==t0,'INITIALIZE_SCHEMA')
    pin=initial['run'];need(type(pin) is dict and set(pin)=={'canonical','device','inode','type'} and pin['type']=='directory' and type(pin['device']) is int and type(pin['inode']) is int,'RUN_PIN_SCHEMA')
    runpin=dict(canonical=pin['canonical'],dev=pin['device'],ino=pin['inode']);need(run_identity()==runpin,'RUN_PIN')
    gi=initial['guard_identity'];need(type(gi) is dict and set(gi)=={'pid','start','namespace'},'GUARD_IDENTITY_SCHEMA');guard=identity(gi['pid']);need(guard and guard['starttime']==gi['start'] and guard['namespace']==gi['namespace'] and guard['ppid']==parent['pid'],'GUARD_IDENTITY')
    guardfd=os.pidfd_open(guard['pid'])
    def protectclose():
        need(same(parent) and same(guard) and not select.select([parentfd,guardfd],[],[],0)[0] and time.monotonic()<t0+4770,'CLOSURE_PROTECTOR_OR_DEADLINE')
    # All local imports follow complete manifest + interpreter authentication.
    from manifest_contract import load_list
    load_list(ROOT,args.manifest_sha256)
    from frozen_custody import FrozenCustody
    allowed=parse(plain(ROOT/'prep_authority.json'))['output_files'];need(type(allowed) is list and all(type(x) is str for x in allowed),'OUTPUT_AUTHORITY')
    def custody_save(path,value):
        protectclose();path=Path(path);rel=str(path.relative_to(ROOT));need(rel in allowed and rel+'.tmp' in allowed,'OUTPUT_NOT_APPROVED')
        need(run_identity()==runpin,'RUN_DRIFT');temp=Path(str(path)+'.tmp');raw=json.dumps(value,separators=(',',':'),allow_nan=False).encode()
        fd=os.open(temp,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        try:
            off=0
            while off<len(raw):
                protectclose();n=os.write(fd,raw[off:]);need(n>0,'CUSTODY_WRITE');off+=n
            os.fsync(fd)
        finally:os.close(fd)
        protectclose();need(not path.is_symlink(),'CUSTODY_DESTINATION');os.replace(temp,path);need(run_identity()==runpin,'RUN_DRIFT')
    custody=FrozenCustody(policy,custody_save,args.manifest_sha256)
    gchannel=Channel(args.guard_ack_fd,args.guard_fd,protectclose)
    worker=WorkerCore(args.manifest_sha256,t0,args.run_id,parent,guard,runpin,gchannel,custody)
    control.checkpoint=worker.checkpoint;gchannel.checkpoint=worker.checkpoint
    closed=False
    try:
        custody.check('initial',t0+4500);worker.checkpoint()
        control.send(msg('initialized',watchdog_identity={'pid':os.getpid(),'start':identity(os.getpid())['starttime'],'namespace':identity(os.getpid())['namespace']}),t0+4500)
        begin=control.receive(t0+4500)
        expected=msg('prepare_begin',mode=MODE,manifest_sha256=args.manifest_sha256,argv_sha256=sha(plain(ROOT/'argv.json')),expected_completed=8,expected_test_count=0)
        need(begin==expected,'PREPARE_BEGIN')
        gchannel.exchange(begin,{**begin,'type':'prepare_begin_ack'},t0+4500);control.send({**begin,'type':'prepare_begin_ack'},t0+4500)
        for ordinal in range(1,9):
            command=control.receive(t0+4500);need(type(command) is dict and command==msg('run',ordinal=ordinal,id=IDS[ordinal-1]) and type(command['ordinal']) is int,'RUN_COMMAND')
            result=worker.execute_job(ordinal)
            control.send(msg('result',ordinal=ordinal,id=IDS[ordinal-1],result_sha256=worker.results[-1],rc=result['rc'],cleanup_verified=True),t0+4500)
        command=control.receive(t0+4500);need(command==msg('prepare_end'),'PREPARE_END_COMMAND')
        inventory_report=parse(plain(ROOT/'run/inventory.json'));comparison=parse(plain(ROOT/'run/comparability.json'))
        need(inventory_report.get('status')=='PASS' and comparison.get('status')=='PASS','GATE_PASS_REQUIRED')
        custody.freeze_gate(comparison);custody.check('final',t0+4500);custody.check_negative_paths('final',t0+4500);worker.checkpoint()
        # Independent prepared inputs snapshot excludes itself and mutable closure.
        records=[]
        for path,digest in sorted(custody.gate_inputs.items()):
            p=Path(path);location=custody.gate_locations[path]
            def pinned_location():
                return dict(type=stat.S_IFMT(p.lstat().st_mode),resolved=str(p.resolve(strict=True)),link=os.readlink(p) if p.is_symlink() else None)
            need(pinned_location()==location,'GATE_LOCATION_DRIFT')
            # Only an alias already frozen by comparator/custody is accepted.
            # Read its pinned canonical target; do not relax plain() globally.
            data=plain(Path(location['resolved']))
            need(pinned_location()==location and sha(data)==digest,'GATE_INPUT_DRIFT')
            records.append(dict(path=path,bytes=len(data),sha256=digest,location=dict(location)))
        result_records=[]
        for ident in IDS:
            for suffix in ('.json','.stdout','.stderr'):
                p=ROOT/'run'/(ident+suffix);data=plain(p);result_records.append(dict(path=str(p),bytes=len(data),sha256=sha(data)))
        snapshot=dict(schema_version=1,mode=MODE,test_count=0,status='PREPARED_PENDING_D',input_manifest_sha256=args.manifest_sha256,argv_sha256=sha(plain(ROOT/'argv.json')),gate_inputs=records,job_outputs=result_records,negative_path_assertions=custody.negative_path_assertions,environment=policy['fixed_environment'],G1='NOT_PASSED',V3='BLOCKED',self_hash_excluded=True,closure_evidence_external=True)
        save_exclusive(ROOT/'run/prepared-inputs.json',snapshot,t0+4500);worker.checkpoint()
        end=msg('prepare_end',completed=8,test_count=0,last_id=IDS[-1],inventory_report_sha256=sha(plain(ROOT/'run/inventory.json')),comparability_report_sha256=sha(plain(ROOT/'run/comparability.json')),result_sha256s=worker.results)
        gchannel.exchange(end,{**end,'type':'prepare_end_ack'},t0+4500);control.send({**end,'type':'prepare_end_ack'},t0+4500)
        command=control.receive(t0+4500);need(command==msg('close_prepare',success=True,completed=8,test_count=0),'CLOSE_PREPARE')
        custody.check('closure',t0+4500);custody.check_negative_paths('closure',t0+4500);worker.checkpoint();need(not inventory(worker.known),'CLOSURE_WORK_REMAINS')
        close=msg('closure_begin',mode=MODE,success=True,completed=8,test_count=0)
        gchannel.exchange(close,{**close,'type':'closure_begin_ack'},t0+4500)
        control.checkpoint=protectclose;gchannel.checkpoint=protectclose
        control.send(msg('closed',success=True,completed=8,test_count=0,cleanup_verified=True,guard_closure_ack=True),t0+4770);closed=True;return 0
    except BaseException:
        if worker.failure is None:worker.failure='PREPARATION_REJECTED'
        control.checkpoint=protectclose;gchannel.checkpoint=protectclose
        # execute_job cleaned its descendants; other failures cannot create work.
        try:
            need(not inventory(worker.known),'NEGATIVE_CLOSURE_REMAINS')
            close=msg('closure_begin',mode=MODE,success=False,completed=len(worker.results),test_count=0)
            gchannel.negative_queue=True
            gchannel.send(close,t0+4770)
            reply=gchannel.receive(t0+4770)
            if reply.get('type')=='guard_rejected':
                need(reply==msg('guard_rejected',error_code='GUARD_REJECTED',completed=len(worker.results),test_count=0),'GUARD_REJECTED_SCHEMA')
                reply=gchannel.receive(t0+4770)
            need(reply=={**close,'type':'closure_begin_ack'} and not gchannel.buffer,'NEGATIVE_CLOSURE_ACK');gchannel.negative_queue=False
            control.send(msg('closed',success=False,completed=len(worker.results),test_count=0,cleanup_verified=True,guard_closure_ack=True),t0+4770);closed=True
        except BaseException:
            try:control.send(msg('failed',error_code='PREPARATION_REJECTED',completed=len(worker.results),test_count=0),t0+4770)
            except BaseException:pass
        return 2
    finally:
        # Only after this return/EOF and real waitpid may entry use its GC/GA.
        for fd in (args.command_fd,args.reply_fd,args.guard_fd,args.guard_ack_fd):
            try:os.close(fd)
            except OSError:pass

if __name__=='__main__':
    sys.exit(runtime_main())

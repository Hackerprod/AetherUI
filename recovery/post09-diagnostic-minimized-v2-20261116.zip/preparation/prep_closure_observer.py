import sys, os, json, hashlib, stat, re, time
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
EXPECTED_ROOT=Path('/RELOCATE/preparation')
def authenticate(approved):
    if ROOT!=EXPECTED_ROOT or not re.fullmatch('[0-9a-f]{64}',approved):raise ValueError('ROOT_OR_AUTHORITY')
    def unique(items):
        d={}
        for k,v in items:
            if k in d:raise ValueError('DUPLICATE')
            d[k]=v
        return d
    def plain(p):
        for a in [p,*p.parents]:
            if a.is_symlink():raise ValueError('SYMLINK')
        if not stat.S_ISREG(p.lstat().st_mode):raise ValueError('NOT_REGULAR')
        return p.read_bytes()
    raw=plain(ROOT/'evidence.sha256.json')
    if hashlib.sha256(raw).hexdigest()!=approved:raise ValueError('UNAPPROVED')
    rows=json.loads(raw,object_pairs_hook=unique,parse_constant=lambda value: (_ for _ in ()).throw(ValueError('NONFINITE_JSON'))); seen=set()
    if type(rows) is not list:raise ValueError('MANIFEST_SCHEMA')
    for row in rows:
        if type(row) is not dict or set(row)!={'path','bytes','sha256'} or type(row['bytes']) is not int or row['bytes']<0 or type(row['sha256']) is not str or not re.fullmatch('[0-9a-f]{64}',row['sha256']):raise ValueError('MANIFEST_ROW')
        name=row['path']
        if not isinstance(name,str) or name.startswith('/') or any(s in ('','.','..') for s in name.split('/')) or '\\' in name or '\x00' in name or name in seen:raise ValueError('PATH')
        seen.add(name); data=plain(ROOT/name)
        if len(data)!=row['bytes'] or hashlib.sha256(data).hexdigest()!=row['sha256']:raise ValueError('CONTENT')
    if not {'prep_collector.py','prep_external_supervisor.py','prep_writer.py','prep_external_contract.py','prep-external-recipe.json','prep_entry.py','prep_closure_observer.py','prep_outer_supervisor.py','prep-closure-recipe.json','prep_concurrency.py'}<=seen:raise ValueError('MISSING_MODULE')
    if 'policy.json' not in seen:raise ValueError('MISSING_TOOL_POLICY')
    policy=json.loads(plain(ROOT/'policy.json'),object_pairs_hook=unique,parse_constant=lambda value: (_ for _ in ()).throw(ValueError('NONFINITE_JSON')))
    record=policy['tools']['python3']
    expected='/RELOCATE/python3'
    if record['path']!=expected or not re.fullmatch('[0-9a-f]{64}',record['sha256']):raise ValueError('INTERPRETER_AUTHORITY')
    resolved=Path(expected).resolve(strict=True)
    if Path(sys.executable).resolve(strict=True)!=resolved or Path('/proc/self/exe').resolve(strict=True)!=resolved:raise ValueError('INTERPRETER_IDENTITY')
    executable=plain(resolved)
    if hashlib.sha256(executable).hexdigest()!=record['sha256']:raise ValueError('INTERPRETER_CONTENT')

def main():
    import select,subprocess,signal,ctypes
    if len(sys.argv)!=11 or sys.argv[1::2]!=['--manifest-sha256','--origin-monotonic','--run-id','--ready-fd','--final-fd']:raise ValueError('ARGV')
    approved=sys.argv[2];t0=float(sys.argv[4]);runid=sys.argv[6];readyfd=int(sys.argv[8]);finalfd=int(sys.argv[10]);authenticate(approved)
    from prep_external_contract import PYTHON,identity,same,discover,kill_verified,reap,unique,spawn_budget,check_spawn,directory_identity,check_directories,validate_directory,validate_summary,validate_capture,validate_entry
    from prep_concurrency import capture_role,ns
    policy=json.loads((ROOT/'policy.json').read_bytes(),object_pairs_hook=unique)
    if not 0<=time.monotonic()-t0<4500 or not re.fullmatch('[0-9a-f]{32}',runid):raise ValueError('ORIGIN')
    for fd in (readyfd,finalfd):
        if not stat.S_ISFIFO(os.fstat(fd).st_mode) or os.fpathconf(fd,'PC_PIPE_BUF')<4096:raise ValueError('PIPE')
        os.set_blocking(fd,False);os.set_inheritable(fd,False)
    if ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)!=0:raise RuntimeError('SUBREAPER')
    parent_pid=os.getppid();parent=identity(parent_pid);parentfd=os.pidfd_open(parent_pid)
    def ident(pid):
        r=identity(pid)
        if r is None:raise ValueError('IDENTITY')
        return dict(pid=pid,start=r['start'],namespace=os.readlink('/proc/'+str(pid)+'/ns/pid'))
    parent_identity=ident(parent_pid)
    state={'mode':'PREPARATION_ZERO_TESTS','test_count':0,'schema_version':1,'kind':'OBSERVER_FINAL','manifest_sha256':approved,'run_id':runid,'t0':t0,'work_status':'REJECTED','identified_work_closure':'UNVERIFIED','collector_identity':None,'collector_rc':None,'collector_reaped':False,'supervisor_identity':None,'supervisor_rc':None,'supervisor_reaped':False,'registration_valid':False,'capture_bytes':None,'capture_sha256':None,'capture_verified':False,'capture_truncated':False,'parent_lost':False,'remaining_identities_count':0,'error_code':'OBSERVER_REJECTED','outer_return':'NOT_SELF_OBSERVED','independent_outer_termination_guarantee':False}
    collector=None;superfd=None;known={};streams={};buffers={};registration=bytearray();registrationfd=None;ackfd=None
    def parent_alive():
        if state['parent_lost']:raise RuntimeError('PARENT_LOST')
        now=identity(parent_pid)
        if select.select([parentfd],[],[],0)[0] or os.getppid()!=parent_pid or not same(parent) or now is None or now['state'] in ('Z','X','x'):
            state['parent_lost']=True;raise RuntimeError('PARENT_LOST')
    def decode(raw):
        if len(raw)<4 or not 2<=int.from_bytes(raw[:4],'little')<=4092 or len(raw)!=4+int.from_bytes(raw[:4],'little'):raise ValueError('FRAME')
        return json.loads(bytes(raw[4:]),object_pairs_hook=unique,parse_constant=lambda value: (_ for _ in ()).throw(ValueError('NONFINITE_JSON')))
    def send(fd,value,deadline,check=True):
        payload=json.dumps(value,separators=(',',':')).encode();wire=len(payload).to_bytes(4,'little')+payload
        if len(wire)>4096:raise ValueError('FRAME_QUOTA')
        offset=0
        while offset<len(wire) and time.monotonic()<deadline:
            if check:parent_alive()
            _,ww,_=select.select([],[fd],[],min(.02,max(0,deadline-time.monotonic())))
            if ww:
                try:offset+=os.write(fd,wire[offset:])
                except (BlockingIOError,InterruptedError):pass
                except OSError:return False
        return offset==len(wire)
    def poll_supervisor():
        if not state['collector_reaped'] or state['supervisor_identity'] is None or state['supervisor_reaped']:return
        pid=state['supervisor_identity']['pid']
        if superfd is None or not select.select([superfd],[],[],0)[0]:return
        current=identity(pid)
        if current is not None and current['start']!=state['supervisor_identity']['start']:raise ValueError('ADOPTED_IDENTITY_CHANGED')
        try:
            got,status=os.waitpid(pid,os.WNOHANG)
            if got==pid:state['supervisor_rc']=os.waitstatus_to_exitcode(status);state['supervisor_reaped']=True
        except ChildProcessError:pass
    try:
        raw=bytearray();ready_eof=False
        while time.monotonic()<min(t0+4500,t0+4778):
            parent_alive();rr,_,_=select.select([readyfd],[],[],.02)
            if rr:
                part=os.read(readyfd,4097-len(raw));raw.extend(part)
                if len(raw)>4096:raise ValueError('READY_QUOTA')
                if not part:ready_eof=True;break
                # Require EOF as well as exact framing; late trailing bytes reject.
                if len(raw)>=4 and int.from_bytes(raw[:4],'little')>4092:raise ValueError('READY_LENGTH')
        if not ready_eof:raise ValueError('READY_EOF_MISSING')
        ready=decode(raw)
        if type(ready) is not dict or 'run' not in ready:raise ValueError('READY_RUN')
        run_identity=validate_directory(ready['run'],ROOT/'run')
        registry=ready.get('concurrency_roles')
        if type(registry) is not dict or set(registry)!={'namespaces','roles'} or registry['namespaces']!=ns(os.getpid()) or type(registry['roles']) is not list or [r.get('role') for r in registry['roles']]!=['outer','closure-observer']:raise ValueError('READY_ROLES')
        outer_argv=[PYTHON,'-B',str(ROOT/'prep_outer_supervisor.py'),'--manifest-sha256',approved]
        observer_argv=[PYTHON,'-B',str(ROOT/'prep_closure_observer.py'),*sys.argv[1:]]
        if registry['roles']!=[capture_role(policy,approved,'outer',parent_pid,outer_argv),capture_role(policy,approved,'closure-observer',os.getpid(),observer_argv)]:raise ValueError('ROLE_CHAIN')
        expected={'concurrency_roles':registry,'run':run_identity,'schema_version':1,'kind':'OUTER_READY','manifest_sha256':approved,'run_id':runid,'t0':t0,'parent_identity':parent_identity,'deadlines':{k:t0+v for k,v in [('work',4500),('internal',4770),('emission',4772),('observer',4778),('term',4780),('kill',4790),('absolute',4800)]}}
        if ready!=expected or type(ready['schema_version']) is not int:raise ValueError('READY_INVALID')
        os.close(readyfd);parent_alive()
        registrationfd,registration_w=os.pipe2(os.O_CLOEXEC|os.O_NONBLOCK);ack_r,ackfd=os.pipe2(os.O_CLOEXEC|os.O_NONBLOCK)
        argv=[PYTHON,'-B',str(ROOT/'prep_collector.py'),'--manifest-sha256',approved,'--origin-monotonic',repr(t0),'--run-id',runid,'--registration-fd',str(registration_w),'--registration-ack-fd',str(ack_r)]
        launch_deadline=spawn_budget(t0)
        parent_alive();check_spawn(launch_deadline,parent)
        collector=subprocess.Popen(argv,pass_fds=(registration_w,ack_r),stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,close_fds=True)
        state['collector_identity']=ident(collector.pid);os.close(registration_w);os.close(ack_r)
        parent_alive();check_spawn(launch_deadline,parent)
        registry['roles'].append(capture_role(policy,approved,'collector',collector.pid,argv))
        streams={registrationfd:('registration',4096),collector.stdout.fileno():('stdout',65536),collector.stderr.fileno():('stderr',65536)};buffers={k:bytearray() for k in ('registration','stdout','stderr')}
        for fd in streams:os.set_blocking(fd,False)
        while time.monotonic()<t0+4776:
            parent_alive();discover(os.getpid(),known)
            state['collector_rc']=collector.poll();state['collector_reaped']=state['collector_rc'] is not None;poll_supervisor()
            rr,_,_=select.select(list(streams),[],[],min(.02,max(0,t0+4776-time.monotonic())))
            # Drain all channels even if collector pidfd/wait signals exit.
            for fd in rr:
                name,quota=streams[fd]
                try:chunk=os.read(fd,8192)
                except BlockingIOError:continue
                if not chunk:streams.pop(fd);continue
                room=max(0,quota-len(buffers[name]));buffers[name].extend(chunk[:room])
                if len(chunk)>room:state['capture_truncated']=True
                if name=='registration' and not state['registration_valid'] and len(buffers[name])>=4 and len(buffers[name])>=4+int.from_bytes(buffers[name][:4],'little'):
                    check_spawn(launch_deadline,parent)
                    reg=decode(buffers[name]);keys={'schema_version','kind','manifest_sha256','run_id','t0','collector_identity','supervisor_identity','external_supervisor_role'}
                    if not isinstance(reg,dict) or set(reg)!=keys or type(reg['schema_version']) is not int or reg['schema_version']!=1 or reg['kind']!='COLLECTOR_REGISTRATION' or reg['manifest_sha256']!=approved or reg['run_id']!=runid or reg['t0']!=t0:raise ValueError('REGISTRATION_SCHEMA')
                    if reg['collector_identity']!=state['collector_identity'] or ident(collector.pid)!=state['collector_identity']:raise ValueError('COLLECTOR_IDENTITY')
                    sid=reg['supervisor_identity']
                    if not isinstance(sid,dict) or set(sid)!={'pid','start','namespace'} or type(sid['pid']) is not int or sid!=ident(sid['pid']) or identity(sid['pid'])['ppid']!=collector.pid:raise ValueError('SUPERVISOR_IDENTITY')
                    role=reg['external_supervisor_role']
                    if type(role) is not dict or type(role.get('fds')) is not dict or set(role['fds'])!={'ready'} or type(role['fds']['ready']) is not int:raise ValueError('SUPERVISOR_ROLE')
                    supervisor_argv=[PYTHON,'-B',str(ROOT/'prep_external_supervisor.py'),approved,repr(t0),str(collector.pid),state['collector_identity']['start'],str(role['fds']['ready'])]
                    if role!=capture_role(policy,approved,'external-supervisor',sid['pid'],supervisor_argv):raise ValueError('SUPERVISOR_ROLE_PIN')
                    registry['roles'].append(role)
                    superfd=os.pidfd_open(sid['pid']);state['supervisor_identity']=sid;state['registration_valid']=True
                    ack={'schema_version':1,'kind':'REGISTRATION_ACK','manifest_sha256':approved,'run_id':runid,'registration_sha256':hashlib.sha256(bytes(buffers[name][4:])).hexdigest(),'run':run_identity,'concurrency_roles':registry}
                    if not send(ackfd,ack,min(launch_deadline,time.monotonic()+2)):raise ValueError('ACK_WRITE')
                    os.close(ackfd);ackfd=None
                    parent_alive();check_spawn(launch_deadline,parent)
            # Extra registration bytes are rejected; an EOF is still required.
            if state['registration_valid']:decode(buffers['registration'])
            direct={collector.pid}
            if state['supervisor_identity']:direct.add(state['supervisor_identity']['pid'])
            reap([r for r in discover(os.getpid(),known) if r['pid'] not in direct])
            if state['collector_reaped'] and state['supervisor_reaped'] and not streams and not discover(os.getpid(),known):break
        parent_alive();poll_supervisor()
        if not state['registration_valid'] or streams or state['capture_truncated'] or not state['collector_reaped'] or not state['supervisor_reaped']:raise ValueError('INCOMPLETE_CAPTURE')
        # Read only the fixed path; never a path supplied by protocol content.
        lines=bytes(buffers['stdout']).splitlines()
        if len(lines)!=1:raise ValueError('COLLECTOR_SUMMARY_COUNT')
        summary=json.loads(lines[0],object_pairs_hook=unique,parse_constant=lambda value: (_ for _ in ()).throw(ValueError('NONFINITE_JSON')))
        validate_summary(summary,ROOT,runid,t0,state['supervisor_identity'],run_identity)
        if summary.get('run_id')!=runid or summary.get('external_guard_lost') is not False or summary.get('writer_receipt_valid') is not True or type(summary.get('writer_rc')) is not int or summary.get('writer_rc')!=0 or summary.get('writer_reaped') is not True:raise ValueError('COLLECTOR_SUMMARY')
        file=ROOT/'run'/'external-output'/runid/'capture.json'
        pinned={str(path):directory_identity(path) for path in (ROOT/'run',ROOT/'run'/'external-output',file.parent)}
        check_directories(pinned)
        for p in (file,*file.parents):
            if p.is_symlink():raise ValueError('CAPTURE_SYMLINK')
        if not stat.S_ISREG(file.lstat().st_mode) or file.stat().st_size>262144:raise ValueError('CAPTURE_TYPE_QUOTA')
        with open(file,'rb') as stream:captured=stream.read(262145)
        parent_alive()
        if len(captured)>262144 or len(captured)!=summary.get('capture_bytes') or hashlib.sha256(captured).hexdigest()!=summary.get('capture_sha256'):raise ValueError('CAPTURE_HASH')
        check_directories(pinned)
        if time.monotonic()>=t0+4776:raise ValueError('CAPTURE_DEADLINE')
        capture=json.loads(captured,object_pairs_hook=unique,parse_constant=lambda value: (_ for _ in ()).throw(ValueError('NONFINITE_JSON')))
        validate_capture(capture,ROOT,approved,runid,t0,state['supervisor_identity'],run_identity)
        validate_entry(capture['frame'],ROOT,approved,runid,t0,capture['launcher_rc'])
        if capture['directory_identities']!=summary['directory_identities']:raise ValueError('DIRECTORY_CHAIN')
        if capture.get('manifest_sha256')!=approved or capture.get('run_id')!=runid or capture.get('external_guard_lost') is not False or capture.get('collector_outcome')!='CAPTURE_AND_RETURN_OBSERVED' or capture.get('final_frame_valid') is not True or capture.get('final_frame_complete') is not True:raise ValueError('CAPTURE_CONTENT')
        for observation in (summary,capture):
            pinned=observation.get('external_supervisor_initial_identity')
            if not isinstance(pinned,dict) or pinned.get('pid')!=state['supervisor_identity']['pid'] or pinned.get('start')!=state['supervisor_identity']['start']:raise ValueError('PINNED_SUPERVISOR_CONFLICT')
        work=capture['frame']['preparation_status']
        if work not in ('PREPARED','REJECTED'):raise ValueError('WORK_STATUS')
        state.update(work_status=work,capture_bytes=len(captured),capture_sha256=hashlib.sha256(captured).hexdigest(),capture_verified=True)
        remaining=discover(os.getpid(),known);state['remaining_identities_count']=len(remaining)
        if state['collector_rc']==0 and state['supervisor_rc']==0 and not remaining and time.monotonic()<t0+4778:
            state['identified_work_closure']='OBSERVED';state['error_code']=None
        else:raise ValueError('CLOSURE_INCOMPLETE')
    except Exception:
        state['identified_work_closure']='UNVERIFIED';state['error_code']='OBSERVER_REJECTED'
        # No file writes/retries. Best-effort cleanup under the unchanged cap.
        kill_at=min(time.monotonic()+1,t0+4777)
        while time.monotonic()<t0+4777:
            rows=discover(os.getpid(),known)
            for row in rows:kill_verified(row,signal.SIGTERM if time.monotonic()<kill_at else signal.SIGKILL)
            if collector is not None:state['collector_rc']=collector.poll();state['collector_reaped']=state['collector_rc'] is not None
            poll_supervisor();excluded={collector.pid} if collector else set()
            if state['supervisor_identity']:excluded.add(state['supervisor_identity']['pid'])
            reap([r for r in rows if r['pid'] not in excluded])
            if not discover(os.getpid(),known):break
            time.sleep(min(.02,max(0,t0+4777-time.monotonic())))
        state['remaining_identities_count']=len(discover(os.getpid(),known))
    try:parent_alive()
    except Exception:state['parent_lost']=True;state['identified_work_closure']='UNVERIFIED';state['error_code']='OBSERVER_REJECTED'
    emitted=send(finalfd,state,min(time.monotonic()+2,t0+4778),check=False)
    os.close(finalfd)
    return 0 if emitted and state['work_status']=='PREPARED' and state['identified_work_closure']=='OBSERVED' else 2
if __name__=='__main__':sys.exit(main())

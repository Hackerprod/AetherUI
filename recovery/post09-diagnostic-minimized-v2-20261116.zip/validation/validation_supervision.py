#!/usr/bin/env python3
"""V0 materialization only. Future closed harness calls REAL frozen components.
No candidate is modified, no entry lock removed, no Coordinator/product invocation.
"""
import argparse
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import select
import signal
import stat
import subprocess
import sys
import time
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent

class HarnessFailure(RuntimeError):pass

def require(ok,message):
    if not ok:raise HarnessFailure(message)

def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def write(path,value):
    path=Path(path);temporary=path.with_name(path.name+'.tmp')
    with open(temporary,'x',encoding='utf-8') as stream:
        json.dump(value,stream,indent=2);stream.write('\n');stream.flush();os.fsync(stream.fileno())
    os.replace(temporary,path)

def auth(expected):
    require(len(expected)==64 and all(c in '0123456789abcdef' for c in expected),'MANIFEST_SHA_SCHEMA')
    mp=ROOT/'evidence.sha256.json';require(not mp.is_symlink() and stat.S_ISREG(mp.lstat().st_mode),'MANIFEST_TYPE')
    raw=mp.read_bytes();require(hashlib.sha256(raw).hexdigest()==expected,'MANIFEST_HASH')
    def unique(pairs):
        out={}
        for k,v in pairs:
            require(k not in out,'DUPLICATE_JSON_KEY');out[k]=v
        return out
    rows=json.loads(raw,object_pairs_hook=unique);require(isinstance(rows,list),'MANIFEST_LIST')
    records={}
    for row in rows:
        require(isinstance(row,dict) and set(row)=={'path','bytes','sha256'},'MANIFEST_ROW')
        key=row['path'];require(isinstance(key,str) and key and not key.startswith('/') and '\\' not in key and '\x00' not in key and all(c not in ('','.','..') for c in key.split('/')),'MANIFEST_PATH')
        require(key.split('/')[0]!='external-output','OUTPUT_NOT_INPUT')
        require(key not in records and type(row['bytes']) is int and row['bytes']>=0,'MANIFEST_DUPLICATE_SIZE')
        p=ROOT/key
        for parent in [p,*p.parents]:require(not parent.is_symlink(),'SYMLINK_AUTHORITY')
        require(stat.S_ISREG(p.lstat().st_mode),'MEMBER_TYPE:'+key)
        data=p.read_bytes();require(len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256'],'MEMBER_HASH:'+key)
        records[key]=row
    required={'supervisor.py','guard_deadlines.py','manifest_contract.py','frozen_custody.py','concurrency_preflight.py','verify_comparability.py','parse_post09_observer.py','validation_supervision.py','validation_job.py','validation-supervision-plan.json'}
    require(required<=records.keys(),'MISSING_AUTHENTICATED_MODULE')
    # Only now are local imports permitted. No __main__ candidate entry is run.
    sys.path.insert(0,str(ROOT))
    import manifest_contract
    manifest_contract.load_list(ROOT,expected,excluded=('run','build-Hc','build-J','home','tmp','external-output'))
    module_spec=importlib.util.spec_from_file_location('post09_supervisor_candidate',ROOT/'supervisor.py')
    sup=importlib.util.module_from_spec(module_spec);module_spec.loader.exec_module(sup)
    import frozen_custody
    return records,sup,frozen_custody

class Session:
    def __init__(self,scenario,manifest,deadline,records,sup,custody_module):
        self.id=scenario;self.sup=sup;self.records=records;self.manifest=manifest
        self.start=time.monotonic();self.deadline=min(deadline,self.start+60);self.work=min(self.start+45,self.deadline-10)
        require(self.work>self.start,'SCENARIO_NO_WORK_BUDGET')
        self.root=ROOT/'run/scenarios'/scenario;self.root.mkdir(parents=True,exist_ok=False)
        template=ROOT/'validation-scenarios'/scenario
        for name in ('case-policy.json','case.json','evidence.sha256.json'):
            data=(template/name).read_bytes();record=records['validation-scenarios/'+scenario+'/'+name]
            require(len(data)==record['bytes'] and hashlib.sha256(data).hexdigest()==record['sha256'],'TEMPLATE_DRIFT')
            (self.root/name).write_bytes(data)
        self.case=json.loads((self.root/'case.json').read_text())
        self.policy=json.loads((self.root/'case-policy.json').read_text())
        require(self.policy['root']==str(self.root),'SCENARIO_POLICY_ROOT')
        self.python=self.policy['tools']['python3']['path']
        require(Path(sys.executable).resolve()==Path(self.python).resolve() and digest(self.python)==self.policy['tools']['python3']['sha256'],'INTERPRETER_AUTHORITY')
        self.run=self.root/'run';self.run.mkdir()
        for t in ('Hc','J'):(self.root/('build-'+t)).mkdir()
        self.custody=custody_module.FrozenCustody(self.policy,write,records['validation-scenarios/'+scenario+'/evidence.sha256.json']['sha256'])
        self.custody.check('initial',self.work)
        negatives=[]
        for tree in ('Hc','J'):
            parent=self.root/('build-'+tree);st=parent.lstat()
            negatives.append(dict(path=str(parent/'glibc-hwcaps'),expected='ABSENT',method='lstat',parent=dict(path=str(parent),canonical_path=str(parent),device=st.st_dev,inode=st.st_ino,type='directory'),observed_monotonic=time.monotonic()))
        gate=dict(status='PASS',inputs={},negative_path_assertions=negatives,synthetic_authority=True,not_a_binary_comparability_result=True)
        write(self.run/'comparability.json',gate);self.custody.freeze_gate(gate)
        self.signals=[]
        for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):signal.signal(sig,lambda number,frame:self.signals.append(number))
        self.rbuf=b'';self.abuf=b'';self.tbuf=b'';self.telemetry_open=True;self.telemetry_records=[];self.results=[]
        r,w=os.pipe();rr,ww=os.pipe();gr,gw=os.pipe();ar,aw=os.pipe();tr,tw=os.pipe()
        self.sendfd=w;self.readfd=rr;self.guardfd=gw;self.ackfd=ar;self.telemetryfd=tr;os.set_blocking(tr,False)
        me=sup.proc(os.getpid())
        # This wrapper authenticates the exact candidate then calls watchdog(),
        # rather than invoking or removing its blocked __main__ entry.
        worker=[self.python,str(ROOT/'validation_supervision.py'),'--worker',str(r),str(ww),str(self.deadline),str(self.work),str(os.getpid()),me['start'],str(self.root),str(gw),str(ar),'--manifest-sha256',manifest]
        self.wd=subprocess.Popen(worker,pass_fds=(r,ww,gw,ar),stdin=subprocess.DEVNULL,stdout=open(self.run/'watchdog.stdout','xb'),stderr=open(self.run/'watchdog.stderr','xb'),start_new_session=True)
        os.close(r);os.close(ww)
        wi=sup.proc(self.wd.pid);require(wi is not None,'WATCHDOG_IDENTITY');self.wd_identity=dict(wi)
        guard=[self.python,str(ROOT/'guard_deadlines.py'),'--parent',str(os.getpid()),me['start'],'--watchdog',str(self.wd.pid),wi['start'],'--deadline',str(self.deadline),'--work-deadline',str(self.work),'--control-fd',str(gr),'--ack-fd',str(aw),'--telemetry-fd',str(tw),'--manifest-sha256',manifest]
        self.guard=subprocess.Popen(guard,pass_fds=(gr,aw,tw),stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=open(self.run/'guard.stderr','xb'),start_new_session=True)
        os.close(gr);os.close(aw);os.close(tw)
        ready=self.read_ack();require(ready.get('ack')=='ready','GUARD_READY')
        self.namespace=ready['execution_identity']['namespaces']['pid']+'/pid:'+str(ready['execution_identity']['pid'])+'/start:'+ready['execution_identity']['identity']['start']
        wdready=self.receive();require(wdready.get('type')=='ready','WATCHDOG_READY')
        write(self.run/'launch.json',dict(worker_argv=worker,guard_argv=guard,start=self.start,work_deadline=self.work,absolute_deadline=self.deadline,guard_ready=ready,watchdog_ready=wdready))

    def drain(self):
        if not self.telemetry_open:return
        while True:
            try:data=os.read(self.telemetryfd,65536)
            except BlockingIOError:break
            if not data:
                self.telemetry_open=False;require(not self.tbuf,'TRUNCATED_TELEMETRY');break
            self.tbuf+=data;require(len(self.tbuf)<=1048576,'TELEMETRY_OVERFLOW')
            while b'\n' in self.tbuf:
                line,self.tbuf=self.tbuf.split(b'\n',1);row=json.loads(line)
                if hasattr(self,'namespace'):require(row.get('namespace')==self.namespace,'TELEMETRY_IDENTITY')
                self.telemetry_records.append(row)
                with open(self.run/'guard-telemetry.jsonl','ab') as stream:stream.write(line+b'\n');stream.flush();os.fsync(stream.fileno())

    def line(self,fd,kind):
        attribute='abuf' if kind=='ack' else 'rbuf';buf=getattr(self,attribute)
        while b'\n' not in buf:
            left=self.deadline-time.monotonic();require(left>0,'SCENARIO_ABSOLUTE_CAP')
            ready=self.sup.wait_readable([fd]+([self.telemetryfd] if self.telemetry_open else []),min(.1,left))
            if self.telemetryfd in ready:self.drain()
            if fd in ready:
                piece=os.read(fd,65536);require(piece,'CONTROL_EOF:'+kind);buf+=piece;require(len(buf)<=1048576,'CONTROL_OVERFLOW')
        line,buf=buf.split(b'\n',1);setattr(self,attribute,buf);return json.loads(line)
    def read_ack(self):return self.line(self.ackfd,'ack')
    def receive(self):return self.line(self.readfd,'result')
    def send(self,value):os.write(self.sendfd,(json.dumps(value)+'\n').encode())
    def guard_send(self,value):os.write(self.guardfd,(json.dumps(value)+'\n').encode())
    def check(self,label):self.custody.check_negative_paths(label,self.work)

    def begin(self):
        now=time.monotonic();self.tests_deadline=now+900
        self.send(dict(type='tests_begin',tests_start=now,tests_deadline=self.tests_deadline,session=str(self.root)))
        expected=dict(type='tests_begin_ack',ack='tests_begin',phase='TESTS',tests_start=now,tests_deadline=self.tests_deadline,session=str(self.root))
        require(self.receive()==expected,'TESTS_BEGIN_ACK')

    def spec(self,ident,stage,mode='noop'):
        require(stage in ('test','observer','preflight'),'CLOSED_STAGE')
        require(mode in ('noop','hang-descendant') and (mode!='hang-descendant' or self.id=='S2'),'CLOSED_WORKLOAD')
        argv=[self.python,str(ROOT/'validation_job.py'),mode]
        if mode=='hang-descendant':argv.append(str(self.run/'descendant-identities.jsonl'))
        require(digest(ROOT/'validation_job.py')==self.records['validation_job.py']['sha256'],'JOB_HASH_DRIFT')
        return dict(id=ident,stage=stage,cap_seconds=1 if mode=='hang-descendant' else 2,cwd=str(self.root),argv=argv)

    def invoke(self,spec,expect_timeout=False):
        self.check('before-'+spec['id'])
        require(time.monotonic()<self.work,'SCENARIO_WORK_CAP')
        self.send(dict(type='run',spec=spec,env={'PATH':'/usr/bin:/bin','LC_ALL':'C','LANG':'C','TZ':'UTC'},tests_deadline=getattr(self,'tests_deadline',self.work)))
        started=self.receive();require(started.get('type')=='started' and started.get('id')==spec['id'],'STARTED_ID')
        result=self.receive();require(result.get('type')=='result','RESULT_TYPE');result=result['result']
        require(result.get('id')==spec['id'] and result.get('cleanup_verified') is True,'RESULT_CLEANUP')
        if expect_timeout:require(result.get('termination_reason') is not None and 'CAP' in result['termination_reason'],'EXPECTED_CAP_NOT_OBSERVED')
        else:
            require(result['rc']==0 and result.get('termination_reason') is None,'UNEXPECTED_WORKLOAD_FAILURE')
            require(Path(result['stdout']).read_bytes()==b'VALIDATION_NOOP\n' and Path(result['stderr']).read_bytes()==b'','NOOP_OUTPUT_MISMATCH')
        self.results.append(result);self.check('after-'+spec['id']);return result

    def close(self,success,report):
        if success:
            self.send(dict(type='close'));require(self.receive()=={'type':'closed','cleanup_verified':True},'WD_CLOSE')
            require(self.wd.wait(timeout=max(.01,self.deadline-time.monotonic()))==0,'WD_RC')
        else:
            if self.wd.poll() is None:
                self.send(dict(type='stop',reason='EXPECTED_VALIDATION_REJECTION'))
                while True:
                    row=self.receive()
                    if row.get('type')=='stopped':break
                    require(row.get('type')=='result','UNEXPECTED_STOP_MESSAGE')
            require(self.wd.wait(timeout=max(.01,self.deadline-time.monotonic()))==124,'WD_STOP_RC')
            self.guard_send({'closure_begin':True,'success':False})
            require(self.read_ack()=={'ack':'closure_begin','success':False},'NEGATIVE_CLOSURE_BEGIN')
        self.guard_send({'telemetry_snapshot':True});require(self.read_ack()=={'ack':'telemetry_snapshot'},'SNAPSHOT_ACK');self.drain()
        finals=[x for x in self.telemetry_records if x.get('event')=='final_snapshot'];require(len(finals)==1,'SNAPSHOT_NOT_PERSISTED')
        self.guard_send({'done':True})
        ack=self.read_ack();require(ack=={'ack':'done','identified_work_exited':True,'reaping':'NOT_OBSERVED_BY_GUARD'},'DONE_ACK')
        require(self.guard.poll() is None,'GUARD_EXITED_BEFORE_ACK_PERSISTED')
        ackfile=self.run/'closure-ack.json';write(ackfile,dict(ack=ack,guard_alive_before_persistence=True,recorded=time.monotonic()))
        report.update(status='EXPECTED_SCENARIO_OBSERVED_CLOSURE_PENDING',causal_gate='CLOSED_AWAITING_D',not_a_product_test_verdict=True,invocations=self.results,signal_notifications=self.signals,closure_ack_sha256=digest(ackfile),guard_rc='EXTERNAL_RETURN_REQUIRED',NOT_TESTED=['Coordinator.__init__/preflight/invoke/observe_test/execute','product XML/parser integration','full900s/4800s waits','transient adversarial negative-path replacement'])
        write(self.run/'REPORT.json',report)
        require(time.monotonic()<self.deadline,'CLOSURE_CAP')
        h=digest(ackfile);self.guard_send({'ack_persisted':True,'sha256':h});require(self.read_ack()=={'ack':'ack_persisted','sha256':h},'PERSISTED_ACK')
        require(self.guard.wait(timeout=max(.01,self.deadline-time.monotonic()))==0,'GUARD_RC')
        # No required filesystem IO after guard release. Return observed externally.

    def close_failed_s2(self,observation,original_error):
        # Only instrument an already observed/reaped failure, never accept S2.
        self.failure_handled=True
        release_started=False
        report=dict(status='REJECTED',causal_gate='CLOSED_REJECTED',
                    original_error=type(original_error).__name__+':'+str(original_error),
                    required_watchdog_rc=124,observed_watchdog_rc=observation['watchdog_wait_rc'],
                    S2_pass=False,checks_after_wd_assertion='NOT_RUN',
                    failure_evidence_status='INCOMPLETE',closure='CLOSURE_PENDING',
                    failure_closure_error=None,not_a_product_test=True,observation=observation)
        def budget():require(time.monotonic()<self.deadline,'FAILED_S2_CLOSURE_CAP')
        def save_failure():
            budget();require(self.guard.poll() is None,'FAILED_S2_GUARD_NOT_LIVE')
            require(len(json.dumps(report).encode())<=32768,'FAILED_S2_REPORT_SIZE')
            write(self.run/'FAILED-S2-EVIDENCE.json',report)
        try:
            budget()
            require(self.id=='S2' and type(observation['watchdog_wait_rc']) is int and observation['watchdog_wait_rc']!=124 and observation['wait_timed_out'] is False,'FAILED_S2_ENTRY')
            require(observation['workload_result'].get('cleanup_verified') is True,'FAILED_S2_WORKLOAD_NOT_CLOSED')
            require(observation['watchdog_identity']==self.wd_identity,'FAILED_S2_IDENTITY')
            require(self.guard.poll() is None,'FAILED_S2_GUARD_NOT_LIVE')
            write(self.run/'REJECTED.json',dict(status='REJECTED',error=report['original_error'],causal_gate='CLOSED_REJECTED',closure='CLOSURE_PENDING'))
            budget();self.guard_send({'closure_begin':True,'success':False})
            require(self.read_ack()=={'ack':'closure_begin','success':False},'FAILED_S2_CLOSURE_BEGIN_ACK')
            budget();self.guard_send({'telemetry_snapshot':True})
            require(self.read_ack()=={'ack':'telemetry_snapshot'},'FAILED_S2_SNAPSHOT_ACK');self.drain()
            finals=[x for x in self.telemetry_records if x.get('event')=='final_snapshot']
            require(len(finals)==1,'FAILED_S2_SNAPSHOT_COUNT')
            snapshot=finals[0]
            require(snapshot.get('namespace')==self.namespace,'FAILED_S2_SNAPSHOT_NAMESPACE')
            stats=snapshot.get('stats',{})
            require(stats.get('evidence_incomplete') is False and stats.get('error_count')==0,'FAILED_S2_SNAPSHOT_INCOMPLETE')
            require(not self.tbuf,'FAILED_S2_TELEMETRY_PARTIAL')
            require(snapshot.get('primary') is None and snapshot.get('reaping')=='NOT_OBSERVED_BY_GUARD','FAILED_S2_SNAPSHOT_CONTRACT')
            wd_records=[x for x in self.telemetry_records if x.get('identity',{}).get('role')=='watchdog' and x['identity'].get('pid')==self.wd_identity['pid'] and x['identity'].get('start')==self.wd_identity['start']]
            require(any(x.get('event')=='init' for x in wd_records) and any(x.get('event')=='retire' and x['identity'].get('exit_observed') is True for x in wd_records),'FAILED_S2_WATCHDOG_LEDGER_IDENTITY')
            report['watchdog_ledger_records']=wd_records
            report['signal_sender_attribution']='UNDETERMINED'
            report['signal_counts_exported_by_existing_telemetry']=False
            budget();self.guard_send({'done':True})
            ack=self.read_ack()
            require(ack=={'ack':'done','identified_work_exited':True,'reaping':'NOT_OBSERVED_BY_GUARD'},'FAILED_S2_DONE_ACK')
            require(self.guard.poll() is None,'FAILED_S2_GUARD_EXITED_BEFORE_PERSIST')
            budget();ackfile=self.run/'closure-ack.json'
            write(ackfile,dict(ack=ack,guard_alive_before_persistence=True,recorded=time.monotonic(),scenario_status='REJECTED'))
            report.update(failure_evidence_status='CAPTURED_CLOSURE_PENDING',snapshot=snapshot,
                          telemetry_sha256=digest(self.run/'guard-telemetry.jsonl'),closure_ack_sha256=digest(ackfile),
                          guard_rc='EXTERNAL_RETURN_REQUIRED')
            save_failure();budget()
            # No file writes from this route or generic handler after this point.
            release_started=True
            self.guard_send({'ack_persisted':True,'sha256':report['closure_ack_sha256']})
            require(self.read_ack()=={'ack':'ack_persisted','sha256':report['closure_ack_sha256']},'FAILED_S2_PERSISTED_ACK')
            require(self.guard.wait(timeout=max(.001,self.deadline-time.monotonic()))==0,'FAILED_S2_GUARD_RC')
        except BaseException as close_error:
            report['failure_evidence_status']='INCOMPLETE'
            report['closure']='UNVERIFIED'
            report['failure_closure_error']=(type(close_error).__name__+':'+str(close_error))[:1024]
            self.failure_closure_error=report['failure_closure_error']
            if not release_started:
                try:save_failure()
                except BaseException:pass
        # Caller rethrows original_error regardless of capture/closure outcome.

    def run_case(self):
        if self.id=='S1':
            self.begin()
            for tree in ('Hc','J'):
                for i in range(1,6):
                    ident='test-'+tree+'-'+str(i).zfill(2)
                    self.invoke(self.spec(ident,'test'))
                    self.invoke(self.spec('observe-'+ident,'observer'))
            self.send(dict(type='tests_end',tests_deadline=self.tests_deadline,session=str(self.root),completed=10,last_id='test-J-05'))
            require(self.receive()==dict(type='tests_end_ack',ack='tests_end',phase='AFTER_TESTS',tests_deadline=self.tests_deadline,session=str(self.root),completed=10,last_id='test-J-05'),'TEN_TESTS_END_ACK')
            self.custody.check('final',self.work)
            self.close(True,dict(scenario='S1',expected='10noop tests+10noop observer; actual guard/watchdog/custody; normal ACK persistence',observed_test_jobs=10,observed_observer_jobs=10))
        elif self.id=='S2':
            self.begin();self.invoke(self.spec('test-Hc-01','test','hang-descendant'),expect_timeout=True)
            message=self.receive();require(message.get('type')=='stopped','WD_NOT_STOPPED_AFTER_CAP')
            # A-only observation: one wait, unchanged required rc124.
            wd_rc=None;wait_timed_out=False
            try:
                wd_rc=self.wd.wait(timeout=max(.01,self.deadline-time.monotonic()))
            except subprocess.TimeoutExpired:
                wait_timed_out=True
            original_error=None;preliminary_observation_error=None
            if not wait_timed_out and wd_rc!=124:
                original_error=HarnessFailure('WD_TIMEOUT_RC')
                self.failure_handled=True # Protect the original failure before any observation IO.
            try:
                if time.monotonic()<min(self.work,self.deadline):
                    log_hashes={}
                    for name in ('watchdog.jsonl','watchdog.stdout','watchdog.stderr','guard.stderr','guard-telemetry.jsonl'):
                        if time.monotonic()>=min(self.work,self.deadline):break
                        path=self.run/name
                        if path.is_file() and not path.is_symlink() and path.stat().st_size<=1048576:
                            log_hashes[name]={'bytes':path.stat().st_size,'sha256':digest(path)}
                    if time.monotonic()<min(self.work,self.deadline):
                        observation=dict(
                            schema_version=1,watchdog_identity=self.wd_identity,
                            watchdog_wait_rc=wd_rc,watchdog_signal=(-wd_rc if wd_rc is not None and wd_rc<0 else None),
                            wait_timed_out=wait_timed_out,observed_monotonic=time.monotonic(),
                            stopped_message=message,workload_result=self.results[-1],
                            guard_identity_observed=self.sup.proc(self.guard.pid),guard_rc_observed=self.guard.poll(),
                            available_log_hashes=log_hashes,required_watchdog_rc=124,
                            closure='NOT_CERTIFIED',not_a_product_test=True)
                        require(len(json.dumps(observation).encode())<=16384,'S2_OBSERVATION_SIZE')
                        write(self.run/'S2-watchdog-wait-observation.json',observation)
            except BaseException as observation_error:
                if original_error is None:raise
                preliminary_observation_error=(type(observation_error).__name__+':'+str(observation_error))[:1024]
            require(not wait_timed_out,'WD_WAIT_TIMEOUT')
            if wd_rc!=124:
                # Reuse the single wait and the already received result/stopped.
                failure_observation=dict(watchdog_identity=self.wd_identity,watchdog_wait_rc=wd_rc,
                    watchdog_signal=(-wd_rc if wd_rc<0 else None),wait_timed_out=False,
                    stopped_message=message,workload_result=self.results[-1],
                    preliminary_observation_error=preliminary_observation_error)
                self.close_failed_s2(failure_observation,original_error)
                if getattr(self,'failure_closure_error',None):original_error.add_note('failure_closure_error='+self.failure_closure_error)
                raise original_error
            identities=[json.loads(x) for x in (self.run/'descendant-identities.jsonl').read_text().splitlines()]
            require({x['role'] for x in identities}=={'parent','child'},'DESCENDANT_NOT_OBSERVED')
            for x in identities:require(not self.sup.alive(x),'DESCENDANT_SURVIVED')
            rejected=False
            try:self.send(dict(type='run',spec=self.spec('test-Hc-02','test'),env={'PATH':'/usr/bin:/bin','LC_ALL':'C'},tests_deadline=self.tests_deadline))
            except BrokenPipeError:rejected=True
            require(rejected,'CLOSED_WATCHDOG_CHANNEL_ACCEPTED_WORK')
            spawns=[json.loads(x) for x in (self.run/'watchdog.jsonl').read_text().splitlines() if json.loads(x).get('action')=='spawn']
            require(len(spawns)==1,'POST_CAP_SPAWN')
            self.close(False,dict(scenario='S2',expected='cap1s with forked descendant terminates/reaps; closed channel rejects next launch',identities=identities,next_launch_rejected=True))
        else:
            self.invoke(self.spec('custody-noop','preflight'))
            intruder=self.root/'build-Hc/glibc-hwcaps'
            with open(intruder,'x') as stream:stream.write('V0 deliberate regular-file negative assertion violation\n')
            observed=None
            try:self.check('intentional-negative-violation')
            except Exception as exc:observed=type(exc).__name__+':'+str(exc)
            require(observed is not None and 'RUNPATH_GLIBC_HWCAPS_UNMODELED' in observed,'REAL_CUSTODY_DID_NOT_REJECT')
            require(stat.S_ISREG(intruder.lstat().st_mode),'INTRUDER_NOT_PRESERVED')
            self.close(False,dict(scenario='S3',expected='real custody rejects new regular glibc-hwcaps entry; no cleanup of intruder',custody_failure=observed,intruder=str(intruder),not_tested_variant='unexpected protocol message'))

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--manifest-sha256',required=True)
    group=parser.add_mutually_exclusive_group(required=True);group.add_argument('--scenario',choices=['S1','S2','S3']);group.add_argument('--worker',nargs=9)
    parser.add_argument('--deadline',type=float)
    args=parser.parse_args();records,sup,custody=auth(args.manifest_sha256)
    if args.worker:
        values=args.worker;scenario_root=Path(values[6]);allowed=[ROOT/'run/scenarios'/x for x in ('S1','S2','S3')]
        require(scenario_root in allowed,'WORKER_ROOT')
        require(args.deadline is None,'WORKER_ARGUMENTS')
        parent=int(values[4]);require(parent==os.getppid() and sup.proc(parent)['start']==values[5],'WORKER_PARENT_IDENTITY')
        parent_argv=Path('/proc',str(parent),'cmdline').read_bytes().split(b'\0');parent_argv=[x.decode() for x in parent_argv if x]
        expected_prefix=[str(Path(sys.executable)),str(ROOT/'validation_supervision.py'),'--scenario',scenario_root.name,'--manifest-sha256',args.manifest_sha256,'--deadline']
        require(len(parent_argv)==8 and parent_argv[:7]==expected_prefix,'WORKER_PARENT_NOT_CLOSED_HARNESS')
        absolute=float(values[2]);work=float(values[3]);require(math.isfinite(work) and math.isfinite(absolute) and time.monotonic()<work<absolute<=float(parent_argv[7]),'WORKER_DEADLINES')
        sys.exit(sup.watchdog(int(values[0]),int(values[1]),float(values[2]),float(values[3]),int(values[4]),values[5],str(scenario_root),int(values[7]),int(values[8])))
    require(args.deadline is not None and math.isfinite(args.deadline) and time.monotonic()<args.deadline,'SCENARIO_DEADLINE')
    session=None
    try:
        session=Session(args.scenario,args.manifest_sha256,args.deadline,records,sup,custody);session.run_case()
    except BaseException as exc:
        if session is not None and not getattr(session,'failure_handled',False):
            try:session.send(dict(type='stop',reason='VALIDATION_HARNESS_FAILURE:'+type(exc).__name__))
            except Exception:pass
            try:write(session.run/'REJECTED.json',dict(status='REJECTED',error=type(exc).__name__+':'+str(exc),causal_gate='CLOSED_REJECTED'))
            except Exception:pass
        raise

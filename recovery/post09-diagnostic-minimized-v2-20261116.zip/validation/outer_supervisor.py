"""Static v14 outer parent; no independent guarantee of this process's termination."""
import os, sys, time, json, hashlib, stat, re, struct, select, signal, subprocess, ctypes
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
EXPECTED_ROOT=Path('/RELOCATE/validation')
PYTHON='/RELOCATE/python3'

def unique(items):
    result={}
    for k,v in items:
        if k in result:raise ValueError('DUPLICATE_KEY')
        result[k]=v
    return result

def plain(p):
    for a in [p,*p.parents]:
        if a.is_symlink():raise ValueError('SYMLINK')
    if not stat.S_ISREG(p.lstat().st_mode):raise ValueError('NOT_REGULAR')
    return p.read_bytes()

def authenticate(approved):
    if ROOT!=EXPECTED_ROOT or not re.fullmatch('[0-9a-f]{64}',approved):raise ValueError('ROOT_OR_AUTHORITY')
    raw=plain(ROOT/'evidence.sha256.json')
    if hashlib.sha256(raw).hexdigest()!=approved:raise ValueError('MANIFEST_HASH')
    rows=json.loads(raw,object_pairs_hook=unique);seen=set()
    if type(rows) is not list:raise ValueError('MANIFEST_SCHEMA')
    for row in rows:
        if type(row) is not dict or set(row)!={'path','bytes','sha256'}:raise ValueError('RECORD_SCHEMA')
        name=row['path']
        if not isinstance(name,str) or name.startswith('/') or '\\' in name or '\x00' in name or any(s in ('','.','..') for s in name.split('/')) or name in seen:raise ValueError('PATH')
        if type(row['bytes']) is not int or row['bytes']<0 or not isinstance(row['sha256'],str) or not re.fullmatch('[0-9a-f]{64}',row['sha256']):raise ValueError('RECORD_TYPES')
        seen.add(name);data=plain(ROOT/name)
        if len(data)!=row['bytes'] or hashlib.sha256(data).hexdigest()!=row['sha256']:raise ValueError('CONTENT')
    required={'outer_supervisor.py','closure_observer.py','closure-recipe.json','validation-tools-authority.json','external_collector.py','external_supervisor.py','external_contract.py','external_writer.py','external-recipe.json'}
    if not required<=seen:raise ValueError('MISSING_MODULE')
    authority=json.loads(plain(ROOT/'validation-tools-authority.json'),object_pairs_hook=unique)
    for record in authority['records']:
        path=Path(record['path'])
        if str(path.resolve(strict=True))!=record['resolved']:raise ValueError('TOOL_ALIAS')
        data=plain(Path(record['resolved']))
        if len(data)!=record['bytes'] or hashlib.sha256(data).hexdigest()!=record['sha256']:raise ValueError('TOOL_CONTENT')
    matches=[r for r in authority['records'] if r['path']==PYTHON]
    if len(matches)!=1:raise ValueError('INTERPRETER_AUTHORITY')
    if any(str(p.resolve(strict=True))!=matches[0]['resolved'] for p in (Path(PYTHON),Path(sys.executable),Path('/proc/self/exe'))):raise ValueError('INTERPRETER_IDENTITY')

def identity(pid):
    try:
        text=Path('/proc',str(pid),'stat').read_text();fields=text[text.rfind(')')+2:].split()
        try:namespace=os.readlink('/proc/'+str(pid)+'/ns/pid')
        except (FileNotFoundError,ProcessLookupError):namespace=None
        return {'pid':pid,'start':fields[19],'namespace':namespace,'ppid':int(fields[1]),'state':fields[0]}
    except (FileNotFoundError,ProcessLookupError):return None

def public(row):
    return {k:row[k] for k in ('pid','start','namespace')} if row else None

def same(row):
    now=identity(row['pid'])
    return now is not None and now['start']==row['start'] and (now['namespace']==row['namespace'] or now['namespace'] is None and now['state'] in ('Z','X','x'))

def discover(known):
    rows={}
    for p in Path('/proc').iterdir():
        if p.name.isdigit():
            row=identity(int(p.name))
            if row:rows[row['pid']]=row
    ids={os.getpid()};changed=True
    while changed:
        changed=False
        for pid,row in rows.items():
            if row['ppid'] in ids and pid not in ids:ids.add(pid);changed=True
    for pid in ids-{os.getpid()}:
        if pid in rows:
            key=(pid,rows[pid]['start'])
            if key not in known or rows[pid]['namespace'] is not None:known[key]=rows[pid]
    return [r for r in known.values() if same(r)]

def kill_verified(row,sig):
    fd=None
    try:
        if not same(row):return 'IDENTITY_GONE'
        fd=os.pidfd_open(row['pid'])
        if not same(row):return 'IDENTITY_GONE'
        signal.pidfd_send_signal(fd,sig,None,0)
        return 'SENT' # syscall accepted; this is not evidence of process death.
    except ProcessLookupError:return 'IDENTITY_GONE'
    except OSError:return 'SIGNAL_ERROR'
    finally:
        if fd is not None:os.close(fd)

def reap(rows,observer):
    for row in rows:
        if observer is not None and row['pid']==observer.pid:continue
        now=identity(row['pid'])
        if now and same(row) and now['ppid']==os.getpid():
            try:os.waitpid(row['pid'],os.WNOHANG)
            except ChildProcessError:pass

def pipe_check(fd):
    if not stat.S_ISFIFO(os.fstat(fd).st_mode) or os.fpathconf(fd,'PC_PIPE_BUF')<4096:raise ValueError('PIPE_REQUIRED')
    os.set_blocking(fd,False);os.set_inheritable(fd,False)

def emit(fd,value,deadline,ascii_final=False):
    raw=json.dumps(value,separators=(',',':'),allow_nan=False,ensure_ascii=True).encode('ascii')
    if len(raw)>(4086 if ascii_final else 4092):return False
    wire=(format(len(raw),'08X').encode('ascii')+b':'+raw+b'\n') if ascii_final else struct.pack('<I',len(raw))+raw
    offset=0;end=min(deadline,time.monotonic()+2)
    poll=select.poll();poll.register(fd,select.POLLOUT|select.POLLERR|select.POLLHUP)
    while offset<len(wire) and time.monotonic()<end:
        try:
            n=os.write(fd,wire[offset:])
            if n<=0:return False
            offset+=n
        except (BlockingIOError,InterruptedError):poll.poll(max(0,int(min(.02,max(0,end-time.monotonic()))*1000)))
        except OSError:return False
    return offset==len(wire)

# The observer's closed schema is validated below, never inferred from stdout.
def validate_observer(raw,approved,runid,t0,rc):
    if len(raw)<4:raise ValueError('MISSING_FRAME')
    size=struct.unpack('<I',raw[:4])[0]
    if size<2 or size>4092 or len(raw)!=size+4:raise ValueError('FRAME_LENGTH')
    v=json.loads(raw[4:].decode('utf-8'),object_pairs_hook=unique)
    keys={'schema_version','kind','manifest_sha256','run_id','t0','work_status','identified_work_closure','collector_identity','collector_rc','collector_reaped','supervisor_identity','supervisor_rc','supervisor_reaped','registration_valid','capture_bytes','capture_sha256','capture_verified','capture_truncated','parent_lost','remaining_identities_count','error_code','outer_return','independent_outer_termination_guarantee'}
    if type(v) is not dict or set(v)!=keys:raise ValueError('SCHEMA_KEYS')
    if type(v['schema_version']) is not int or v['schema_version']!=1 or v['kind']!='OBSERVER_FINAL' or v['manifest_sha256']!=approved or v['run_id']!=runid or type(v['t0']) is not float or v['t0']!=t0:raise ValueError('CORRELATION')
    for k in ('collector_reaped','supervisor_reaped','registration_valid','capture_verified','capture_truncated','parent_lost','independent_outer_termination_guarantee'):
        if type(v[k]) is not bool:raise ValueError('BOOL')
    for k in ('collector_identity','supervisor_identity'):
        row=v[k]
        if row is not None and (type(row) is not dict or set(row)!={'pid','start','namespace'} or type(row['pid']) is not int or row['pid']<=0 or type(row['start']) is not str or not row['start'].isdigit() or type(row['namespace']) is not str or not re.fullmatch(r'pid:\[\d+\]',row['namespace'])):raise ValueError('IDENTITY')
    for k in ('collector_rc','supervisor_rc','capture_bytes'):
        if v[k] is not None and type(v[k]) is not int:raise ValueError('INTEGER')
    if v['capture_bytes'] is not None and v['capture_bytes']<0:raise ValueError('CAPTURE_BYTES')
    if v['capture_sha256'] is not None and (type(v['capture_sha256']) is not str or not re.fullmatch('[0-9a-f]{64}',v['capture_sha256'])):raise ValueError('HASH')
    if type(v['remaining_identities_count']) is not int or v['remaining_identities_count']<0:raise ValueError('COUNT')
    if v['work_status'] not in ('COMPLETED','REJECTED') or v['identified_work_closure'] not in ('OBSERVED','UNVERIFIED'):raise ValueError('STATUS')
    if v['outer_return']!='NOT_SELF_OBSERVED' or v['independent_outer_termination_guarantee'] is not False or v['error_code'] not in (None,'OBSERVER_REJECTED'):raise ValueError('RESERVATION')
    prerequisites=(v['collector_identity'] is not None and v['supervisor_identity'] is not None and v['collector_rc']==0 and v['supervisor_rc']==0 and v['collector_reaped'] and v['supervisor_reaped'] and v['registration_valid'] and v['capture_verified'] and v['capture_bytes'] is not None and v['capture_sha256'] is not None and not v['capture_truncated'] and not v['parent_lost'] and v['remaining_identities_count']==0)
    if v['identified_work_closure']=='OBSERVED' and not prerequisites:raise ValueError('CLOSURE_CONFLICT')
    success=v['work_status']=='COMPLETED' and v['identified_work_closure']=='OBSERVED'
    if type(rc) is not int or rc!=(0 if success else 2):raise ValueError('RC_CONFLICT')
    if success and v['error_code'] is not None:raise ValueError('ERROR_CONFLICT')
    return v

def drain(state,errors,deadline):
    poll=select.poll();byfd={s['fd']:s for s in state.values() if not s['eof']}
    for fd in byfd:poll.register(fd,select.POLLIN|select.POLLHUP|select.POLLERR)
    # Drain after poll() reports child return as well; exit is not EOF.
    for fd,event in poll.poll(max(0,int(min(.01,max(0,deadline-time.monotonic()))*1000))):
        s=byfd[fd]
        for _ in range(16):
            if time.monotonic()>=deadline:return
            try:data=os.read(fd,8192)
            except (BlockingIOError,InterruptedError):break
            except OSError:s['eof']=True;errors.append('CAPTURE_READ_FAILED');break
            if not data:s['eof']=True;break
            s['total']+=len(data);s['hash'].update(data)
            room=max(0,s['limit']-len(s['data']));s['data'].extend(data[:room])
            if len(data)>room:s['truncated']=True

def main():
    t0=time.monotonic()
    if len(sys.argv)!=3 or sys.argv[1]!='--manifest-sha256':raise ValueError('ARGV')
    approved=sys.argv[2];pipe_check(1);authenticate(approved)
    if time.monotonic()>=t0+30:raise ValueError('BOOTSTRAP_CAP')
    if ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)!=0:raise ValueError('SUBREAPER_REQUIRED')
    cancelled=[]
    for sig in (signal.SIGINT,signal.SIGTERM,signal.SIGHUP):signal.signal(sig,lambda number,frame:cancelled.append(number))
    runid=os.urandom(16).hex();owner=identity(os.getpid());known={};observer=None;first=None;rc=None
    deadlines={k:t0+v for k,v in {'work':480,'internal':570,'emission':572,'observer':578,'term':580,'kill':590,'absolute':600}.items()}
    ready_r,ready_w=os.pipe2(os.O_NONBLOCK|os.O_CLOEXEC);final_r,final_w=os.pipe2(os.O_NONBLOCK|os.O_CLOEXEC)
    for fd in (ready_r,ready_w,final_r,final_w):pipe_check(fd)
    state={};errors=[];identity_match=True
    deadline_state={'deadline_threshold_reached':{k:False for k in ('observer','term','kill','absolute')},
                    'deadline_closure_failed':False,'deadline_cleanup_activated':False,
                    'deadline_failure_stage':None,'deadline_failure_monotonic':None}
    signal_counts={k:{'attempts':0,'success':0,'skipped_identity_gone':0,'signal_errors':0,'deadline_success':0} for k in ('term','kill')}
    def latch(stage,now):
        if not deadline_state['deadline_closure_failed']:
            deadline_state['deadline_failure_stage']=stage
            deadline_state['deadline_failure_monotonic']=now
        deadline_state['deadline_closure_failed']=True
    def check_deadline(rows):
        now=time.monotonic()
        for key in deadline_state['deadline_threshold_reached']:
            if now>=deadlines[key]:deadline_state['deadline_threshold_reached'][key]=True
        pending=rc is None or len(state)!=3 or any(not x['eof'] for x in state.values()) or bool(rows)
        if now>=deadlines['observer'] and pending:latch('OBSERVER_CLOSURE',now)
        return now
    def cleanup(rows,sig,deadline_reason):
        now=time.monotonic();name='kill' if sig==signal.SIGKILL else 'term';counts=signal_counts[name]
        if rows and deadline_reason:
            latch('DEADLINE_'+name.upper(),now)
            deadline_state['deadline_cleanup_activated']=True
        def add(key):counts[key]=min(1000000,counts[key]+1)
        for row in rows:
            add('attempts');outcome=kill_verified(row,sig)
            if outcome=='SENT':
                add('success')
                if deadline_reason:add('deadline_success')
            elif outcome=='IDENTITY_GONE':add('skipped_identity_gone')
            else:
                add('signal_errors')
                if 'SIGNAL_ERROR' not in errors:errors.append('SIGNAL_ERROR')
    try:
        argv=[PYTHON,'-B',str(ROOT/'closure_observer.py'),'--manifest-sha256',approved,'--origin-monotonic',repr(t0),'--run-id',runid,'--ready-fd',str(ready_r),'--final-fd',str(final_w)]
        observer=subprocess.Popen(argv,cwd=ROOT,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,pass_fds=(ready_r,final_w),close_fds=True,start_new_session=True,env={'PATH':'/usr/bin:/bin','LC_ALL':'C','LANG':'C','TZ':'UTC','PYTHONDONTWRITEBYTECODE':'1'})
        first=identity(observer.pid)
        if first:known[(first['pid'],first['start'])]=first
        os.close(ready_r);ready_r=None;os.close(final_w);final_w=None
        ready={'schema_version':1,'kind':'OUTER_READY','manifest_sha256':approved,'run_id':runid,'t0':t0,'parent_identity':public(owner),'deadlines':deadlines}
        if not emit(ready_w,ready,min(t0+30,t0+578)):errors.append('READY_EMISSION_FAILED')
        os.close(ready_w);ready_w=None
        for name,fd,limit in [('final',final_r,4096),('stdout',observer.stdout.fileno(),65536),('stderr',observer.stderr.fileno(),65536)]:
            pipe_check(fd);state[name]={'fd':fd,'limit':limit,'data':bytearray(),'total':0,'hash':hashlib.sha256(),'eof':False,'truncated':False}
        while time.monotonic()<deadlines['absolute']:
            now=time.monotonic();rows=discover(known);current=identity(observer.pid)
            if current is not None and (first is None or current['start']!=first['start'] or current['namespace'] is not None and current['namespace']!=first['namespace']):identity_match=False
            rc=observer.poll();reap(rows,observer)
            rows=discover(known);now=check_deadline(rows)
            if now>=deadlines['kill']:
                cleanup(rows,signal.SIGKILL,True)
            elif now>=deadlines['term'] or cancelled or errors:
                cleanup(rows,signal.SIGTERM,now>=deadlines['term'])
            drain(state,errors,deadlines['absolute'])
            if rc is not None and not discover(known) and all(s['eof'] for s in state.values()):break
    except BaseException:
        errors.append('OUTER_OBSERVATION_FAILED')
        while time.monotonic()<deadlines['absolute']:
            rows=discover(known)
            if observer is not None:rc=observer.poll()
            reap(rows,observer);rows=discover(known);now=check_deadline(rows)
            cleanup(rows,signal.SIGKILL if now>=deadlines['kill'] else signal.SIGTERM,now>=deadlines['term'])
            drain(state,errors,deadlines['absolute'])
            if not discover(known) and all(x['eof'] for x in state.values()):break
            time.sleep(min(.01,max(0,deadlines['absolute']-time.monotonic())))
    remaining=discover(known);reap(remaining,observer)
    if observer is not None:rc=observer.poll()
    remaining=discover(known);check_deadline(remaining)
    if any(c['deadline_success'] for c in signal_counts.values()) and not deadline_state['deadline_closure_failed']:
        errors.append('DEADLINE_LATCH_INCONSISTENT');latch('INCONSISTENT_SIGNAL_STATE',time.monotonic())
    frame=None;frame_valid=False
    try:
        frame=validate_observer(bytes(state['final']['data']),approved,runid,t0,rc);frame_valid=True
    except BaseException:errors.append('OBSERVER_FRAME_INVALID')
    complete=(len(state)==3 and all(s['eof'] and not s['truncated'] for s in state.values()))
    observed=frame_valid and frame['identified_work_closure']=='OBSERVED' and rc is not None and first is not None and first['namespace'] is not None and identity_match and not remaining and complete and not errors and not deadline_state['deadline_closure_failed'] and not deadline_state['deadline_cleanup_activated'] and not cancelled
    output={'schema_version':1,'kind':'OUTER_RESULT','manifest_sha256':approved,'run_id':runid,'t0':t0,'observer_identity':public(first),'observer_rc':rc,'observer_reaped':rc is not None,'observer_identity_match':first is not None and first['namespace'] is not None and identity_match,'work_status':frame['work_status'] if frame_valid else 'REJECTED','identified_work_closure':'OBSERVED' if observed else 'UNVERIFIED','outer_return':'NOT_SELF_OBSERVED','outer_supervisor_self_reaped':False,'independent_outer_termination_guarantee':False,'frame_valid':frame_valid,'capture_complete':complete,'capture_truncated':any(s['truncated'] for s in state.values()),'deadline_enforced':deadline_state['deadline_closure_failed'] or deadline_state['deadline_cleanup_activated'],'remaining_identities_count':len(remaining),'capture':{name:{'bytes':s['total'],'sha256':s['hash'].hexdigest(),'eof':s['eof'],'truncated':s['truncated']} for name,s in state.items()},'error_codes':sorted(set(errors)),'monotonic_emission_start':time.monotonic()}
    output.update(deadline_state)
    output.update(signal_counts=signal_counts,signal_counter_limit=1000000,
                  term_attempted=signal_counts['term']['attempts']>0,kill_attempted=signal_counts['kill']['attempts']>0,
                  term_syscall_succeeded=signal_counts['term']['success']>0,kill_syscall_succeeded=signal_counts['kill']['success']>0)
    sent=emit(1,output,deadlines['absolute'],ascii_final=True)
    return 0 if observed and output['work_status']=='COMPLETED' and sent else 1
if __name__=='__main__':sys.exit(main())

# B · Revisión independiente del plan diagnóstico G1 posterior a -09

2026-11-16. **PASS del plan como propuesta de investigación y preparación estática. No es autorización de instrumentación, configure, build, tests ni reparación.**

## Alcance y evidencia revisada

Revisión independiente de `plan-diagnostico-fallos-G1-post09-A-20261116.md`, `causal-G1-execution-report-C-20261116-09/ACTA-C.md`, `paired-results.json`, JUnit J de la tanda -09 y fuentes pertinentes del snapshot -01. Se recalcularon por lectura los hashes de `style_diff.{h,cpp}`, `style_runtime_core.cpp`, `style_source_compiler.cpp` y `builtin_properties.cpp`: cada archivo coincide entre H/Hc/J. No se ejecutó producto, compilación ni prueba, ni se modificaron fuentes o evidencias.

No se localizó un dictamen D de resultados -09 en los documentos locales examinados. Esta revisión no lo sustituye ni valida por cuenta propia la totalidad de la custodia y cierre operacional. Debe incorporarse antes de abrir ejecución, como exige el propio plan.

## Fundamentos del PASS

1. **Rigor causal.** Distingue correctamente H de Hc=H+A; igualdad observada Hc/J no equivale a preexistencia en H, igualdad de cierre ejecutable ni explicación causal. Conserva UNDETERMINED, #159 no evaluado, G1 NOT_PASSED y coverage_complete=false. La comparación de mensajes se limita a campos concretos y normalización de raíces, sin convertir ABORT en una señal del ejecutable.
2. **Catálogo y hooks.** Confirmadas por fuente las tres claves registradas ausentes del catálogo, `align-content` stored frente a no-op esperado y las allowlists cerradas. El test de catálogo aborta primero por cardinalidad, antes de listar ausencias. El JUnit de dispatch muestra 19 fallos de cobertura sin claves. Es correcto pedir inventario completo y contratos, no aumentar contadores ni dar por observado el fallo de assertions posteriores.
3. **Impactos.** Confirmadas las vías independientes: dependencia desconocida/flags desconocidos pueden activar `unclassified` y la máscara conservadora; la comparación tipográfica posterior añade TEXT_LAYOUT|LAYOUT|PAINT. El JUnit semantic-diff confirma 81 esperado frente a 83 en line-height, coherente con el bit de pintura adicional, todavía sin demostrar su causa. El plan no cambia expectativas ni reduce todos los fallos a no-op.
4. **EOF profundo.** Fixtures de 10000 y guardia `frames.size()>32` existen. Los seis JUnit sólo acreditan rechazo ABI o ausencia de regla, no el diagnóstico de límite. Localizar el contrato antes de modificar producto o prueba es el orden correcto. Mantener los casos originales y el rechazo transaccional evita fabricar un PASS reduciendo profundidad.
5. **Source-order.** La macro privada sustituye `style_source_size_fits`, pero el compilador usa `source_charge_bytes`. El label compartido de rechazo no identifica el caso. La propuesta conserva esta incertidumbre, prioriza identificar la llamada y evita restaurar una vía obsoleta en producción para satisfacer el fixture.
6. **Proporcionalidad.** Tabla estática primero, tres pruebas dirigidas más dos controles en Hc/J después, diez invocaciones exactas y sin reintentos. EOF, catálogo y source-order no entran por sorpresa en esa tanda. Los límites son techos y #159 conserva gate separado. Una reparación futura exige hipótesis única, negativo y validación posterior completa; el diagnóstico pequeño no desbloquea OFF/ON/G2.

## Precisiones que C debe resolver en el expediente antes de D

Son criterios de ejecución ya compatibles con el plan, no permiso para ejecutar ahora:

- Fijar casos y firmas exactos que observará. Registrar solamente el primer fallo global de transform-runtime capturaría un no-op, no necesariamente las mutaciones 31 frente a 12/13. El límite de logging debe permitir observar cada firma elegida sin saltar ni truncar ejecución de pruebas; si no se alcanza una firma, marcarla UNOBSERVED.
- Identificar los dos controles por nombre (`aether.smoke`, `aether.abi-c`), targets, argv, cierre de dependencias, flags y puntos de instrumentación simétricos. Los observadores deben preservar predicados, expectativas y resultados; cualquier divergencia de firma respecto a -09 se registra, no se normaliza o ignora.
- Para EOF, derivar el significado de profundidad 32/33 del frame inicial y punto de comprobación antes de fijar expectativas fronterizas. La condición `frames.size()>32` no basta por sí sola para numerar niveles externos.
- Mantener explícita la reserva de cierre bajo el techo global. Los máximos nominales de configure/build/tests suman 4740 s; D debe verificar que supervisión y cierre caben en el presupuesto aprobado, sin interpretar cada máximo como tiempo garantizado simultáneamente.
- Adjuntar el dictamen D de resultados -09 y congelar un expediente nuevo. No reutilizar hashes de aprobación, builds ni permisos anteriores para los observadores.

## Dictamen y siguiente paso admisible

**PASS para preparar el expediente estático nuevo de C.** Los hallazgos están sustentados y las hipótesis están falsablemente formuladas sin atribución excesiva. No hay defecto sustantivo que requiera devolver el plan a A antes de esa preparación.

**Ejecución todavía cerrada:** requiere incorporar D de resultados -09 y revisión/congelación por D del expediente instrumental nuevo. Esta revisión no certifica causalidad, reparación, G1 ni publicación.

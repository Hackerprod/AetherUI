# C · Acta de única observación v5

2026-11-16. Entrega para revisión D. Sin reparación ni producto.

## Entrada y resultado

Una sola ejecución, cwd `causal-G1-static-C-20261116-05`, argv:

`/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12 /workspace/scratch/2ac40fb4b2af/causal-G1-static-C-20261116-05/observe_orders.py --manifest-sha256 3c10d68485b13f1cc8ba33c01a0e510dcfc1db9933ac2bee0c50984f3d363a4f`

Salida 0. Orden inherited → restored, una vez cada uno. Estado `CONTROLLED_MECHANISM_OBSERVED_ONLY`; duración registrada 0,56180924 s, techo 30 s. Ambos `DISCRIMINATING_ORDER_OBSERVED`. Sin cap ni reintento. Las cifras de descendientes muestreadas fueron 2 y 1; el 1 no se interpreta como ausencia del hijo rápido.

## Evidencia discriminante

En ambos órdenes pidfd=1102, event_fd=1101, control_fd=1104, RLIMIT existente 16384. Guardia -04 intacta.

- **inherited:** readiness acredita handler heredado, SIGTERM desbloqueado/no ignorado. Envío real `SENT`. El hijo confirma recepción en el handler a 96769.051439259; liberación del padre a 96769.053646818; hijo confirma SIG_DFL a 96769.054612887. Permanece vivo hasta 96769.359168314. Por tanto recepción < liberación < reset, con observación posterior de más de 0,3 s. Limpieza separada: SIGKILL `SENT`, waitpid=9, exit_code=-9, sin errores, complete=true. No se confunde este SIGKILL con el SIGTERM experimental.
- **restored:** readiness a 96769.445656051 acredita SIG_DFL y SIGTERM no capturado/no ignorado/desbloqueado antes del envío a 96769.448201257. Envío `SENT`; ledger `EXIT_OBSERVED` mediante pidfd, waitpid=15, exit_code=-15. Cleanup complete=true, sin señal adicional ni errores.
- Cada ledger termina opened=1, retired=1, live=0, error_count=0, evidence_incomplete=false. El controlador pasó su comprobación de ausencia de hijos después de cada orden. La inspección independiente posterior no encontró procesos coincidentes visibles, pero se limita a su namespace y no constituye prueba global.

## Custodia

15 archivos de salida preservados, hashes/tamaños en `observation-artifacts.sha256.json`. Los seis archivos estáticos -05 y sus referencias fueron revalidados al cierre por el controlador. Verificación independiente adicional: -01 4294 archivos, -02 9, -03 11, -04 15, -05 6, todos intactos; 15 salidas sintéticas -04 intactas; 1442 archivos vivos intactos, HEAD/rama/index/parche/status/cached iguales. Sin ejecución de CMake, build, CTest, producto ni reparación.

`custody_complete=true` del experimento se refiere a su manifiesto/configuración/referencias. La custodia ampliada independiente queda desglosada en `custody-after.json`, no se presume a partir de ese booleano.

## Interpretación y límite

El experimento demuestra el mecanismo bajo estos dos órdenes impuestos y con la guardia real sin cambios: SIGTERM capturado antes de reset no mata posteriormente al hijo; SIGTERM entregado después de readiness SIG_DFL sí termina con señal 15. No reconstruye el orden ocurrido en -04 ni prueba retrospectivamente su causa. **historical_cause=UNDETERMINED**.

No se modifica el resultado FAIL histórico de high_descriptors -04, no se completan sus cinco casos NOT_RUN, no se autoriza repetir -04 ni ejecutar producto. G1 NOT_PASSED; OFF/ON/G2 bloqueados; coverage_complete=false. C se detiene para dictamen D.

# C · Propuesta v6: readiness explícita y evidencia parcial del fixture

2026-11-16. **PROPUESTA PARA D. NO MATERIALIZADA. NO AUTORIZA EJECUCIÓN.**

## 1. Base y conclusión admisible

D aceptó la evidencia de v5. La única tanda observacional mostró ambos órdenes impuestos con pidfd 1102: SIGTERM recibido por handler heredado antes de reset permite supervivencia; SIGTERM después de readiness SIG_DFL termina con -15. No demuestra cuál ocurrió históricamente en -04. Su causa histórica sigue **UNDETERMINED**, no «corregida» retrospectivamente.

Se propone eliminar la ambigüedad del fixture y conservar diagnóstico si vuelve a fallar. No se altera el mecanismo productivo ni se atribuye un defecto a la guardia.

Bases SHA256:

| Archivo | SHA256 |
|---|---|
| -04/evidence.sha256.json | 92b4840453a4a53b9bd43a78bd0728966353139a3e0bbc6b63842e039b6ec5d0 |
| -04/synthetic_harness.py | d6c4dfdab880ed39844138b1f3498d2fd0243ed98ed159fa117b4c4fe09d9da0 |
| -04/synthetic_cases.json | 13afc41dc45a5fd569a00ef515b7376bd4f610cd65703e7b55dc74005a3b173c |
| -04/guard_deadlines.py | 0b0bca123bf88776640c36cc34a201a2c51053c60a605f83b061dfe935c3296b |
| -04/supervisor.py | f9f12eb750fcec0ee769f935db46cb0be426501f669d9564b43ca500fa7a5e7f |
| -04/frozen_custody.py | 81fdd367518633f5aa10b2fc6873a838e34990d9d86d5ab5397b6a497fd49b06 |
| -05/evidence.sha256.json | 3c10d68485b13f1cc8ba33c01a0e510dcfc1db9933ac2bee0c50984f3d363a4f |
| observation-report -05/evidence.sha256.json | f10b7bb4397573fd92f4df3533511fb533734307eb4a9033cc2acd2f2a5c7864 |

Todos los prefijos se resuelven bajo `/workspace/scratch/2ac40fb4b2af/`, como `causal-G1-static-C-20261116-04/` y `causal-G1-observation-report-C-20261116-05/`.

## 2. Alcance y diff normativo propuesto

Futuro directorio separado `causal-G1-static-C-20261116-06/`; salida exclusiva `causal-G1-synthetic-C-20261116-06/`. No se escribe ni se reutiliza -01/-02/-03/-04/-05. No se crean todavía esos directorios. Los fragmentos siguientes especifican el cambio a materializar, no son un patch ejecutado ni hashes de código aún inexistente.

### A. Nuevo helper exclusivo de high_descriptors

`child_held()` original y `rotation_1500()` permanecen byte a byte. Se añade `child_held_ready()` con dos pipes, hold y readiness. El hijo cierra extremos ajenos, restablece SIGTERM/SIGINT a SIG_DFL, lee SigBlk/SigIgn/SigCgt desde `/proc/self/status`, captura identidad, namespace y monotónico, y emite un único JSON pequeño con fase `DEFAULT_READY`. Emite sólo después del reset, sin modificar máscara. Después espera en hold. El padre cierra sus extremos ajenos y recibe `(pid, hold_write, ready_read)`; registra inmediatamente ambos descriptores para cierre y la identidad para cleanup, antes de esperar ACK. La guardia real fija el pidfd como antes.

```diff
@@ Case.high_descriptors
- pid,w=child_held();rec=self.pin(pid,ledger);require(rec['fd']>1024,'PIDFD_NOT_HIGH')
+ pid,w,ready_fd=child_held_ready()
+ self.fds.extend([w,ready_fd])
+ rec=self.pin(pid,ledger)
+ require(rec['fd']>1024,'PIDFD_NOT_HIGH')
+ ready,rest=wait_json(ready_fd,min(self.deadline,time.monotonic()+3))
+ persist_partial(ready=ready,ready_buffer=rest,identity=rec_identity,pidfd=rec['fd'])
+ require(rest==b'' and valid_default_ready(ready,rec),'INVALID_CHILD_READINESS')
@@ before experimental SIGTERM
- result=self.g.safe_signal(rec,signal.SIGTERM);self.wait_exit(rec);os.close(w)
+ persist_partial(signal_begin=time.monotonic(),signal_status='ATTEMPTING')
+ try:
+     result=self.g.safe_signal(rec,signal.SIGTERM)
+ except BaseException as exc:
+     persist_partial(signal_error=exception_with_errno(exc))
+     raise
+ finally:
+     persist_partial(signal_end=time.monotonic(),signal_result=result_or_unobserved,
+                     ledger=ledger.stats())
+ require(result.get('status')=='SENT','SIGNAL_NOT_CONFIRMED_SENT')
+ self.wait_exit(rec)
+ persist_partial(pidfd_exit_observed=True)
@@ after waitpid
+ persist_partial(waitpid_pid=got,waitpid_status=status,
+                 waitpid_exit_code=os.waitstatus_to_exitcode(status))
+ require(got==pid and os.waitstatus_to_exitcode(status)==-signal.SIGTERM,
+         'SIGNAL_NOT_OBSERVED')
```

`valid_default_ready` exige PID/start y namespace iguales a la identidad fijada, fase DEFAULT_READY, comparación directa del handler con SIG_DFL, SIGTERM no bloqueado/ignorado/capturado y timestamp readiness anterior al inicio del envío. No basta el retorno SENT. No se envía SIGTERM si falta readiness, hay EOF, máscara incompatible, JSON incorrecto o se vence el cap. Ningún reintento/segundo envío experimental. La espera de salida sigue limitada a 3 s y al deadline del caso.

El hold_write permanece abierto hasta finalizar la observación; al cerrar se retira de `self.fds` para evitar doble cierre/alias. Si falla antes, cleanup conserva su propiedad. La comprobación ya existente de pipe alto mediante `supervisor.wait_readable`, retiro y descriptor reutilizado con `RETIRED_NO_SIGNAL` se conserva. Se persistirá también su inicio/resultado/error, antes de comprobarlo. No se añade un handler de recepción a este caso: aquí se valida exclusivamente el orden SIG_DFL-ready, no se repite v5.

### B. Persistencia que no depende del retorno exitoso

Añadir `self.partial={}` y `self.diagnostic_errors=[]` a Case. `persist_partial` actualiza y escribe atómicamente `partial-observations.json`, antes de cada assertion posterior. `result_or_unobserved` se inicializa antes del try. El ledger emite cada evento a `ledger-events.jsonl` inmediatamente, además de su lista en memoria; final/retire/stats se guardan en finally. Los errores incluyen tipo, texto y errno cuando existe; la ausencia de errno se representa null, no 0 inferido.

```diff
@@ run_case, initialization
+ result['observations']=case.partial
@@ exception and finally paths
+ result['observations_partial']=case.partial
+ result['diagnostic_errors']=case.diagnostic_errors
```

No sustituir el error primario por un fallo al escribir/cerrar. La escritura inicial fallida impide iniciar el experimento. Si una escritura posterior falla, registrar el error secundario donde aún sea posible, marcar evidencia incompleta, parar y limpiar; nunca PASS. La salida parcial anterior queda conservada. Si no se logra emitir resultado final, el controlador registra salida inesperada y para, no presume éxito.

En finally del caso alto: retirar idempotentemente el rec si existe; persistir ledger y observaciones incluso al fallar; cerrar held y pipes propios exactamente una vez. La limpieza de procesos existente permanece separada: sus señales SIGKILL no cuentan como envíos experimentales. Resultado incluye identidad y proceso reaped, wait status y exit code, o incertidumbre explícita; no declarar cleanup completo por no encontrar un PID desde otro namespace.

### C. Metadatos de nueva tanda

Cambiar sólo OUTPUT y output_directory a -06; regenerar matriz NOT_RUN. Añadir a expectativas de high_descriptors readiness SIG_DFL/máscara/identidad previa, persistencia parcial, señal SENT y waitpid=-15. Registrar bases/propuesta/hash y diff completo en entrega estática. El resto del harness no cambia salvo persistencia parcial común descrita. Guardia, supervisor y frozen_custody se copian **byte a byte**, con los hashes de arriba. No tocar política/producto ni alterar límites, watchdog, protocolo, máscaras o rlimit.

## 3. Validación sintética futura solicitada, no autorizada aún

Proponer **una nueva tanda completa**, no continuación ni reparación en caliente de -04. Los siete casos fijos, una vez y en este orden: rotation_1500 (80 s), high_descriptors (20 s), real_watchdog (25 s), group_individual_cap (30 s), aggregate_idle_cap (25 s), guard_control_eof (20 s), broken_pipe_stop (20 s). Suma 220 s, techo global 240 s, reserva de cierre 10 s, máximo 4 descendientes vivos. El techo global prevalece sobre todos los caps. Mantener preflight de recursos y capacidades existente, no instalar ni relajar controles. El nuevo ACK consume el presupuesto del caso, no lo extiende.

Parar inmediatamente ante BLOCKED, FAIL, cap, evidencia/custodia incompleta o cleanup incierto. No seguir con casos restantes ni reintentar. Los cinco casos NOT_RUN de -04 no se consideran aprobados por v5. La repetición propuesta de rotation_1500 es una validación integral de la nueva tanda, requiere autorización expresa D sobre el nuevo manifiesto.

Entrada futura: Python exacto de policy, cwd -06, `synthetic_harness.py --manifest-sha256 NUEVO_SHA_APROBADO_D`. Ningún modo interno se ejecuta separadamente. Los hashes nuevos son **PENDING_STATIC_MATERIALIZATION**, no se pueden afirmar antes de existir el código. Ningún hash previo se acepta para lanzar -06.

## 4. Gates y entregables obligatorios

1. D revisa esta propuesta. Su aprobación sólo permitiría materialización estática, no importación, compilación Python ni ejecución.
2. C materializa -06 separado, entrega diff literal completo contra -04, hashes de todos los archivos/configuración/entrada, matriz NOT_RUN y custodia de versiones y salida previas. C verifica estáticamente que todo cambio cae en A/B/C. Cualquier cambio adicional vuelve a propuesta.
3. D inspecciona código, ownership/cierre de pipes, readiness, persistencia en fallos, caps y nuevo manifiesto. Sólo un gate D posterior puede autorizar una tanda exacta.
4. Si autorizada, congelar salida/telemetría, custodia, procesos/reaping y acta para D. No reparar/reintentar después de un fallo.

No builds, CTest, producto, #159, nuevas variantes, publicación ni cambios vivos. Aun si toda la futura tanda pasa, no autoriza producto automáticamente. **G1 NOT_PASSED; OFF/ON/G2 bloqueados; coverage_complete=false; causa histórica -04 UNDETERMINED.**

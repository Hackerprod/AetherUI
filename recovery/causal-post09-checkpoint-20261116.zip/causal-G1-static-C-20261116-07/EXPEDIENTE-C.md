# C · Nueva tanda causal de producto -07: preparación estática para D

2026-11-16. **NO EJECUTADA. No importar, compilar ni lanzar hasta gate D sobre manifiesto exacto.**

## Procedencia

Los cuatro programas supervisor.py, guard_deadlines.py, frozen_custody.py y verify_comparability.py son copias byte a byte de -06, iguales a sus bases -04. La tanda sintética -06 validó siete escenarios con la guardia/supervisor reales, no producto ni exhaustividad; informe SHA256 `2ae9eb791ab31f6424556705cc8840281f1e4f9db6efb35b29bfecbcb3970ea4`. El mecanismo observacional v5 no determina retrospectivamente la causa del fallo -04.

No se modifica código de supervisión, fixture, adaptación A, selección, presupuesto, entorno permitido o producto. Cambios respecto de configuración heredada -06: raíz/run/builds/inventarios/salidas/argv apuntan exclusivamente a -07, y policy fija hashes de referencias a evidencia posterior. Diff literal en delta-config-v6-v7.patch. No se incorpora ni ejecuta el harness sintético como entrada de esta tanda.

## Fuentes y destinos

- H, Hc y J congelados continúan en `causal-G1-static-C-20261116-01/`.
- H es referencia estática; Hc=H+A y J=WIP final son los dos árboles de ejecución.
- Adaptación A inalterada: dos inclusiones ya aprobadas, sin corrección OOM/z-index/classifier. Hash `4f15fd37f28ec395b16938f55d474621e2370b950161ca35108147ab9221dd39`.
- Nueva raíz: `/workspace/scratch/2ac40fb4b2af/causal-G1-static-C-20261116-07/`.
- Nuevos destinos exclusivos: `run/`, `build-Hc/`, `build-J/` bajo esa raíz, todos inexistentes al congelar.
- Ningún binario, CMakeCache, objeto o build -03/-04/-06 se copia/reutiliza. Las referencias históricas a -03 son sólo custodia, no entrada de compilación.

## Entrada y secuencia exacta

`entry.json` fija cwd, Python exacto y prefijo argv. Se suministra externamente el SHA256 de evidence.sha256.json que D apruebe; no se inserta un hash autorreferente dentro del manifiesto. Antes de ejecutar, el operador debe verificar ese hash y ausencia de las tres salidas. No hay opción resume/bypass/retry.

`argv.json` contiene 52 invocaciones ordenadas: configure Hc; inventario Hc; configure J; inventario J; gate inventario; build Hc; build J; gate comparabilidad; 44 tests. Ambos builds son seriales entre sí, cada build con --parallel 2 y --verbose, 18 targets originales. Ningún test precede a comparabilidad PASS. Cada caso se invoca exactamente una vez por árbol con selección exacta, no todos los tests.

22 nombres originales: 20 no-PASS de la campaña histórica sin #159, más aether.smoke y aether.abi-c. Son 44 filas NOT_RUN en matrix-NOT_RUN.json; atribución y señales no observadas se mantienen UNDETERMINED/UNOBSERVED. Los comandos auxiliares de preflight/custodia, watchdog y guardia se generan por el supervisor congelado, no son entradas independientes ni variantes autorizadas.

Presupuestos sin ampliación: configure 120 s por árbol; build 1800 s por árbol; test 120 s por invocación; agregado 900 s desde primer CTest de la fase de pruebas hasta cierre explícito confirmado, incluidos huecos; inventario/comparación 120 s; techo absoluto 4800 s, trabajo 4770 s, reserva de cierre 30 s. Prevalece el menor deadline efectivo. No se promete completar todas las filas si un cap impide continuar.

## Preflight y cierre obligatorios

El supervisor verifica manifiestos, herramientas/resolución de alias, arquitectura, entorno permitido, locales, fuentes congeladas y checkout vivo; rechaza builds existentes, presión de recursos o campañas concurrentes visibles. Recursos: conservar requisitos implementados (disco ≥12 GiB, memoria ≥4 GiB), sin instalar ni bajar umbrales. Preflight real sigue pendiente: la lectura estática actual no sustituye la comprobación en el instante del lanzamiento.

Guardia/watchdog, controles de procesos y telemetría permanecen sin cambios. Ante fallo de infraestructura, build/configure/gate, cap, control smoke/abi-c, custodia o cierre: preservar evidencia y detener, sin reparar, repetir ni continuar filas pendientes. Los FAIL de casos diagnósticos seleccionados se registran según la política original; no se convierten automáticamente en infraestructura fallida.

Al finalizar: revalidación de árboles H/Hc/J, manifiestos, archivos de configuración ejecutados, checkout vivo y Git. Parada que impida completarla se registra INCOMPLETE_CUSTODY. No se presume limpieza por ausencia de mensajes o visibilidad de otro namespace.

El outcome favorable previo al cierre dice DIAGNOSTIC_RESULTS_RECORDED_CLOSURE_PENDING. No significa cierre confirmado: el operador debe conservar retorno del supervisor y revisar ACK final/rc de guardia junto a telemetría y resultados. Los siete sintéticos no eximen de esta verificación en producto.

## Estado y prohibiciones

Sólo preparación de esta tanda para revisión D. No ejecución, publicación, cambios vivos, #159, variantes, nuevas adaptaciones ni presupuestos ampliados. G1 NOT_PASSED; OFF/ON/G2 bloqueados; coverage_complete=false. La futura tanda es diagnóstica, no apertura automática de gates ni atribución causal definitiva.

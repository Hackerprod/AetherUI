# C · Acta de parada -07 en preflight

2026-11-16. Una sola invocación exacta de entry.json, manifiesto `1fd262495279db7c6b1bc316d3705cc611ae622ec64cc8bc6a011f5e6af938b1`. Session10902; retorno1. No reintento ni reparación.

## Resultado

Preflight detuvo la tanda a 1,226603965 s: `CONCURRENT_CAMPAIGN:[{"pid": 1, "comm": "codex"}]`. No configure, inventarios, builds, gates ni tests de producto. Ambas rutas build inexistentes; 44 filas NOT_RUN. No evidencia causal nueva de producto.

Outcome original STOPPED/INCOMPLETE_CUSTODY, cleanup_verified=false, custody_complete=false. No se reemplaza por un éxito posterior. Custodia preflight fue registrada; cierre completo de custodia quedó NOT_OBSERVED. Watchdog registra stop; guardia observa salida del watchdog, snapshot final sin errores, con handle del padre pendiente. closure-errors no registra secundarios, pero guard_returncode=null. Esta evidencia no certifica ACK/rc final ni limpieza completa histórica. La inspección posterior no ve procesos supervisor/guardia coincidentes, limitada al nuevo sandbox; no prueba ausencia global ni sustituye identidades originales.

## Custodia independiente posterior

14 archivos runtime preservados en runtime-artifacts.sha256.json. Expedientes -01 a -07 intactos; salidas históricas -04 (15), v5 (15) y -06 (73) intactas. 1442 archivos vivos/Git iguales a referencia. Esta comprobación independiente es posterior y no modifica el outcome de cierre incompleto. No builds/tests/código nuevo ejecutados fuera de la invocación autorizada.

## Análisis de clasificación

El código supervisor.py:397–407 excluye coordinador/watchdog/guardia y padre inmediato; lee comm y cmdline completo concatenado, y clasifica campaña si cualquier marcador aparece **en cualquier argumento**, aunque sólo sea texto transportado por un wrapper. `codex` no está en campaign_process_names; por lógica del código, la clasificación original dependió de un marcador en cmdline. No se guardaron cmdline, marcador, start ni exe del PID1 original, por lo que no se atribuye un argumento concreto como hecho histórico observado.

La observación read-only posterior documenta PID1 como wrapper `/opt/codex/bin/codex`, argv0=codex-linux-sandbox, transportando el comando shell actual como argumento15. Ese comando de inspección contiene el literal `/supervisor.py`, y el mismo predicado de substring lo detecta en el payload aunque esta llamada no ejecuta supervisor alguno. Esto demuestra un falso positivo posible y observado en la clasificación por datos transportados. El primer sondeo posterior sin ese literal no coincidió. Los start de PID1 cambian entre llamadas; incluso el namespace inode numéricamente igual no permite identificarlo con el PID1 original.

La entrada shell original sí contenía la ruta supervisor.py. Que el wrapper original transportara ese texto es una explicación fuertemente apoyada por el patrón observado, pero su cmdline no quedó preservado. No se declara probada la ausencia histórica de cualquier campaña concurrente.

C se detiene para D. Propuesta separada de preflight, sin materialización. G1 NOT_PASSED; OFF/ON/G2 bloqueados; coverage_complete=false; causa histórica -04 UNDETERMINED.

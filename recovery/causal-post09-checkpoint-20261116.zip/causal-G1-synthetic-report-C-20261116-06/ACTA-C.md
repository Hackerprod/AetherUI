# C · Única tanda sintética -06

2026-11-16. Entrega para revisión independiente D. **PASS_SYNTHETIC_ONLY**, no producto.

## Ejecución autorizada

Una sola invocación, cwd `/workspace/scratch/2ac40fb4b2af/causal-G1-static-C-20261116-06`:

`/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12 /workspace/scratch/2ac40fb4b2af/causal-G1-static-C-20261116-06/synthetic_harness.py --manifest-sha256 4c45ed18b28a8e65d40a6ffb3dde3bbb3a23e74aea25429678be916c717389f0`

Salida 0; 7/7 casos PASS; duración registrada 6,851606469 s, dentro del techo de 240 s. Preflight PASS: disco disponible 25.787.572.224 bytes, memoria disponible 9.048.838.144 bytes. Máximo muestreado cuatro descendientes vivos. Sin cap inesperado, reintento, reparación, build, CTest ni producto. Los caps/EOF provocados son estímulos esperados de casos, no fallos de la tanda.

## Resultados

| Caso | Resultado y evidencia |
|---|---|
| rotation_1500 | 1500 ciclos, opened=retired=1500, live=0, peak=1, error_count=0; fd_before=fd_after=4. |
| high_descriptors | pidfd=1101; pipes=1103/1104. Readiness DEFAULT_READY, identidad/namespace coincidentes, SIGTERM no bloqueado/ignorado/capturado, handler_default=true. Readiness 97298.363864095 anterior al envío 97298.368349784; SENT, pidfd_exit_observed=true, waitpid=15/exit_code=-15. Registro retirado devuelve RETIRED_NO_SIGNAL ante descriptor reutilizado. Ledger final opened=retired=1, live=0, errores=0. |
| real_watchdog | Hijo trivial rc0 y cleanup_verified=true; parada explícita esperada watchdog124 y guard0; snapshot y cierre observados. |
| group_individual_cap | Cap individual real dispara SIGTERM de coordinador; watchdog0, guard0, descendiente setsid identificado; cierre sin residuos. |
| aggregate_idle_cap | Guardia real mantiene latch agregado preenvejecido de 900 s tras deadline:null; cap dispara SIGTERM y cierre watchdog0/guard0. No equivale a 900 s completos de carga. |
| guard_control_eof | Watchdog0; worker transfiere reaping a controlador, que registra guard PID1524 rc124 adoptado; remaining=[]. Sin telemetría en este caso por diseño aprobado. |
| broken_pipe_stop | Resultado esperado STOPPED/INCOMPLETE_CUSTODY con reason=SYNTHETIC_PRIMARY_ERROR y custody_complete=false; no falso éxito del stop. El caso sintético pasa por observar ese fallo controlado. |

El valor ATTEMPTING de los campos históricos signal_status/retired_signal_status no se actualiza por diseño del fixture; los retornos finales están en signal_result=SENT y retired_signal_result=RETIRED_NO_SIGNAL y las observaciones de salida separadas. Se conservan los bytes tal como fueron emitidos, sin normalizar ni reparar evidencia.

## Telemetría, cleanup y custodia

73 archivos de salida en `causal-G1-synthetic-C-20261116-06/`, congelados por hash/tamaño en `synthetic-artifacts.sha256.json`. Stderr vacíos. `telemetry-summary.json` conserva snapshots y eventos de error/incompletitud. Los snapshots de guardia pueden retener el handle del padre vivo hasta cierre final; no se presenta su live=1 previo al cierre como fuga ni como reaping observado por la guardia. Los resultados del fixture/controlador aportan la observación de cleanup/reaping.

Todos los casos tienen remaining=[] en el controlador. Los casos con cleanup local registran no_children=true y errors=[]; EOF declara explícitamente handoff, satisfecho por adopción/reaping posterior. Inspección independiente posterior sin procesos coincidentes visibles, limitada a su namespace; no es una garantía global de ausencia.

Custodia independiente: -01 4294 archivos, -02 9, -03 11, -04 15, -05 6, -06 16, todos iguales a sus manifiestos; 15 salidas -04 y 15 salidas observacionales -05 intactas. 1442 archivos vivos, HEAD/rama/index/parche/status/cached sin cambios. El controlador revalidó además su manifiesto y todos sus archivos al cierre. Ver detalle en `custody-after-independent.json`.

## Límites y siguiente gate

La tanda valida únicamente los siete escenarios sintéticos definidos, no prueba exhaustiva del supervisor ni producto. No cambia los resultados históricos -03/-04 ni determina retrospectivamente la causa -04. No se infiere comportamiento de la persistencia bajo todos los fallos posibles de almacenamiento a partir de esta tanda favorable.

**Causa histórica UNDETERMINED. G1 NOT_PASSED; OFF/ON/G2 bloqueados; coverage_complete=false.** No autorización implícita para tanda de producto, nuevas variantes o reparación. C se detiene y entrega a D.

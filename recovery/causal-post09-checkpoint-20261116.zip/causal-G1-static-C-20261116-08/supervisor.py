#!/usr/bin/env python3
"""STATIC, NOT EXECUTED. Closed one-shot diagnostic supervisor for D review.
The watchdog owns all commands and is a Linux child subreaper. No shell runs.
"""
import ctypes
import datetime
import fcntl
import hashlib
import json
import os
import pathlib
import select
import signal
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True

START = time.monotonic()
HERE = pathlib.Path(__file__).resolve().parent
WATCHDOG_KNOWN = {}

def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1024*1024), b''): h.update(b)
    return h.hexdigest()
def save(p,data):
    p=pathlib.Path(p); tmp=p.with_name(p.name+'.tmp')
    with open(tmp,'w') as f: json.dump(data,f,indent=2); f.write('\n'); f.flush(); os.fsync(f.fileno())
    os.replace(tmp,p)
def event(p, data):
    with open(p,'a') as f: f.write(json.dumps(dict(utc=utc(),mono=time.monotonic(),**data))+'\n');f.flush();os.fsync(f.fileno())
def proc(pid):
    try:
        s=pathlib.Path('/proc',str(pid),'stat').read_text(); r=s[s.rfind(')')+2:].split()
        return dict(pid=int(pid),ppid=int(r[1]),pgid=int(r[2]),start=r[19],state=r[0],rss_bytes=int(r[21])*os.sysconf('SC_PAGE_SIZE'))
    except (FileNotFoundError,ProcessLookupError): return None

def allprocs():
    out={}
    for p in pathlib.Path('/proc').iterdir():
        if p.name.isdigit():
            v=proc(p.name)
            if v: out[int(p.name)]=v
    return out

def same(x):
    v=proc(x['pid']); return v is not None and v['start']==x['start']
def alive(x):
    v=proc(x['pid']);return v is not None and v['start']==x['start'] and v['state']!='Z'
def owned(me,known):
    ps=allprocs(); ids={me}; change=True
    while change:
        change=False
        for pid,p in ps.items():
            if p['ppid'] in ids and pid not in ids: ids.add(pid);change=True
    for pid in ids-{me}:known[pid]=ps[pid]
    return [x for x in known.values() if same(x)]
def send_signal(x,sig):
    # pidfd pins the target identity; never signal a reusable integer PID/PGID.
    if not same(x):return
    try:fd=os.pidfd_open(x['pid'],0)
    except ProcessLookupError:return
    try:
        if same(x):signal.pidfd_send_signal(fd,sig,None,0)
    except ProcessLookupError:pass
    finally:os.close(fd)

def wait_readable(fds,timeout):
    # poll accepts descriptors above FD_SETSIZE; timeout is seconds or None.
    poller=select.poll()
    for fd in fds:poller.register(fd,select.POLLIN|select.POLLHUP|select.POLLERR|select.POLLNVAL)
    milliseconds=None if timeout is None else max(0,int(timeout*1000))
    events=poller.poll(milliseconds)
    if any(mask & select.POLLNVAL for fd,mask in events):raise RuntimeError('INVALID_CONTROL_FD')
    return [fd for fd,mask in events]

def namespace_identity():
    return dict(pid=os.getpid(),identity=proc(os.getpid()),namespaces={n:os.readlink('/proc/self/ns/'+n) for n in ['pid','mnt','user']})

def resources(root):
    mem={a:int(b.split()[0])*1024 for a,b in (line.split(':',1) for line in pathlib.Path('/proc/meminfo').read_text().splitlines())}
    d=os.statvfs(root)
    return dict(available_bytes=d.f_bavail*d.f_frsize,mem_available_bytes=mem['MemAvailable'],load=os.getloadavg())
def resource_ok(x): return x['available_bytes']>=12*1024**3 and x['mem_available_bytes']>=4*1024**3

def subreaper():
    libc=ctypes.CDLL(None,use_errno=True)
    if libc.prctl(36,1,0,0,0)!=0: raise OSError(ctypes.get_errno(),'PR_SET_CHILD_SUBREAPER failed')

def watchdog(rfd,wfd,deadline,work_deadline,parent_pid,parent_start,root,guardfd,ackfd):
    """Owns subprocesses; watches deadlines even if coordinator is blocked."""
    subreaper(); os.set_blocking(rfd,False)
    run=pathlib.Path(root)/'run'; log=run/'watchdog.jsonl'
    global WATCHDOG_KNOWN
    active=None; known={}; WATCHDOG_KNOWN=known; buf=b''; stopped=None; stop_at=None; last_resource=0; main_open=True
    phase='BEFORE_TESTS';tests_start=None;tests_deadline=None;test_count=0;last_test=None
    sigstate=[]
    for sig in [signal.SIGINT,signal.SIGTERM,signal.SIGHUP]: signal.signal(sig,lambda s,f:sigstate.append(s))
    def reply(x):
        try:os.write(wfd,(json.dumps(x)+'\n').encode())
        except BrokenPipeError:pass
    def phase_limit():return min(work_deadline,tests_deadline) if phase=='TESTS' else work_deadline
    def guard_exchange(message,expected):
        os.write(guardfd,(json.dumps(message)+'\n').encode())
        ack=b''
        while b'\n' not in ack:
            remaining=phase_limit()-time.monotonic()
            if remaining<=0:raise RuntimeError('TESTS_AGGREGATE_CAP' if phase=='TESTS' else 'GLOBAL_WORK_CAP')
            ready_ack=wait_readable([ackfd],remaining)
            if not ready_ack:raise RuntimeError('GUARD_ACK_TIMEOUT')
            part=os.read(ackfd,4096)
            if not part:raise RuntimeError('GUARD_LOST')
            ack+=part
        if json.loads(ack.split(b'\n')[0])!=expected:raise RuntimeError('GUARD_ACK_MISMATCH')
        if time.monotonic()>=phase_limit():raise RuntimeError('TESTS_AGGREGATE_CAP' if phase=='TESTS' else 'GLOBAL_WORK_CAP')
    def cleanup(reason):
        nonlocal stopped,stop_at,phase
        if stopped is None:
            stopped=reason;stop_at=time.monotonic();phase='STOPPED';event(log,dict(action='stop',reason=reason))
            for x in owned(os.getpid(),known):
                if alive(x):
                    try:
                        send_signal(x,signal.SIGTERM)
                        event(log,dict(action='TERM',identity=x))
                    except ProcessLookupError:pass
    reply(dict(type='ready',pid=os.getpid(),execution_identity=namespace_identity()))
    while True:
        now=time.monotonic()
        p=proc(parent_pid)
        if not p or p['start']!=parent_start:main_open=False;cleanup('PARENT_LOST')
        if phase=='TESTS' and now>=tests_deadline:cleanup('DIAGNOSTIC_CAP:TESTS_AGGREGATE_CAP')
        if now>=work_deadline:cleanup('GLOBAL_WORK_CAP')
        if active and now>=active['effective_deadline']:cleanup('DIAGNOSTIC_CAP')
        if sigstate:cleanup('WATCHDOG_SIGNAL_'+str(sigstate[0]))
        if now-last_resource>=1:
            last_resource=now
            try:
                sample=resources(root);sample['owned']=owned(os.getpid(),known)
                event(run/'resources.jsonl',sample)
                if not resource_ok(sample):cleanup('RESOURCE_PRESSURE')
            except Exception as e:cleanup('RESOURCE_READ_ERROR:'+type(e).__name__)
        if stopped:
            survivors=owned(os.getpid(),known)
            if now>=min(stop_at+5,deadline-2):
                for x in survivors:
                    if alive(x) and same(x):
                        try:send_signal(x,signal.SIGKILL);event(log,dict(action='KILL',identity=x))
                        except ProcessLookupError:pass
        if active:
            rc=active['p'].poll()
            # Popen reaps direct child. Adopted grandchildren are reaped separately.
            if rc is not None:
                reaped_all=False
                while True:
                    try:
                        pid,status=os.waitpid(-1,os.WNOHANG)
                        if not pid:break
                        event(log,dict(action='reaped_adopted',pid=pid,status=status))
                    except ChildProcessError:reaped_all=True;break
                rest=[x for x in owned(os.getpid(),known) if alive(x)]
                if rest and not stopped:cleanup('DESCENDANTS_AFTER_PARENT_EXIT')
                if not owned(os.getpid(),known) and reaped_all:
                    result={k:v for k,v in active.items() if k not in ['p','handles']}
                    result.update(rc=rc,signal=(-rc if rc<0 else None),end_utc=utc(),end_mono=now,termination_reason=stopped,cleanup_verified=True)
                    for f in active['handles']:f.close()
                    result['stdout_sha256']=digest(result['stdout']);result['stderr_sha256']=digest(result['stderr'])
                    save(run/(result['id']+'.json'),result)
                    if result['stage']=='test':
                        test_count+=1;last_test=result['id']
                    active=None
                    # Clearing a command deadline NEVER clears the persistent tests phase.
                    if not stopped:guard_exchange({'deadline':None},{'ack':'deadline','deadline':None})
                    reply(dict(type='result',result=result))
        if now>=deadline:
            remaining=[x for x in owned(os.getpid(),known) if alive(x)]
            event(log,dict(action='HARD_DEADLINE',remaining=remaining,cleanup_verified=not remaining))
            if p and p['start']==parent_start:
                try:send_signal(p,signal.SIGKILL)
                except ProcessLookupError:pass
            os._exit(124)
        if stopped and active is None:
            reply(dict(type='stopped',reason=stopped));return 124
        ready=wait_readable([rfd],0.05)
        if not ready:continue
        data=os.read(rfd,65536)
        if not data:main_open=False;cleanup('CONTROL_EOF');continue
        buf+=data
        while b'\n' in buf:
            line,buf=buf.split(b'\n',1);msg=json.loads(line)
            if msg['type']=='stop':cleanup(msg.get('reason','CANCELLED'));continue
            if msg['type']=='tests_begin':
                start_value=msg.get('tests_start');end_value=msg.get('tests_deadline')
                if phase!='BEFORE_TESTS' or active or stopped or test_count or msg.get('session')!=root or not isinstance(start_value,(int,float)) or not isinstance(end_value,(int,float)) or end_value-start_value!=900 or start_value>time.monotonic() or not time.monotonic()<min(end_value,work_deadline):
                    cleanup('INVALID_TESTS_BEGIN');continue
                tests_start=start_value;tests_deadline=end_value;phase='TESTS'
                expected=dict(ack='tests_begin',phase='TESTS',tests_start=tests_start,tests_deadline=tests_deadline,session=root)
                guard_exchange(msg,expected)
                if time.monotonic()>=phase_limit():cleanup('DIAGNOSTIC_CAP:TESTS_AGGREGATE_CAP');continue
                reply(dict(type='tests_begin_ack',**expected));continue
            if msg['type']=='tests_end':
                if phase!='TESTS' or active or stopped or test_count!=44 or last_test!='test-J-22' or msg!=dict(type='tests_end',tests_deadline=tests_deadline,session=root,completed=44,last_id=last_test) or not time.monotonic()<phase_limit():
                    cleanup('INVALID_OR_EXPIRED_TESTS_END');continue
                expected=dict(ack='tests_end',phase='AFTER_TESTS',tests_deadline=tests_deadline,session=root,completed=44,last_id=last_test)
                guard_exchange(msg,expected)
                if time.monotonic()>=phase_limit():cleanup('DIAGNOSTIC_CAP:TESTS_AGGREGATE_CAP');continue
                phase='AFTER_TESTS'
                reply(dict(type='tests_end_ack',**expected));continue
            if msg['type']=='close':
                if phase!='AFTER_TESTS' or active or owned(os.getpid(),known):cleanup('INVALID_CLOSE');continue
                reply(dict(type='closed',cleanup_verified=True));return 0
            if msg['type']!='run' or active or stopped:cleanup('PROTOCOL_ERROR');continue
            spec=msg['spec']
            if spec['stage']=='test':
                if phase!='TESTS' or test_count>=44:cleanup('TEST_OUTSIDE_PHASE');continue
                expected_id='test-'+('Hc' if test_count<22 else 'J')+'-'+str(test_count%22+1).zfill(2)
                if spec['id']!=expected_id:cleanup('TEST_SEQUENCE_MISMATCH');continue
            elif phase=='TESTS':cleanup('NON_TEST_INSIDE_TESTS_PHASE');continue
            eff=min(time.monotonic()+spec['cap_seconds'],phase_limit())
            if eff<=time.monotonic():cleanup('NO_BUDGET');continue
            guard_exchange(dict(deadline=eff),dict(ack='deadline',deadline=eff))
            if time.monotonic()>=eff:cleanup('DIAGNOSTIC_CAP');continue
            stdout=run/(spec['id']+'.stdout');stderr=run/(spec['id']+'.stderr')
            handles=[open(stdout,'xb'),open(stderr,'xb')]
            # Handlers only append a flag; no exception interrupts spawn/registration.
            old=None
            try:
                child=subprocess.Popen(spec['argv'],cwd=spec['cwd'],env=msg['env'],stdin=subprocess.DEVNULL,stdout=handles[0],stderr=handles[1],start_new_session=True)
                ident=proc(child.pid)
                if ident:known[child.pid]=ident
                active=dict(id=spec['id'],stage=spec['stage'],tree=spec.get('tree'),argv=spec['argv'],cwd=spec['cwd'],environment=msg['env'],start_utc=utc(),start_mono=now,effective_deadline=eff,pid=child.pid,identity=ident,stdout=str(stdout),stderr=str(stderr),p=child,handles=handles)
                event(log,dict(action='spawn',id=spec['id'],identity=ident,effective_deadline=eff))
                reply(dict(type='started',id=spec['id'],pid=child.pid,effective_deadline=eff))
            finally:pass

class Coordinator:
    def __init__(self,policy,approved_manifest_sha256):
        self.approved_manifest_sha256=approved_manifest_sha256
        self.policy=policy;self.root=pathlib.Path(policy['root'])
        if self.root!=HERE:raise RuntimeError('EXECUTION_ROOT_MISMATCH')
        self.run=self.root/'run';self.run.mkdir(exist_ok=False)
        self.deadline=START+4800;self.work_deadline=START+4770;self.buf=b'';self.matrix=json.loads((self.root/'matrix-NOT_RUN.json').read_text());self.tests_deadline=None;self.tests_start=None;self.tests_phase='BEFORE_TESTS';self.observed_tests=0;self.last_observed=None;self.gate=False;self.frozen=None;self.custody_complete=False;self._stopping=False;self.live_expected=None;self.git_expected=None
        self.lock=open(self.root.parent/'.causal-G1-campaign.lock','a+')
        fcntl.flock(self.lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        r,w=os.pipe();rr,ww=os.pipe();gr,gw=os.pipe();ar,aw=os.pipe();tr,tw=os.pipe();self.telemetryfd=tr;self.telemetry_open=True;self.telemetry_buffer=b'';os.set_blocking(tr,False);os.set_blocking(gw,False);self.guardfd=gw;self.guardack=ar;parent=proc(os.getpid())
        self.wd=subprocess.Popen([sys.executable,str(HERE/'supervisor.py'),'--watchdog',str(r),str(ww),str(self.deadline),str(self.work_deadline),str(os.getpid()),parent['start'],str(self.root),str(gw),str(ar)],pass_fds=(r,ww,gw,ar),stdin=subprocess.DEVNULL,stdout=open(self.run/'watchdog.stdout','xb'),stderr=open(self.run/'watchdog.stderr','xb'),start_new_session=True)
        os.close(r);os.close(ww);self.sendfd=w;self.readfd=rr
        wd_identity=proc(self.wd.pid)
        self.guard=subprocess.Popen([sys.executable,str(HERE/'guard_deadlines.py'),'--parent',str(os.getpid()),parent['start'],'--watchdog',str(self.wd.pid),wd_identity['start'],'--deadline',str(self.deadline),'--work-deadline',str(self.work_deadline),'--control-fd',str(gr),'--ack-fd',str(aw),'--telemetry-fd',str(tw)],pass_fds=(gr,aw,tw),stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=open(self.run/'guard.stderr','xb'),start_new_session=True)
        os.close(gr);os.close(aw);os.close(tw)
        ready_guard=b''
        while b'\n' not in ready_guard:
            rd=wait_readable([ar],max(0,self.work_deadline-time.monotonic()))
            if not rd:raise RuntimeError('GUARD_START_TIMEOUT')
            piece=os.read(ar,4096)
            if not piece:raise RuntimeError('GUARD_START_FAILED')
            ready_guard+=piece
        guard_ready=json.loads(ready_guard.split(b'\n')[0])
        if guard_ready.get('ack')!='ready':raise RuntimeError('GUARD_START_PROTOCOL')
        gi=guard_ready['execution_identity']
        self.guard_namespace=gi['namespaces']['pid']+'/pid:'+str(gi['pid'])+'/start:'+gi['identity']['start']
        self.final_snapshot_seen=False
        self.env={k:os.environ[k] for k in policy['environment_whitelist'] if k in os.environ}
        save(self.run/'matrix.json',self.matrix)
        save(self.run/'custody-final-summary.json',dict(custody_complete=False,status='NOT_OBSERVED',components={n:'NOT_OBSERVED' for n in ['H','Hc','J','expediente_v1','executed_v4','references','tools','tool_alias_resolution','gate_inputs','live_git_and_files']}))
        for sig in [signal.SIGINT,signal.SIGTERM,signal.SIGHUP]:signal.signal(sig,self.cancel)
        watchdog_ready=self.receive()
        if watchdog_ready['type']!='ready':raise RuntimeError('WATCHDOG_NOT_READY')
        save(self.run/'execution-identities.json',dict(coordinator=namespace_identity(),watchdog=watchdog_ready,guard=guard_ready))
    def cancel(self,sig,frame):
        if self._stopping:return
        try:self.send(dict(type='stop',reason='COORDINATOR_SIGNAL_'+str(sig)))
        except OSError:pass
        raise RuntimeError('CANCELLED:'+str(sig))
    def send(self,x):os.write(self.sendfd,(json.dumps(x)+'\n').encode())
    def receive(self):
        while b'\n' not in self.buf:
            if self.tests_phase=='TESTS' and time.monotonic()>=self.tests_deadline:raise RuntimeError('DIAGNOSTIC_CAP:TESTS_AGGREGATE_CAP')
            if time.monotonic()>=self.work_deadline:raise RuntimeError('GLOBAL_WORK_CAP')
            ready=wait_readable([self.readfd]+([self.telemetryfd] if self.telemetry_open else []),0.1)
            if self.telemetryfd in ready:self.drain_telemetry()
            if self.readfd in ready:
                d=os.read(self.readfd,65536)
                if not d:raise RuntimeError('WATCHDOG_LOST')
                self.buf+=d
        line,self.buf=self.buf.split(b'\n',1);return json.loads(line)
    def drain_telemetry(self):
        if not self.telemetry_open:return
        while True:
            try:chunk=os.read(self.telemetryfd,65536)
            except BlockingIOError:break
            if not chunk:
                self.telemetry_open=False
                if self.telemetry_buffer:raise RuntimeError('TRUNCATED_GUARD_TELEMETRY')
                break
            self.telemetry_buffer+=chunk
            if len(self.telemetry_buffer)>1048576:raise RuntimeError('TELEMETRY_OVERFLOW')
            while b'\n' in self.telemetry_buffer:
                line,self.telemetry_buffer=self.telemetry_buffer.split(b'\n',1)
                record=json.loads(line)
                if record.get('namespace')!=self.guard_namespace:raise RuntimeError('GUARD_TELEMETRY_IDENTITY_MISMATCH')
                with open(self.run/'guard-telemetry.jsonl','ab') as out:out.write(line+b'\n');out.flush();os.fsync(out.fileno())
                if record.get('event')=='final_snapshot':self.final_snapshot_seen=True
    def guard_snapshot(self):
        if self.final_snapshot_seen:return
        os.write(self.guardfd,b'{"telemetry_snapshot":true}\n')
        ack=b''
        while b'\n' not in ack:
            remaining=self.deadline-time.monotonic()
            if remaining<=0:raise RuntimeError('GLOBAL_CAP_DURING_SNAPSHOT')
            ready=wait_readable([self.guardack]+([self.telemetryfd] if self.telemetry_open else []),min(.1,remaining))
            if self.telemetryfd in ready:self.drain_telemetry()
            if self.guardack in ready:
                data=os.read(self.guardack,4096)
                if not data:raise RuntimeError('GUARD_SNAPSHOT_CHANNEL_LOST')
                ack+=data
        if json.loads(ack.split(b'\n')[0])!={'ack':'telemetry_snapshot'}:raise RuntimeError('GUARD_SNAPSHOT_ACK')
        self.drain_telemetry()
        if not self.final_snapshot_seen:raise RuntimeError('FINAL_GUARD_SNAPSHOT_NOT_PERSISTED')
    def invoke(self,spec):
        if spec['stage']=='test' and not self.gate:raise RuntimeError('COMPARABILITY_NOT_PASS')
        if spec['stage']=='test' and self.tests_phase=='BEFORE_TESTS':self.begin_tests()
        if spec['stage']=='test' and self.tests_phase!='TESTS':raise RuntimeError('TESTS_PHASE_CLOSED')
        self.send(dict(type='run',spec=spec,env=self.env,tests_deadline=self.tests_deadline if self.tests_phase=='TESTS' else self.work_deadline))
        while True:
            reply=self.receive()
            if reply['type']=='result':
                r=reply['result']
                if r['id']!=spec['id']:raise RuntimeError('RESULT_ID_MISMATCH')
                if r['termination_reason']:
                    if spec['stage']=='test':
                        row=next(x for x in self.matrix if x['invocation_id']==spec['id'])
                        row.update(status='DIAGNOSTIC_CAP' if 'CAP' in r['termination_reason'] else 'INTERRUPTED',termination_reason=r['termination_reason'],executable_signal='UNOBSERVED')
                        save(self.run/'matrix.json',self.matrix)
                    raise RuntimeError(r['termination_reason'])
                return r
            if reply['type']!='started':raise RuntimeError(str(reply))
            if spec['stage']=='test':
                row=next(x for x in self.matrix if x['invocation_id']==spec['id']);row.update(status='RUNNING',start_monotonic=time.monotonic())
                save(self.run/'matrix.json',self.matrix)
    def begin_tests(self):
        if self.tests_phase!='BEFORE_TESTS' or not self.gate:raise RuntimeError('INVALID_TESTS_BEGIN')
        self.tests_start=time.monotonic();self.tests_deadline=self.tests_start+900;self.tests_phase='TESTS'
        self.send(dict(type='tests_begin',tests_start=self.tests_start,tests_deadline=self.tests_deadline,session=str(self.root)))
        expected=dict(type='tests_begin_ack',ack='tests_begin',phase='TESTS',tests_start=self.tests_start,tests_deadline=self.tests_deadline,session=str(self.root))
        if self.receive()!=expected or time.monotonic()>=min(self.tests_deadline,self.work_deadline):raise RuntimeError('TESTS_BEGIN_NOT_CONFIRMED')
    def end_tests(self):
        if self.tests_phase!='TESTS' or self.observed_tests!=44 or self.last_observed!='test-J-22' or time.monotonic()>=min(self.tests_deadline,self.work_deadline):raise RuntimeError('TESTS_END_NOT_ELIGIBLE')
        msg=dict(type='tests_end',tests_deadline=self.tests_deadline,session=str(self.root),completed=44,last_id=self.last_observed)
        self.send(msg)
        expected=dict(type='tests_end_ack',ack='tests_end',phase='AFTER_TESTS',tests_deadline=self.tests_deadline,session=str(self.root),completed=44,last_id=self.last_observed)
        if self.receive()!=expected or time.monotonic()>=min(self.tests_deadline,self.work_deadline):raise RuntimeError('TESTS_END_NOT_CONFIRMED')
        self.tests_phase='AFTER_TESTS'
    def custody(self):
        s=self.policy['source_root'];live=pathlib.Path(self.policy['live']);expected=self.git_expected
        if expected is None or self.live_expected is None:raise RuntimeError('LIVE_CUSTODY_AUTHORITY_UNAVAILABLE')
        def git(*args):
            spec=dict(id='custody-'+str(time.monotonic_ns()),stage='custody',cap_seconds=10,cwd=str(live),argv=[self.policy['tools']['git']['path'],'--no-optional-locks','-C',str(live),*args])
            result=self.invoke(spec)
            if result['rc']!=0:raise RuntimeError('GIT_CUSTODY_READ_FAILED')
            return pathlib.Path(result['stdout']).read_bytes()
        ix=pathlib.Path(git('rev-parse','--git-path','index').decode().strip());ix=ix if ix.is_absolute() else live/ix
        got=dict(head=git('rev-parse','HEAD').decode().strip(),branch=git('branch','--show-current').decode().strip(),index_sha256=digest(ix),patch_sha256=hashlib.sha256(git('diff','--binary')).hexdigest(),status=git('status','--porcelain=v1','--untracked-files=all').decode(),cached_bytes=len(git('diff','--cached')))
        got['status_entries']=len(got['status'].splitlines())
        if got!=expected:raise RuntimeError('LIVE_CUSTODY_DIVERGENCE')
        for rel,h in self.live_expected.items():
            if digest(live/rel)!=h:raise RuntimeError('LIVE_FILE_DIVERGENCE:'+rel)
        return got
    def preflight(self):
        self.frozen=FrozenCustody(self.policy,save,self.approved_manifest_sha256)
        self.frozen.check('preflight',self.work_deadline)
        self.live_expected=self.frozen.approved_json('live-files-before.json')
        self.git_expected=self.frozen.approved_json('custody-before.json')
        for k in self.policy['forbidden_environment']:
            if os.environ.get(k):raise RuntimeError('UNAPPROVED_ENVIRONMENT:'+k)
        for p,h in json.loads((self.root/'evidence.sha256.json').read_text()).items():
            if digest(self.root/p)!=h:raise RuntimeError('V2_HASH_DIVERGENCE:'+p)
        for p,h in self.policy['references'].items():
            if digest(p)!=h:raise RuntimeError('REFERENCE_DIVERGENCE:'+p)
        old=pathlib.Path(self.policy['source_root'])
        for p,h in json.loads((old/'evidence.sha256.json').read_text()).items():
            if digest(old/p)!=h:raise RuntimeError('V1_HASH_DIVERGENCE:'+p)
        for t in self.policy['tools'].values():
            if digest(t['path'])!=t['sha256']:raise RuntimeError('TOOL_DIVERGENCE')
        for name,t in self.policy['tool_aliases'].items():
            effective=shutil.which(name,path=self.env.get('PATH',''))
            if not effective or str(pathlib.Path(effective).resolve())!=t['resolved'] or digest(effective)!=t['sha256'] or digest(t['path'])!=t['sha256']:raise RuntimeError('TOOL_ALIAS_DIVERGENCE:'+name)
        for p in self.policy['builds'].values():
            if pathlib.Path(p).exists() or pathlib.Path(p).is_symlink():raise RuntimeError('BUILD_EXISTS')
        sample=resources(self.root)
        if not resource_ok(sample):raise RuntimeError('INSUFFICIENT_RESOURCES')
        # The classifier validates its own approved bytes and derives the launch
        # contract solely from entry.json plus the externally approved digest.
        from concurrency_preflight import scan
        own_records=json.loads((self.run/'execution-identities.json').read_text())
        scan(self.policy,self.approved_manifest_sha256,own_records,
             lambda report:save(self.run/'concurrency-preflight.json',report),
             entry_filename='entry.json')
        loc=self.invoke(dict(id='locales',stage='preflight',cap_seconds=10,cwd=str(self.root),argv=[self.policy['tools']['locale']['path'],'-a']))
        if loc['rc']!=0:raise RuntimeError('LOCALE_DISCOVERY_FAILED')
        if os.uname().machine!=self.policy['architecture']:raise RuntimeError('ARCHITECTURE_DIFFERENCE')
        save(self.run/'preflight.json',dict(status='PASS',architecture=os.uname().machine,uname=list(os.uname()),environment=self.env,resources=sample,custody=self.custody(),utc=utc()))
    def observe_test(self,spec,r):
        # CTest JUnit is explicitly requested; it records observed one-test status.
        xml=pathlib.Path(spec['junit']);root=ET.parse(xml).getroot();cases=root.findall('.//testcase')
        if len(cases)!=1 or cases[0].get('name')!=spec['name']:raise RuntimeError('TEST_NOT_EXACTLY_ONE')
        c=cases[0]
        if c.find('skipped') is not None:raise RuntimeError('UNEXPECTED_SKIP')
        if c.find('error') is not None:raise RuntimeError('TEST_INFRASTRUCTURE_ERROR')
        fail=c.find('failure');text='' if fail is None else ET.tostring(fail,encoding='unicode')
        if c.get('status','run').lower() in ['notrun','disabled'] or any(x in text for x in ['Not Run','Unable to find executable','Failed to change working directory']):raise RuntimeError('TEST_NOT_EXECUTED')
        status='PASS' if fail is None else ('TIMEOUT' if 'Timeout' in text else ('ABORT' if 'Subprocess aborted' in text or 'Exception' in text else 'FAIL'))
        if r['rc'] not in [0,8] or (status=='PASS')!=(r['rc']==0):raise RuntimeError('CTEST_RC_STATUS_MISMATCH')
        row=next(x for x in self.matrix if x['tree']==spec['tree'] and x['name']==spec['name'])
        row.update(status=status,ctest_rc=r['rc'],ctest_signal=r['signal'],executable_signal='UNOBSERVED',assertions_not_emitted='UNOBSERVED',junit=str(xml),junit_sha256=digest(xml),stdout=r['stdout'],stderr=r['stderr'])
        save(self.run/'matrix.json',self.matrix)
        self.observed_tests+=1;self.last_observed=spec['id']
        if spec['name'] in ['aether.smoke','aether.abi-c'] and status!='PASS':raise RuntimeError('CONTROL_FAILED')
    def execute(self):
        self.preflight()
        for spec in json.loads((self.root/'argv.json').read_text()):
            r=self.invoke(spec)
            if spec['stage']=='test':self.observe_test(spec,r)
            elif r['rc']!=0:raise RuntimeError('STAGE_FAILED:'+spec['id'])
            if spec['stage'] in ['inventory-gate','comparability']:
                result=json.loads(pathlib.Path(spec['output']).read_text())
                if result.get('status')!='PASS':raise RuntimeError('GATE_NOT_PASS')
                if spec['stage']=='comparability':
                    self.frozen.freeze_gate(result);self.gate=True
        self.end_tests()
        final_frozen=self.frozen.check('final',self.work_deadline)
        save(self.run/'custody-after.json',self.custody())
        self.custody_complete=True
        save(self.run/'custody-final-summary.json',dict(custody_complete=True,status='PASS',components={**{n:c['status'] for n,c in final_frozen['components'].items()},'live_git_and_files':'PASS'}))
        self.send(dict(type='close'))
        if self.receive()['type']!='closed':raise RuntimeError('CLEANUP_NOT_VERIFIED')
        self.wd.wait(timeout=max(.1,self.deadline-time.monotonic()))
        self.guard_snapshot()
        save(self.run/'outcome.json',dict(status='DIAGNOSTIC_RESULTS_RECORDED_CLOSURE_PENDING',custody_complete=self.custody_complete,cleanup_verified=False,end=utc(),wall=time.monotonic()-START,note='Final guard ACK and rc are checked before supervisor returns; this pre-exit record does not certify closure'))
        os.write(self.guardfd,b'{"done":true}\n')
        ack=b''
        while b'\n' not in ack:
            remaining=self.deadline-time.monotonic()
            if remaining<=0:raise RuntimeError('GUARD_DONE_CAP')
            ready=wait_readable([self.guardack],min(.1,remaining))
            if ready:
                part=os.read(self.guardack,4096)
                if not part:raise RuntimeError('GUARD_DONE_CHANNEL_LOST')
                ack+=part
        if json.loads(ack.split(b'\n')[0])!={'ack':'done','identified_work_exited':True,'reaping':'NOT_OBSERVED_BY_GUARD'}:raise RuntimeError('GUARD_DONE_ACK')
        if self.guard.wait(timeout=max(.1,self.deadline-time.monotonic()))!=0:raise RuntimeError('GUARD_FINAL_RC')
        self.closure_confirmed=True  # No mandatory file IO after the guard exits.
    def stop(self,error):
        self._stopping=True;self.tests_phase='STOPPED'
        try:self.send(dict(type='stop',reason=str(error)))
        except OSError:pass
        save(self.run/'outcome.json',dict(status='STOPPED/INCOMPLETE_CUSTODY',reason=str(error),end=utc(),wall=time.monotonic()-START,cleanup_verified=False,custody_complete=False,frozen_components='See incremental custody-frozen reports; unreported components NOT_OBSERVED'))
        # Pending rows remain NOT_RUN; a started capped test is separately marked.
        for p in self.run.glob('test-*.json'):
            r=json.loads(p.read_text())
            if r.get('termination_reason'):
                for row in self.matrix:
                    if row.get('invocation_id')==r['id']:row.update(status='DIAGNOSTIC_CAP' if 'CAP' in r['termination_reason'] else 'INTERRUPTED',termination_reason=r['termination_reason'])
        save(self.run/'matrix.json',self.matrix)
        try:
            live=pathlib.Path(self.policy['live']);old=pathlib.Path(self.policy['source_root'])
            if self.live_expected is None:raise RuntimeError('LIVE_CUSTODY_AUTHORITY_UNAVAILABLE')
            mismatches=[p for p,h in self.live_expected.items() if not (live/p).is_file() or digest(live/p)!=h]
            save(self.run/'custody-stop.json',dict(file_mismatches=mismatches,git_metadata='UNOBSERVED_AFTER_STOP',status='INCOMPLETE_CUSTODY_CHECK'))
        except Exception as e:event(self.run/'errors.jsonl',dict(custody_stop_error=type(e).__name__))
        try:self.wd.wait(timeout=max(.1,self.deadline-time.monotonic()-1))
        except subprocess.TimeoutExpired:pass
        secondary=[]
        try:self.drain_telemetry()
        except Exception as exc:secondary.append('telemetry:'+type(exc).__name__+':'+str(exc))
        if self.wd.poll() is not None:
            try:self.guard_snapshot()
            except Exception as exc:secondary.append('guard_snapshot:'+type(exc).__name__+':'+str(exc))
            # Persist primary and secondary separately while any live guard still watches.
            save(self.run/'closure-errors.json',dict(primary=str(error),secondary=secondary,guard_returncode=self.guard.poll(),cleanup_verified=False))
            try:os.write(self.guardfd,b'{"done":true}\n')
            except OSError as exc:
                secondary.append('guard_done:'+type(exc).__name__+':'+str(exc))
                save(self.run/'closure-errors.json',dict(primary=str(error),secondary=secondary,guard_returncode=self.guard.poll(),cleanup_verified=False))
            try:self.guard.wait(timeout=max(.1,self.deadline-time.monotonic()))
            except subprocess.TimeoutExpired:pass

if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='--watchdog':
        try:sys.exit(watchdog(int(sys.argv[2]),int(sys.argv[3]),float(sys.argv[4]),float(sys.argv[5]),int(sys.argv[6]),sys.argv[7],sys.argv[8],int(sys.argv[9]),int(sys.argv[10])))
        except BaseException:
            # No new work after unexpected watchdog failure. Kill owned descendants.
            known=WATCHDOG_KNOWN
            emergency_errors=[]
            try:owned(os.getpid(),known)
            except Exception as exc:emergency_errors.append(dict(operation='discover',error=type(exc).__name__+':'+str(exc)))
            for x in list(known.values()):
                try:send_signal(x,signal.SIGKILL)
                except Exception as exc:emergency_errors.append(dict(identity=x,error=type(exc).__name__+':'+str(exc)))
            if emergency_errors:
                try:os.write(2,(json.dumps(dict(emergency_errors=emergency_errors))+'\n').encode())
                except Exception:pass
            raise
    if len(sys.argv)!=3 or sys.argv[1]!='--manifest-sha256' or len(sys.argv[2])!=64 or any(ch not in '0123456789abcdef' for ch in sys.argv[2]):raise SystemExit('Required approved --manifest-sha256; no bypass/resume options')
    c=None
    try:
        approved_manifest=sys.argv[2]
        manifest_bytes=(HERE/'evidence.sha256.json').read_bytes()
        if hashlib.sha256(manifest_bytes).hexdigest()!=approved_manifest:raise RuntimeError('MANIFEST_NOT_APPROVED')
        approved_files=json.loads(manifest_bytes)
        for program in ['supervisor.py','guard_deadlines.py','frozen_custody.py','verify_comparability.py','concurrency_preflight.py']:
            path=HERE/program
            if path.is_symlink() or digest(path)!=approved_files[program]:raise RuntimeError('PROGRAM_NOT_APPROVED:'+program)
        from frozen_custody import FrozenCustody
        policy_bytes=(HERE/'policy.json').read_bytes()
        if hashlib.sha256(policy_bytes).hexdigest()!=approved_files['policy.json']:raise RuntimeError('POLICY_NOT_APPROVED')
        c=Coordinator(json.loads(policy_bytes),approved_manifest);c.execute()
    except BaseException as e:
        if c is not None:c.stop(e)
        raise

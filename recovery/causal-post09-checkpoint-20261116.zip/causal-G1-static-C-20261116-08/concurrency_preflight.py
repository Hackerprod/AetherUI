"""Static-prepared, not executed/imported during preparation.
Closed concurrency classifier; no shell evaluation or process mutation.
Public API: classify(snapshot, context), collect_snapshot(pid), build_context(...),
normalize_own_records(...), scan(policy, manifest_digest, own_records, persist,
entry_filename='entry.json'). scan persists redacted evidence BEFORE raising.
"""
import hashlib
import json
import os
from pathlib import Path
import shlex

WRAPPER_EXE='/opt/codex/bin/codex'
WRAPPER_SHA256='57c94ea520df28beb76955316c5c48f672550fe42c6cff7003badb76e1ee10d8'
# Fixed ordering, arity and separator. Data values never interpreted as commands.
WRAPPER_OPTION_NAMES=['--sandbox-policy-cwd','--command-cwd','--permission-profile',
                      '--apply-seccomp-then-exec','--managed-network','--proxy-route-spec']
PYTHON_SINGLE_OPTIONS={'-B','-E','-I','-O','-OO','-s','-S','-u','-q','-b','-bb'}
PYTHON_VALUE_OPTIONS={'-W':{'default','error','ignore','always','module','once'},
                      '-X':{'dev','utf8','utf8=0','utf8=1','faulthandler'}}
CAMPAIGN_NAMES={'cmake','ctest','make','gmake','ninja','cc','c++','gcc','g++',
                'cc1','cc1plus','clang','clang++','collect2','ld','ld.bfd','ld.gold'}
CAMPAIGN_SCRIPTS={'supervisor.py','execute.py','synthetic_harness.py',
                  'concurrency_synthetic.py','observe_orders.py','guard_deadlines.py','fixture.py','fixtures.py'}
MARKERS=('/aether_','supervisor.py','execute.py','synthetic_harness.py',
         'concurrency_synthetic.py','observe_orders.py','guard_deadlines.py','--fixture')
DECISION_TABLE={
 'identity':'EXITED only after verified disappearance; inconsistent/read failure -> UNKNOWN',
 'own':'exact captured pid/start/ns + approved Python exe/hash + role script',
 'campaign':'real exe basename/comm campaign names or aether_ prefix; supported Python program slot script',
 'python':'only enumerated switches, optional --, one program slot; -c/-m/unknown -> UNKNOWN',
 'transport':'only exact codex hash/layout, real ancestor chain and independently derived entry payload',
 'data':'only approved known-data executable hash; arguments are data, never searched as programs',
 'other':'UNKNOWN, not generic name/uid/pid allowlisting'}

class ConcurrencyBlocked(RuntimeError):
    def __init__(self,report):self.report=report;super().__init__('CONCURRENT_CAMPAIGN_OR_UNKNOWN')
class EvidencePersistenceError(RuntimeError):pass
class ContractError(RuntimeError):
    def __init__(self,code,snapshot=None,ancestry=None):
        self.snapshot=snapshot;self.ancestry=ancestry;super().__init__(code)

def digest_bytes(data):return hashlib.sha256(data).hexdigest()
def file_hash(path):
    h=hashlib.sha256()
    with open(path,'rb') as stream:
        for chunk in iter(lambda:stream.read(1048576),b''):h.update(chunk)
    return h.hexdigest()
def identity(pid):
    data=Path('/proc',str(pid),'stat').read_text();v=data[data.rfind(')')+2:].split()
    return dict(pid=int(pid),ppid=int(v[1]),start=v[19])
def ns(pid):return {n:os.readlink('/proc/'+str(pid)+'/ns/'+n) for n in ('pid','mnt','user')}

def collect_snapshot(pid):
    """Raw argv remains memory-only. Capture identity, namespace and path twice."""
    result={'pid':int(pid),'status':'UNKNOWN','consistent':False}
    before=None
    try:
        before=identity(pid);result.update(before)
        namespace=ns(pid)
        root=Path('/proc',str(pid))
        exe=os.readlink(root/'exe');cwd=os.readlink(root/'cwd')
        argv_raw=(root/'cmdline').read_bytes()
        if not argv_raw or not argv_raw.endswith(b'\0'):raise ContractError('EMPTY_OR_UNTERMINATED_ARGV')
        argv=[x.decode('utf-8','strict') for x in argv_raw[:-1].split(b'\0')]
        # Open /proc/pid/exe, not an argv-supplied path; process identity checked again.
        exe_hash=file_hash(root/'exe');comm=(root/'comm').read_text().rstrip('\n')
        after=identity(pid);after_ns=ns(pid)
        if before!=after or namespace!=after_ns or exe!=os.readlink(root/'exe') or cwd!=os.readlink(root/'cwd') or argv_raw!=(root/'cmdline').read_bytes():
            raise ContractError('INCOHERENT_OR_REUSED_PROCESS')
        result.update(status='OK',consistent=True,namespaces=namespace,exe=exe,
                      exe_sha256=exe_hash,comm=comm,argv=argv,cwd=cwd)
    except (FileNotFoundError,ProcessLookupError):
        # A failed read is not itself proof of exit; verify /proc identity is gone.
        try:
            again=identity(pid)
            result.update(error='READ_FAILED_PROCESS_PRESENT',after_identity=again)
        except (FileNotFoundError,ProcessLookupError):
            if not Path('/proc',str(pid)).exists():result.update(status='EXITED',consistent=True,error='VERIFIED_DISAPPEARANCE')
            else:result.update(error='DISAPPEARANCE_NOT_VERIFIED')
        except Exception as exc:result.update(error=type(exc).__name__,errno=getattr(exc,'errno',None))
    except Exception as exc:
        result.update(error=type(exc).__name__+(':'+str(exc) if isinstance(exc,ContractError) else ''),errno=getattr(exc,'errno',None))
    return result

def same_identity(actual,expected,with_exe=False):
    keys=('pid','start','ppid','namespaces')+ (('exe','exe_sha256') if with_exe else ())
    return all(actual.get(k)==expected.get(k) for k in keys)

def normalize_own_records(records,policy):
    """Runtime execution-identities: coordinator/WD/guard, or explicit normalized list.
    Expected exe/hash ALWAYS derive from approved policy, not a fresh observation.
    """
    python=policy['tools']['python3'];expected_exe=str(Path(python['path']).resolve())
    output=[]
    iterable=records.items() if isinstance(records,dict) else ((r['role'],r) for r in records)
    for role,record in iterable:
        if role not in ('coordinator','watchdog','guard'):raise ContractError('UNKNOWN_OWN_ROLE')
        entry=record.get('execution_identity',record)
        ident=entry.get('identity',entry)
        namespaces=entry.get('namespaces',record.get('namespaces'))
        if not isinstance(namespaces,dict) or set(namespaces)!={'pid','mnt','user'}:raise ContractError('OWN_NAMESPACE_MISSING')
        value={k:ident[k] for k in ('pid','start','ppid')}
        value.update(role=role,namespaces=dict(namespaces),exe=expected_exe,exe_sha256=python['sha256'])
        output.append(value)
    if len({r['pid'] for r in output})!=len(output):raise ContractError('DUPLICATE_OWN_PID')
    return output

def verified_json(path,h):
    raw=Path(path).read_bytes()
    if digest_bytes(raw)!=h:raise ContractError('APPROVED_FILE_CHANGED')
    return json.loads(raw)

def build_context(policy,manifest_digest,own_records,entry_filename='entry.json'):
    if entry_filename not in ('entry.json','synthetic-entry.json'):raise ContractError('UNAPPROVED_ENTRY_KIND')
    root=Path(policy['root'])
    if root.is_symlink() or root.resolve()!=root:raise ContractError('ROOT_LOCATION')
    manifest=verified_json(root/'evidence.sha256.json',manifest_digest)
    frozen_policy=verified_json(root/'policy.json',manifest['policy.json'])
    if policy!=frozen_policy:raise ContractError('CALLER_POLICY_NOT_APPROVED')
    entry=verified_json(root/entry_filename,manifest[entry_filename])
    prefix=entry.get('argv_prefix')
    script='supervisor.py' if entry_filename=='entry.json' else 'concurrency_synthetic.py'
    expected=[policy['tools']['python3']['path'],str(root/script),'--manifest-sha256']
    if prefix!=expected or entry.get('cwd')!=str(root):raise ContractError('ENTRY_NOT_CLOSED_DIRECT_LAUNCH')
    argv=prefix+[manifest_digest]
    payload='exec '+shlex.join(argv)
    own=normalize_own_records(own_records,policy)
    coord=[r for r in own if r['role']=='coordinator']
    if len(coord)!=1 or coord[0]['pid']!=os.getpid():raise ContractError('COORDINATOR_IDENTITY_REQUIRED')
    actual=collect_snapshot(os.getpid())
    if actual['status']!='OK' or not same_identity(actual,coord[0],True) or actual['argv']!=argv or actual['cwd']!=str(root):
        raise ContractError('COORDINATOR_NOT_APPROVED_ENTRY',actual)
    chain=[];last=actual;seen={actual['pid']}
    while last['ppid']:
        parent=collect_snapshot(last['ppid'])
        if parent['status']!='OK' or parent['pid'] in seen:raise ContractError('ANCESTRY_UNPROVABLE',parent,chain)
        if parent['namespaces']!=actual['namespaces']:raise ContractError('ANCESTRY_NAMESPACE_DIFFERENCE',parent,chain)
        chain.append({k:parent[k] for k in ('pid','ppid','start','namespaces','exe','exe_sha256')})
        seen.add(parent['pid']);last=parent
    # Confirm child identity/parent pointer after ancestry reads.
    rechecked=collect_snapshot(os.getpid())
    if not same_identity(rechecked,actual,True):raise ContractError('ANCESTRY_CHANGED',rechecked,chain)
    return dict(root=str(root),workspace_root=str(root.parent),own=own,ancestors=chain,
                launch=dict(coordinator=coord[0],argv=argv,cwd=str(root),payload=payload),
                python=dict(exe=str(Path(policy['tools']['python3']['path']).resolve()),sha256=policy['tools']['python3']['sha256']),
                known_data_executables=dict(policy.get('concurrency_known_data_executables',{})),
                campaign_executables=[str(Path(policy['tools'][n]['path']).resolve()) for n in ('cc','c++','cmake','ctest','make') if n in policy['tools']],
                entry_filename=entry_filename,manifest_digest=manifest_digest)

def campaign_name(name):
    return name in CAMPAIGN_NAMES or name.startswith('aether_') or any(name.startswith(x+'-') for x in ('gcc','g++','clang','clang++','cmake','ctest'))

def python_program(argv):
    index=1
    while index<len(argv):
        arg=argv[index]
        if arg=='--':return index+1 if index+1<len(argv) else None,'SCRIPT_AFTER_SEPARATOR'
        if arg in PYTHON_SINGLE_OPTIONS:index+=1;continue
        if arg in PYTHON_VALUE_OPTIONS:
            if index+1>=len(argv) or argv[index+1] not in PYTHON_VALUE_OPTIONS[arg]:return None,'UNSUPPORTED_PYTHON_OPTION_VALUE'
            index+=2;continue
        if arg.startswith('-'):return None,'UNSUPPORTED_PYTHON_OPTION'
        return index,'PYTHON_PROGRAM_SLOT'
    return None,'NO_PYTHON_PROGRAM'

def classify(snapshot,context):
    """Pure classifier: no /proc, hashing, persistence, environment or file reads.
    Raw synthetic snapshots must be explicitly labelled by their harness externally.
    """
    argv=snapshot.get('argv',[])
    argv_valid=isinstance(argv,list) and all(isinstance(x,str) for x in argv)
    hits=[i for i,v in enumerate(argv) if any(m in v for m in MARKERS)] if argv_valid else []
    def answer(verdict,rule,reason,**extra):return dict(verdict=verdict,rule=rule,reason=reason,matched_indices=hits,**extra)
    if snapshot.get('status')=='EXITED' and snapshot.get('consistent') is True:return answer('EXITED','identity','Verified disappearance')
    if snapshot.get('status')!='OK' or snapshot.get('consistent') is not True:return answer('UNKNOWN','identity','Incomplete or inconsistent observation')
    if not argv_valid or not argv:return answer('UNKNOWN','argv','Missing or invalid argv')
    if not all(k in snapshot for k in ('pid','start','ppid','namespaces','exe','exe_sha256','cwd','comm')):
        return answer('UNKNOWN','identity','Required observation field missing')
    for own in context['own']:
        if snapshot['pid']==own['pid']:
            if not same_identity(snapshot,own,True):return answer('UNKNOWN','own','Own PID identity differs')
            role=own['role']
            if role=='coordinator':valid=argv==context['launch']['argv'] and snapshot['cwd']==context['launch']['cwd']
            else:
                script='supervisor.py' if role=='watchdog' else 'guard_deadlines.py'
                valid=len(argv)>1 and argv[1]==context['root']+'/'+script
                if role=='watchdog':valid=valid and len(argv)>2 and argv[2]=='--watchdog'
            return answer('OWN_PROCESS' if valid else 'UNKNOWN','own','Captured role identity and script' if valid else 'Own script mismatch')
    exe=snapshot['exe'];base=Path(exe).name;comm=snapshot.get('comm','')
    if exe in context.get('campaign_executables',[]) or campaign_name(base) or campaign_name(comm):return answer('CAMPAIGN','campaign_executable','Executable/comm matches closed campaign rule')
    if exe==WRAPPER_EXE or argv[0]=='codex-linux-sandbox':
        ancestor=next((a for a in context['ancestors'] if a['pid']==snapshot['pid']),None)
        if not ancestor or not same_identity(snapshot,ancestor,True):return answer('UNKNOWN','transport','Not the captured launch ancestor')
        if exe!=WRAPPER_EXE or snapshot['exe_sha256']!=WRAPPER_SHA256:return answer('UNKNOWN','transport','Wrapper executable/hash differs')
        expected_flags={1:'--sandbox-policy-cwd',3:'--command-cwd',5:'--permission-profile',7:'--apply-seccomp-then-exec',8:'--managed-network',10:'--proxy-route-spec',12:'--',13:'/bin/bash',14:'-lc'}
        if len(argv)!=16 or argv[0]!='codex-linux-sandbox' or any(argv[i]!=v for i,v in expected_flags.items()):return answer('UNKNOWN','transport','Unsupported wrapper layout/options')
        if argv[2]!=context['workspace_root'] or argv[4]!=context['launch']['cwd']:return answer('UNKNOWN','transport','Wrapper directories differ from approved entry')
        # Opaque policy/network route parameters are data, never an extra command.
        # Require complete JSON objects. Their contents never appear in evidence.
        try:
            if not all(isinstance(json.loads(argv[i]),dict) for i in (6,9,11)):raise ValueError()
        except (ValueError,TypeError):return answer('UNKNOWN','transport','Unsupported opaque option data')
        match=argv[15]==context['launch']['payload']
        return answer('OWN_LAUNCH_TRANSPORT' if match else 'UNKNOWN','transport','Exact approved payload' if match else 'Payload differs',
                      payload_sha256=digest_bytes(argv[15].encode()),payload_length=len(argv[15].encode()),payload_exact_match=match)
    if exe==context['python']['exe'] or base.startswith('python'):
        if exe!=context['python']['exe'] or snapshot['exe_sha256']!=context['python']['sha256']:return answer('UNKNOWN','python','Unapproved Python executable/hash')
        index,rule=python_program(argv)
        if index is None:return answer('UNKNOWN','python',rule)
        program=argv[index]
        if not program.startswith('/'):
            cwd=snapshot.get('cwd')
            if not cwd or not cwd.startswith('/'):return answer('UNKNOWN','python','Program path cannot resolve')
            program=str(Path(cwd)/program)
        if Path(program).name in CAMPAIGN_SCRIPTS or Path(program).name.startswith('aether_') or '--fixture' in argv[index+1:]:
            return answer('CAMPAIGN','python_program','Campaign script in actual program slot',program_index=index)
        return answer('UNKNOWN','python_program','Script semantics not approved',program_index=index)
    known=context.get('known_data_executables',{})
    if known.get(exe)==snapshot['exe_sha256']:
        # Closed safe data executables, never arbitrary policy-supplied command interpreters.
        if exe in ('/usr/bin/printf','/usr/bin/echo','/usr/bin/cat','/usr/bin/sleep','/usr/bin/true','/usr/bin/false'):
            return answer('NOT_CAMPAIGN','known_data','Approved data-only executable; marker arguments not executed')
    return answer('UNKNOWN','unknown_execution','No approved execution semantics')

def redact(snapshot,verdict):
    clean={k:snapshot.get(k) for k in ('pid','start','ppid','status','consistent','namespaces','exe','exe_sha256','comm','error','errno') if k in snapshot}
    clean['argv_count']=len(snapshot.get('argv',[]))
    # No raw argv, cwd or command payload, including UNKNOWN processes.
    clean['argv_metadata']=[dict(index=i,length=len(arg.encode()),sha256=digest_bytes(arg.encode())) for i,arg in enumerate(snapshot.get('argv',[]))]
    if 'cwd' in snapshot:clean['cwd_sha256']=digest_bytes(snapshot['cwd'].encode())
    clean['decision']=verdict
    return clean

def scan(policy,manifest_digest,own_records,persist,entry_filename='entry.json'):
    """One read-only pass. Evidence failure prevents any PASS/result return.
    persist takes one serializable report, writes it atomically, raises on failure.
    Own identities come from previously captured ready records, not this new scan.
    """
    report=dict(status='BLOCKED',records=[],blockers=[],entry_filename=entry_filename,
                manifest_sha256=manifest_digest,decision_table=DECISION_TABLE)
    try:
        context=build_context(policy,manifest_digest,own_records,entry_filename)
        report['ancestry']=context['ancestors']
        report['contract']=dict(entry_filename=entry_filename,payload_length=len(context['launch']['payload'].encode()),
                                payload_sha256=digest_bytes(context['launch']['payload'].encode()))
        pids=sorted(int(p.name) for p in Path('/proc').iterdir() if p.name.isdigit())
        for pid in pids:
            snapshot=collect_snapshot(pid)
            decision=classify(snapshot,context)
            row=redact(snapshot,decision);report['records'].append(row)
            if decision['verdict'] in ('UNKNOWN','CAMPAIGN'):report['blockers'].append(dict(pid=pid,rule=decision['rule'],verdict=decision['verdict']))
        # Snapshot must still match captured launch/own identities at decision time.
        for expected in context['own']+context['ancestors']:
            after=collect_snapshot(expected['pid'])
            if after['status']!='OK' or not same_identity(after,expected,True):
                report['blockers'].append(dict(pid=expected['pid'],rule='identity_recheck',verdict='UNKNOWN'))
                report['records'].append(redact(after,dict(verdict='UNKNOWN',rule='identity_recheck',reason='Identity changed before decision',matched_indices=[])))
        final_pids=sorted(int(p.name) for p in Path('/proc').iterdir() if p.name.isdigit())
        if final_pids!=pids:
            report['blockers'].append(dict(rule='process_set_changed',verdict='UNKNOWN'))
            report['process_set_delta']=dict(appeared=sorted(set(final_pids)-set(pids)),disappeared=sorted(set(pids)-set(final_pids)))
        for row in list(report['records']):
            if row.get('status')=='EXITED' and Path('/proc',str(row['pid'])).exists():
                returned=collect_snapshot(row['pid'])
                report['blockers'].append(dict(pid=row['pid'],rule='pid_returned_after_exit',verdict='UNKNOWN'))
                report['records'].append(redact(returned,dict(verdict='UNKNOWN',rule='pid_returned_after_exit',reason='PID present after verified disappearance',matched_indices=[])))
        report['counts']={v:sum(r['decision']['verdict']==v for r in report['records']) for v in ('OWN_PROCESS','OWN_LAUNCH_TRANSPORT','NOT_CAMPAIGN','CAMPAIGN','UNKNOWN','EXITED')}
        report['status']='PASS' if not report['blockers'] else 'BLOCKED'
    except Exception as exc:
        report['status']='BLOCKED';report['error']=dict(type=type(exc).__name__,code=str(exc) if isinstance(exc,ContractError) else 'READ_OR_CLASSIFICATION_FAILURE',errno=getattr(exc,'errno',None))
        if isinstance(exc,ContractError):
            if exc.ancestry is not None:report['ancestry']=exc.ancestry
            if exc.snapshot is not None:
                report['records'].append(redact(exc.snapshot,dict(verdict='UNKNOWN',rule='contract_or_ancestry',reason=str(exc),matched_indices=[])))
    try:persist(report)
    except Exception as exc:raise EvidencePersistenceError('CONCURRENCY_EVIDENCE_NOT_PERSISTED') from exc
    if report['status']!='PASS':raise ConcurrencyBlocked(report)
    return report

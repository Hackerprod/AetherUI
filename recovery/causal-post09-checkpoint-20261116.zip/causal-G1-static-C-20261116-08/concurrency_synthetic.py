#!/usr/bin/env python3
"""STATIC ONLY until D separately approves this exact manifest and entry.
A single read-only classifier validation; no product, subprocess commands, repair,
permission changes, or retries. No descendants. SIGALRM exits at absolute60.
"""
import argparse
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import sys
import time

sys.dont_write_bytecode=True
START=time.monotonic()
HERE=Path(__file__).resolve().parent
OUTPUT=HERE.parent/'causal-G1-concurrency-C-20261116-08'
ABSOLUTE=START+60
WORK=START+55

class SyntheticFailure(RuntimeError):pass

def require(ok,reason):
    if not ok:raise SyntheticFailure(reason)
def digest(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1048576),b''):h.update(chunk)
    return h.hexdigest()
def save(name,value):
    p=OUTPUT/name;tmp=p.with_suffix(p.suffix+'.tmp')
    with open(tmp,'w') as f:json.dump(value,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
    os.replace(tmp,p)
def append(name,value):
    with open(OUTPUT/name,'a') as f:f.write(json.dumps(value)+'\n');f.flush();os.fsync(f.fileno())
def budget():require(time.monotonic()<WORK,'SYNTHETIC_WORK_CAP')
def namespace():return {n:os.readlink('/proc/self/ns/'+n) for n in ('pid','mnt','user')}
def read_identity(pid):
    try:
        f=Path('/proc',str(pid),'stat').read_text().rsplit(')',1)[1].split()
        return dict(pid=int(pid),ppid=int(f[1]),start=f[19],namespaces=namespace() if pid==os.getpid() else {n:os.readlink('/proc/'+str(pid)+'/ns/'+n) for n in ('pid','mnt','user')})
    except (FileNotFoundError,ProcessLookupError):return None

def verify_manifest(approved_hash):
    require(len(approved_hash)==64 and all(c in '0123456789abcdef' for c in approved_hash),'BAD_APPROVED_MANIFEST_DIGEST')
    raw=(HERE/'evidence.sha256.json').read_bytes()
    require(hashlib.sha256(raw).hexdigest()==approved_hash,'MANIFEST_NOT_APPROVED')
    files=json.loads(raw)
    for name,h in files.items():
        budget();p=HERE/name
        require(not p.is_symlink() and p.is_file() and digest(p)==h,'APPROVED_FILE_MISMATCH:'+name)
    for name in ('concurrency_synthetic.py','concurrency_preflight.py','concurrency-cases.json','synthetic-entry.json','policy.json'):
        require(name in files,'REQUIRED_APPROVED_FILE_MISSING:'+name)
    return dict(sha256=approved_hash,files=files)

def load_classifier():
    spec=importlib.util.spec_from_file_location('concurrency_preflight',HERE/'concurrency_preflight.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module


def table_cases(module,table):
    # All inputs here are frozen artificial snapshots. Never execute their argv.
    results=[]
    for case in table['cases']:
        budget()
        snapshot=copy.deepcopy(case['snapshot']);context=copy.deepcopy(case['context'])
        got=module.classify(snapshot,context)
        record=dict(id=case['id'],input_kind='ARTIFICIAL_SNAPSHOT_NOT_EXECUTION',expected=case['expected'],observed=got)
        append('table-results.jsonl',record);results.append(record)
        require(got['verdict']==case['expected'],'TABLE_VERDICT_MISMATCH:'+case['id'])
    return results


def integration(module,policy,approved):
    # Entry authority is frozen synthetic-entry.json + externally supplied hash.
    # No observed cmdline/payload is ever used to manufacture approval.
    budget();own_coordinator=module.collect_snapshot(os.getpid())
    require(own_coordinator['status']=='OK','OWN_IDENTITY_NOT_OBSERVED')
    own_records={'coordinator':own_coordinator}
    policy=copy.deepcopy(policy)
    persisted=[]
    def persist(report):
        # Classifier supplies only redacted evidence; raw snapshots stay in memory.
        save('integration-real.json',report);persisted.append(report)
    report=module.scan(policy,approved['sha256'],own_records,persist,entry_filename='synthetic-entry.json')
    require(persisted and report.get('status')=='PASS','REAL_INTEGRATION_DID_NOT_PASS')
    budget()
    context=module.build_context(policy,approved['sha256'],own_records,entry_filename='synthetic-entry.json')
    wrapper_snapshots=[]
    for ancestor in context['ancestors']:
        snap=module.collect_snapshot(ancestor['pid'])
        if snap.get('exe')=='/opt/codex/bin/codex':wrapper_snapshots.append(snap)
    require(len(wrapper_snapshots)==1,'EXPECTED_ONE_REAL_LAUNCH_WRAPPER')
    actual=module.classify(wrapper_snapshots[0],context)
    require(actual['verdict']=='OWN_LAUNCH_TRANSPORT','OWN_WRAPPER_NOT_VALIDATED')
    invalid_context=copy.deepcopy(context)
    invalid_context['launch']['payload']=invalid_context['launch']['payload']+' INVALID_SYNTHETIC_CONTRACT'
    invalid=module.classify(wrapper_snapshots[0],invalid_context)
    save('integration-invalid-contract.json',dict(input_kind='REAL_SNAPSHOT_WITH_INVALID_CONTRACT_AS_DATA_ONLY',observed=invalid))
    require(invalid['verdict']=='UNKNOWN','INVALID_CONTRACT_NOT_BLOCKED')
    budget()
    attempts=[]
    def fail_persist(redacted_report):
        attempts.append(dict(status=redacted_report.get('status'),process_count=len(redacted_report.get('records',[]))))
        raise PermissionError('SYNTHETIC_EXPECTED_EVIDENCE_PERSISTENCE_FAILURE')
    try:
        module.scan(policy,approved['sha256'],own_records,fail_persist,entry_filename='synthetic-entry.json')
    except module.EvidencePersistenceError as exc:
        save('expected-persistence-failure.json',dict(expected=True,exception=type(exc).__name__,attempts=attempts,operation='callback exception only; no permission changes'))
        require(bool(attempts),'PERSISTENCE_NOT_ATTEMPTED')
    else:raise SyntheticFailure('PERSISTENCE_FAILURE_WAS_NOT_BLOCKING')
    return dict(real_wrapper=actual,invalid_contract=invalid,persistence_failure_observed=True)


def main():
    # No children to clean up. Keep the hard timer armed throughout reads,
    # hashes, callbacks, fsync and final outcome; handler performs no IO.
    signal.signal(signal.SIGALRM,lambda signum,frame:os._exit(124))
    signal.setitimer(signal.ITIMER_REAL,max(.001,ABSOLUTE-time.monotonic()))
    p=argparse.ArgumentParser();p.add_argument('--manifest-sha256',required=True);args=p.parse_args()
    approved=verify_manifest(args.manifest_sha256)
    entry=json.loads((HERE/'synthetic-entry.json').read_text())
    require(entry['cwd']==str(HERE) and Path.cwd()==HERE,'SYNTHETIC_CWD_NOT_APPROVED')
    require(entry['argv_prefix'][1]==str(HERE/'concurrency_synthetic.py'),'ENTRY_SCRIPT_NOT_APPROVED')
    require(entry['output_directory']==str(OUTPUT),'OUTPUT_NOT_APPROVED')
    require(not OUTPUT.exists() and not OUTPUT.is_symlink(),'OUTPUT_ALREADY_EXISTS_NO_RETRY')
    OUTPUT.mkdir()
    completed=False
    try:
        save('identity.json',dict(coordinator=read_identity(os.getpid()),namespace=namespace(),start=START,absolute_deadline=ABSOLUTE,work_deadline=WORK,max_descendants=4,actual_descendants=0))
        save('outcome.json',dict(status='RUNNING',product_executions=0,program_custody_complete=False))
        module=load_classifier();table=json.loads((HERE/'concurrency-cases.json').read_text());policy=json.loads((HERE/'policy.json').read_text())
        save('selection-initial.json',dict(cases=[dict(id=c['id'],status='NOT_RUN') for c in table['cases']+table['integration_cases']],fixed_selection=True))
        results=table_cases(module,table);live=integration(module,policy,approved)
        budget()
        require(digest(HERE/'evidence.sha256.json')==args.manifest_sha256,'FINAL_MANIFEST_DRIFT')
        for name,h in approved['files'].items():
            budget();path=HERE/name;require(not path.is_symlink() and path.is_file() and digest(path)==h,'FINAL_FILE_DRIFT:'+name)
        save('outcome.json',dict(status='PASS_SYNTHETIC_ONLY',table_cases=len(results),live_integration=live,product_executions=0,program_custody_complete=True,wall=time.monotonic()-START,closure='No descendants; hard alarm remains armed through final persistence'))
        completed=True
    except BaseException as exc:
        # Error type only: do not leak unredacted third-party argv from exception text.
        try:save('outcome.json',dict(status='STOPPED',error_type=type(exc).__name__,reason=str(exc) if isinstance(exc,SyntheticFailure) else 'See redacted classifier evidence',product_executions=0,program_custody_complete=False,wall=time.monotonic()-START))
        except Exception:pass
    finally:
        # Nothing can outlive this process: no children were created.
        pass
    return 0 if completed else 2

if __name__=='__main__':os._exit(main())

# C · V8: preflight de concurrencia y ensayo sintético, sólo estático

2026-11-16. Preparación conforme a propuesta `propuesta-preflight-concurrencia-C-v8-20261116.md`, SHA256 `2b1959e4dfaee1a440baa9b3545649e56b79db77de33312d36855adc59120dae`, y condiciones D. **Nada ejecutado, importado o compilado. Producto prohibido.**

## Motivación y límites

-07 se detuvo antes de configure/build/test. El predicado por substring del cmdline completo puede clasificar texto transportado por el wrapper como campaña ejecutándose. El falso positivo se observó en inspección posterior, pero no se preservó el argv/identidad original completo. La explicación histórica original continúa siendo inferencia. Su outcome INCOMPLETE_CUSTODY no se reescribe.

V8 separa identidad y rol ejecutable de datos transportados. No elimina la comprobación de concurrencia ni incorpora una excepción genérica para PID1/codex. CAMPAIGN y UNKNOWN bloquean. No mata procesos ajenos ni altera entorno para pasar.

## Alcance

Nuevo módulo concurrency_preflight.py compartido por supervisor y ensayo. Supervisor cambia sólo la llamada de clasificación/preflight y aprobación explícita del módulo nuevo. Guardia, frozen_custody.py y verify_comparability.py permanecen idénticos a -07. La tabla de decisiones y opciones admitidas se revisa junto al módulo/política, sin evaluación dinámica del payload.

El contrato del transporte propio deriva del argv_prefix de la entrada aprobada y del SHA externo aprobado. Payload shell exacto: prefijo `exec ` seguido de shlex.join(argv_prefix + [SHA_D]). La entrada productiva inerte se describe en entry.json; la única entrada candidata del ensayo está en synthetic-entry.json. No obtener el contrato esperado del contenido declarado por el proceso inspeccionado.

Una futura llamada de ejecución debe contener exclusivamente ese payload congelado, no concatenar cat/sha256sum/test al lanzamiento. Verificar hash y ausencia de salida en una llamada read-only anterior. El wrapper real observado tiene exe/hash/layout concretos y debe ser ancestro real por PID/start/ns; un wrapper distinto/ajeno/layout nuevo permanece UNKNOWN. Hermanos y demás procesos continúan inspeccionándose.

Evidencia persistida antes de bloquear: identidad, ancestría, exe/hash, reglas y coincidencias por índice, hashes/longitudes de payload sin argv privado completo. Lectura incoherente, identidad reutilizada, permisos o persistencia fallida bloquean. La interpretación conservadora de wrappers/intérpretes se define en el clasificador; no parsear shell genérico ni tomar texto arbitrario como permiso.

## Validación pendiente

concurrency_synthetic.py y concurrency-cases.json fijan snapshots artificiales y la integración read-only con el transporte real. Los casos artificiales prueban la función real de clasificación sobre datos etiquetados, no simulan ejecución real de compiladores. La prueba de contrato inválido no lanza otra campaña.

Techo 60 s y máximo cuatro descendientes; una sola tanda, salida exclusiva `causal-G1-concurrency-C-20261116-08/`. Error/cap/persistencia incompleta implica parada, sin reparación/reintento. No builds ni CTest/producto. El ensayo requiere otro gate D sobre código, entrada y manifiesto.

La configuración y argv de producto -08 se conservan inertes para inspeccionar la integración: 22 nombres, 18 targets, 44 pruebas, 52 argv; caps originales 120/1800/120/900/4800, trabajo 4770 y reserva 30. Sus destinos run/build-Hc/build-J permanecen inexistentes. No están autorizados ni se ejecutarán por un gate sólo sintético. Si el ensayo pasa, D debe revisar sus resultados y otro expediente/rutas nuevos antes de producto.

Versiones -01 a -07, resultados previos y checkout vivo permanecen intactos; custody-static.json documenta la verificación. G1 NOT_PASSED; OFF/ON/G2 bloqueados; coverage_complete=false; causa histórica -04 UNDETERMINED.

## Tabla congelada del ensayo

37 snapshots artificiales en concurrency-cases.json: programas de campaña reales por slot/comm, opciones Python explícitas, wrapper propio exacto, datos de printf/cat conocidos, wrapper ajeno o hash/layout/payload/cwd/start/namespace inválidos, desaparición verificada frente a incierta, lectura incoherente/denegada, shell ambiguo, -c/-m/opciones Python desconocidas, intérprete desconocido, identidad propia alterada y campaña hermana no excluida.

Tres comprobaciones read-only adicionales: scan real con wrapper exacto; mismo snapshot con contrato invalidado sólo en memoria; callback de persistencia que lanza PermissionError sintético, sin cambiar permisos. El algoritmo y scan usados son los del módulo real, no una réplica. El harness no crea hijos (0 ≤ 4); SIGALRM duro a 60 s se arma antes de leer manifiestos y sigue activo durante toda la persistencia final. Trabajo limitado a 55 s. No se amplía la whitelist de roles propios para añadir un guardian sintético.

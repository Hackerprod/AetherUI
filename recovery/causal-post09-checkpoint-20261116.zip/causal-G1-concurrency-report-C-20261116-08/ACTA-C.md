# C · Acta única tanda sintética v8

2026-11-16. **PASS_SYNTHETIC_ONLY**, pendiente revisión independiente D. Producto no autorizado ni ejecutado.

## Entrada y cierre

Precomprobación read-only separada: manifiesto exacto y salida inexistente. Una sola llamada, cwd `causal-G1-static-C-20261116-08`, payload exacto:

`exec /opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12 /workspace/scratch/2ac40fb4b2af/causal-G1-static-C-20261116-08/concurrency_synthetic.py --manifest-sha256 17768def02fdea1823834f909082d2549789a7c6cbb2accf0713be2f56e79ed9`

Retorno 0; duración 2,153265819 s. 37/37 snapshots con veredicto esperado y tres comprobaciones read-only satisfechas. Sin reintento, reparación o cap. No hijos creados; límite ≤4, trabajo55 s/techo60 s. El timer duro permanece armado durante persistencia final y salida.

## Evidencia

- Tabla: 37 resultados persistidos individualmente. Son datos artificiales explícitos que invocan la función real, no ejecuciones reales de compiladores ni campañas ajenas.
- Integración real: scan PASS, blockers=[]; un OWN_PROCESS (coordinador PID2) y un OWN_LAUNCH_TRANSPORT (wrapper PID1), sin UNKNOWN ni CAMPAIGN. Evidencia contiene identidades/start/ns, hashes de ejecutable, ancestry y contrato redactado. El payload coincide exactamente con la entrada aprobada: SHA256 `c8c2be004d7d2b0ed6a9fd341ddbd89eec5521a5e14760b9f3e2f690a0c575dc`, 252 bytes, marcador en argumento15. La decisión no deriva de que PID sea1 o comm sea codex.
- Mismo snapshot con contrato invalidado sólo como dato: UNKNOWN/Payload differs, payload_exact_match=false. No ejecutó otra campaña.
- Persistencia: callback deliberadamente lanza PermissionError sin cambiar permisos. scan eleva EvidencePersistenceError; queda registrada una tentativa sobre reporte PASS de dos procesos. Esto valida que la falta de persistencia impide devolver PASS, no simula todas las formas de fallo físico del almacenamiento.

El manifiesto y todos los archivos ejecutados fueron revalidados por el harness antes de cerrar. Outcome program_custody_complete=true. Siete archivos originales en `causal-G1-concurrency-C-20261116-08/`, preservados con hashes/tamaños y segunda comprobación; no se editaron salidas.

## Custodia y límites

Verificación independiente: expedientes -01 a -08 intactos (4294,9,11,15,6,16,12,17 archivos); salidas anteriores -04/v5/-06/-07 intactas (15/15/73/14). Checkout: 1442 archivos y HEAD/rama/index/parche/status/cached iguales. Run/build-Hc/build-J de producto -08 inexistentes.

Inspección posterior sin procesos coincidentes visibles, sólo en su sandbox; no se presenta como garantía global. El ensayo no crea descendientes y su retorno fue0. No se reescribe el cierre histórico incompleto de -07 ni se prueba retrospectivamente la causa exacta de su clasificación PID1.

Esto valida el clasificador en la tabla definida y el transporte real de este ensayo, no todo preflight futuro ni ausencia global de concurrencia. Una tanda de producto requiere expediente/rutas nuevos y gate D propio. G1 NOT_PASSED; OFF/ON/G2 bloqueados; coverage_complete=false. Causa histórica -04 UNDETERMINED. C se detiene para D.

# C · Experimento observacional v5, preparación estática

2026-11-16. **STATIC_PREPARATION_ONLY. NO EJECUTADO. Producto y reparación NO AUTORIZADOS.**

Preparado según propuesta SHA256 7ddbdec8bc397e8c5878797a7671d34d1e7d7d0907d30317973410b3bf85d6ff y condición D: no basta enviar SIGTERM; el propio hijo debe confirmar que lo recibió en su handler heredado antes de permitir restablecimiento.

## Objeto y alcance

Dos órdenes controlados, no reintento del harness -04. Se importan **sin cambios** pin/exited/safe_signal/retire/HandleLedger del guard_deadlines.py -04, cuyo hash se fija en policy. Ningún módulo de producto ni CMake/CTest se ejecutaría. La observación futura no podrá establecer retrospectivamente el orden que ocurrió en el fallo -04.

`observe_orders.py` es nuevo fixture/controlador. `policy.json`, `entry.json` y matriz inicial fijan alcance y entrada. No se ejecutó/importó/compiló este programa durante preparación. La guardia -04, todos los expedientes y salidas anteriores permanecen intactos.

## Control discriminante obligatorio

### inherited

1. Worker instala un handler SIGTERM y hace fork; el hijo lo hereda realmente.
2. Hijo emite readiness con comparación directa del handler, identidad/namespace y SigBlk/SigIgn/SigCgt obtenidos de /proc. No cambia máscara.
3. Padre verifica readiness y que SIGTERM esté entregable, fija pidfd>1024 e intenta exactamente un SIGTERM mediante la función real. Persiste inicio/fin, retorno/errno disponible, errores y ledger aun si falla después.
4. El handler del **hijo** emite `handler_received`, con PID, señal, fase y monotónico. Sólo tras recibir, validar y persistir esa confirmación el padre puede escribir la liberación `R`.
5. El hijo además comprueba su propio indicador de recepción antes de aceptar `R`; no basta una declaración del padre. Sólo entonces restablece SIG_DFL y emite `reset_confirmed`, con máscara/default y monotónico.
6. Se exige orden recepción ≤ liberación ≤ reset. Se observa al hijo vivo durante0,3s tras reset, sin enviar otro SIGTERM. La limpieza SIGKILL y waitpid quedan separadas del resultado experimental.

**Si no llega confirmación en3s, hay máscara bloqueante, retorno de envío no confirmado o presupuesto insuficiente: NON_DISCRIMINATING, sin liberar reset, sin continuar al segundo orden.** El handler escribe un evento pequeño por pipe no bloqueante; cualquier incapacidad de emitir confirmación invalida la observación.

### restored

El hijo restablece SIG_DFL **antes** de readiness. Readiness acredita SIG_DFL, ausencia de captura/ignore de SIGTERM y máscara no bloqueante. El padre envía una sola señal con las mismas funciones y descriptores altos. Se requiere salida observada por pidfd **y** waitpid con exit_code=-SIGTERM. No se infiere recepción a partir de un retorno de envío.

La sincronización es una intervención explícita para controlar orden, no una reproducción probabilística de la carrera histórica. Los callbacks de readiness/recepción son instrumentación del fixture, no modificaciones de la guardia real ni del producto.

## Presupuestos y evidencia

- Una tanda nueva: inherited y luego restored, una vez cada uno, parada ante resultado no discriminante.
- 30s absolutos; trabajo hasta26s, reserva4s dentro del techo. Máximo10s por worker (8s de trabajo y2s de cierre dentro del cap),3s por confirmación/espera de salida,0,3s de observación viva; el techo global prevalece.
- Máximo4 descendientes; el diseño normal usa worker+hijo. Controlador subreaper y observación de procesos/namespace. Sólo señales a identidades propias fijadas; cleanup no es una repetición del envío experimental.
- No cambia rlimit ni máscaras. Capacidad insuficiente de pidfd/poll, rlimit existente insuficiente para fd>1024, disco<12GiB o memoria<4GiB => parada no discriminante, sin instalar o relajar controles.
- Eventos, retorno/errores de señal y estados parciales se persisten antes de assertions posteriores y en finally. Se diferencia salida observada, señal real de waitpid y recolección. Un cap o error de cleanup impide resultado favorable.
- Revalidación de manifiesto/configuración y referencias al final. Si el cierre no completa, se conserva estado parcial, no se declara mecanismo observado.

Salida futura exclusiva: `/workspace/scratch/2ac40fb4b2af/causal-G1-observation-C-20261116-05/`, inexistente en preparación. No se escribe en las fuentes congeladas. No se reutilizan salidas sintéticas -04 ni residuos de producto -03.

## Entrada que requiere otro gate D

Python exacto de policy, cwd -05:

`observe_orders.py --manifest-sha256 SHA256_EXACTO_APROBADO_POR_D`

El temporizador de arranque se arma antes de leer hashes/referencias; el deadline no se reinicia al entrar al controlador. El SHA se suministra desde el dictamen, fuera del manifiesto autorreferente. Los modos internos de worker no son entradas autorizadas independientes. **Esta entrega no autoriza lanzar nada.** D debe revisar código, hashes, argv, sincronización, caps y cleanup primero.

Si ambos órdenes coinciden con sus observaciones exigidas, el estado será CONTROLLED_MECHANISM_OBSERVED_ONLY con historical_cause=UNDETERMINED. Si no, NON_DISCRIMINATING_STOP. Ni uno ni otro autoriza reparar, repetir -04, completar sus cinco pendientes o ejecutar producto.

**G1 NOT_PASSED; OFF/ON/G2 bloqueados; coverage_complete=false.**

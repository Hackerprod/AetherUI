# C · Materialización v6 exclusivamente estática

Propuesta aprobada: `propuesta-correccion-fixture-C-v6-20261116.md`, SHA256 `8bdc033b38b3d76067178803f48dc89d69806a4e3b10a67f29fdaf404493137f`.

No ejecutada, importada ni compilada. Producto prohibido. Requiere nuevo gate D sobre este manifiesto antes de cualquier ejecución.

## Cambio

Helper independiente `child_held_ready` sólo para high_descriptors. El hijo acredita SIG_DFL, máscara, identidad y namespace antes del único SIGTERM experimental. Sin ACK válido no se envía. El pipe hold permanece abierto hasta observar salida; cierre único de extremos poseídos. Rotación y child_held original intactos. Observaciones parciales, ledger y errores se persisten incluso al fallar; errores secundarios/custodia incompleta impiden PASS. Archivo `delta-v4-v6.patch` contiene diff literal de todos los archivos base modificados/eliminados.

Guardia, supervisor, frozen_custody y verificador se mantienen byte a byte respecto de -04. Los archivos heredados `policy.json`, `argv.json`, `matrix-NOT_RUN.json` y `references/` son contexto inerte de producto, conservado sin cambios, no entradas autorizadas. Sólo `synthetic-entry.json` describe la entrada que se podría autorizar. Sus modos internos tampoco son entradas independientes.

## Entrada futura y límites

cwd: `/workspace/scratch/2ac40fb4b2af/causal-G1-static-C-20261116-06`

`/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12 synthetic_harness.py --manifest-sha256 SHA256_NUEVO_APROBADO_D`

Salida nueva: `/workspace/scratch/2ac40fb4b2af/causal-G1-synthetic-C-20261116-06`, inexistente al congelar. Siete casos NOT_RUN, orden y caps en synthetic_cases.json y synthetic-matrix-NOT_RUN.json; una tanda, 240 s global, reserva 10 s, máximo 4 descendientes. ACK máximo 3 s dentro del presupuesto del caso. Parar ante bloqueo/error/cap/custodia incompleta, sin reintentos. No alteración de máscaras, rlimit, instalaciones o producto.

No se presume corregida la causa histórica -04: UNDETERMINED. V5 demuestra sólo mecanismo bajo órdenes impuestos. Aunque una futura tanda sintética pase, producto exige otro gate. G1 NOT_PASSED; OFF/ON/G2 bloqueados; coverage_complete=false.

# A · Diagnóstico causal posterior a la tanda -09

2026-11-16. **Propuesta para B; sólo lectura estática y este Markdown. No autoriza instrumentación, builds, tests ni correcciones.**

## Base y límites

Se leyeron `causal-G1-execution-report-C-20261116-09/ACTA-C.md`, `paired-results.json`, los JUnit J de `causal-G1-static-C-20261116-09/run/`, el plan A anterior y fuentes de `causal-G1-static-C-20261116-01/{H,Hc,J}`. La búsqueda por nombres y contenido en Markdown locales no encontró un dictamen D de **resultados -09**; los dictámenes anteriores no se sustituyen por una aprobación presumida. B debe incorporar ese dictamen si el coordinador lo obtiene.

Hc=H+A y J tienen, cada uno, 19 FAIL, 1 ABORT y 2 controles PASS. Los 22 pares coinciden en estado y en los campos de mensajes comparados después de normalizar únicamente las raíces de build. Eso reproduce los fallos en **baseline adaptado**, no demuestra preexistencia dinámica en H ni causa común. No atribuir señal al ejecutable por la etiqueta ABORT. #159 no fue evaluado. **G1 NOT_PASSED; OFF/ON/G2 bloqueados; coverage_complete=false.**

A contiene dos adiciones de include de preparación en CMake para source-order y flex-text test core. Los hashes de `style_diff.{h,cpp}`, `style_runtime_core.cpp`, `style_source_compiler.cpp` y `builtin_properties.cpp` coinciden en H/Hc/J. Su identidad reduce el interés de bisecar primero cambios de dibujo, pero no prueba igualdad del cierre ejecutable ni elimina el confusor A.

## Hallazgos estáticos y predicciones, no causas certificadas

Rutas siguientes relativas a `J/native/` del snapshot -01.

### 1. Catálogo y hooks: divergencias de inventario comprobables sin ejecutar

- `tests/test_style_diff_catalog.cpp:10` aborta por cardinalidad antes de imprimir claves ausentes. No convertir su salida en un listado de ausencias observado.
- `src/style_runtime/builtin_properties.cpp:2346–2374` registra `word-break`, `overflow-wrap` y alias `word-wrap`; esas claves no están en `style_diff.h:185–281`. Es una inconsistencia estática concreta, no un censo exhaustivo de todo el registro.
- Hay otra inconsistencia explícita: catálogo declara `align-content` como `stored`, pero `test_style_diff_catalog.cpp` lo clasifica entre no-op y exige 11 no-op/4 alias. Aun arreglando cardinalidad, pueden aparecer fallos posteriores. No expandir números a ciegas.
- `test_transform_origin_dispatch.cpp:108–127` usa allowlists cerradas para css-wide/contextual/explicit. Su log registra 19 fallos de cobertura sin nombres. Obtener el conjunto completo de registros, aliases y callbacks, incluyendo registro programático; una extracción regex es índice de candidatos, no inventario definitivo.

**Paso mínimo:** C prepara tabla estática propiedad → lugar de registro → alias/canonical → callbacks → política de catálogo → assertion. Revisar cada discrepancia con contrato/consumidor y distinguir test obsoleto de falta real de política. Si requiere runtime, proponer un dumper sólo diagnóstico, sin suprimir el abort ni cambiar expectativas originales. B revisa antes de materializarlo.

### 2. No-op e impactos: dos vías independientes que deben separarse

- `style_diff.cpp:168–173` marca `unclassified` para una clave de dependencia desconocida. `:382–386` fuerza máscara conservadora y almacenamiento no equivalente. Las claves ausentes del catálogo son una **hipótesis** para updates repetidos, pero no consta que sean las claves de los casos fallidos.
- `style_runtime_core.cpp:1094–1102` compara evidencia tipográfica después del classifier y añade TEXT_LAYOUT|LAYOUT|PAINT si falta o cambia. Esto puede producir updates con valores visuales iguales. No sabemos qué campo difiere en un no-op real.
- `test_style_semantic_diff.cpp:260` espera 81 para `line-height:2` → `line-height:32px` con font-size16; salió83. Las políticas scalar/sidecar de line-height son81 (`style_diff.h:67,150`), y el OR tipográfico es una explicación candidata precisa del bit2 adicional. No cambiar81 por83 sin resolver el contrato de invalidez de pintura frente a cambio sólo de evidencia.
- `transform-runtime` emite además actual31 contra12/13 en mutaciones; no clasificar todo el grupo como estabilidad no-op. `has-strict-list` también falla impacto de opacity. Son salidas distintas a explicar, aunque una vía pudiera conectarlas.

**Primer experimento propuesto, sólo tras gates:** instrumentación observacional simétrica en copias nuevas de Hc/J para registrar, en la primera assertion fallida elegida, nodo/caso, máscara inmediatamente tras classifier y después de cada OR, `unclassified`, storage_equivalent y nombres/flags de dependencias desconocidas, campo de evidencia tipográfica diferente y valor anterior/candidato. Nada de cambiar predicados, saltar casos o modificar expected. Limitar volumen de log por contador diagnóstico, nunca ejecución del test.

Selección inicial pequeña: `aether.style-semantic-diff`, `aether.transition-property-pipeline`, `aether.transform-runtime` y los dos controles. Un caso simple de no-op, una equivalencia semántica y una mutación distinguen las dos vías con menor coste que repetir los veinte. No extrapolar el resultado a length/gradient/flex/selectores hasta cubrir sus firmas.

Predicciones: si el classifier ya produce impacto por `unclassified`, identificar clave y reconstruir su productor; si devuelve0/81 y el OR tipográfico lo altera, identificar el campo y seguir creación/freeze/publicación/comparación de esa evidencia. Si ninguna ocurre, mantener UNDETERMINED y revisar las demás vías sin parchar por semejanza. Una intervención futura será una sola hipótesis por variante, no catálogo+tipografía a la vez.

### 3. EOF profundo: conflicto concreto entre fixture y límite

`test_stylesheet_eof{,_compiler}.cpp` construye 10000 `@media` anidados. `style_source_compiler.cpp:613–614` rechaza media/supports cuando frames.size()>32. Esto ofrece una ruta estática muy fuerte para los seis fallos, pero los logs congelados sólo muestran rechazo ABI o falta de regla, no ese diagnóstico específico.

Antes de gastar ejecución: localizar la justificación/contrato del límite32 y del requisito10000. No eliminar el límite, reducir profundidad ni cambiar expectativas por conveniencia. Si el límite es deliberado, proponer reconciliación explícita del contrato y conservar cobertura de EOF profundo por una entrada compatible sólo cuando esté justificada, además de rechazo transaccional del exceso. Si se exige aceptar10000, proponer diseño iterativo con presupuesto de recursos, no retirar protección sin reemplazo.

Si falta confirmación de la ruta: propuesta de captura de status+diagnóstico+reglas en las dos APIs usando los seis casos intactos. Casos frontera32/33 pueden complementar una futura campaña, nunca reemplazar10000 ni afirmar PASS retrospectivo.

### 4. Source-order: hook pequeño posiblemente desconectado

`test_stylesheet_source_order_small_source.cpp` sustituye por macro `style_source_size_fits` para imponer128 bytes. La fuente actual `style_source_compiler.cpp` usa `source_charge_bytes` y `budget.source_bytes_limit` y no contiene llamada a `style_source_size_fits`. Eso sugiere que el inyector ya no controla la vía activa. Pero `Fixture::reject` es compartido por rechazo de IDs, handles y tamaño; la salida «controlled add rejection» no identifica cuál falló primero.

El orden estático de `main` es counter_transaction → handle_transaction → source_and_inline_rejection antes de las pruebas reentrantes. Falta identificar cuál invocación de reject emitió el fallo. Si se aprueba instrumentación, emitir etiqueta de llamada, status observado/esperado, límite activo y motivo de diagnóstico sin tocar estado. Si se confirma desconexión, proponer adaptar la inyección privada a la vía de presupuesto real conservando128 y todas las assertions de rollback. No cambiar el producto para volver a un helper obsoleto sólo por el test. Si falla antes en IDs/handles, investigar ese camino de forma independiente.

### 5. #159 separado

Permanece TIMEOUT histórico, no evaluado -09. No abrirlo como parte de esta campaña pequeña. Mantener el protocolo separado del plan A anterior: análisis de fases/avance y eventual observación censurada con gate propio. Ningún resultado de los veinte liquida este pendiente.

## Ruta operacional proporcionada y gates

1. **B revisa este plan**, la clasificación de hallazgos frente a hipótesis y el dictamen D de resultados -09 cuando exista. Sin ello, no abre ejecución.
2. **C prepara sólo expediente estático nuevo**: tabla de contratos y discrepancias; propuesta exacta de instrumentación observacional y mapa de puntos; copies/hashes/target closure/argv/nombres y entorno. No tocar H/Hc/J ni builds -09. Explicitar si algún observador requiere un target adicional. Para atribuir a H sin A se necesita puente aprobado o declarar esa atribución fuera de alcance.
3. **D revisa y congela el expediente** antes de configure/build/tests. Reutilizar la disciplina de supervisión ya validada, no el directorio operativo ni hashes de aprobación anteriores. Preservar controles, comparación del observador y flags/link, manifiestos antes/después, procesos terminados y límites de recursos.
4. **Una tanda pequeña de diagnóstico**, no reparación: propuesta máximo2 configure de120s,2 builds seleccionados de1800s, paralelismo2; tests seriales,120s por test,900s agregado,4800s total con reserva de cierre. Es techo, no obligación de consumirlo. No reintentos ni escalada de tiempo. C precisa número exacto de invocaciones: selección inicial5×2=10; EOF/catalog/source-order requieren un expediente posterior o ampliación explícita aprobada, no adición espontánea.
5. **A/B evalúan predicción frente a observación**. D acepta únicamente causalidad sustentada. Corrección separada por causa y contrato; una variante y test negativo por intervención, controles idénticos, sin tolerancias nuevas ni descarte de assertions. Diferenciar reparación de prueba por contrato confirmado de reparación de implementación.
6. **Validación posterior completa**: una corrección focalizada no certifica G1. Proponer plan explícito para todos los casos afectados, los20 históricos y #159 por su gate, luego G1 completo del árbol final antes de OFF/ON/G2. D decide reuso permitido; nada de trasladar un PASS previo a bytes modificados.

## Entrega esperada de C

Matriz assertion/caso → fuente → observación congelada → hipótesis → predicción → medición propuesta → resultado → alternativas abiertas. Registrar qué se observó y qué quedó inaccesible tras primer fallo. No afirmar que se inspeccionaron assertions posteriores ejecutando sólo el inicio. Aceptación final por evidencia, no por número de tests verdes.

Este trabajo no ejecutó producto, compilación, tests, profiler ni nueva campaña; no modificó código, evidencias congeladas, Git ni remoto. Sólo creó este plan.

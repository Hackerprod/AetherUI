# C · Propuesta v8 de clasificación de concurrencia para D

2026-11-16. **PROPUESTA ÚNICAMENTE. NO MATERIALIZAR NI EJECUTAR SIN GATES D.**

## Base

- -07/evidence.sha256.json: `1fd262495279db7c6b1bc316d3705cc611ae622ec64cc8bc6a011f5e6af938b1`.
- supervisor.py: `f9f12eb750fcec0ee769f935db46cb0be426501f669d9564b43ca500fa7a5e7f`.
- Guardia/custodia/verificador, fuentes y todos los presupuestos permanecerían intactos.
- Acta: `causal-G1-execution-report-C-20261116-07/ACTA-C.md`.

Se observó que el predicado sobre cmdline completo clasifica como campaña un marcador dentro del comando transportado por codex-linux-sandbox. El cmdline original no fue preservado; la explicación del fallo original es inferencia, no reconstrucción probada. La corrección debe mejorar semántica y diagnóstico, no simplemente permitir PID1/codex ni relajar concurrencia.

## Cambio propuesto

Sustituir exclusivamente la decisión de concurrencia del preflight por un clasificador explícito y auditable; ningún cambio en ejecución, tiempos, fuentes, selección, supervisión, test o producto.

```diff
- if comm in campaign_process_names or any(x in cmd for x in campaign_command_markers):
-     campaigns.append(dict(pid=pid,comm=comm))
+ snapshot = read_identity_exe_argv_cwd_and_ancestry_consistently(pid)
+ verdict = classify_execution(snapshot, approved_launch_identity, wrapper_policy)
+ persist_redacted_concurrency_evidence(snapshot, verdict)
+ if verdict in {CAMPAIGN, UNKNOWN}: blockers.append(verdict)
```

La materialización deberá incluir código literal y tabla completa de decisiones, no sólo este pseudodiff.

### Identidad y roles

1. Capturar PID/start/PPID, namespace, exe resuelto/hash, comm, argv NUL separado y cwd cuando pertinente; verificar identidad antes/después. PID desaparecido sólo se admite como EXITED si la desaparición se verifica; PID reutilizado/permiso denegado/lectura incoherente => UNKNOWN y parada. No ignorar excepciones ambiguas.
2. Conservar exclusión exacta de los tres procesos propios identificados. Para padres/ancestros no usar una lista blanca global por nombre, PID1, UID o basename. Capturar cadena real hasta raíz, con start y namespace. Clasificar todos los demás procesos, incluidos hermanos y descendientes de wrappers admitidos.
3. Para ejecutables de campaña (cmake/ctest/make/ninja/compiladores/aether), exigir coincidencia de ejecutable real o nombre de proceso según reglas conservadoras existentes. Detectar intérprete+script en el argumento de programa, incluidas opciones Python soportadas explícitamente. Script en posición ejecutable con supervisor.py/execute.py/synthetic_harness.py/fixtures o binarios aether => CAMPAIGN si no es identidad propia.
4. Si un marcador aparece sólo en argumento de datos de un ejecutable no relacionado, no equivale automáticamente a ejecución de campaña. No obstante, sólo clasificar NOT_CAMPAIGN si hay semántica conocida de ese ejecutable. Shell `-c`, intérpretes `-c`/`-m`, wrappers desconocidos, argumentos ambiguos o programa no resoluble con marcadores => UNKNOWN; no improvisar parsing shell genérico.

### Wrapper de lanzamiento propio

Caso estrecho propuesto: ancestro real del coordinador, ejecutable resuelto `/opt/codex/bin/codex`, hash aprobado de materialización, argv0=codex-linux-sandbox y layout de opciones observado/validado. Un `--` separa opciones del comando transportado. Verificar que ese comando corresponde a la entrada exacta aprobada de esta tanda mediante contrato congelado del lanzamiento, no por contener su ruta. El wrapper se clasifica OWN_LAUNCH_TRANSPORT sólo con identidad/ancestría y contrato válidos; un codex ajeno, otro payload, opciones nuevas o hash distinto => UNKNOWN. No autorizar al wrapper por PID1 ni permitir todos los ancestros.

Para hacer verificable el contrato se propone una entrada futura directa única, sin cat/sha/test concatenados en el mismo shell: comprobaciones de manifiesto/ausencia de salidas en llamada read-only anterior; lanzamiento shell exactamente `exec PYTHON_ABSOLUTO SUPERVISOR_ABSOLUTO --manifest-sha256 HASH_D`, con quoting congelado. El contrato se compara por bytes de la cadena payload del wrapper conocido; no se ejecuta ni evalúa el contenido para verificarlo. La identidad del proceso que resulta tras exec debe coincidir con el coordinador. D revisará que el wrapper real observado soporta ese layout; si no, parar para propuesta, no generalizar.

No se fija aquí el hash definitivo del wrapper futuro: el hash observado en la inspección es `57c94ea520df28beb76955316c5c48f672550fe42c6cff7003badb76e1ee10d8`; se revalidaría estáticamente y D aprobaría su valor antes de uso. No incorporar automáticamente un binario nuevo.

### Evidencia y fail-closed

Guardar antes de decidir: PID/start/PPID/ns/exe/hash, índices de argumentos coincidentes, regla aplicada, motivo y cadena de ancestros, conteos; hash/longitud del payload y comparación exacta, sin guardar payloads privados completos ni secretos de argumentos ajenos. Persistir también los procesos desconocidos y desaparecidos. Error de lectura/persistencia impide producto. Esta evidencia debe existir aunque se produzca CONCURRENT_CAMPAIGN/UNKNOWN. No matar procesos detectados ni cambiar entorno para hacer pasar el preflight.

## Validación requerida antes de otro producto

Primero D revisa propuesta; luego materialización estática separada -08 con diff literal, parser/tabla, fixture sintético y manifiesto. No modificar -07 ni su salida. Guardia/custodia byte a byte; cualquier cambio adicional vuelve a propuesta.

D revisa bytes y abre, si procede, una única tanda sintética nueva con techo 60 s, máximo cuatro descendientes, sin producto, compiladores ni CTest. El fixture invoca la misma función de clasificación, no una réplica. Tabla fija:

- Positivos: ejecutable de campaña, intérprete+script en posición ejecutable; marcador en ruta con opciones soportadas; campaña hermana no excluida por wrapper propio.
- Negativos discriminantes: wrapper propio con ancestry/start/ns/hash/layout/contrato exactos, y argumento de datos de ejecutable conocido que no representa ejecución.
- Fail-closed: wrapper ajeno mismo nombre, hash distinto, layout distinto, payload distinto, PID/start cambiado, permisos/lectura incompleta, shell ambiguo, módulo/opción de intérprete no soportado, escritura de evidencia fallida.
- Integración read-only bajo wrapper real del tool: capturar transporte y ancestry; comprobar contrato válido sin lanzar producto, y variante de contrato inválido como datos de prueba, no como otra campaña.

Las entradas puramente tabulares son snapshots artificiales explícitos, no prueba de ejecución real de esos programas. El test de transporte real verifica sólo integración propia. Una vez sintéticos revisados, preparar otro expediente producto con rutas nuevas, selección/presupuestos originales y nuevo gate D. No reintentar -07 ni reutilizar builds. Ningún PASS sintético autoriza producto automáticamente.

G1 NOT_PASSED. No atribución causal nueva de producto; evidencia -04 sigue UNDETERMINED.

# D · Revisión independiente de la tanda diagnóstica -09

2026-11-16. Dictamen previamente emitido, documentado a petición del coordinador. No altera el expediente ni la evidencia original.

## Dictamen: PASS de evidencia diagnóstica

No constituye PASS de G1 ni autorización para otra ejecución. La revisión fue de sólo lectura: no se ejecutó, importó ni compiló código candidato.

## Integridad verificada

- Manifiesto del informe `causal-G1-execution-report-C-20261116-09/evidence.sha256.json`: SHA256 `e29b1fb56986293509ea63963f41e103093a1ab9dd8ad98b1e92c31344347c91`. Sus 9 entradas coinciden.
- Manifiesto estático -09 aprobado: SHA256 `7125e967be2d1f302a4537e1b7bf79ea33a4b694115ab6a5b6a0809d3e7ebc83`.
- Los 6978 artefactos runtime/build coinciden en SHA256 y tamaño: 1.403.792.318 bytes. Conjunto exacto, sin faltantes ni extras.
- Manifiestos estáticos -01 a -09 intactos: respectivamente 4294, 9, 11, 15, 6, 16, 12, 17 y 13 entradas verificadas.
- Los 1442 archivos vivos coinciden con J congelado. HEAD, rama, status y parche Git coinciden con la custodia documentada; cached diff vacío.
- Preflight, inventario y comparabilidad registran PASS. Los resultados de las 52 invocaciones concuerdan con su resumen; comparabilidad precede a todos los tests.

## Resultados corroborados desde JUnit

| Árbol | PASS | FAIL | ABORT | TIMEOUT | NOT_RUN |
|---|---:|---:|---:|---:|---:|
| Hc = H + A | 2 | 19 | 1 | 0 | 0 |
| J | 2 | 19 | 1 | 0 | 0 |

- Controles aether.smoke y aether.abi-c pasan en ambos.
- 22/22 estados iguales.
- 21/22 pares tienen igualdad exacta de system-out y failure serializado; 22/22 tras normalizar exclusivamente las raíces build-Hc/build-J. La única diferencia corresponde a aether.flex-number-pipeline.
- ABORT de aether.style-diff-catalog está respaldado por `Subprocess aborted`; no demuestra una señal concreta del ejecutable.
- Ningún timeout/cap observado. Ventana de las 44 invocaciones de tests: aproximadamente 11,007 s.
- Outcome previo al cierre registra 537,939 s, no el instante exacto de retorno. Los límites aprobados siguen siendo configure 120 s cada uno, build 1800 s cada uno, test 120 s cada uno, agregado tests 900 s y techo absoluto 4800 s con reserva de cierre. No se autorizan reintentos.

## Cierre y sus límites

Cierre aceptable con la limitación declarada. El rc0 reportado por la herramienta, junto al flujo del supervisor congelado, sustenta haber recibido el ACK exacto `done/identified_work_exited=true/reaping=NOT_OBSERVED_BY_GUARD` y guard rc0. No existe copia persistida independiente del ACK. Por ello debe conservarse el `DIAGNOSTIC_RESULTS_RECORDED_CLOSURE_PENDING` original, sin convertirlo retrospectivamente en un certificado escrito.

Telemetría y limpieza por invocación no presentan errores. Los 52 resultados registran cleanup_verified=true. Snapshot final: opened 2412, retired 2411, live 1, peak 12, error_count 0, evidence_incomplete=false. El handle final corresponde al coordinador vivo antes del cierre y no equivale a trabajo de producto residual. No se atribuye reaping a la guardia. La inspección posterior de procesos está limitada al sandbox observado y no constituye garantía global.

## Atribución permitida

Los 20 no-PASS seleccionados se reproducen en **H+A** y J bajo esta comparación. No se observa diferencia de estado ni de los mensajes comparados atribuible al WIP en esta tanda. Esto no prueba preexistencia en H sin adaptación, ausencia general de regresiones ni causa raíz. Mantener las celdas de atribución `UNDETERMINED`.

La igualdad limitada de textos no implica igualdad binaria, igualdad de XML completo ni de todos los logs. La adaptación A y la única ejecución limitan la inferencia. #159 sigue sin diagnóstico en esta tanda.

## Siguiente paso permitido

Análisis estático de fuentes, assertions y diferencias ya congeladas para formular hipótesis por fallo y una propuesta causal acotada. Cualquier reparación, instrumentación o nueva tanda necesita expediente y gate separados. No borrar builds ni sustituir evidencia. No publicación ni apertura automática de gates.

**G1 NOT_PASSED; OFF/ON/G2 bloqueados; coverage_complete=false.** Los outcomes incompletos anteriores conservan su estado; la causa histórica de la síntesis -04 continúa UNDETERMINED.

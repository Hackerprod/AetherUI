# C · Acta única tanda diagnóstica -09

2026-11-16. **44/44 pruebas observadas; no diferencias de estado Hc/J en esta tanda. No significa G1 PASS.** Entrega para revisión D.

## Ejecución

Verificación read-only separada y una sola llamada exacta, cwd `causal-G1-static-C-20261116-09`:

`exec /opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12 /workspace/scratch/2ac40fb4b2af/causal-G1-static-C-20261116-09/supervisor.py --manifest-sha256 7125e967be2d1f302a4537e1b7bf79ea33a4b694115ab6a5b6a0809d3e7ebc83`

Supervisor retorno0, sin reintentos ni reparaciones. Preflight PASS. Configure/inventarios ambos PASS, gate inventario PASS, builds Hc y J rc0 (263,147 s y 251,140 s), gate comparabilidad PASS antes de todo test. Los 52 argv registran cleanup_verified=true. Sin cap, infraestructura interrumpida o reutilización de builds anteriores.

Ventana observada de 44 invocaciones de tests: 11,007 s entre primer start y último end. Outcome previo a cierre final registra 537,939 s de tanda, dentro de techo4800; no se presenta ese timestamp previo al ACK como hora exacta de retorno.

## Resultado emparejado

| Árbol | PASS | FAIL | ABORT | TIMEOUT | NOT_RUN |
|---|---:|---:|---:|---:|---:|
| Hc = H + adaptación A | 2 | 19 | 1 | 0 | 0 |
| J = WIP congelado | 2 | 19 | 1 | 0 | 0 |

Los dos controles aether.smoke y aether.abi-c pasan en ambos. aether.style-diff-catalog figura ABORT en ambos, con diagnóstico emitido «dependency catalog covers every registered property exactly once». Los otros 19 seleccionados no-PASS fallan en ambos. El nombre ABORT es la clasificación observada de CTest/JUnit; señal exacta del ejecutable continúa UNOBSERVED.

Los 22 pares tienen igual estado. En 21 pares son exactamente iguales el texto JUnit system-out y el elemento failure serializado. El único distinto, aether.flex-number-pipeline, difiere sólo en la ruta de biblioteca cargada (`build-Hc/libaether_core.so.0` frente a `build-J/libaether_core.so.0`). Tras sustituir únicamente esas dos raíces por `<BUILD>`, los 22 pares son iguales en esos campos. Esto **no** afirma igualdad binaria de ejecutables, de XML completo ni de todos los logs. paired-results.json fija la comparación y hashes de texto.

Ejemplos emitidos coincidentes: estabilidad de resolución/impactos en casos numéricos y selectores; rechazo de stylesheet EOF profundo; rechazo controlado en source-order; catálogo de dependencias; semantic-diff con impacto81 esperado frente a83 observado. No se infieren assertions que no llegaron a emitirse ni una causa común sólo porque coincidan mensajes.

## Interpretación causal limitada

Los 20 resultados no-PASS seleccionados se reproducen en el baseline adaptado Hc y en J bajo las condiciones comparables de esta tanda. No aparece una diferencia observada atribuible al WIP en este subconjunto/ejecución. Esto aporta evidencia de reproducción en H+A, **no** prueba que H sin A tenga todos esos fallos, ni que el WIP nunca cambie comportamiento, ni explica la raíz de cada fallo. La adaptación A y la única ejecución limitan atribución; las celdas oficiales permanecen UNDETERMINED. #159 no se ejecutó.

## Cierre y custodia

El archivo original outcome.json permanece DIAGNOSTIC_RESULTS_RECORDED_CLOSURE_PENDING, como prescribe el programa: se guarda antes del último ACK para no hacer IO obligatorio después de salir la guardia. No fue reescrito.

La herramienta observó retorno0 del supervisor. El código congelado sólo retorna normalmente después del ACK exacto `done/identified_work_exited=true/reaping=NOT_OBSERVED_BY_GUARD` y guard rc0. Esa combinación sustenta cierre de protocolo; los bytes del ACK no tienen un artefacto separado, y no se inventa uno. closure-observation.json distingue esta inferencia del dato persistido. Stderr de guardia/watchdog vacíos.

Snapshot final guardia: opened2412, retired2411, live1, peak12, error_count0, evidence_incomplete=false; el handle pendiente corresponde al coordinador aún vivo antes de cierre final, no trabajo de producto pendiente. Reaping no se atribuye a la guardia. Todos los resultados de invocaciones muestran cleanup_verified=true. Inspección posterior sin supervisor/guardia coincidentes visibles, limitada al nuevo sandbox, no garantía global.

Custodia final del supervisor PASS para H/Hc/J, expediente fuente, programas ejecutados, referencias, herramientas/aliases, entradas de comparabilidad y checkout/Git. Verificación independiente posterior confirma expedientes -01 a -09 y 1442 archivos vivos, HEAD/rama/index/parche/status/cached intactos.

6978 archivos runtime/build congelados en runtime-artifacts.sha256.json: 1.403.792.318 bytes. Contiene configuración efectivamente usada, artefactos de build, logs, JUnit y telemetría. Verificación repetida sin cambios. No modificar ni borrar esos builds como «limpieza».

## Gate siguiente

C se detiene para revisión D. No publicación, nueva tanda, variación, reparación ni apertura automática. **G1 NOT_PASSED; OFF/ON/G2 bloqueados; coverage_complete=false.** La selección diagnóstica no sustituye validación completa. Causa histórica de -04 continúa UNDETERMINED; los outcomes incompletos anteriores conservan su estado.

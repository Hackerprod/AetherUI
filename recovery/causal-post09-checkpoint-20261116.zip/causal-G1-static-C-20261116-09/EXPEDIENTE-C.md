# C · Tanda diagnóstica de producto -09, preparación para D

2026-11-16. **STATIC_PREPARATION_ONLY. No ejecutada/importada/compilada. Esperar gate D de manifiesto exacto.**

## Supervisión congelada

Cinco programas copiados byte a byte de -08: supervisor.py, concurrency_preflight.py, guard_deadlines.py, frozen_custody.py y verify_comparability.py. Sin correcciones ni ampliación de reglas. Referencias: sintéticos de supervisión -06 (7/7) y clasificador -08 (37 snapshots+3 comprobaciones read-only). Validación sintética no equivale a producto ni a ausencia global de concurrencia.

Manifiesto -08: `17768def02fdea1823834f909082d2549789a7c6cbb2accf0713be2f56e79ed9`. Informe sintético -08: `d153dbc4386dc45341436bd1716ccc384e5a1aa72e0b6eefe91ae1919e53e37c`. Guardia/custodia siguen sus bytes ya validados. No se incluyen ni se invocan harness sintéticos.

Cambios exclusivamente de configuración: nueva raíz -09 y nuevos destinos de ejecución, referencias de evidencia posterior y estado descriptivo de entrada. Diff literal delta-config-v8-v9.patch. No fuente, selección, adaptación, flags, clasificación o presupuesto modificados.

## Destinos limpios y contrato de lanzamiento

Nueva raíz: `/workspace/scratch/2ac40fb4b2af/causal-G1-static-C-20261116-09/`.

`run/`, `build-Hc/` y `build-J/` bajo -09 son nuevos e inexistentes. Ningún objeto/cache/binario/build/output de -03/-07/-08 se copia, reutiliza o continúa. Referencias anteriores se usan sólo como evidencia/custodia.

Fuentes congeladas H/Hc/J permanecen en -01. H es referencia estática; Hc y J son los árboles de ejecución. Adaptación A inalterada, SHA256 `4f15fd37f28ec395b16938f55d474621e2370b950161ca35108147ab9221dd39`.

Entrada exacta en entry.json. Antes de un futuro lanzamiento autorizado: verificar manifiesto y ausencia de las tres salidas en una llamada read-only separada. Después, cwd -09 y **sólo** este payload, sustituyendo el hash externo autorizado por D:

`exec /opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3.12 /workspace/scratch/2ac40fb4b2af/causal-G1-static-C-20261116-09/supervisor.py --manifest-sha256 {APPROVED_MANIFEST_SHA256}`

No concatenar cat, sha256sum, test, pipes u otros comandos al payload. No añadir alternativas de entrada ni resume/bypass/retry. El clasificador deriva el contrato de entry.json aprobado y hash externo; no de datos del wrapper inspeccionado. Excepción sólo al transporte propio con ancestry/start/ns/exe/hash/layout/contrato exactos. CAMPAIGN/UNKNOWN o evidencia no persistida bloquean; hermanos y demás procesos se inspeccionan. No whitelist PID1/codex.

## Selección, orden y límites sin cambios

22 nombres originales (20 no-PASS históricos, excluido #159, más smoke y abi-c); 18 targets; 44 filas NOT_RUN. Atribución UNDETERMINED y señales/assertions no emitidas UNOBSERVED. Listas completas en policy.json y matrix-NOT_RUN.json.

52 argv fijos: configure Hc → inventario Hc → configure J → inventario J → gate inventario → build Hc → build J → gate comparabilidad → 44 invocaciones de tests. Ambos builds y gate de comparabilidad PASS antes de cualquier test. Builds seriales entre sí, cada uno --parallel 2 --verbose; selección exacta, sin suite ampliada.

Configure 120 s/árbol; build 1800 s/árbol; test 120 s/invocación; agregado 900 s desde primer CTest de fase de pruebas hasta cierre explícito confirmado, incluidos huecos; inventario/comparación 120 s. Techo absoluto 4800 s, trabajo 4770 s, reserva cierre 30 s. Prevalece deadline menor; no se amplía presupuesto para completar filas.

Preflight runtime obligatorio: hashes/manifiestos/herramientas/aliases, arquitectura/locales/entorno, árboles/checkout y Git, destinos inexistentes, recursos (disco≥12 GiB, memoria≥4 GiB), exclusión de concurrencia con evidencia redactada. Lectura estática no sustituye el preflight al lanzar. Cambios de wrapper/tool/hash/layout/entorno ⇒ parada, no adaptación en caliente.

## Parada, cierre y límites interpretativos

Ante error de infraestructura/configure/build/gate, cap, control smoke/abi-c fallido, custodia/cierre inciertos: preservar y detener sin reparación/reintento. FAIL diagnósticos de casos seleccionados se registran conforme a política original, no se convierten automáticamente en fallo de infraestructura.

Custodia final revalida H/Hc/J, manifiestos, configuración ejecutada y checkout/Git. Si la parada impide terminar: INCOMPLETE_CUSTODY. El registro favorable previo a salida conserva CLOSURE_PENDING; sólo retorno supervisor y verificación ACK/rc final/telemetría/evidencia permiten valorar cierre. No presumir limpieza desde una inspección posterior en otro sandbox.

Esta entrega no abre ejecución por sí sola ni reescribe fallos anteriores. G1 NOT_PASSED; OFF/ON/G2 bloqueados; coverage_complete=false; causa histórica -04 UNDETERMINED. La futura tanda sigue siendo diagnóstica, no cierre automático de gates ni atribución causal definitiva.

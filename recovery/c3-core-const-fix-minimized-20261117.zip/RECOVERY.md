# Same-stage core const correction

Source-only incremental recovery: one core source file and its repository-relative patch. Restore after the prior C3 test copy-initialization fix, using the exact before hash in SOURCE_HASHES.json. Apply candidate.patch from repository root, or replace the named file; verify the after hash. No other source change is included.

The impact contribution declaration changes constexpr uint32_t to const uint32_t while preserving its bitwise-OR expression and all subsequent uses. This archive does not claim compilation success, behavioral validation or product acceptance.

Packaging checks cover stable bytes, hashes, exact patch restoration and archive integrity only. No private records, internal paths, environment/session data, logs or binaries are included. This file is not a complete repository; restore the matching prior sources separately and independently validate before use.

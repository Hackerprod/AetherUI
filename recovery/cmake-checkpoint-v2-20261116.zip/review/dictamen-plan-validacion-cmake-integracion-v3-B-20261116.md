# B independiente: PASS del plan de validación CMake v3

2026-11-16. **PASS_PLAN_ONLY** para `plan-validacion-cmake-integracion-v3-A-20261116.md`, SHA256 `0d9ab82a44565b53687e4f1ed533d45387b3b8ae0779bf6fabb5926cddbbc8cc`. No es PASS de build, ejecución, integración o producto; tampoco sustituye G0 de D ni la autorización de coordinación.

## Comprobación independiente

- Checkout observado: `aetherui-drawing-integration-C-20261116-01`, rama `local/drawing-exact-v3`, HEAD `22fba13df2dc7775d4e091dac432c3e4b2960c46`, 61 entradas en status. Los 61 hashes de `drawing-integration-correction-materialized-C-20261116-01/changed-files.sha256.json` coinciden con los archivos actuales.
- `git diff --binary` arroja `f4f9bcec4a60e5034835b3305fc2c00a636f0285d8c89338ca72da862f2a20a2`. Los hashes del plan previo, los dos dictámenes D y `DrawingExample.cmake` coinciden con los fijados por A.
- El binario CMake existe y su SHA256 coincide con `7ea6e681a679e5e635b059765467a9830e142feaea4cd49af01615cf4c11882f`; CTest existe ejecutable. B no ejecutó las herramientas: versión 4.4.5 sigue siendo declaración de coordinación hasta el registro G0 de C.
- Leídos `native/CMakeLists.txt`, `native/cmake/DrawingExample.cmake`, los wrappers contractual/demo y los dictámenes históricos citados. Existen los tres directorios de recetas de G3. Leído también `dictamen-final-operacional-v3-clips-D-20261116.md`.

## Motivos del PASS

1. G1 coincide con las opciones y targets reales: defaults OFF; C++20; renderer privado con selector 0/1, separado de `aether_core`; contratos v1/v3 seleccionados por CTest; helper/count sólo ON y no128-selector en no-MSVC. Los targets pedidos cubren los tests drawing registrados para el host GCC/Clang previsto. Se exige inventario no vacío y evidencia efectiva de compilación/enlace, no sólo rc0.
2. La demo corregida contiene cinco invocaciones, siete outputs primarios y seis referencias distintas, además de retained/missing. El plan distingue la comparación fraccional OFF de la exactitud ON. El checker selecciona explícitamente v1/v2/v3. Ejecutar ON/v1 y ON/v2 aparte conserva sus incompatibilidades sin falsear el éxito de los tests positivos.
3. G2 distingue fallo ON sin example, capacidad efectiva del compilador y prueba limitada del selector. No confunde una variable de caché forzada con detección ni extiende resultados a Windows/MSVC/ARM.
4. G3 bloquea correctamente el uso ciego de recetas históricas: la nueva biblioteca recompila fuentes y no existe autorización de reuso dinámico por similitud. D debe fijar adaptaciones, entradas, referencias, argv e inventario antes de materializar/ejecutar. La correspondencia test12-v3 evita contarlo dos veces.
5. G4 preserva el alcance operacional histórico (éxito/cancelación, transferencia raw, viewport y sequence, límites de tiempo/memoria). Reconoce 233 rutas y 28+28 como campaña pendiente con estos objetos, no como resultados nuevos ya obtenidos.
6. Custodia WIP, salidas nuevas, rc/stdout/stderr, parada y revisión ante fallos, y prohibición de reparación espontánea/publicación/Actions quedan explícitos. Las actas históricas no se reescriben y PASS experimental no equivale a aceptación productiva.

## Puertas que permanecen cerradas

D nuevo debe revisar identidad y alcance G0 antes de que coordinación habilite a C nuevo. G1/G2 no habilitan por sí solos G4: se conserva la revisión G3. Ningún resultado dinámico se certifica aquí; default/OFF/ON/contratos nuevos/regresiones/corpus/operacional continúan NOT_RUN en esta fase. Si configure/build/test falla realmente, aplicar la secuencia de propuesta y revisión del plan, no remediar ni repetir de oficio.

B sólo realizó lecturas locales, consultas Git y comparación de hashes; única escritura este dictamen. No ejecutó CMake/CTest, builds, renderer, tests ni scripts históricos; no modificó el plan ni el checkout; no red, Actions, instalación ni publicación.

# D: revisión independiente de cobertura sidecars

2026-11-16. **PASS_PROPOSAL_ONLY.** Corrección acotada de cobertura de test, no PASS runtime ni autorización automática para ejecutar. No materialicé cambios.

## Evidencia y raíz

Verifiqué por hash los **6347/6347** archivos de `drawing-cmake-validation-C-20261116-04/evidence.sha256.json`, cuyo SHA256 es `89a7534ab9a3c166e356df22d3c1e5938de8835f50953a1fe10bd8341e498640`. Coinciden también los 63/63 hashes vivos de custodia y los 5/5 failure-inputs. El build registrado termina rc2 tras 1165.0 segundos; stderr confirma el static_assert 25 == 19 del classifier. El porcentaje 100 de otro target no altera ese FAIL.

Comparé bytes vivos de test_style_diff_classifier.cpp y style_diff.h con `git show HEAD`: ambos son idénticos a HEAD. El desajuste es de la base, no una regresión introducida por los deltas revisados de dibujo/CMake. Leí el inventario de 25 entradas y las 19 decisiones estáticas existentes: faltan exactamente las seis nombradas por C. El test afirma cubrir todo el inventario; actualizar sólo su número dejaría incumplida esa intención.

## Evaluación técnica

El delta propuesto repara tanto el bloqueo de cardinalidad como la omisión de cobertura explícita: mantiene un guard fijo, añade decisiones independientes y ejercicios dinámicos para las seis entradas. Los valores esperados son constantes del test, no resultados derivados automáticamente de la tabla productiva.

- word_break y overflow_wrap: 81 heredable es coherente con el contrato existente de cambio de layout/text-layout heredado. Sus lectores se usan en layout_engine.
- Metadatos flex: 7 no heredable coincide con la clasificación conservadora de geometría/paint/hit-test; layout_flex consume esos campos. No se pretende demostrar que cada valor modifique siempre los tres dominios.
- background_gradient: 2 no heredable es coherente con evidencia de admisión/pintura, sin modificación de layout ni del flat style.
- Los comparadores concretos comparan cada campo congelado frente al candidato y marcan metadata_changed; los cambios no alteran style_storage_equivalent. La ruta freeze copia los seis campos. Los cinco enteros son int32_t inicializados a 0, y el gradiente comienza unproven; los valores propuestos son compatibles con los tipos.
- Cada una de las seis secuencias hace cinco comparaciones: igualdad inicial, ida, igualdad congelada, vuelta, igualdad recongelada. Son 30 comparaciones nuevas; cada compare conserva el chequeo existente de cero allocations. Las congelaciones quedan fuera de esa ventana, como en el harness actual.

**Límites:** 0↔1 y las dos etiquetas del gradiente prueban detección y transporte, no todos los valores de enums/bitmasks, combinación de campos, parser, render ni corrección universal de las políticas. Fixture::expect tampoco inspecciona inherited_metadata_changed; no se debe ampliar la afirmación a comprobar todos los miembros de StyleDiff. Esto no invalida la reparación solicitada, que mantiene el contrato del harness existente y comprueba own/inherited-value/storage/metadata/unclassified.

## Alcance y A/B

La propuesta sí amplía las assertions del test, pero **no cambia el contrato de producto ni relaja expectativas existentes**. La cardinalidad 19 obsoleta se reemplaza junto con la cobertura que su guard exigía, no simplemente para obtener verde. No se altera ningún expected gráfico, selector, política productiva ni test previo. El plan A contempla detenerse y proponer una corrección revisada tras errores reales, incluido harness; este caso cabe en ese procedimiento.

**No requiero nueva planificación A/B para este delta literal.** Requeriría volver a A/B si se pretendiera modificar máscaras/producto, reducir comprobaciones, desactivar el test, redefinir aceptación o ampliar la campaña. Este PASS no autoriza esas variantes ni sustituye la autorización de coordinación para materializar y la revisión D posterior del delta.

## Gates posteriores

1. Materializar sólo las cuatro operaciones documentadas en test_style_diff_classifier.cpp. Verificar SHA previo `1f569dad8b4b716f511a872354288f959ea59df18c5bc78d66f2c2852729fe4d`, sustituciones únicas y conservación exacta del resto. Esperar 64 caminos, los 63 WIP anteriores inalterados, HEAD/rama/índice intactos. Capturar evidencia y someter delta a D.
2. Mantengo la opción conservadora propuesta: G1 completo en salida -05 nueva o siguiente inexistente, sin reuso dinámico de -04 ni anteriores. El build -04 conserva FAIL; configure/consumer gate no se trasladan como validación del árbol nuevo. No se necesita borrar evidencia ni objetos históricos.
3. Mantener controles prebuild de trece consumidores lookup, soporte OOM exacto y compilación única frozen_style por target z-index. Tras build exitoso, resolución/link z-index y controles ABI/OOM completos antes de CTest. Inventario no vacío con classifier y z-index; CTest default completo, OFF/ON secuenciales. Comprobar salida real del classifier, no sólo que compila.
4. Un fallo nuevo requiere parada/propuesta/revisión. G2 sólo tras G1 completo; G3/G4 cerrados. Sin renders adicionales, red, publicación, Actions, instalación ni otra PC. Coverage y límites históricos no se amplían.

D sólo leyó documentos/código/evidencia, comparó hashes y contenido Git y escribió este dictamen. No modificó código ni ejecutó configure/build/test.

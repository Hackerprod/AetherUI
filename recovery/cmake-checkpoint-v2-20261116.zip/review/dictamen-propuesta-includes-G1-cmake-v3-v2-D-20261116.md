# D: PASS de propuesta includes v2, previo a materialización

2026-11-16. **PASS_PROPOSAL_ONLY** para `propuesta-correccion-includes-G1-cmake-v3-v2-C-20261116.md`, SHA256 `4358b8e353307aa89bd3c1a64a81e2890122e207c4f15448bade3e792fb0606e`, verificado y leído íntegro. No es PASS de implementación, build ni producto.

La v2 resuelve el hallazgo bloqueante de la v1 sin alterar su historia: cinco targets comunes bajo el guard existente AETHERUI_BUILD_TESTS, y cuatro targets exclusivos de Linux bajo CMAKE_SYSTEM_NAME STREQUAL "Linux" anidado en ese mismo guard. Esa conjunción reproduce sus condiciones originales de creación verificadas en CMakeLists. No introduce target_include_directories sobre targets inexistentes en otros sistemas ni usa if(TARGET) para ocultar nombres incorrectos.

La causa, nueve consumidores y evidencia del fallo conservan la verificación independiente del dictamen `dictamen-propuesta-includes-G1-cmake-v3-D-20261116.md`, SHA256 `53780c6523e93a242ab0f5a0b0752a9101558cde85b60afb7a2cc36c098aa235`. Dos fallos dinámicos y siete consumidores potenciales no se confunden. El alcance exacto añade sólo preparation/include como PRIVATE a nueve targets de tests; no global/PUBLIC, producto, ABI, selector, defaults, flags numéricos, fixtures, expected ni retirada de tests.

Custodia actual comprobada nuevamente: git diff --binary SHA256 `f4f9bcec4a60e5034835b3305fc2c00a636f0285d8c89338ca72da862f2a20a2`. Ninguna corrección materializada todavía.

Se permite a coordinación autorizar únicamente el bloque exacto v2 en native/CMakeLists.txt, conservando índice y WIP. C debe entregar acta, diff separado, parche total y manifiesto nuevo de 61 caminos, con sólo CMakeLists cambiado. **D debe revisar ese delta antes de ejecutar.** Este PASS no habilita todavía nuevos configure/build/test.

Tras PASS del delta y paso de coordinación, G1 completo en salida nueva, sin reutilizar objetos parciales; G2 sólo si G1 pasa. Ante nuevo fallo real, detener y revisar propuesta nueva. G3/G4 conservan sus gates. El fallo default anterior sigue documentado, OFF/ON/G2 no ejecutados. Windows/MSVC/ARM continúan NOT_VERIFIED: preservar guards no equivale a probar esas plataformas.

D sólo leyó archivos y Git y escribió este dictamen. No modificación del checkout, ejecución, red, Actions, instalación ni publicación.

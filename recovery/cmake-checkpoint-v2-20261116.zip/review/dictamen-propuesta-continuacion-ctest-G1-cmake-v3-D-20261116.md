# D: continuación diagnóstica de CTest -05

2026-11-16. **PASS_PROPOSAL_ONLY, limitado a completar evidencia pendiente.** No PASS de G1 ni autorización para OFF/ON/G2. Coordinación debe autorizar la ejecución acotada.

## Verificación independiente

Recalculé los **6360/6360** hashes de evidencia -05 sin discrepancias; manifiesto SHA256 `b460e319df2fa26d051a2856ab7b10606e1617635c7aaad61e9917d5b0b1e865`. Los **64/64** hashes vivos de after-ctest-interruption.changed.json coinciden. El inventario JSON contiene 287 tests. Parseé los resultados del stdout: 158 terminados, 142 Passed y 16 fallidos; termina con Start 159 sin resultado. Coincide con la clasificación de C.

El #159 es `aether.adjacent-cache-runtime`; #287 es `aether.flex-reverse-private`. El inventario no declara fixtures setup/cleanup ni dependencias que provoquen repetir #1–158 al seleccionar 159–287. Revisé el código del #159: es un test de runtime/caches con estado en proceso, sin escritura explícita de archivos ni lanzamiento explícito de procesos que exija restauración de fixtures persistentes antes de reiniciarlo. La evidencia registra terminación de la sesión, no una salida propia de CTest; se debe conservar esta distinción. Ausencia en ps aislado no prueba ausencia global.

Build y gate ABI están registrados como rc0. Los objetos/binarios/bibliotecas y comandos de enlace incluidos en el manifiesto siguen coincidiendo. La evidencia estática no sustituye los OOM runtime todavía pendientes.

## Reuso y cambio acotado de protocolo

**Apruebo el reuso exclusivamente de los artefactos -05 idénticos por hash para la misma campaña incompleta.** No hubo cambio de código desde ese build; no procede recompilar para completar evidencia ni trasladar este permiso a otro árbol. No se permite reuso -01 a -04.

La única invocación permitida por esta propuesta es el comando CTest documentado, con selección **159–287 inclusive**, sin repeats, rerun-failed ni selección ampliada. #159 es reinicio de un intento interrumpido, registrado como tal; #160–287 son primeros intentos. Los 16 FAIL y los 142 PASS iniciales no se ejecutan otra vez ni se borran del resultado combinado.

Dejar terminar esa invocación aunque aparezcan FAIL es una **excepción diagnóstica explícita y limitada** al protocolo de parada inmediata, no una apertura del gate: permite conocer los pendientes sin reparar ni repetir fallos. No requiere nueva planificación A/B para esta recopilación delimitada. No se debe presentar como continuación normal hacia aceptación. A/B sí sería pertinente antes de una campaña causal comparativa, cambios de expectativas, nuevos builds o reparación de producto. Una cancelación del usuario o problema de seguridad sigue obligando a detener.

## Condiciones previas y cierre

1. Antes de ejecutar, revalidar custodia, fuentes/referencias/toolchain capturados, inventario completo (nombres, comandos, propiedades y orden), compile_commands, binarios y bibliotecas contra -05. Cualquier divergencia bloquea la ejecución. El inventario tiene skips previstos por código 77; conservar SKIP como tal, nunca convertirlo en PASS.
2. Crear continuation-01 inexistente o siguiente libre. Copiar y hashear primero todo Testing/Temporary histórico y preservar stdout/stderr/manifest originales. CTest cambia sus logs operativos: la copia inmutable debe permitir verificar el primer segmento posteriormente; no exigir que los logs operativos modificables conserven su hash después de ejecutar.
3. Capturar argv, tiempos, stdout/stderr y rc real de la nueva invocación. No configurar, compilar, cambiar timeouts/flags, ejecutar tests por separado ni relanzar #159 por un fallo nuevo. Mantener propiedades y límites existentes. Si la continuación se interrumpe otra vez, registrar cobertura incompleta y devolver a revisión sin retry automático.
4. Capturar desde LastTest.log la salida del classifier y los dos OOM. Conservar los resultados individuales, incluidos FAIL, SKIP y NOT_RUN. No sumar un test interrumpido como ejecución completada ni inferir causa común de mensajes parecidos.
5. Al terminar, detener y remitir a D evidencia nueva y matriz combinada. G1 sigue NOT_PASSED incluso si todos los pendientes pasan. OFF/ON/G2 bloqueados; G3/G4 cerrados. No hay permiso para diagnosticar causalmente mediante ejecuciones adicionales, modificar producto/expected, realizar renders extra, publicar, usar red/Actions, instalar o cambiar de equipo.

D sólo revisó archivos/código, recálculo de hashes e inventarios y escribió este dictamen. No cambió código ni ejecutó build/CTest.

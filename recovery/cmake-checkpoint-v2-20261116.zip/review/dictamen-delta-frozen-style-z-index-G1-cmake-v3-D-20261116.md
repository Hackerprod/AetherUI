# D: revisión independiente del delta frozen_style en z-index

2026-11-16. **PASS_DELTA_ONLY.** La materialización coincide exactamente con la propuesta aprobada. No es PASS de build, tests, G1, integración ni producto.

## Comprobaciones independientes

- Evidencia `drawing-cmake-zindex-correction-C-20261116-01/evidence.sha256.json`, SHA256 `c6e4c78ee71d171435d94c06d27ce53a809b29b2de29c92cf8dedfe5a71f4724`: 15/15 archivos coinciden por recálculo.
- Propuesta SHA256 `de4de621ff9984d1f64839e0bd056495aab2dafa7ec15810e662e8c4d9abbd29` y dictamen de propuesta `9a12dd5dbef5ea29e452c0a044d76ef5bdea8034085bc73d610b419829e3ce0e` coinciden con documentos vivos y captura.
- Extraje los dos bloques CMake de la propuesta; el bloque anterior aparece exactamente una vez. Su sustitución literal reconstruye exactamente el snapshot posterior, idéntico al CMake vivo. Único delta: añadir `src/css/frozen_style.cpp` a la lista de fuentes de `aether_z_index_test`.
- Manifiestos antes/después: mismos 63 caminos; el anterior coincide con la custodia de parada -03. Sólo cambia `native/CMakeLists.txt`. Los 63 hashes posteriores coinciden con el checkout vivo.
- CMake posterior SHA256 `d1dd682815d0d411594399620ec6f06e1bf17ada0399dcb0343ed0255e6fc7f3`; manifiesto posterior `630daca5d59a12a0816b23e5e873a8bce6fb7a64bca4b944eec99f3dc678cacb`.
- HEAD `22fba13df2dc7775d4e091dac432c3e4b2960c46`, rama `local/drawing-exact-v3`, índice `be7b51333cf41b08f39b6a73c21f8a933daa45cece43b42595cc9f7bc3b49361`, cached diff vacío. Status vivo idéntico a captura; parche tracked vivo idéntico a after.patch (`216a0ffac61e54d7785632b13d780e654f1e676882a00c7726d05d7b616136b7`). Evidencia diff-check rc0.

No hay cambios adicionales de tests, fixtures, expected, API, visibilidad ni flags en el delta revisado. Se preserva la composición preexistente del test; no se añade el soporte OOM entero.

## Próximos gates

Gate D de delta satisfecho. Coordinación puede autorizar G1 completo en salida nueva -04 o siguiente inexistente, con default/OFF/ON independientes y secuenciales. Se mantiene íntegra la decisión de invalidación de mi dictamen de propuesta: no reusar objetos, caches, binarios ni resultados dinámicos de -01/-02/-03 para certificar este árbol.

Antes de build: custodia/toolchain/flags, trece consumidores lookup, soporte OOM de tres fuentes y exactamente una compilación de frozen_style.cpp por target z-index en compile_commands. Tras build exitoso y antes de CTest: link de z-index con ese objeto y resolución de transforms en el ejecutable sin importación indefinida correspondiente, lector todavía oculto en core; todos los controles previos ABI/link/NEEDED/operator-new/interposición OOM. No imponer a z-index el contrato de ausencia de duplicación API C de OOM, ajeno a su composición histórica.

Después: inventario CTest no vacío que incluya aether.z-index, CTest default completo y OFF/ON conforme al plan A. Cualquier error real exige parada y propuesta/revisión nueva. G2 sólo después de G1 completo; G3/G4 cerrados. Los FAIL históricos no cambian y no se presume éxito de pruebas aún no ejecutadas. Sin renders extra, publicación, red, Actions, instalaciones ni otra PC. Permanecen los límites históricos y coverage_complete=false.

D sólo leyó y comparó documentos, snapshots, hashes y Git; escribió este dictamen. No implementó, configuró, compiló, probó ni publicó.

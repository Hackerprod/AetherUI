# C: parada G1 -04 por inventario sidecar incompleto en test

2026-11-16. **FAIL_BUILD; STOPPED_FOR_D_REVIEW.**

Tras PASS_DELTA_ONLY de frozen_style/z-index y autorización de coordinación, C inició G1 desde salida nueva `drawing-cmake-validation-C-20261116-04/`, sin objetos, caches, binarios ni resultados dinámicos reutilizados. Default, OFF y ON previstos independientes/secuenciales; sólo default llegó a ejecutarse.

## Ejecución y resultado

G0 recapturó y verificó 63/63 hashes, fuentes/referencias, documentos, herramientas/versiones y custodia. Configure default rc0, consumer gate rc0: trece targets lookup, una unidad lookup por consumidor, soporte OOM exacto de tres fuentes y exactamente una compilación frozen_style.cpp en target z-index. Las adaptaciones del coordinador local de comandos están guardadas en -04, sin modificar scripts históricos ni producto.

Build default `cmake --build .../default --parallel 2 --verbose`: **rc2**, duración **1165.0 s**. Al final aparece:

```
tests/test_style_diff_classifier.cpp:180:56: error: static assertion failed
static_assert(static_cast<size_t>(StyleSidecar::count) == 19);
note: the comparison reduces to ‘(25 == 19)’
```

El progreso de otro target llegó al 100 % mientras make esperaba el job paralelo; ese porcentaje no significa build PASS. El fallo es compilación del test classifier, no linker, assertions runtime ni render. El nuevo z-index sí fue construido según stdout, pero no se ejecutó ni se presenta como validado runtime. El gate ABI/OOM y resolución z-index completo queda NOT_RUN al no pasar el build.

C no reintentó ni corrigió. No CTest, OFF/ON, G2, G3 o G4. No hay procesos build/test asociados activos tras finalizar.

## Diagnóstico de sólo lectura

`StyleSidecar` contiene 25 nombres; el test sólo fija políticas explícitas para 19. Diferencia exacta: word_break, overflow_wrap, flex_wrap_mode, flex_align_content, flex_alignment_unproven y background_gradient. No hay nombres de test ajenos al inventario. El test y style_diff.h no tienen diff respecto de HEAD: desacople preexistente en base. Cambiar únicamente 19 a 25 omitiría la decisión de cobertura que el propio guard exige.

Propuesta razonada nueva: `propuesta-cobertura-sidecars-G1-cmake-v3-C-20261116.md`. Incluye cardinalidad fija 25, seis decisiones de política y 30 comparaciones nuevas con congelación/ida/vuelta/cero allocations. Ningún cambio se materializó; requiere D y autorización de coordinación. No se presenta como fallo causado por dibujo ni como arreglo validado.

## Evidencia y custodia

Salida -04 conserva argv/rc/stdout/stderr de cada comando, inventario estático de consumidores, flags efectivos/compile_commands/link, fuentes/objetos/binarios construidos y captura de procesos. `sidecar-inventory.json` registra los dos conjuntos y su diferencia; `failure-inputs.sha256.json` fija fuentes relevantes.

`drawing-cmake-validation-C-20261116-04/evidence.sha256.json`: **6347 archivos**, SHA256 `89a7534ab9a3c166e356df22d3c1e5938de8835f50953a1fe10bd8341e498640`.

Custodia posterior coincide con G0: HEAD `22fba13df2dc7775d4e091dac432c3e4b2960c46`, rama `local/drawing-exact-v3`, 63 caminos, índice `be7b51333cf41b08f39b6a73c21f8a933daa45cece43b42595cc9f7bc3b49361`, parche tracked `216a0ffac61e54d7785632b13d780e654f1e676882a00c7726d05d7b616136b7`, cached diff vacío, hashes 63/63 intactos. Ningún checkout editado durante G1.

Los cuatro intentos conservan su historia; no se reescribieron actas. Sin red, Actions, publicación, instalaciones ni otra PC. coverage_complete=false; rendimiento/plataformas NOT_VERIFIED, Direct2D NOT_RUN/NOT_VERIFIED y LSan NO GO histórico. PASS parcial de configure/consumer gate no equivale a G1 ni aceptación productiva.

# C: materialización exacta de corrección includes G1 v2

2026-11-16. **MATERIALIZED_AWAITING_D_DELTA. No nueva ejecución.**

Tras PASS_PROPOSAL_ONLY D v2 y autorización de coordinación se insertó exclusivamente el bloque cmake aprobado, después de set_tests_properties(aether.flex-reverse-private PROPERTIES TIMEOUT 120) y dentro del guard AETHERUI_BUILD_TESTS. Cinco targets comunes y cuatro bajo guard Linux; includes PRIVATE.

Salida nueva `drawing-cmake-includes-correction-C-20261116-01/`. Contiene before/after status, parche total y 61 hashes; snapshots CMakeLists; correction-only.patch; diff-check rc0; manifiesto de evidencia.

Custodia antes/después: HEAD/rama, 61 caminos de status, índice e intent-to-add intactos; cached diff vacío. Sólo native/CMakeLists.txt cambia respecto de los 61 hashes históricos; los otros 60 coinciden. Historia y actas anteriores no se tocaron.

- CMakeLists nuevo: `318ef3809ed7c6f29e64c53dbda20ae71eb15cd19c838f42dc89d8a02a5941fe`.
- Delta separado: `66eede93cc89e5cfa8367b585e37da1568c23d753d81b8a0ed4d75c09f0b74be`.
- Parche total nuevo: `20b07f7a12a3b37d6965955bcbd6311e818166b9710d8936619058714d082308`.
- Manifiesto 61: `19675f9213211cdcbc62c7dd20cde417772591d6e58879b2458e53a88809db6f`.
- Evidencia: `4b528f980319f1a768d4ec52bc4740635eb850a1a0d0cca41d1e649acc173cb4`.

Se solicita revisión D del delta antes de configure/build/test. El default fallido permanece como tal. No nuevos builds/tests/renders ni OFF/ON/G2; G3/G4 cerrados. Sin red, Actions, instalación, publicación o segunda PC.

# C nuevo: acta G0 y parada real G1 CMake v3

2026-11-16. **G0 registrado; G1 DEFAULT_BUILD_FAIL; OFF/ON/G2 NOT_RUN.**

## Autorización y custodia

Ejecutor C nuevo tras PASS G0 D y autorización de coordinación. Se siguió el plan A SHA256 `0d9ab82a44565b53687e4f1ed533d45387b3b8ae0779bf6fabb5926cddbbc8cc`.
Salida nueva: `drawing-cmake-validation-C-20261116-01/`; ningún destino previo sobrescrito.

`before.json` y `after-stop.json` coinciden: HEAD `22fba13df2dc7775d4e091dac432c3e4b2960c46`, rama `local/drawing-exact-v3`, 61 entradas/61 hashes conformes, parche `f4f9bcec4a60e5034835b3305fc2c00a636f0285d8c89338ca72da862f2a20a2`, índice `be7b51333cf41b08f39b6a73c21f8a933daa45cece43b42595cc9f7bc3b49361`, cached diff vacío. Intent-to-add preservado.
Se guardaron parche binario/status/manifiestos nativos y referencias, documentos/hashes y herramientas/versiones/hashes. CMake/CTest 4.4.5, GCC/G++ 14.2.0 y Python 3.12.14 verificados por ejecución de --version.

## Ejecución y fallo

`default-configure.json/.stdout/.stderr`: rc0. Debug, tests ON, export compile_commands ON, ambas opciones drawing sin definir (defaults OFF).
`default-build.json/.stdout/.stderr`: rc2, paralelo 2, verbose. No prueba CTest ni render ejecutados.

Ambos errores fatales reportados: `aether/rendering/preparation/paint_snapshot.hpp: No such file or directory`, desde software_renderer.h:4, al compilar layout_engine.cpp de `aether_stylesheet_source_order_runtime_test` y `aether_rule_index_test_core`. El header existe. La cadena es layout_engine.cpp → real_simple_text_policy.h → real_html_blocks.h → real_html_text.h → software_renderer.h → include angular de preparación.

`aether_core` posee el include privado de preparación; los targets que reutilizan fuentes mediante SOURCES no heredan ese include. Flags observados: -g, -std=gnu++20, -ffp-contract=off, sin -DNDEBUG ni selector experimental. El build falló antes de alcanzar la totalidad de targets; no es PASS core ni default.

Se dejó terminar la salida del comando fallido y se detuvo la secuencia automáticamente con `STOP.json`. No se lanzó OFF/ON/G2, inventario CTest, reintento, instalación ni corrección. `g2.py` es sólo una receta preparada, NO ejecutada. G3/G4 siguen cerrados.

## Auditoría estática y evidencias

`include-audit.json` inspecciona recursivamente includes locales de las 1454 entradas y 283 targets de compile_commands, sin compilador/preprocesador y sin evaluar condicionales. Detecta 9 targets con caminos al header de preparación sin directorio: los 8 que compilan layout_engine.cpp y adicionalmente `aether_layout_intrusive_registry_test`, cuyo TU incluye layout_engine.cpp. Es análisis conservador, no resultado de compilación de los otros siete.

`evidence.sha256.json` fija todos los archivos existentes de salida, incluyendo logs, compile_commands, caché, objetos/bibliotecas/binarios parciales y recetas. No se reutilizarán como certificación dinámica de una fuente corregida.

## Límites

No modificación del checkout, historia, fixtures ni actas históricas. Sin red, Actions, segunda PC, commit/push/PR o instalación. G1 no aceptado; G2/G3/G4 NOT_RUN. coverage_complete=false; PERFORMANCE/HOST_ISOLATION/REAL_WORKLOAD/PERF_BUDGET NOT_VERIFIED; Windows/MSVC/ARM NOT_VERIFIED; Direct2D NOT_RUN/NOT_VERIFIED; LSan NO GO histórico.

SHA256 del manifiesto de evidencia: `676531c75e4c55ab85748ae33f6b7d13ae33a2c193bb0c9d5761295c216be480`.
Duración build: 156.31 s.

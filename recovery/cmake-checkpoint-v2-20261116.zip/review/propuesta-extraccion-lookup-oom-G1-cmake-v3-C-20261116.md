# C: propuesta extracción mecánica lookup_box para tests OOM

2026-11-16. **Propuesta revisada, sin materializar ni ejecutar.**

## Contexto y rechazo de alternativa

Se conserva la segunda parada real G1 y su acta SHA256 `5f8492f9801305a5996fa851f5e70abbec5ac906ff8c762fbce0001261f5ca3b`. Se conserva la propuesta de soporte con TUs completos `propuesta-soporte-privado-oom-G1-cmake-v3-C-20261116.md` SHA256 `34464a07d8922b921af72697e079d8769cbe264c668b5e12eb78ab9cb582fcd2`, no aprobada ni materializada. D señaló correctamente que --exclude-libs no impide resolver referencias ABI C del ejecutable contra la copia estática de layout_box.cpp; ocultar exports no basta.

Esta propuesta excluye layout_box.cpp y style_map_version.cpp del soporte test. Extrae sólo lookup_box a un TU privado compartido por core y soporte. No API C, motor, constructor global ni estado nuevo en soporte; funciones de lectura/clasificación auténticas, sin versión simulada del helper. Mantiene tests, fixtures y shared-core/operator-new interposition.

## Delta exacto: tres archivos

### 1. native/src/layout/layout_box.cpp

SHA previo `7570bc0bb822a120d75470779fc3027e491231b12e6c0e439257b788a6b14e62`. Eliminar exclusivamente el texto siguiente (una ocurrencia), conservando namespace, presentation, operación pin y demás contenido byte por byte:

```cpp
ComputedStyleReadView StyleLookup::lookup_box(const aether_layout_box_s& box, BoxStylePolicy policy) const noexcept {
    if (policy == BoxStylePolicy::effective_map && box.element) {
        if (const auto found = lookup_node(box.element)) return *found;
    }
    return box.style.view();
}
```

### 2. Crear native/src/layout/style_lookup_box.cpp

Destino debe ser inexistente. Contenido exacto:

```cpp
#include "layout_types.h"

namespace aether::layout {
ComputedStyleReadView StyleLookup::lookup_box(const aether_layout_box_s& box, BoxStylePolicy policy) const noexcept {
    if (policy == BoxStylePolicy::effective_map && box.element) {
        if (const auto found = lookup_node(box.element)) return *found;
    }
    return box.style.view();
}
} // namespace aether::layout
```

El cuerpo y firma movidos deben ser idénticos byte por byte al original. No cambios a política snapshot/effective_map, noexcept, lookup_node ni box.style.view.

### 3. native/CMakeLists.txt

SHA previo `318ef3809ed7c6f29e64c53dbda20ae71eb15cd19c838f42dc89d8a02a5941fe`. Dos transformaciones exactas:

A. Sustituir las cuatro ocurrencias literales de `src/layout/layout_box.cpp` por `src/layout/layout_box.cpp src/layout/style_lookup_box.cpp`. Esto añade el TU al core y a los tres consumidores con lista explícita: aether_z_index_test, aether_layout_ownership_test y aether_contextual_transitions_test. Los nueve targets adicionales que reutilizan SOURCES reciben automáticamente el nuevo TU del core. Auditoría de compile_commands previo: 13 targets compilan layout_box.cpp, uno core + tres explícitos + nueve reutilizadores. Ningún TU fuente incluye layout_box.cpp directamente según búsqueda completa en tests/src. El nuevo archivo no contiene presentación ni ownership, sólo lookup_box.

B. Insertar tras el bloque includes v2 aprobado, antes del endif final de AETHERUI_BUILD_TESTS, este bloque:

```cmake
    # Private reader support only; OOM/layout operations stay in the shared core.
    if(CMAKE_SYSTEM_NAME STREQUAL "Linux" AND CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
        add_library(aether_hit_oom_private STATIC
            src/layout/style_lookup_box.cpp
            src/css/frozen_style.cpp
            src/rendering/stacking.cpp)
        target_include_directories(aether_hit_oom_private PRIVATE include src)
        target_compile_options(aether_hit_oom_private PRIVATE -Wall -Wextra -pedantic -ffp-contract=off)
        set_target_properties(aether_hit_oom_private PROPERTIES
            CXX_VISIBILITY_PRESET hidden
            VISIBILITY_INLINES_HIDDEN YES)
        foreach(aether_hit_oom_test IN ITEMS
            aether_inline_hanging_oom_test
            aether_inline_units_oom_test)
            target_link_libraries(${aether_hit_oom_test} PRIVATE aether_hit_oom_private)
        endforeach()
    endif()
```

No --exclude-libs: el archivo de soporte no debe definir símbolos ABI C del producto y esto se comprueba antes de tests. frozen_style.cpp contiene lectores privados y stacking.cpp funciones de clasificación/ordenación; no API AETHER_API ni estado global. No se cambia visibilidad del core ni sus exportaciones. El guard limita soporte a Linux GNU/Clang observado; no se añaden flags GNU a otras plataformas ni se proclama resolverlas. La extracción mecánica sí alcanza los consumidores multiplataforma sin cambiar comportamiento.

## Auditoría y custodia exigidas

- Guardar hashes previos de los tres caminos (nuevo archivo inexistente). Mantener 61 archivos WIP originales; sólo CMakeLists cambia entre ellos. layout_box.cpp pasa de limpio a modificado y style_lookup_box.cpp aparece nuevo sin staging: esperado 63 caminos de status. Índice SHA256 debe seguir `be7b51333cf41b08f39b6a73c21f8a933daa45cece43b42595cc9f7bc3b49361`; no git add ni intent-to-add nuevo.
- El diff Git total por sí solo no incluye el nuevo archivo untracked. Entregar además contenido nuevo y parche separado de creación, manifiesto de los 63 caminos y delta exacto respecto del sello corregido. No atribuir completitud al git diff --binary sin esa parte.
- Verificar firma/cuerpo extraídos por comparación textual exacta y que no hay ningún otro cambio de producto. D revisa delta antes de configure/build/test. El parche anterior 20b07f... y las actas se conservan.

## Reanudación y criterios

Tras PASS de propuesta, coordinación autoriza materialización; tras PASS delta y nueva autorización, G1 completo en salida nueva -03 (o siguiente inexistente), sin reuso de objetos. No tocar el primer o segundo intento.

Después de configure, antes de build: inspeccionar compile_commands para confirmar que los 13 targets que compilan layout_box.cpp reciben exactamente una compilación de style_lookup_box.cpp, además del target soporte; verificar archivo soporte de tres fuentes, no core completo. Esto es control de configuración, no ejecución extra de tests.

Después de default build y antes de default CTest: registrar nm/readelf/link.txt y hashes. Deben cumplirse todas estas condiciones:
- Soporte tiene exactamente tres objetos; sólo definiciones privadas previstas y runtime/templates, ninguna definición global fuerte de ABI C `aether_*` ni de operador new/delete, motor, runtime o renderer.
- Los cuatro símbolos originalmente no resueltos quedan resueltos en ambos tests y el DSO conserva sus implementaciones privadas, sin nuevos exports ABI.
- Los símbolos ABI C usados por los tests para operaciones de layout/OOM siguen importados dinámicamente del DSO; NEEDED incluye libaether_core.so.0. No copia estática de aether_layout_layout, aether_layout_result_destroy, clone_snapshot o display_list_build en ejecutables.
- operator new de test sigue definido dinámicamente en ambos ejecutables y disponible para interposición; el soporte no contiene reemplazo alguno.
- Ninguna fuente completa layout_box.cpp ni biblioteca core estática incorporada al test a través del soporte; link.txt sólo incorpora TU test, soporte mínimo, DSO y bibliotecas sistema.

Incumplimiento detiene antes de CTest y vuelve a propuesta/revisión. Si es conforme, inventario no vacío y CTest default original, incluyendo ambos OOM. No renders/tests extra ni instrumentación sin gate. OFF/ON y G2 únicamente después de PASS G1 según plan; G3/G4 permanecen cerrados. Fallos originales permanecen FAIL. Windows/MSVC/ARM NOT_VERIFIED; coverage_complete=false y no aceptación productiva. Sin red, Actions, instalación, publicación o segunda PC.

# A: nueva fase de validación real CMake de integración v3

2026-11-16. **Plan, no ejecución ni aceptación.** A es un agente nuevo. Los C/D anteriores no están disponibles tras reinicio: sus documentos son evidencia histórica, no autorización atribuida a agentes activos. Coordinación debe asignar ejecutor C nuevo y revisor D nuevo explícitamente. Este plan no corrige ni sustituye retrospectivamente sus actas.

## Base y custodia

Raíz común: `/workspace/scratch/2ac40fb4b2af/`; todos los caminos siguientes son relativos a ella.

- Checkout: `aetherui-drawing-integration-C-20261116-01`, rama `local/drawing-exact-v3`, HEAD local verificado `22fba13df2dc7775d4e091dac432c3e4b2960c46`. Conservar sus 61 archivos modificados/agregados y estado del índice. No reset, clean, checkout sobre WIP ni commit/publicación.
- `plan-integracion-local-dibujo-v3-A-20261116.md`: SHA256 `dfcc400753d1a1243d6c03618a6cef306c8130fa49c4653c5063a0e069e2aec0`.
- `dictamen-integracion-local-dibujo-v3-D-20261116.md`: `6c3930fd118d30938da1d4e1ae7a2395cbd0f87a1d7780d5dfdca5903ec0f999`.
- `dictamen-controles-scripts-integracion-v3-D-20261116.md`: `c103853dff664f967443045078c5630063e72e4ebb28d3dad9b3de6e346a65ff`.
- Parche corregido `drawing-integration-correction-materialized-C-20261116-01/integration-corrected.patch`: `f4f9bcec4a60e5034835b3305fc2c00a636f0285d8c89338ca72da862f2a20a2`, igual al SHA256 del `git diff --binary` observado por A hoy.
- `native/cmake/DrawingExample.cmake` dentro del checkout: `2310631b3a5025dc5796d0203bbd8d3160c041598fccb346b069bc9f6b934d6e`.
- CMake disponible según coordinación, versión declarada 4.4.5, ejecutable `tooling-cmake-20261116/install/cmake/data/bin/cmake`: SHA256 leído `7ea6e681a679e5e635b059765467a9830e142feaea4cd49af01615cf4c11882f`. `ctest` existe ejecutable en el mismo directorio. A no ejecutó ninguno.

La corrección de scripts tiene PASS_SCRIPT_CONTROL_ONLY. No repetir simulaciones ni cambiar fixtures. OFF/ON/renderer/corpus/regresiones/operacional siguen NOT_RUN para este build. No reuso dinámico aprobado. El nuevo CMake elimina la ausencia de herramienta, no demuestra que configure o compile.

## Gates y secuencia mínima

**G0, antes de ejecutar:** B revisa dirección; D nuevo revisa identidad del árbol y alcance; coordinación da paso a C nuevo. C registra HEAD/rama/status, parche binario, manifiesto de fuentes y referencias, versión/hash de CMake/CTest, compilador y Python. Revalida los 61 hashes contra la materialización histórica. Usar directorios nuevos fuera del checkout; si el nombre existe, elegir sufijo nuevo, no borrar ni sobrescribir. Un único C ejecuta, D sólo revisa evidencia. No instalar nada más, cambiar equipo o lanzar acciones remotas.

**G1, builds normales:** tres directorios independientes: default/core (ambas opciones sin definir), drawing OFF y drawing ON. Debug, C++20 del proyecto, assertions activas según targets; registrar flags efectivos, no asumir equivalencia con compilación histórica. Plantilla de comandos tras G0, no ejecutada por A:

```sh
ROOT=/workspace/scratch/2ac40fb4b2af
SRC="$ROOT/aetherui-drawing-integration-C-20261116-01/native"
BIN="$ROOT/tooling-cmake-20261116/install/cmake/data/bin"
OUT="$ROOT/drawing-cmake-validation-C-20261116-01" # exigir inexistencia
mkdir "$OUT"
"$BIN/cmake" -S "$SRC" -B "$OUT/default" -DCMAKE_BUILD_TYPE=Debug -DCMAKE_EXPORT_COMPILE_COMMANDS=ON -DAETHERUI_BUILD_TESTS=ON
"$BIN/cmake" --build "$OUT/default" --parallel 2 --verbose
"$BIN/ctest" --test-dir "$OUT/default" --output-on-failure
"$BIN/cmake" -S "$SRC" -B "$OUT/off" -DCMAKE_BUILD_TYPE=Debug -DCMAKE_EXPORT_COMPILE_COMMANDS=ON -DAETHERUI_BUILD_TESTS=ON -DAETHER_BUILD_DRAWING_EXAMPLE=ON -DAETHER_EXPERIMENTAL_IMAGE_EXACT_LATTICE=OFF
"$BIN/cmake" --build "$OUT/off" --parallel 2 --verbose --target aether_drawing_demo aether_drawing_contract_v1 aether_drawing_no128
"$BIN/ctest" --test-dir "$OUT/off" -R '^drawing\.' --output-on-failure
"$BIN/cmake" -S "$SRC" -B "$OUT/on" -DCMAKE_BUILD_TYPE=Debug -DCMAKE_EXPORT_COMPILE_COMMANDS=ON -DAETHERUI_BUILD_TESTS=ON -DAETHER_BUILD_DRAWING_EXAMPLE=ON -DAETHER_EXPERIMENTAL_IMAGE_EXACT_LATTICE=ON
"$BIN/cmake" --build "$OUT/on" --parallel 2 --verbose --target aether_drawing_demo aether_drawing_contract_v1 aether_drawing_contract_v2 aether_drawing_contract_v3 aether_drawing_unit_v3 aether_drawing_count_v3 aether_drawing_no128
"$BIN/ctest" --test-dir "$OUT/on" -R '^drawing\.' --output-on-failure
```

Ejecutar secuencialmente, conservando rc/stdout/stderr de cada comando, inventario CTest y resultados completos; no pegar la plantilla sin control de fallos. Verificar que no hubo cero tests y que el inventario incluye los nombres esperados. Default prueba build normal no alterado; no confundirlo con dibujo instalado. OFF prueba v1 y F con semántica legacy; ON prueba helper/count/v3/F real y no128-selector. F debe comprobar cinco invocaciones, siete outputs primarios, seis referencias completas, retained/missing; PNG sólo visualización secundaria. Objetos/biblioteca/binarios nuevos, compile_commands, link commands y hashes demuestran que se enlazó el renderer integrado y la definición OFF=0/ON=1, no stubs o ejecutables históricos. `aether_core` no recibe selector experimental.

**G2, controles de configuración:** directorios nuevos para ON sin example (fallo requerido), y capacidad no128 simulada mediante compilador con `-U__SIZEOF_INT128__` (GCC/Clang comprobado). Capturar fallo efectivo de la detección ON y configuración OFF disponible. No basta imponer el booleano cache de capacidad. No compilar todo el renderer bajo macro simulada si falla una dependencia del toolchain; registrar el límite. Esto y el target selector no validan Windows/MSVC/ARM. Mantener defaults OFF. Ejecutar ON/v1 y ON/v2 por separado con checker y salidas nuevas: incompatibilidad esperada se registra FAIL contractual, no xfail ni PASS numérico. Diferenciar un mismatch completo de un crash/archivo ausente. No cambiar expected para obtener verde.

**G3, antes de campaña final:** D revisa G1/G2. C presenta sólo la adaptación mínima de las recetas históricas a los objetos integrados (28 C++ + 28 HTML, corpus233 pertinente y operacional). Aún no están empaquetadas en CMake: NO ejecutar scripts históricos a ciegas, pues pueden relanzar compilación/manual o binarios viejos. Puntos de partida existentes: `s1-clips-regresiones-continuacion-C-20261116-01/`, `s1-fraccional-corpus-C-20261116-01/`, `s1-clips-operacional-C-20261116-01/` y dictamen final operacional. Nuevo D fija por hashes fuentes, inputs, expected, argv, lista exacta de 28+28, corpus y adaptación de link antes de materializar y luego antes de ejecutar. No duplicar tests ya cubiertos por G1: documentar correspondencia de test12-v3 y contar una sola vez. Ningún reuso histórico dinámico por similitud de código.

**G4, una campaña final integrada:** correr la lista aprobada 28+28, corpus pertinente (por defecto las 233 rutas, pues toolchain/flags/objetos integrados son nuevos), y exactamente un éxito y una cancelación operacional bajo límites originales: 30s por render, 120s campaña, baseline+256MiB, mismo viewport128×32/sequence2 y expected racional. Preservar supervisor, sondeo, contabilidad y transferencia raw. Sin warmups/retries/renders extra ni benchmark A/A. Si D permite reuso parcial debe señalar identidad exacta y alcance antes de ejecución; no hay tal permiso actualmente.

## Fallos, cierre y límites

Cualquier error real de configure/build/test: conservar evidencia y detener la etapa afectada. C propone corrección mínima en documento nuevo; D revisa propuesta; coordinación autoriza materialización; D revisa delta antes de nuevas pruebas. No reparar espontáneamente CMake, producto, harness, referencias o documentación histórica. Si cambian fuentes/flags/selección, invalidar sólo resultados afectados, con decisión D, sin repetir por ritual.

Cerrar con acta C nueva y dictamen D nuevo: matriz default/OFF/ON/contratos/plataformas, comandos/rc, hashes de inputs/objetos/binarios/outputs y comparación íntegra, evidencia nueva separada de histórica, delta final y custodia antes/después. Documentación de estado puede actualizarse únicamente como corrección propuesta/revisada; no reescribir las actas históricas NOT_RUN. PASS de build, PASS experimental y aceptación de producto son estados distintos.

No main/defaultON, release, commit/push/PR, GitHub Actions, workflows, publicación, red, segunda PC, nueva instalación ni cambios de permisos. V1/V2 incompatibles con ON permanecen explícitos. coverage_complete=false; fuera de dominio, PERFORMANCE/HOST_ISOLATION/REAL_WORKLOAD/PERF_BUDGET NOT_VERIFIED; Windows/MSVC/ARM NOT_VERIFIED; Direct2D NOT_RUN/NOT_VERIFIED; LSan NO GO histórico. A sólo leyó archivos/Git y escribió este plan; no ejecutó build, test, render ni modificó el checkout.

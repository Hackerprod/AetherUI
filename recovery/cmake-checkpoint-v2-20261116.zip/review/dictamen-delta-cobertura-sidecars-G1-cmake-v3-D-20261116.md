# D: revisión del delta materializado de cobertura sidecars

2026-11-16. **PASS_DELTA_ONLY.** Materialización exacta de la propuesta aprobada; no PASS de compilación, ejecución, G1 ni producto.

## Verificación independiente

- Manifiesto `drawing-cmake-sidecars-correction-C-20261116-01/evidence.sha256.json`: SHA256 `f6ef5f56158b297b975bace47294a927a3c348b8b07a660f6949754e6acea1bf`, **15/15 archivos** coinciden por recálculo. También coinciden los hashes documentales de propuesta y dictamen.
- Reconstruí en memoria las cuatro operaciones desde los seis bloques C++ de la propuesta. Todas las anclas/sustituciones tienen una sola ocurrencia. Resultado exactamente igual a test.after.cpp y al archivo vivo. Sólo se cambian cardinalidad, seis CHECK_SIDECAR, la función literal added_sidecars y su llamada en main; no se alteran otras assertions.
- El snapshot previo del test coincide byte a byte con HEAD. Los 63 hashes WIP previos son idénticos a la parada -04 y permanecen sin cambios. El manifiesto posterior tiene exactamente 64 caminos: único nuevo modificado `native/tests/test_style_diff_classifier.cpp`. **64/64 hashes vivos coinciden**.
- Test posterior SHA256 `91de08b27335b4e6266a0bfcfddfead0e1da3fe9a4c6d5811092f186eea5928a`; manifiesto posterior `77a3780af9e71299010271aec631e50f334be607a6562ad3697920855329258c`.
- HEAD `22fba13df2dc7775d4e091dac432c3e4b2960c46`, rama `local/drawing-exact-v3`, índice `be7b51333cf41b08f39b6a73c21f8a933daa45cece43b42595cc9f7bc3b49361`, cached diff vacío. Parche vivo y status coinciden exactamente con las capturas posteriores. Parche tracked SHA256 `40391aa9f6c15926e08c5ec4109f18a3384814a1c19762bded8d4983c1527a08`.

## Alcance y siguiente gate

Gate D de delta satisfecho. Coordinación puede autorizar G1 completo en -05 o siguiente salida inexistente, default/OFF/ON independientes y secuenciales, sin reutilizar objetos/caches/binarios/resultados dinámicos anteriores. No se requiere nueva planificación A/B para este delta exacto.

Mantener controles prebuild de trece consumidores lookup, soporte OOM exacto de tres fuentes y compilación única frozen_style por target z-index. Tras build exitoso, resolución/link z-index y controles completos ABI/link/NEEDED/operator-new/interposición OOM antes de CTest. Inventario no vacío con classifier y z-index, CTest default completo y salida real del classifier; después OFF/ON y sólo entonces G2. Un fallo real exige detener y someter nueva propuesta a revisión.

Las 30 comparaciones añadidas no son resultados ejecutados. Su alcance sigue siendo detección/transporte de seis campos, ida/vuelta/congelación y cero allocations durante compare; no todo el dominio de valores, parser, render ni inherited_metadata_changed. No cambia la aceptación productiva ni los límites históricos. G3/G4 cerrados; sin renders extra, publicación, red, Actions, instalaciones ni otra PC.

D sólo leyó y comparó contenido, hashes y Git y escribió este dictamen. No modificó código ni ejecutó configure/build/test.

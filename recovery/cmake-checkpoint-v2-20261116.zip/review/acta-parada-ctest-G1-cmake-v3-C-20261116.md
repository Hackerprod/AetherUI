# C: build default PASS; CTest interrumpido con 16 fallos

2026-11-16. **G1 NOT_PASSED; INTERRUPTED_WITH_FAILURES.**

## Ejecución -05 y gates cumplidos

Tras PASS D del delta sidecars y autorización explícita se creó `drawing-cmake-validation-C-20261116-05/`, sin reutilizar objetos, caches o binarios. G0 validó 64/64 hashes, HEAD/rama/índice/parche, fuentes/referencias y toolchain. Configure y consumer gate rc0: trece consumidores lookup, soporte OOM exacto y una compilación frozen_style por z-index.

Default build **rc0 en 1160.95 s**. Después, gate completo ABI/OOM + resolución z-index **rc0**. Evidencia nm/readelf/link confirma soportes, importaciones ABI C, NEEDED, operadores new dinámicos, símbolos privados ocultos en core y resolución local de transforms en z-index. Es comprobación estática de prerrequisitos de interposición, no PASS runtime de OOM.

Inventario CTest **287 tests**, incluye z-index (#98), classifier (#225), inline-hanging-oom (#242) e inline-units-oom (#265). Se lanzó el CTest default completo exacto del plan, sin selección reducida ni repeats.

## Fallos y parada

Al revisar el stdout durante CTest se observaron **16 fallos** entre los primeros 158 terminados. C envió Ctrl-C para cumplir parada ante fallo, antes de recibir la indicación posterior de coordinación de dejarlo terminar. La sesión 96082 terminó con **rc130**. No existe rc final de CTest: no se le atribuye rc130 como salida propia ni se inventa `default-ctest.json` exitoso/fallido. No se repitió la suite.

Estado verificable: **142 PASS observados, 16 FAIL observados, test #159 iniciado sin resultado (INTERRUPTED), #160–287 NOT_RUN (128 tests).** z-index #98 PASS; classifier y ambos OOM prioritarios todavía NOT_RUN. No salida real de las 30 comparaciones nuevas, no interposición OOM runtime certificada.

Detalle exhaustivo por test y mensajes completos en `ctest-interruption-summary.json`; lista legible en `observed-failures.md` dentro de -05:

- #20 length-locale; #71 gradient-angle-runtime; #76 flex-number-pipeline: estabilidad/no actualizaciones en resolución repetida.
- #80 transform-origin-dispatch: cobertura exacta hook CSS-wide.
- #120 has-strict-list; #125 forgiving-empty-list; #128 has-pseudo-element; #134 selector-identifier-start-runtime; #137 selector-multiple-ids: resolución repetida no-op incumplida.
- #146–151 stylesheet-eof, variantes ABI/compiler, closed/open/mixed profundas: add stylesheet/deep rule.
- #155 stylesheet-source-order-runtime: controlled add rejection.

Agrupar mensajes no demuestra causa común. **Atribución de todos los fallos: UNDETERMINED**. No hay ejecución pareada de baseline con igual toolchain/flags; identidad de fuentes con HEAD no bastaría para declararlos preexistentes ni exonerar los deltas. No se aplicó ninguna corrección.

## Evidencia, custodia y limitación de procesos

`drawing-cmake-validation-C-20261116-05/evidence.sha256.json`: **6360 archivos**, SHA256 `b460e319df2fa26d051a2856ab7b10606e1617635c7aaad61e9917d5b0b1e865`. Incluye logs, inventario, símbolos/link, compilación, artefactos, datos CTest temporales, clasificación de cada test y terminación de sesión.

Custodia posterior: 64/64 coinciden, HEAD `22fba13df2dc7775d4e091dac432c3e4b2960c46`, rama `local/drawing-exact-v3`, índice `be7b51333cf41b08f39b6a73c21f8a933daa45cece43b42595cc9f7bc3b49361`, parche tracked `40391aa9f6c15926e08c5ec4109f18a3384814a1c19762bded8d4983c1527a08`, cached diff vacío. Sin cambios del checkout durante ejecución.

Observación técnica nueva: `ps` desde otra invocación exec está aislado y no ve necesariamente procesos de otras sesiones. Su ausencia no acredita ausencia global. Para este CTest se usa la terminación confirmada por write_stdin de la propia sesión. Esta limitación aclara las afirmaciones de procesos basadas sólo en ps en actas previas, sin reescribirlas.

OFF/ON/G2 NOT_RUN; G3/G4 cerrados. Propuesta de completar inventario pendiente sin repetir resultados en `propuesta-continuacion-ctest-G1-cmake-v3-C-20261116.md`, requiere D. Sin publicación, Actions, red, instalaciones ni otra PC; límites históricos y coverage_complete=false permanecen.

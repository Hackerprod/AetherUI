# C: segunda parada real G1 CMake v3

2026-11-16. **DEFAULT_BUILD_FAIL_2; CTest/OFF/ON/G2 NOT_RUN.**

Tras PASS D del delta includes v2 y autorización de coordinación, se revalidó G0 contra manifiesto corregido de 61 archivos y se ejecutó G1 desde cero en `drawing-cmake-validation-C-20261116-02`. CMake/CTest 4.4.5, GCC 14.2.0, Python 3.12.14. No reuso de objetos del primer intento.

Configure default rc0; build default rc2 alrededor de 67%. Cada comando tiene argv, rc, inicio/fin, stdout y stderr completos. El include de preparación aparece efectivamente en los nueve targets corregidos. No se afirma PASS global de ese cambio: el build completo vuelve a fallar, ahora por enlace.

## Causa confirmada

`aether_inline_hanging_oom_test` enlaza su TU con `libaether_core.so.0.1.0` y dl. Su helper hit_order_oom_helpers.h invoca layout_children_paint_order, que requiere cuatro símbolos privados: StyleLookup::lookup_box, ComputedStyleReadView::transforms, classify_element_paint(StyleScalars const&) y stable_sort_stack_items. Existen como símbolos locales (t) en el DSO, no exportados dinámicamente. Falta enlace privado del soporte de comprobación; no falta implementación de producto. No se propone hacerlos ABI público.

Auditoría de los 17 TUs que incluyen directamente el helper: dos consumidores enlazan sólo shared core sin soporte privado (inline_hanging_oom y inline_units_oom); los otros quince disponen de fuentes/objetos core privados (catorce via flex_text_test_core y uno con fuentes propias). El segundo aún no falló dinámicamente en esta corrida, por lo que se clasifica riesgo confirmado estáticamente, no fallo ejecutado. Las órdenes completas y hashes constan en helper-consumers-link-audit.json.

La inspección nm de cuatro objetos existentes (no recompilación) constata que layout_box.cpp necesita structure_valid de style_map_version.cpp y aether_layout_result_destroy público. frozen_style.cpp y stacking.cpp no requieren otros símbolos privados fuera de ese grupo. Los símbolos del runtime C++ se resuelven normalmente por toolchain. Esto identifica un cierre de soporte, no demuestra por sí solo enlace correcto ni semántica de interposición.

## Parada y custodia

STOP.json detuvo la secuencia al rc2. No CTest, inventario CTest, OFF/ON, contratos, renderer demo, G2/G3/G4 ni reintentos. `after-stop.json` conserva HEAD/rama, índice, 61/61 archivos corregidos y parche total `20b07f7a12a3b37d6965955bcbd6311e818166b9710d8936619058714d082308`. No cambios adicionales al checkout. G2 permanece condicionado a G1 PASS.

Evidencia nueva independiente de -01: `evidence.sha256.json` fija logs, compilación/enlace, caché, objetos/binarios parciales, auditorías y custodia. Actas previas no se tocaron. Sin red, Actions, otra PC, instalación, commit/push/PR ni publicación.

coverage_complete=false; no aceptación de producto. PERFORMANCE/HOST_ISOLATION/REAL_WORKLOAD/PERF_BUDGET y Windows/MSVC/ARM NOT_VERIFIED; Direct2D NOT_RUN/NOT_VERIFIED; LSan NO GO histórico.

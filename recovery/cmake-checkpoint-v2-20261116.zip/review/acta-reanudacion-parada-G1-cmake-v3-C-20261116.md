# C: reanudación e interrupción nueva de G1 CMake v3

2026-11-16. **FAIL_BUILD; STOPPED_FOR_D_REVIEW.** No PASS G1, integración ni producto.

## Estado recuperado y decisión

C fue reasignado explícitamente para continuar la validación interrumpida. Leyó el plan A, PASS_PLAN_ONLY B, G0 D y los dictámenes de propuesta/delta lookup OOM. En `drawing-cmake-validation-C-20261116-03` encontró configure y consumer gate rc0, build sin registro de terminación `default-build.json`, stdout terminando aproximadamente al 47 % y warnings, sin fallo fatal registrado. No había procesos de compilación/test activos. No se inventa un rc para esa invocación interrumpida.

Antes de continuar verificó 63/63 hashes actuales, manifiesto completo de fuentes/referencias, documentos y herramientas contra la captura de -03; HEAD/rama, índice y parche intactos. Reanudó únicamente el mismo build -03 con idénticos argumentos, sin reconfigure, limpieza ni objetos de los intentos -01/-02. La orden expresa de reanudar se ejecutó como continuación del build interrumpido, no como repetición de un fallo. Se preservaron íntegramente todos los archivos de evidencia preexistentes de la raíz -03, verificados por hashes posteriores.

Toda evidencia nueva está en `drawing-cmake-validation-C-20261116-03/resume-01/`: decisión, procesos antes/después, custodia antes/después, logs, argv/rc/tiempos, símbolos y link. Los objetos del build -03 evolucionaron por compilación, como parte de la continuación. No se modificó el checkout.

## Resultado real

Comando: `tooling-cmake-20261116/install/cmake/data/bin/cmake --build drawing-cmake-validation-C-20261116-03/default --parallel 2 --verbose` (rutas absolutas y cwd exactos en JSON).

`default-build-resumed.json`: **rc 2**, duración aproximada 154.8 s. Nuevo error de enlace en `aether_z_index_test`:

```
undefined reference to `aether::style::ComputedStyleReadView::transforms() const'
```

Dos referencias desde `layout_children_paint_order` en `layout_types.h`, instanciado por `test_z_index.cpp`. `link.txt` contiene las fuentes privadas explícitas del test pero no `frozen_style.cpp`. Inspección de símbolos: objeto del test importa `transforms`; shared core contiene la implementación como símbolo local `t`, no exportada dinámicamente. No falta la implementación de producto: falta el lector privado en este consumidor directo. El build terminó y no quedaron procesos activos asociados.

No se ejecutó ABI gate completo ni CTest porque el build no pasó. Default tests, OFF/ON, G2, G3 y G4 continúan NOT_RUN en esta campaña. Los resultados históricos no se alteran. No se han evaluado aquí otros posibles fallos posteriores del build.

## Custodia y entrega

- HEAD: `22fba13df2dc7775d4e091dac432c3e4b2960c46`; rama `local/drawing-exact-v3`.
- 63 caminos, manifiesto actual coincidente; cached diff vacío.
- Índice: `be7b51333cf41b08f39b6a73c21f8a933daa45cece43b42595cc9f7bc3b49361`.
- Parche tracked: `e9be892505ebd453c5a6867cc9dbc241d33e593afd2e10c07690a34ed5c5387a`.
- `resume-01/evidence.sha256.json`: `b3baf0dd0038d3e3db99f7c57aba78c67657708a430f0b77536689c5984bdb00`.
- Propuesta nueva: `propuesta-frozen-style-z-index-G1-cmake-v3-C-20261116.md`.

Sin correcciones, reintentos, publicación, red, Actions, instalaciones ni segunda PC. G3/G4 cerrados. coverage_complete=false; PERFORMANCE/HOST_ISOLATION/REAL_WORKLOAD/PERF_BUDGET y Windows/MSVC/ARM NOT_VERIFIED; Direct2D NOT_RUN/NOT_VERIFIED; LSan NO GO histórico. La propuesta requiere D, autorización de coordinación, materialización y revisión del delta antes de ejecutar otra vez.

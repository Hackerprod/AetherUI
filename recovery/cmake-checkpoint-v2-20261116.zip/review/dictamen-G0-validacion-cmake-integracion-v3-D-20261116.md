# D nuevo: PASS G0 de identidad, custodia y alcance

2026-11-16. **PASS_G0_REVIEW_ONLY.** Revisión independiente de D nuevo, con asignación separada y contexto limpio. No se asume identidad, autorización ni trabajo de los anteriores C/D. Sus actas se conservan como evidencia histórica, sin reescribirlas.

## Documentos fijados

- Plan A `plan-validacion-cmake-integracion-v3-A-20261116.md`: SHA256 `0d9ab82a44565b53687e4f1ed533d45387b3b8ae0779bf6fabb5926cddbbc8cc`, verificado.
- Dictamen B `dictamen-plan-validacion-cmake-integracion-v3-B-20261116.md`: SHA256 `1e25c1120ccc27a868d8259c8dd6079e32fdeecb10456cbd8c4dda9f06f9f985`, verificado; PASS_PLAN_ONLY no sustituye ejecución.
- Plan histórico de integración `dfcc400753d1a1243d6c03618a6cef306c8130fa49c4653c5063a0e069e2aec0` y dictámenes históricos D `6c3930fd118d30938da1d4e1ae7a2395cbd0f87a1d7780d5dfdca5903ec0f999` y `c103853dff664f967443045078c5630063e72e4ebb28d3dad9b3de6e346a65ff`: hashes verificados. Los dos dictámenes D fueron leídos; el segundo sólo acredita controles de scripts simulados.

## Estado y custodia comprobados por D

Raíz `/workspace/scratch/2ac40fb4b2af/`; checkout `aetherui-drawing-integration-C-20261116-01`.

- HEAD `22fba13df2dc7775d4e091dac432c3e4b2960c46`; rama `local/drawing-exact-v3`.
- `git --no-optional-locks status --porcelain=v1 -uall`: 61 entradas. Su conjunto de caminos coincide exactamente con las 61 claves del manifiesto histórico corregido; 61/61 SHA256 actuales coinciden.
- Manifiesto `drawing-integration-correction-materialized-C-20261116-01/changed-files.sha256.json`: SHA256 `561f693141941736d5b3d25f2a66d97837897276ff4ba04ffbbd0e3122770187`.
- `git diff --binary`: SHA256 `f4f9bcec4a60e5034835b3305fc2c00a636f0285d8c89338ca72da862f2a20a2`, igual al parche corregido. `git diff --check`: rc 0, sin salida. `git diff --cached --binary`: 0 bytes. Se preservan las entradas intent-to-add existentes: no normalizar índice ni inferir ausencia de índice por diff cached vacío.
- Índice `.git/index` observado: SHA256 `be7b51333cf41b08f39b6a73c21f8a933daa45cece43b42595cc9f7bc3b49361`.
- `native/cmake/DrawingExample.cmake`: SHA256 `2310631b3a5025dc5796d0203bbd8d3160c041598fccb346b069bc9f6b934d6e`, incluido en 61/61. Leído íntegro: defaults OFF, guard ON sin example, detección efectiva de unsigned128, renderer privado, tests OFF/ON y selector limitado coherentes con el plan.
- CMake existe ejecutable: SHA256 `7ea6e681a679e5e635b059765467a9830e142feaea4cd49af01615cf4c11882f`. CTest existe ejecutable: SHA256 `d2cd03927dd2477420b2e71212a80401f4f331657198e6b30839b33a581f2da7`. Ambos bajo `tooling-cmake-20261116/install/cmake/data/bin/`. D no los ejecutó. Versión declarada 4.4.5 todavía debe registrarla C, no se certifica por existencia/hash.

## Paso permitido y condiciones previas restantes

Coordinación identificó expresamente al C nuevo como `/root/c_cmake_validacion` y solicitó el paso tras PASS. Esta revisión satisface la parte D de G0 y permite a coordinación habilitar a ese único C para completar su registro G0 y ejecutar G1/G2 exactamente en el alcance del plan. No es un permiso genérico ni aceptación de producto.

Antes del primer configure, C debe registrar nuevamente HEAD/rama/status, índice, parche, manifiesto de fuentes/referencias, los 61 hashes, versiones y hashes de CMake/CTest, compilador y Python. Debe elegir salidas inexistentes fuera del checkout; no borrar ni sobreescribir destinos existentes. Ante divergencia de custodia, detener y consultar antes de ejecutar. D no certifica anticipadamente esa captura todavía pendiente.

G1: default/core, OFF y ON separados, secuenciales, con rc/stdout/stderr, inventario CTest no vacío, fuentes/objetos/flags/enlace efectivos y comparaciones íntegras. Sin reuso de ejecutables históricos ni stubs. G2: negativos de configuración y contratos según plan, distinguiendo mismatch completo de crash o ausencia. No confundir el target no128 con portabilidad del renderer.

Un fallo real detiene la etapa afectada: propuesta C nueva, revisión D, autorización de coordinación, materialización y revisión del delta antes de nuevas pruebas. No reparación ni reintento espontáneo.

G3 sigue cerrado hasta revisión D de G1/G2 y fijación por hashes de adaptación, inputs, expected, argv e inventario exacto antes de materializar y antes de ejecutar. G4 no queda habilitado por este PASS. No se autoriza reuso dinámico histórico, repetición de simulaciones, warmups, benchmark A/A ni renders adicionales.

Sin commit/push/PR, Actions/workflows, publicación, red, instalación adicional, otra PC, cambios de permisos, reset/clean/checkout sobre WIP, main/defaultON o release. No modificar actas históricas ni fixtures/expected para obtener verde.

## Resultado y límites

**PASS G0 de revisión D; ejecución aún pendiente de registro C y paso de coordinación.** Default/OFF/ON, contratos nuevos, regresiones, corpus y operacional continúan NOT_RUN para esta fase. PASS de build, PASS experimental y aceptación de producto son estados diferentes. Se mantienen coverage_complete=false, fuera de dominio y PERFORMANCE/HOST_ISOLATION/REAL_WORKLOAD/PERF_BUDGET NOT_VERIFIED, Windows/MSVC/ARM NOT_VERIFIED, Direct2D NOT_RUN/NOT_VERIFIED y LSan NO GO histórico.

D sólo realizó lecturas locales, consultas Git sin actualización opcional del índice, hashes/comparaciones y escribió este dictamen. No ejecutó CMake/CTest, compilación, renderer, tests de producto ni scripts históricos. No modificó el checkout.

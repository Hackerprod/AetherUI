# C: propuesta soporte privado OOM, segundo fallo G1

2026-11-16. **Sólo propuesta para revisión D; no materializada ni compilada.**

## Evidencia y alcance

Acta `acta-segunda-parada-G1-cmake-v3-C-20261116.md` SHA256 `5f8492f9801305a5996fa851f5e70abbec5ac906ff8c762fbce0001261f5ca3b`. Auditorías y evidencia en `drawing-cmake-validation-C-20261116-02/`. Dos targets afectados por enlace al DSO sin soporte privado: aether_inline_hanging_oom_test (fallo real), aether_inline_units_oom_test (potencial estático). Los otros quince consumidores del helper ya usan fuentes/objetos privados. No tocar helper, expectativas, pruebas ni lógica de producto.

El test declara semántica shared-core/operator-new interposition. Se descarta enlazar un segundo core completo, sustituir el DSO por objetos, exportar las cuatro funciones privadas o añadir directamente layout_box.cpp al ejecutable sin ocultarlo. Esta última opción introduciría aether_layout_clone_snapshot definido por duplicado con visibilidad default y posible interposición.

## Solución propuesta restringida al host soportado

Mantener enlace actual con AetherUI::Core y dl; añadir un archivo estático de soporte mínimo, sólo para estos dos tests en Linux con compilador GNU/Clang. Cuatro fuentes auténticas sin copia ni modificación: layout_box.cpp, frozen_style.cpp, stacking.cpp, style_map_version.cpp. nm de objetos existentes muestra cierre de símbolos privados dentro del grupo; aether_layout_result_destroy sigue resuelto por DSO. No hay motor/layout_engine, renderer ni runtime_core en el soporte.

El archivo incluye incidentalmente el API clone_snapshot porque comparte TU con lookup_box. No basta visibility hidden (AETHER_API fuerza default): `--exclude-libs` para el nombre exacto del archivo impide que sus definiciones sean exportadas dinámicamente/interpongan llamadas del DSO. Se exige comprobarlo antes de CTest. Las llamadas públicas de layout/OOM del test siguen viniendo del DSO; operator new permanece definido por el TU de test y disponible para interposición.

Fuera de Linux GNU/Clang, no crear archivo ni flags GNU; no pretender solucionar ni verificar esas plataformas. Sus condiciones actuales se conservan y permanecen NOT_VERIFIED. Esta limitación es explícita, no se omiten tests.

## Delta exacto propuesto

Sólo native/CMakeLists.txt (hash previo `318ef3809ed7c6f29e64c53dbda20ae71eb15cd19c838f42dc89d8a02a5941fe`). Insertar después del bloque de includes v2 aprobado, todavía dentro de AETHERUI_BUILD_TESTS y antes del endif final de tests:

```cmake
    # Test-only private readers; layout/OOM operations still use the shared core.
    if(CMAKE_SYSTEM_NAME STREQUAL "Linux" AND CMAKE_CXX_COMPILER_ID MATCHES "GNU|Clang")
        add_library(aether_hit_oom_private STATIC
            src/layout/layout_box.cpp
            src/css/frozen_style.cpp
            src/rendering/stacking.cpp
            src/css/style_map_version.cpp)
        target_include_directories(aether_hit_oom_private PRIVATE include src)
        target_compile_definitions(aether_hit_oom_private PRIVATE AETHER_EXPORTS)
        target_compile_options(aether_hit_oom_private PRIVATE -Wall -Wextra -pedantic -ffp-contract=off)
        set_target_properties(aether_hit_oom_private PROPERTIES
            CXX_VISIBILITY_PRESET hidden
            VISIBILITY_INLINES_HIDDEN YES)
        foreach(aether_hit_oom_test IN ITEMS
            aether_inline_hanging_oom_test
            aether_inline_units_oom_test)
            target_link_libraries(${aether_hit_oom_test} PRIVATE aether_hit_oom_private)
            target_link_options(${aether_hit_oom_test} PRIVATE
                "-Wl,--exclude-libs,${CMAKE_STATIC_LIBRARY_PREFIX}aether_hit_oom_private${CMAKE_STATIC_LIBRARY_SUFFIX}")
        endforeach()
    endif()
```

Ningún otro cambio. No global export, install, ABI, selección, fuente/harness, defaults ni fixtures. El nuevo target queda dentro de tests; AETHERUI_BUILD_TESTS=OFF no lo crea. El orden de enlace generado debe revisarse, no asumirse: soporte puede aparecer después del DSO según orden CMake, pero los símbolos públicos requeridos ya existen también entre referencias del TU del test. Si el enlace no resuelve, detener, no ajustar espontáneamente.

## Gates y controles adicionales obligatorios

1. D revisa dirección y exactitud, incluyendo riesgo de duplicación incidental de clone_snapshot y ocultamiento por archivo. Coordinación autoriza únicamente tras PASS.
2. Materialización conserva índice y 61 caminos; sólo CMakeLists cambia respecto de sello anterior. Delta/manifiesto nuevo; revisión D antes de build.
3. G1 completo en salida nueva -03 (o siguiente inexistente), sin reusar objetos. Default configure/build originales.
4. Antes de default CTest, inspección estática nm/readelf de ambos ejecutables y DSO: cuatro funciones privadas resueltas localmente; ninguna definición dinámica de funciones aether_* desde soporte (en particular clone_snapshot); símbolos públicos de layout utilizados por los tests siguen indefinidos dinámicamente y resolubles por DSO; operator new sigue definición dinámica del ejecutable. NEEDED conserva libaether_core.so.0; link.txt contiene DSO y archivo mínimo, no objetos completos del core duplicados. Fallo de estas condiciones detiene antes de CTest y vuelve a revisión. Registrar hashes/órdenes/rc.
5. Sólo entonces inventario y CTest default del plan (incluye ambas pruebas OOM, sin ejecuciones extras); OFF/ON y G2 secuenciales si PASS. Ante cualquier otro fallo real detener y proponer; G3/G4 cerrados.

La inspección de símbolos no equivale por sí sola a demostrar interposición ni semántica: los tests OOM existentes son necesarios, y cualquier necesidad de instrumentación adicional requiere propuesta antes de ejecutarla. No reetiquetar fallos previos; sin red, Actions, segunda PC, publicación ni instalaciones. coverage_complete=false; no aceptación productiva.

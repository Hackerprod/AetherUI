# D: PASS del delta includes G1 v2

2026-11-16. **PASS_DELTA_ONLY**, previo a nuevos builds. Acta C `acta-materializacion-includes-G1-cmake-v3-v2-C-20261116.md`, SHA256 `ffb89ea79eb4978a2919e1b7be40e1d59391e5ac38ec69070dc184ab8dc5a38e`, verificada.

D comparó el bloque literal de la propuesta v2 SHA256 `4358b8e353307aa89bd3c1a64a81e2890122e207c4f15448bade3e792fb0606e` con snapshots antes/después: insertar exactamente ese bloque en el punto aprobado produce byte por byte el snapshot posterior, idéntico al CMakeLists actual. Sólo incluye PRIVATE de cinco targets comunes y cuatro Linux; guards preservados.

En `drawing-cmake-includes-correction-C-20261116-01/`, manifiesto evidencia SHA256 `4b528f980319f1a768d4ec52bc4740635eb850a1a0d0cca41d1e649acc173cb4`: 12/12 hashes coinciden. Manifiesto actual de 61 archivos coincide 61/61 con checkout. Sólo native/CMakeLists.txt difiere del histórico; 60/61 intactos.

- CMakeLists nuevo: `318ef3809ed7c6f29e64c53dbda20ae71eb15cd19c838f42dc89d8a02a5941fe`.
- Delta separado: `66eede93cc89e5cfa8367b585e37da1568c23d753d81b8a0ed4d75c09f0b74be`.
- Parche total: `20b07f7a12a3b37d6965955bcbd6311e818166b9710d8936619058714d082308`, idéntico al git diff --binary actual.
- Manifiesto 61: `19675f9213211cdcbc62c7dd20cde417772591d6e58879b2458e53a88809db6f`.
- Índice actual: `be7b51333cf41b08f39b6a73c21f8a933daa45cece43b42595cc9f7bc3b49361`, intacto. Status actual idéntico al previo, 61 caminos. Capturas before/after mantienen HEAD/rama y cached diff vacío. No reemplazo de historia ni evidencia anterior.

**Gate D del delta satisfecho.** Coordinación puede dar paso a C para repetir G1 completo en salida nueva con el sello corregido, sin objetos parciales anteriores, manteniendo default/core, OFF, ON secuenciales y todos los controles del plan. G2 sólo si G1 pasa. El configure antiguo no acredita configuración corregida; default previo permanece FAIL. Un fallo real nuevo detiene su etapa y vuelve a propuesta/revisión, sin corrección espontánea.

G3/G4 siguen cerrados hasta sus revisiones específicas. No PASS runtime, integración ni producto; no amplía alcance ni verifica otras plataformas. Sin red, Actions, publicación, instalación ni segunda PC.

D sólo leyó/comparó hashes, texto y Git y escribió este dictamen. No ejecutó CMake/CTest, compilación, renderer o tests, ni modificó checkout.

# D: PASS del delta extracción lookup OOM

2026-11-16. **PASS_DELTA_ONLY.** Acta C SHA256 `b8a5bae135b05b915468d51825804c9f1717caf7fe9fbf2657ce4dc5b1d7b26b`, verificado. Propuesta aprobada SHA256 `eaafd00cd4fa1636867f597036d86a9822ced9aa63d533b17629f4c3c121750f`.

## Comprobación independiente

- Evidencia `drawing-cmake-lookup-correction-C-20261116-01/evidence.sha256.json`, SHA256 `969a690da82e43370381f7376550efee39d31162eb0834db0e794e8b9cbddd7a`: 15/15 archivos coinciden.
- Manifiesto `after.changed-files.sha256.json`, SHA256 `11767facf46a032aad8fe238e98efb9a20b021f1462cf5b12fee96ee66c91810`: 63/63 archivos actuales coinciden. Entre 61 previos sólo cambia CMakeLists; los dos caminos adicionales son layout_box.cpp y style_lookup_box.cpp.
- D reconstruyó en memoria el resultado exacto de las tres transformaciones propuestas: eliminar únicamente firma/cuerpo literal de lookup_box del original; nuevo TU exactamente igual al bloque propuesto; cuatro sustituciones de rutas y bloque CMake literal en punto previsto. Los tres resultados coinciden con snapshots posteriores y manifiesto vivo. No cambios adicionales, stubs, API C duplicada, engine ni tests modificados.
- Nuevo style_lookup_box.cpp está entregado como contenido y parche /dev/null separados. El parche Git total es sólo tracked, no se presenta como entrega completa.
- CMakeLists `7748354e5d7dfaf9b24d0a9959932cb836057265177fb7a5a3edf13f08a9d485`; layout_box.cpp `01715d2dddbc44c3516f9c4754b297fc71deed880571e9cbba09972aff641dbf`; nuevo TU `c10798164d74f214f41672384d74d14798e40a6274be54844a6a68d781b9cba9`.
- Parche tracked actual idéntico a after-tracked-only.patch, SHA256 `e9be892505ebd453c5a6867cc9dbc241d33e593afd2e10c07690a34ed5c5387a`. Índice actual intacto `be7b51333cf41b08f39b6a73c21f8a933daa45cece43b42595cc9f7bc3b49361`; custodia captura HEAD/rama anteriores, cached diff vacío, 63 caminos y diff-check rc0.

## Gate de continuación

Gate D del delta satisfecho. Coordinación puede autorizar G1 completo desde salida nueva -03 o siguiente inexistente, sin reuso de objetos. **Antes del build:** verificar las trece asignaciones del nuevo TU y soporte exacto de tres fuentes. **Antes de CTest:** controles completos de símbolos/link/NEEDED/operator-new y ausencia de copias ABI C o engine exigidos en propuesta y dictamen anterior. No reemplazar esos controles por mera presencia de flags hidden. Incumplimiento detiene; cualquier nuevo fallo real requiere propuesta/revisión.

G2 sólo después de G1 completo. G3/G4 continúan cerrados. Este PASS no certifica enlace, interposición OOM, exactitud renderer, portabilidad, integración ni producto. Los dos builds fallidos conservan sus FAIL históricos. Sin ampliación de alcance, Actions, red, publicación, instalación ni otra PC.

D sólo realizó lecturas, reconstrucción textual en memoria, comparación de hashes y Git; escribió este dictamen. No modificó checkout ni ejecutó configure/build/test/renderer.

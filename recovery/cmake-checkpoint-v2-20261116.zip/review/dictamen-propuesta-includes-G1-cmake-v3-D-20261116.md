# D: FAIL de propuesta includes G1; fallo real y custodia confirmados

2026-11-16. **FAIL_PROPOSAL_ONLY** de `propuesta-correccion-includes-G1-cmake-v3-C-20261116.md`, SHA256 `a260a4b3f74ab50d06a2fe1b35fbd409c6383d154ff13827ca6fd8847997be12`, verificado. No materializar ese bloque tal como está.

## Evidencia confirmada

Acta C `acta-parada-G1-cmake-integracion-v3-C-20261116.md`, SHA256 `1c1144b17805d72f9f8734c7b635aafa6ad18304b58cf234332cabfb4586b8a7`, verificado. Manifiesto `drawing-cmake-validation-C-20261116-01/evidence.sha256.json`, SHA256 `676531c75e4c55ab85748ae33f6b7d13ae33a2c193bb0c9d5761295c216be480`: 3338/3338 archivos coinciden. Auditoría include SHA256 `653e910ea06ae9427d08a23cfedc95fd1e803725b49f887b43c9e7d3253453e7`, verificado.

D leyó logs y comandos efectivos: configure rc0, build rc2, dos errores fatales por paint_snapshot.hpp en stylesheet_source_order_runtime y rule_index_test_core. Header existe y sus comandos omiten preparation/include, a diferencia de aether_core. No es ausencia de herramienta ni fallo numérico del renderer. Before y after-stop coinciden; parche actual conserva f4f9bcec4a60e5034835b3305fc2c00a636f0285d8c89338ca72da862f2a20a2 y CMakeLists conserva 5908e8d0aa67f16e4726e67c3e2dcea453cea782dbe2566a279346fd651a95e1.

D verificó ocho targets con layout_engine.cpp en compile_commands y el noveno indirecto: test_layout_intrusive_registry.cpp incluye ../src/layout/layout_engine.cpp. El alcance PRIVATE para consumidores es correcto; siete siguen siendo riesgos estáticos, no fallos dinámicos observados.

## Hallazgo bloqueante

El bloque propuesto al final está condicionado sólo a AETHERUI_BUILD_TESTS, pero cuatro de sus targets se crean exclusivamente cuando CMAKE_SYSTEM_NAME es Linux:

- aether_contextual_geometry_malloc_test: bloque en native/CMakeLists.txt:1407-1422.
- aether_layout_checked_edges_test y aether_layout_checked_edges_atomic_test: bloque 1576-1597.
- aether_contextual_sampler_atomic_test: bloque 1599-1617.

En no-Linux, target_include_directories intentaría modificar targets inexistentes y produciría un error de configuración nuevo. NOT_VERIFIED de otras plataformas no permite introducir una regresión estática evidente. No hace falta ejecutar otra plataforma para identificar el desacoplamiento entre condiciones.

## Corrección mínima de la propuesta

Presentar documento nuevo que preserve las condiciones de existencia de los targets: cinco consumidores comunes bajo AETHERUI_BUILD_TESTS y cuatro adicionales bajo CMAKE_SYSTEM_NAME STREQUAL "Linux", o guarda explícita if(TARGET ...) correctamente delimitada. Se prefiere reflejar la condición Linux original para no ocultar errores de nombres. Mantener exactamente el include PRIVATE, sin modificaciones a producto, ABI, defaults, tests o expected.

D debe revisar esa propuesta nueva antes de materializar; coordinación autoriza y D comprueba delta antes de nuevos builds. Custodia y política de salidas nuevas de C son adecuadas. G1 sigue DEFAULT_BUILD_FAIL; OFF/ON/G2/G3/G4 no ejecutados. Ningún PASS de build o producto.

Sólo lectura local/comparación de hashes y escritura de este dictamen. Sin CMake/CTest, compilación, renderer, tests, instalación, red ni Actions; checkout intacto.

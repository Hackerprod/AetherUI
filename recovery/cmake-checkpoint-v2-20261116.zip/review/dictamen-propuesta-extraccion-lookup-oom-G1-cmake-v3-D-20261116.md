# D: PASS de propuesta extracción mínima lookup OOM

2026-11-16. **PASS_PROPOSAL_ONLY** de `propuesta-extraccion-lookup-oom-G1-cmake-v3-C-20261116.md`, SHA256 `eaafd00cd4fa1636867f597036d86a9822ced9aa63d533b17629f4c3c121750f`, verificado y leído íntegro. No autoriza ejecución antes de revisión del delta y paso de coordinación.

## Fallo y evidencia

Acta segunda parada SHA256 `5f8492f9801305a5996fa851f5e70abbec5ac906ff8c762fbce0001261f5ca3b` verificada. Manifiesto de -02 SHA256 `9091a18c4bee3a019aaf7ac0faec0a319ed8c9f66c731b29fdaa97a4495cc499`: D comprobó 5143/5143 archivos. Logs/link.txt/nm confirman rc2 y referencias a cuatro símbolos privados presentes como locales en DSO, no ausencia de implementaciones. Segundo test OOM es riesgo estático, no fallo dinámico observado.

## Evaluación independiente de diseño

El soporte anterior de TUs completos no era aceptable: --exclude-libs no impide que llamadas ABI C del ejecutable se resuelvan a copias estáticas. Esta propuesta elimina esa vía: excluye layout_box.cpp y style_map_version.cpp del soporte; mueve únicamente firma/cuerpo originales de StyleLookup::lookup_box a un TU privado, con los mismos tipos y namespace. D contrastó el texto propuesto con el original: política effective_map/snapshot, noexcept y retorno permanecen iguales. presentation y operación pin no se trasladan.

D leyó frozen_style.cpp y stacking.cpp: lectores y clasificación/ordenación, sin ABI C de producto ni estado global nuevo. Soporte de tres TUs no duplica el engine, renderer, layout_layout ni ownership. La comprobación sigue usando algoritmos reales, no stubs. Los dos tests mantienen reemplazos operator new/delete y llamadas a layout/paint por shared core; esto es intención estática hasta verificar enlace y CTest, no evidencia runtime anticipada.

D contó cuatro ocurrencias de layout_box.cpp en CMakeLists y trece targets que lo compilan en compile_commands default anterior. Confirmó ausencia de includes directos de layout_box.cpp en src/tests y que style_lookup_box.cpp no existe aún. Añadir la nueva unidad al core y tres listas explícitas cubre los trece consumidores; los de SOURCES la heredan. No se elimina funcionalidad ni se relajan tests. El soporte GNU/Clang queda bajo Linux y AETHERUI_BUILD_TESTS; no introduce flags incompatibles en otras plataformas ni afirma que sus tests estén resueltos.

## Gates obligatorios

Coordinación puede autorizar sólo los tres archivos y transformaciones literales de la propuesta. D debe revisar delta antes de configure/build/test: extracción byte por byte, bloque CMake exacto, 63 caminos, índice intacto, sólo CMakeLists cambiado entre 61 históricos. Nuevo untracked debe tener contenido/parche de creación y hash aparte: git diff no lo incluye.

Tras PASS del delta y autorización: G1 nuevo completo sin reutilizar objetos. Antes de build verificar trece consumidores con una unidad nueva cada uno y soporte de tres fuentes. Antes de CTest son obligatorios todos los controles de símbolos/enlace propuestos: ninguna definición ABI C del producto u operador new/delete en soporte; ninguna copia estática de operaciones layout/ownership/paint en ejecutables; ABI C importada del DSO, NEEDED correcto; operator new de tests dinámicamente disponible; símbolos privados resueltos sin exports nuevos del DSO. La visibilidad hidden por sí sola no sustituye esos controles. Cualquier incumplimiento detiene antes de CTest.

No se presume que esta propuesta cierre todos los defectos de build. Fallo nuevo implica parada/propuesta/revisión. OFF/ON siguen secuenciales dentro de G1, G2 condicionado al G1 completo; G3/G4 cerrados. No PASS de integración o producto ni portabilidad, y se conservan límites históricos.

D sólo inspeccionó archivos, logs, símbolos ya construidos y hashes; escribió este dictamen. Sin compilación/preprocesado, tests, renderer, checkout editado, red, Actions, instalación o publicación.

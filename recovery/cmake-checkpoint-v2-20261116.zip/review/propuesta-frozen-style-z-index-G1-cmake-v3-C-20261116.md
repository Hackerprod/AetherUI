# C: propuesta mínima de lector privado para z-index

2026-11-16. **PROPOSAL_ONLY, no materializada.** Derivada del fallo real documentado en `acta-reanudacion-parada-G1-cmake-v3-C-20261116.md` y evidencia `drawing-cmake-validation-C-20261116-03/resume-01/`.

## Causa observada

`aether_z_index_test` compila directamente `stacking.cpp`, `layout_box.cpp`, `style_lookup_box.cpp` y otros soportes privados; `layout_types.h` llama a `ComputedStyleReadView::transforms()`. Su implementación está en `src/css/frozen_style.cpp`, presente en shared core pero oculta. La lista del test no la compila. El enlace falla rc2, no es un fallo de assertions ni de imagen. No se propone exportar símbolos privados ni modificar shared core.

## Delta exacto propuesto

Único archivo: `aetherui-drawing-integration-C-20261116-01/native/CMakeLists.txt`, SHA256 previo `7748354e5d7dfaf9b24d0a9959932cb836057265177fb7a5a3edf13f08a9d485`.

Sustituir exactamente una ocurrencia del bloque:

```cmake
    add_executable(aether_z_index_test tests/test_z_index.cpp src/rendering/stacking.cpp src/layout/layout_box.cpp src/layout/style_lookup_box.cpp
        src/css/style_freeze.cpp src/css/frozen_c_string.cpp src/css/frozen_node_record.cpp
        src/css/immutable_style_backing.cpp src/css/style_map_version.cpp)
```

por:

```cmake
    add_executable(aether_z_index_test tests/test_z_index.cpp src/rendering/stacking.cpp src/layout/layout_box.cpp src/layout/style_lookup_box.cpp
        src/css/style_freeze.cpp src/css/frozen_c_string.cpp src/css/frozen_node_record.cpp
        src/css/immutable_style_backing.cpp src/css/style_map_version.cpp src/css/frozen_style.cpp)
```

No otros cambios. El TU agregado contiene seis lectores `ComputedStyleReadView`, sin API C, engine, renderer ni reemplazos de allocation. No se enlaza el archivo de soporte OOM entero, que duplicaría fuentes que este test ya compila. Se preserva su composición preexistente, incluido el enlace shared core y sus fuentes de layout; no se afirma que este test tenga la misma arquitectura de interposición exigida para los tests OOM. No se cambia el diseño, asserts, fixtures, expected, selector, flags o visibilidad del producto.

## Gates y continuación propuesta

1. D revisa causa, delta y alcance. Coordinación autoriza materializar sólo la sustitución literal. C captura antes/después y confirma 63 caminos, índice/HEAD/rama intactos, único cambio CMakeLists respecto de la custodia actual. D revisa delta antes de ejecutar.
2. Para evitar asumir reuso por cambio de configuración, se propone G1 completo en una salida nueva inexistente `drawing-cmake-validation-C-20261116-04` (o siguiente libre), sin borrar ni reusar objetos de intentos anteriores. D debe fijar explícitamente la invalidación/reuso que considere procedente; esta propuesta no autoriza un reintento.
3. Antes del build, conservar gate trece consumidores y soporte OOM de tres fuentes, añadiendo comprobación de una sola compilación de frozen_style.cpp en z-index. Tras build, comprobar enlace z-index con ese objeto y resolución local del lector. No exigir ausencia de ABI C duplicada en z-index como si fuese un nuevo contrato: su lista previa ya compila layout_box.cpp; no se añade ninguna copia nueva de ese tipo.
4. Mantener íntegros los controles ABI/interposición OOM previos antes de CTest. Sólo tras build y gates pasar a inventario no vacío y CTest default, y luego OFF/ON secuenciales según plan. G2 únicamente después de G1 completo. Cualquier error real implica nueva parada/propuesta/revisión, nunca reparación espontánea.
5. G3/G4 siguen cerrados. Sin renders o tests extra, red, Actions, publicación, instalación ni otra PC. No se presume que el cambio resuelva todos los defectos que aún pueda descubrir el build.

La custodia anterior y los tres intentos conservan sus estados históricos; ninguna acta se reescribe. Esta propuesta no certifica integración, exactitud ni aceptación productiva.

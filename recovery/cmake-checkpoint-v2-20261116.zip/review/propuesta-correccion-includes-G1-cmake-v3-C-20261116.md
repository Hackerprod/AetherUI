# C: propuesta mínima ante fallo real G1 CMake v3

2026-11-16. **Sólo propuesta. No materializada ni reintentada.** Requiere revisión D, autorización de coordinación y revisión D del delta antes de nuevas pruebas.

## Causa y auditoría

El build default real falla por include privado de preparación ausente al reutilizar fuentes de aether_core. Evidencia y custodia en `acta-parada-G1-cmake-integracion-v3-C-20261116.md` y `drawing-cmake-validation-C-20261116-01/`.

Auditoría léxica de 1454 comandos/283 targets: nueve consumidores potenciales sin el directorio. Los dos fallos están confirmados; siete restantes se identifican estáticamente. La lista se conserva completa en `include-audit.json` (cadenas por TU). `aether_layout_intrusive_registry_test` incluye layout_engine.cpp dentro de su TU, por eso no basta buscar sólo filenames de compile_commands. aether_core ya posee el include; drawing_private también lo declara. No hace falta exponerlo PUBLIC ni cambiar cabeceras o renderer.

## Cambio exacto propuesto

Únicamente `native/CMakeLists.txt`, hash previo `5908e8d0aa67f16e4726e67c3e2dcea453cea782dbe2566a279346fd651a95e1`.
Insertar el siguiente bloque inmediatamente después de `set_tests_properties(aether.flex-reverse-private PROPERTIES TIMEOUT 120)` y antes del `endif()` que cierra AETHERUI_BUILD_TESTS:

```cmake
    # Private source-reuse targets need the preparation headers included by layout.
    foreach(aether_private_layout_target IN ITEMS
        aether_contextual_geometry_malloc_test
        aether_contextual_sampler_atomic_test
        aether_flex_text_test_core
        aether_layout_checked_edges_atomic_test
        aether_layout_checked_edges_test
        aether_layout_immutable_consumers_test
        aether_layout_intrusive_registry_test
        aether_rule_index_test_core
        aether_stylesheet_source_order_runtime_test
    )
        target_include_directories(${aether_private_layout_target} PRIVATE
            "${CMAKE_CURRENT_SOURCE_DIR}/src/rendering/preparation/include")
    endforeach()
```

Sin otros cambios. Includes PRIVATE y sólo en targets nombrados dentro del bloque de tests; no include_directories global, no selector en core, ningún cambio a ABI/export/install, fuentes, flags numéricos, asserts, fixtures/expected o lista de tests. No afecta defaults OFF.

## Custodia, revisión y reanudación propuesta

1. D revisa esta propuesta, sus nueve targets y evidencia. Coordinación autoriza materialización únicamente de ese bloque.
2. C registra estado previo y aplica el delta conservando WIP/índice. Produce diff de corrección separado, manifiesto nuevo de 61 archivos y parche total nuevo sin sustituir el histórico.
3. D revisa delta exacto y nuevos hashes antes de ejecutar. Custodia esperada: los mismos 61 caminos; sólo CMakeLists.txt cambia de hash respecto de la materialización anterior; índice permanece idéntico.
4. Tras PASS y autorización, G1 completo en salidas nuevas `drawing-cmake-validation-C-20261116-02` (o siguiente inexistente), primero default/core, luego OFF, luego ON. No reusar objetos parciales ni borrar -01. La corrección modifica el grafo de includes; no se declara PASS por el configure antiguo. Si aparece otro fallo real, detener nuevamente y proponer sin reparación espontánea.
5. Sólo si G1 pasa, G2 original. G3/G4 continúan cerrados hasta gates originales. Sin cambios de alcance ni aceptación de producto.

No se propone deshabilitar tests ni relajar validación para conseguir verde.

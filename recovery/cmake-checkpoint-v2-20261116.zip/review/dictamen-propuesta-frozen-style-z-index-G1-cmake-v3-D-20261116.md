# D: revisión independiente de lector privado z-index

2026-11-16. **PASS_PROPOSAL_ONLY (PASS de propuesta).** No PASS de delta, build, G1, integración ni producto. La materialización requiere autorización de coordinación y revisión posterior D antes de ejecutar.

## Evidencia y causa verificadas

- Manifiesto `drawing-cmake-validation-C-20261116-03/resume-01/evidence.sha256.json`: SHA256 `b3baf0dd0038d3e3db99f7c57aba78c67657708a430f0b77536689c5984bdb00`; 27/27 archivos coinciden por recálculo independiente.
- Custodia viva: 63/63 hashes de `after-stop.changed.json` coinciden; HEAD `22fba13df2dc7775d4e091dac432c3e4b2960c46`, rama `local/drawing-exact-v3`; parche tracked `e9be892505ebd453c5a6867cc9dbc241d33e593afd2e10c07690a34ed5c5387a`, índice `be7b51333cf41b08f39b6a73c21f8a933daa45cece43b42595cc9f7bc3b49361`, cached diff vacío.
- CMake real conserva el bloque propuesto sin modificar y SHA256 previo `7748354e5d7dfaf9b24d0a9959932cb836057265177fb7a5a3edf13f08a9d485`.
- Registro de build: rc 2, 154.8 s; stderr contiene las dos referencias indefinidas a `ComputedStyleReadView::transforms() const`. El link de z-index carece de frozen_style.cpp. El inventario del core contiene la definición local `t`; no figura entre sus exports. La causa concuerda con código y evidencia, no con un fallo de assertions.

## Solución, alcance y riesgos

Agregar únicamente `src/css/frozen_style.cpp` al final de la lista existente de fuentes de `aether_z_index_test` es una solución mínima coherente: proporciona el lector privado que usa el código de layout compilado directamente en ese test. Leí el TU y su header: los seis métodos delegan a lectores inline de FrozenStylePayload; no incorporan API C, engine, renderer ni sustituciones de allocation. No hace falta exportar símbolos privados del core ni añadir el soporte OOM completo.

La composición híbrida preexistente de z-index (fuentes privadas más shared core) sigue siendo un límite: este cambio no demuestra ausencia de interposición en todo el test ni equivale al contrato OOM. No la presenta como arquitectura nueva ni modifica esa ABI. La doble presencia del lector privado entre ejecutable y DSO no implica por sí sola error de definición múltiple, al estar oculto en el DSO; se debe verificar la resolución del ejecutable construido. Otros fallos de compilación o runtime pueden aparecer después: el PASS sólo valida la corrección propuesta para el error observado.

## Invalidación y gates obligatorios

1. Autorizar sólo la sustitución literal propuesta. Capturar antes/después; mantener 63 caminos, HEAD/rama/índice y todos los demás bytes. D debe revisar el delta materializado. No tocar assertions, fixtures, expected, visibilidad, flags ni otras listas de fuentes.
2. **No reusar objetos, caches, binarios ni resultados dinámicos de -01/-02/-03 para certificar el árbol nuevo.** Ejecutar G1 completo en `drawing-cmake-validation-C-20261116-04` si no existe, o siguiente libre, con default/OFF/ON independientes y secuenciales conforme al plan A. El configure/consumer gate previo describe sólo el árbol anterior y se recalcula; el build -03 conserva FAIL. No hay CTest exitoso de esta campaña que deba conservarse como PASS. Documentos, fuentes y evidencia histórica sí se conservan como referencias inmutables.
3. Antes del build: recapturar custodia/toolchain/flags; verificar trece consumidores del TU lookup y soporte OOM exacto de tres fuentes. En compile_commands de z-index exigir exactamente una compilación de frozen_style.cpp para ese target, no una sola global (core lo compila legítimamente también).
4. Tras build exitoso: comprobar link con exactamente ese objeto, definición de transforms en el ejecutable y ausencia de importación indefinida correspondiente; mantener oculto el lector en core. Retener todos los controles anteriores ABI/link/NEEDED/operator-new e interposición OOM. No extender su requisito de ausencia de API C duplicada a la arquitectura histórica de z-index.
5. Sólo después pasar a inventario CTest no vacío, incluyendo aether.z-index, y CTest default completo; luego OFF/ON según plan. Registrar argv/rc/stdout/stderr, comandos de compilación/enlace, hashes y resultados íntegros. Un error real detiene y exige propuesta/revisión nueva, sin reparación espontánea ni reintento automático.
6. G2 sólo tras G1 completo. G3/G4 cerrados. Sin renders extra, red, Actions, instalaciones, publicación ni otra PC. Permanecen coverage_complete=false y los límites de plataformas, rendimiento y LSan históricos.

D sólo leyó documentos/código/evidencia, recalculó hashes y consultó Git; escribió este dictamen. No implementó, configuró, compiló, probó ni publicó.

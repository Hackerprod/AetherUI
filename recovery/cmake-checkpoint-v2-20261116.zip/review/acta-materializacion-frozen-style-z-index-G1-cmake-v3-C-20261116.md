# C: materialización mínima frozen_style en z-index

2026-11-16. **MATERIALIZED_AWAITING_D_DELTA. Sin configure/build/test.**

Tras PASS_PROPOSAL_ONLY D y autorización explícita de coordinación, se aplicó únicamente la sustitución literal de la propuesta `propuesta-frozen-style-z-index-G1-cmake-v3-C-20261116.md`: añadir `src/css/frozen_style.cpp` al final de las fuentes de `aether_z_index_test` en `native/CMakeLists.txt`. Se extrajeron ambos bloques de la propuesta, se comprobó una única ocurrencia y se sustituyó una vez. No se cambió ningún otro byte del checkout.

Evidencia nueva: `drawing-cmake-zindex-correction-C-20261116-01/`. Contiene snapshots CMake antes/después, delta unificado, parches tracked, manifiestos de 63 archivos, status/custodia antes/después, hashes de propuesta/dictamen y diff-check rc0. Todos los archivos previos se conservaron.

## Custodia

- Antes 63/63 hashes coinciden con la parada de -03; después sólo cambia `native/CMakeLists.txt`.
- Status antes/después idéntico: 63 caminos. HEAD `22fba13df2dc7775d4e091dac432c3e4b2960c46`, rama `local/drawing-exact-v3` e índice `be7b51333cf41b08f39b6a73c21f8a933daa45cece43b42595cc9f7bc3b49361` intactos. Cached diff vacío.
- CMakeLists posterior: `d1dd682815d0d411594399620ec6f06e1bf17ada0399dcb0343ed0255e6fc7f3`.
- Manifiesto posterior 63: `630daca5d59a12a0816b23e5e873a8bce6fb7a64bca4b944eec99f3dc678cacb`.
- Parche tracked posterior: `216a0ffac61e54d7785632b13d780e654f1e676882a00c7726d05d7b616136b7`.
- Manifiesto de evidencia: `c6e4c78ee71d171435d94c06d27ce53a809b29b2de29c92cf8dedfe5a71f4724`.

## Estado y siguiente gate

Espero revisión D del delta antes de ejecutar. Conforme al dictamen, una continuación posterior autorizada debe usar salida nueva -04 o siguiente inexistente, G1 completo sin reuso de objetos/caches/binarios/resultados de -01/-02/-03. Permanecen obligatorios los gates de consumidores/soporte OOM, única compilación de frozen_style en target z-index, resolución/link y ABI/OOM previos a CTest.

G1 histórico sigue FAIL; no nuevos tests, OFF/ON ni G2. G3/G4 cerrados. No publicación, Actions, red, instalación ni otra PC. No aceptación de integración/producto ni ampliación de los límites históricos.

# C: materialización extracción mecánica lookup OOM

2026-11-16. **MATERIALIZED_AWAITING_D_DELTA. Sin nueva ejecución.**

Tras PASS D de propuesta y autorización de coordinación se aplicaron exclusivamente tres archivos: CMakeLists.txt, layout_box.cpp y nuevo style_lookup_box.cpp. Extracción firma/cuerpo idéntica; lookup_box eliminado del TU original y añadido al nuevo TU en namespace idéntico. CMake reemplaza cuatro rutas de layout_box.cpp para añadir el nuevo TU y agrega literalmente soporte de tres fuentes para los dos tests OOM, bajo guard Linux GNU/Clang.

Salida `drawing-cmake-lookup-correction-C-20261116-01/`: snapshots antes/después, tres deltas separados incluido parche /dev/null de creación, tracked patch total, manifiesto 63 archivos, status y custodia. El git diff tracked NO incluye el nuevo untracked; el parche de creación y contenido separados son parte obligatoria de la entrega.

Índice/HEAD/rama intactos, cached diff vacío. 63 caminos: 61 anteriores más layout_box modificado y style_lookup_box nuevo. Entre los 61 anteriores sólo CMakeLists cambió. diff --check rc0. Ninguna modificación de tests/fixtures/expected ni reescritura de actas.

- native/CMakeLists.txt: `7748354e5d7dfaf9b24d0a9959932cb836057265177fb7a5a3edf13f08a9d485`.
- native/src/layout/layout_box.cpp: `01715d2dddbc44c3516f9c4754b297fc71deed880571e9cbba09972aff641dbf`.
- native/src/layout/style_lookup_box.cpp: `c10798164d74f214f41672384d74d14798e40a6274be54844a6a68d781b9cba9`.
- Manifiesto 63: `11767facf46a032aad8fe238e98efb9a20b021f1462cf5b12fee96ee66c91810`.
- Evidencia: `969a690da82e43370381f7376550efee39d31162eb0834db0e794e8b9cbddd7a`.

Espero revisión D del delta antes de configure/build/test. Controles consumidores antes de build y ABI/OOM antes CTest siguen pendientes. G1 anterior FAIL; OFF/ON/G2/G3/G4 NOT_RUN. Sin red, Actions, segunda PC, instalaciones ni publicación.

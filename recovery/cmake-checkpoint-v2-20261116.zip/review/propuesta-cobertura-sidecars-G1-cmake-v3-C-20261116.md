# C: propuesta de completar cobertura explícita de seis sidecars

2026-11-16. **PROPOSAL_ONLY. Sin modificar código ni assertions.**

## Causa y por qué no basta 19 → 25

G1 -04 falla al compilar `native/tests/test_style_diff_classifier.cpp:180`: el inventario StyleSidecar tiene 25 entradas y el test fija 19. Ambos archivos están limpios respecto de HEAD; este desacople es preexistente en el árbol base, no un delta de dibujo. La comparación nominal de los inventarios muestra seis entradas sin CHECK_SIDECAR ni mutaciones específicas en ese test: `word_break`, `overflow_wrap`, `flex_wrap_mode`, `flex_align_content`, `flex_alignment_unproven`, `background_gradient`. No sobra ninguna entrada del test.

Cambiar sólo el número ocultaría el aviso de cobertura incompleta. Propongo conservar un número fijo e independiente, agregar las seis decisiones estáticas explícitas y sus comparaciones dinámicas exactas, incluida ida/vuelta con congelación. No derivar el expected de StyleSidecarPolicy ni del inventario productivo. No eliminar el guard ni deshabilitar tests. Requiere revisión independiente de D porque amplía la cobertura de un test y modifica su cardinalidad esperada; no está materializado.

## Alcance exacto

Único archivo: `native/tests/test_style_diff_classifier.cpp`; SHA256 previo `1f569dad8b4b716f511a872354288f959ea59df18c5bc78d66f2c2852729fe4d`.

### 1. Cardinalidad fija

Sustituir una vez:
```cpp
static_assert(static_cast<size_t>(StyleSidecar::count) == 19);
```
por:
```cpp
static_assert(static_cast<size_t>(StyleSidecar::count) == 25);
```

### 2. Seis decisiones estáticas independientes

Insertar inmediatamente después de la única línea `CHECK_SIDECAR(writing_mode, value, 7, true)`:
```cpp
CHECK_SIDECAR(word_break, value, 81, true)
CHECK_SIDECAR(overflow_wrap, value, 81, true)
CHECK_SIDECAR(flex_wrap_mode, value, 7, false)
CHECK_SIDECAR(flex_align_content, value, 7, false)
CHECK_SIDECAR(flex_alignment_unproven, value, 7, false)
CHECK_SIDECAR(background_gradient, value, 2, false)
```

Fundamento de la expectativa a validar por D: word-break/overflow-wrap cambian layout de texto heredable (81 = layout 1 + text-layout 16 + inherited 64), sin cambiar el almacenamiento del flat style. Los tres metadatos privados de flex alteran geometría/hit-test/paint (7 = 1+2+4), no herencia. La evidencia privada de gradiente afecta admisión/pintado (2), no layout ni herencia. En todos esos cambios metadata_changed debe ser true y style_storage_equivalent true, pues muta el sidecar, no el flat style. Esto concuerda con los comparadores existentes pero los tests usarán constantes literales, no leerán la política para calcular el resultado esperado.

### 3. Cobertura dinámica nueva, sin tocar pruebas existentes

Insertar este bloque entre `#undef CHECK_SIDECAR` y `void sidecars() {`:
```cpp
void added_sidecars() {
    auto check_integer = [](int32_t measure_state_s::*member, uint32_t mask, bool inherit) {
        Fixture f;
        f.expect(0,0,true,false);
        const auto original = f.measures.*member;
        f.measures.*member = original + 1;
        f.expect(mask,inherit?mask:0,true,true);
        f.freeze();
        f.expect(0,0,true,false);
        f.measures.*member = original;
        f.expect(mask,inherit?mask:0,true,true);
        f.freeze();
        f.expect(0,0,true,false);
    };
    check_integer(&measure_state_s::word_break,81,true);
    check_integer(&measure_state_s::overflow_wrap,81,true);
    check_integer(&measure_state_s::flex_wrap_mode,7,false);
    check_integer(&measure_state_s::flex_align_content,7,false);
    check_integer(&measure_state_s::flex_alignment_unproven,7,false);
    Fixture f;
    f.expect(0,0,true,false);
    f.measures.background_gradient = aether::css::GradientEvidence::explicit_srgb_cardinal_angle;
    f.expect(2,0,true,true);
    f.freeze();
    f.expect(0,0,true,false);
    f.measures.background_gradient = aether::css::GradientEvidence::unproven;
    f.expect(2,0,true,true);
    f.freeze();
    f.expect(0,0,true,false);
}
```

Los cinco campos enteros son int32_t con default 0, comprobado en measure_state.h; el gradiente tiene las dos etiquetas indicadas, default unproven. Cada Fixture es independiente; la ida, congelación, igualdad, vuelta y recongelación verifican también transporte al estado congelado, no sólo el comparador contra ceros. Cada expect mantiene el chequeo de cero allocations de Fixture::compare. Se agregan 30 comparaciones exactas, no renders ni una campaña extra.

En la línea única de main, sustituir sólo la secuencia literal:
```cpp
scalars();payloads();sidecars();
```
por:
```cpp
scalars();payloads();sidecars();added_sidecars();
```

Conservar todos los demás bytes. No tocar CMake, producto, flags, fixtures/expected gráficos, scripts ni tests previos. El test pasaría de limpio a modificado: 64 caminos esperados, índice intacto, 63 archivos WIP previos sin cambios.

## Validación y reanudación pendientes

D debe validar semántica de máscaras/herencia, cobertura y delta antes de autorizar ejecución. Si considera que el contrato excede una reparación de cobertura, devolver a A para decisión, no aprobar sólo el nuevo número.

Después de PASS de propuesta, autorización de coordinación, materialización y PASS D de delta, propongo G1 completo en nueva salida -05 o siguiente inexistente, sin reuso dinámico de -04. D fija la invalidación/reuso; C no lo decide por similitud. Conservar controles de trece consumidores/soporte OOM y frozen_style en z-index; resolución z-index y todos los gates ABI/OOM antes de CTest. Inventario debe incluir classifier y z-index, CTest default completo, OFF/ON secuenciales y G2 sólo tras G1. Cualquier fallo detiene otra vez.

No se presume que esta propuesta cierre los posibles fallos siguientes. G3/G4 cerrados; sin publicación, Actions, red, nuevas instalaciones ni otra PC. FAIL -04 queda preservado, no aceptación de integración/producto.

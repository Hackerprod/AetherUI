# C: materialización literal de cobertura sidecars

2026-11-16. **MATERIALIZED_AWAITING_D_DELTA. Sin build/test.**

Leído PASS_PROPOSAL_ONLY de D y recibida autorización explícita de coordinación. Se materializaron exclusivamente las cuatro operaciones aprobadas en `native/tests/test_style_diff_classifier.cpp`: cardinalidad fija 25, seis CHECK_SIDECAR literales, función added_sidecars literal y llamada desde main. Los bloques se extrajeron de la propuesta; sustituciones y anclas verificadas como únicas. No se modificaron otros bytes del test ni ningún otro archivo del checkout.

Salida nueva `drawing-cmake-sidecars-correction-C-20261116-01/`: snapshots del test, delta, parches tracked antes/después, status/custodia/manifiestos, hashes de documentos y diff-check rc0.

## Custodia y hashes

- 63/63 WIP anteriores coinciden antes y después. Única nueva ruta modificada: test_style_diff_classifier.cpp, antes limpio y SHA `1f569dad8b4b716f511a872354288f959ea59df18c5bc78d66f2c2852729fe4d`.
- Después 64 caminos, sólo ese agregado frente al status previo. HEAD `22fba13df2dc7775d4e091dac432c3e4b2960c46`, rama `local/drawing-exact-v3` e índice `be7b51333cf41b08f39b6a73c21f8a933daa45cece43b42595cc9f7bc3b49361` intactos. Cached diff vacío.
- Test posterior: `91de08b27335b4e6266a0bfcfddfead0e1da3fe9a4c6d5811092f186eea5928a`.
- Manifiesto 64 posterior: `77a3780af9e71299010271aec631e50f334be607a6562ad3697920855329258c`.
- Parche tracked posterior: `40391aa9f6c15926e08c5ec4109f18a3384814a1c19762bded8d4983c1527a08`.
- Manifiesto evidencia: `f6ef5f56158b297b975bace47294a927a3c348b8b07a660f6949754e6acea1bf`.

## Gate pendiente

No configure, build, preprocesado, tests ni renders. Espero D del delta. G1 posterior sólo tras PASS y autorización, en salida nueva -05 o siguiente libre, sin reuso dinámico anterior. Se mantienen consumidores, soporte OOM, z-index y ABI/OOM antes de CTest. La salida real de classifier aún no existe; las 30 comparaciones son código agregado, no resultados.

Se conservan límites de D: cobertura 0↔1 y dos etiquetas de gradiente, no combinaciones ni todo el dominio; Fixture::expect no comprueba inherited_metadata_changed. No se amplía la aceptación. G1 histórico FAIL, OFF/ON/G2 NOT_RUN, G3/G4 cerrados. Sin publicación, red, Actions, instalaciones ni otra PC.

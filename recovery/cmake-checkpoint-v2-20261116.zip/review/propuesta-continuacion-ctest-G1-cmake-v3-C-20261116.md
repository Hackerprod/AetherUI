# C: propuesta de completar evidencia CTest pendiente, sin reparación

2026-11-16. **PROPOSAL_ONLY, no ejecutada.**

G1 -05 tiene default build y prerrequisitos estáticos PASS, pero CTest parcial registra 16 FAIL, 142 PASS, #159 INTERRUPTED y 128 NOT_RUN. No hay base para corregir producto o relajar tests, ni atribuir fallos a base/delta. La indicación de coordinación de dejar terminar llegó después de la interrupción; no justifica repetir la suite completa.

## Propuesta acotada para D

1. **Sin cambio de código, tests, fixtures, expected, toolchain ni flags.** D revisa la evidencia -05 y fija por sus hashes el árbol de 64 archivos, compile_commands, binarios, bibliotecas, inventario y pruebas pendientes. Si existe divergencia, detener antes de ejecutar.
2. Reutilización solicitada explícitamente: sólo los artefactos -05 del mismo árbol inalterado para continuar esa campaña incompleta, no objetos históricos -01 a -04 ni certificación de un árbol nuevo. Es una solicitud a D, no autorización que C asume.
3. Ejecutar una única continuación de default CTest con índices **159–287 inclusive** del inventario ya fijado, en el mismo build -05, con logs/argv/rc nuevos en subdirectorio inexistente `continuation-01`. No volver a correr #1–158. Comando propuesto:

```sh
/workspace/scratch/2ac40fb4b2af/tooling-cmake-20261116/install/cmake/data/bin/ctest --test-dir /workspace/scratch/2ac40fb4b2af/drawing-cmake-validation-C-20261116-05/default -I 159,287,1 --output-on-failure
```

#159 se inició sin resultado y necesita reinicio explícito; documentarlo como única reejecución parcial por interrupción, no retry de un resultado fallido ni warmup. #160–287 son primeros intentos. El número y nombres deben coincidir exactamente con default-inventory.stdout y ctest-interruption-summary.json; si cambia el inventario, detener. Preservar primero los archivos CTest temporales históricos en copia nueva con hashes, pues CTest actualiza sus propios logs. No borrar ni sobrescribir la evidencia congelada del primer segmento.

4. Esta continuación **no busca verde ni abre gates**. Se solicita dejar completar una sola invocación diagnóstica de los pendientes, incluso si reporta otros FAIL, para registrar el inventario restante, siguiendo la dirección de coordinación. C no repetirá fallos ni continuará a OFF/ON/G2 por un resultado parcial. Si D considera que esto necesita ajuste A/B del protocolo de parada, debe devolverlo antes de ejecutar, no omitir ese gate.
5. Resultado combinado conserva los 16 FAIL iniciales, lista resultados pendientes por separado y jamás convierte la ejecución parcial inicial en PASS. Capturar salida real de classifier desde LastTest.log sin lanzarlo aparte, y resultados de los dos OOM aún pendientes. Los gates estáticos previos siguen siendo prerrequisitos, no evidencia runtime.
6. Tras recopilar, parar para revisión D. Diagnóstico causal posterior de los grupos de fallos requeriría un plan acotado nuevo (posiblemente A/B), con baseline comparativo y límites aprobados antes de nuevos builds/tests. No se propone aquí modificar producto, cambiar expectativas ni declarar preexistencia a partir de un test limpio.

G1 permanece fallido/incompleto y OFF/ON/G2 bloqueados. G3/G4 cerrados, sin renders extra, benchmark, red, publicación, Actions, instalaciones ni otra PC. No se amplía aceptación ni cobertura declarada.

from pathlib import Path
import sys
O=Path(__file__).resolve().parent
sys.argv=['execute.py','definitions']
exec(compile((O/'execute.py').read_text(),str(O/'execute.py'),'exec'))
run('default-abi-gate',[sys.executable,O/'abi_gate.py'])
run('default-inventory',[BIN/'ctest','--test-dir',O/'default','--show-only=json-v1'])
inventory=json.loads((O/'default-inventory.stdout').read_text());names={t['name'] for t in inventory['tests']}
assert names and 'aether.z-index' in names
assert any('style-diff-classifier' in n for n in names),sorted(names)
run('default-ctest',[BIN/'ctest','--test-dir',O/'default','--output-on-failure'])
custody('after-default-tests')

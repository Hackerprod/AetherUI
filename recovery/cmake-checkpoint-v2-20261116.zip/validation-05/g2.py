import sys
sys.argv=['execute.py','definitions']
exec((__import__('pathlib').Path(__file__).parent/'execute.py').read_text())
base=[BIN/'cmake','-S',S/'native','-DCMAKE_BUILD_TYPE=Debug','-DAETHERUI_BUILD_TESTS=ON']
for name,flags,expected,needle in [
 ('on-without-example',['-DAETHER_EXPERIMENTAL_IMAGE_EXACT_LATTICE=ON'],'nonzero','Exact lattice requires AETHER_BUILD_DRAWING_EXAMPLE=ON'),
 ('no128-on',['-DAETHER_BUILD_DRAWING_EXAMPLE=ON','-DAETHER_EXPERIMENTAL_IMAGE_EXACT_LATTICE=ON','-DCMAKE_CXX_FLAGS=-U__SIZEOF_INT128__'],'nonzero','Experimental exact image v3 requires native unsigned128'),
 ('no128-off',['-DAETHER_BUILD_DRAWING_EXAMPLE=ON','-DAETHER_EXPERIMENTAL_IMAGE_EXACT_LATTICE=OFF','-DCMAKE_CXX_FLAGS=-U__SIZEOF_INT128__'],0,'Drawing: native unsigned128=; experimental exact lattice=OFF')]:
 dest=O/name;assert not dest.exists();run(name+'-configure',base+['-B',dest]+flags,expected)
 logs=(O/(name+'-configure.stdout')).read_text()+(O/(name+'-configure.stderr')).read_text()
 assert needle in logs,(name,logs)
 if name.startswith('no128'):
  cache=(dest/'CMakeCache.txt').read_text();assert 'AETHER_HAS_NATIVE_UINT128:INTERNAL=\n' in cache
for v in ['1','2']:
 name='on-contract-v'+v;dest=O/name;assert not dest.exists()
 run(name,[shutil.which('python3'),S/'native/tests/drawing_exact_v3/check_contract.py',O/'on'/('aether_drawing_contract_v'+v),v,dest],'nonzero')
 a=(dest/'frames.bgra').read_bytes();e=(S/'native/tests/drawing_exact_v3'/('frames.reference-v'+v+'.bgra')).read_bytes()
 assert len(a)==len(e)==32768 and a!=e
 assert 'AssertionError: full frozen contract mismatch' in (O/(name+'.stderr')).read_text()
 write(name+'-comparison.json',dict(state='FAIL_CONTRACTUAL',bytes_actual=len(a),bytes_expected=len(e),mismatched_bytes=sum(x!=y for x,y in zip(a,e)),actual_sha256=hashlib.sha256(a).hexdigest(),expected_sha256=hashlib.sha256(e).hexdigest(),crash=False))
custody('after-g2')

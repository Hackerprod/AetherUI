# Private software drawing integration (experimental v3)

**Integration status: NOT_BUILT.** The integration environment had no CMake.
These commands and targets are an unvalidated local diff, not a release claim.
No network, downloads, or additional packages are used by this integration.
An existing CMake >=3.16, C++20 compiler and Python 3 are required.

From repository root, in distinct build directories:

```sh
cmake -S native -B build/drawing-off -DCMAKE_BUILD_TYPE=Debug \
  -DAETHER_BUILD_DRAWING_EXAMPLE=ON -DAETHERUI_BUILD_TESTS=ON \
  -DAETHER_EXPERIMENTAL_IMAGE_EXACT_LATTICE=OFF
cmake --build build/drawing-off --target aether_drawing_demo aether_drawing_contract_v1 aether_drawing_no128
ctest --test-dir build/drawing-off -R '^drawing\.' --output-on-failure

cmake -S native -B build/drawing-on -DCMAKE_BUILD_TYPE=Debug \
  -DAETHER_BUILD_DRAWING_EXAMPLE=ON -DAETHERUI_BUILD_TESTS=ON \
  -DAETHER_EXPERIMENTAL_IMAGE_EXACT_LATTICE=ON
cmake --build build/drawing-on --target aether_drawing_demo aether_drawing_contract_v3 aether_drawing_unit_v3 aether_drawing_count_v3 aether_drawing_no128
ctest --test-dir build/drawing-on -R '^drawing\.' --output-on-failure
```

`aether_core` and installation/public ABI are unchanged. All drawing targets
are private and opt-in. Internal C++ symbols are hidden in the shared library,
so the private static target uses the existing core source list, not another
HTML engine. The renderer source is single, with compile-time selection scoped
to the private target. The two options default OFF.

The recovery HEAD already stored the exact candidate but did not build it in
CMake. OFF on the **new** private drawing target restores the pre-exact legacy
renderer byte-for-byte after removing the guarded exact blocks; this is not a
claim that the recovery HEAD had a previously tested CMake drawing target.
ON is the reviewed clip-aware algorithm plus build guards. No runtime selector,
new scene rejection or public renderer API is added.

## Draw and edit a page

```sh
python3 native/examples/drawing_exact/run_demo.py \
  build/drawing-on/aether_drawing_demo build/drawing-F 1
```

This runs the original F demo and verifies complete frozen BGRA buffers for
fractional scenes A/B with resources A/B and exact A/B, retained rendering and
failed-resource atomicity. Five invocations cover the six frozen references:
A-A sequence checks A.A and B.A; B-A single checks B.A; A-B sequence checks
A.B and B.B; exact-A and exact-B check exact.A and exact.B. The A-B directory
uses resource B bytes under the historical harness filename resource-A.
It exports BGRA and PNG (PNG unpremultiplies alpha; BGRA is authoritative).
Inputs and resources live in `native/examples/drawing_exact/`. For exploration,
copy `A-A` to a new directory and edit `fixtures/A.html` / `fixtures/A.css`:

```sh
mkdir -p build/my-frame
build/drawing-on/aether_drawing_demo path/to/copied-inputs build/my-frame single
```

The harness exercises parse -> style -> layout -> native image catalogue ->
snapshot -> prepare -> raster. It is a 64x64 image-only local example, not a
universal HTML viewer. It retains assertions and the historical missing-image
fixture; do not edit the frozen test copies to silence regressions.

## Contracts and exactness

V1/V2 tests are retained as separate binaries, not xfail or relaxed assertions.
Only v1 belongs to the OFF CTest selection; only v3 to ON. Known ON/v1 and
ON/v2 incompatibilities remain FAIL. The contract checker accepts only versions
1, 2 and 3 and maps each to its own frozen full-buffer reference. Integrated results are all NOT_RUN until
CMake build/run succeeds. V3 freezes 32 frames: only frames 9 and 25 have an
independent rational reconstruction claim; the other 30 retain compatibility.

The helper admits coordinates on a 1/256 lattice and opacity on 1/65536,
finite bounded values and resource extents <=16384. The exact supported ranges
and crop restrictions remain encoded in `image_exact_lattice.h`; outside them
valid input uses legacy. Curved coverage is conditional on the unchanged
16x16 sampler's integer count, not universally exact geometry. No new per-pixel
heap, callback, budget or sampler traversal is introduced.

ON fails configuration without native unsigned128; OFF stays available. The
no128 macro test is only selector coverage, not MSVC/Windows/ARM validation.
The prior reviewed candidate was Linux x86-64; this new CMake integration is
NOT_VERIFIED on every platform until built. Direct2D remains NOT_RUN /
NOT_VERIFIED; historical LSan NO GO remains open. coverage_complete=false;
PERFORMANCE, HOST_ISOLATION, REAL_WORKLOAD and PERF_BUDGET remain NOT_VERIFIED.

## Remaining integration acceptance

Build OFF and ON, helper/count, full contracts and F; then rerun 28 C++ + 28
HTML, relevant 233-route corpus and one bounded operational success/cancel
using the integrated objects. No prior result is counted as a new run or reused
without identity evidence and independent review. This diff does not yet
package that final campaign as CTest. Historical evidence remains outside the
repository and must not be mistaken for passing integrated tests.

Promotion is a concrete later choice: accept v3 byte changes for verified
supported platforms and documented legacy fallback, or preserve the historical
contract. No defaultON, merge, publication, Actions, product or release approval
is implied. Experimental status is not an indefinite universal-proof gate.

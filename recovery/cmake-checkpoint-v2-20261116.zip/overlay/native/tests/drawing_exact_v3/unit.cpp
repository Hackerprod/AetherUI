#ifdef NDEBUG
#error assertions required
#endif
#define image_exact_lattice frozen_image_exact_lattice
#include "frozen_image_exact_lattice.h"
#undef image_exact_lattice
#ifdef UNIT_MUTANT
#include "mutant_image_exact_lattice.h"
#else
#include "image_exact_lattice.h"
#endif
#include <cstdio>
#include <limits>
#include <vector>
namespace n=aether::rendering::software::image_exact_lattice;
namespace o=aether::rendering::software::frozen_image_exact_lattice;
struct Test{double source[4],destination[4],clipped[4],opacity;unsigned width,height;bool full;int x,y;std::uint8_t pixels[48];unsigned count,expected[4];};
#include "vectors.inc"
int main(){
 std::size_t i=0,comparisons=0;
 for(const auto& t:tests){
  n::Context ctx{};assert(n::prepare(ctx,t.source,t.destination,t.clipped,t.opacity,t.width,t.height,t.full,2));
  unsigned out[4];n::sample(ctx,t.pixels,t.width*4,t.x,t.y,out,t.count);
  for(unsigned c=0;c<4;++c)if(out[c]!=t.expected[c]){std::printf("FAIL rational vector=%zu count=%u channel=%u got=%u expected=%u\n",i,t.count,c,out[c],t.expected[c]);return 42;}
  assert(out[0]<=out[3]&&out[1]<=out[3]&&out[2]<=out[3]);
  if(t.count==256){o::Context prior{};assert(o::prepare(prior,t.source,t.destination,t.clipped,t.opacity,t.width,t.height,t.full,0));unsigned old[4];o::sample(prior,t.pixels,t.width*4,t.x,t.y,old);for(unsigned c=0;c<4;++c)assert(out[c]==old[c]);++comparisons;}
  ++i;
 }
 n::Context ctx{};const double src[]{0,0,1,1},dst[]{0,0,10,10};
 for(std::size_t depth:{0u,1u,2u,256u})assert(n::prepare(ctx,src,dst,dst,1,1,1,true,depth));
 for(double v:{std::nextafter(1.,0.),-1.,2.,std::numeric_limits<double>::denorm_min(),std::numeric_limits<double>::quiet_NaN(),std::numeric_limits<double>::infinity()})assert(!n::prepare(ctx,src,dst,dst,v,1,1,true,2));
 for(double v:{-32768.,32768.,std::numeric_limits<double>::denorm_min(),std::numeric_limits<double>::infinity(),std::numeric_limits<double>::quiet_NaN(),std::nextafter(1./256,0.)}){
  double bad[]{v,0,10,10};assert(!n::prepare(ctx,src,bad,dst,1,1,1,true,2));assert(!n::prepare(ctx,src,dst,bad,1,1,1,true,2));
 }
 assert(!n::prepare(ctx,src,dst,dst,1,0,1,true,2));assert(!n::prepare(ctx,src,dst,dst,1,16385,1,true,2));
 const double fractional_src[]{.25,0,1.25,1};assert(!n::prepare(ctx,fractional_src,dst,dst,1,2,1,false,2));assert(n::prepare(ctx,fractional_src,dst,dst,1,2,1,true,2));
 const double narrow[]{0,0,1./256,1./256};assert(n::prepare(ctx,src,narrow,narrow,1,1,1,true,2));
 const double negative_src[]{-1,0,1,1},small_src[]{0,0,.5,1},oversize_src[]{0,0,2,1};
 assert(!n::prepare(ctx,negative_src,dst,dst,1,1,1,true,2));assert(!n::prepare(ctx,small_src,dst,dst,1,1,1,true,2));assert(!n::prepare(ctx,oversize_src,dst,dst,1,1,1,true,2));
 const double reverse_dst[]{10,0,0,10};assert(!n::prepare(ctx,src,reverse_dst,dst,1,1,1,true,2));
 // Inclusive resource bound16384, extrema on admitted coordinate lattice and positive denominator.
 std::vector<std::uint8_t> resource(16384*4,255);
 const double fullsrc[]{0,0,16384,1},extreme[]{-32767.99609375,-32767.99609375,32767.99609375,32767.99609375},pixel[]{0,0,1,1};
 assert(n::prepare(ctx,fullsrc,extreme,pixel,1,16384,1,true,2));
 for(unsigned k:{0u,1u,127u,128u,255u,256u}){unsigned out[4];n::sample(ctx,resource.data(),16384*4,0,0,out,k);const unsigned expected=(255*k+128)/256;for(auto c:out)assert(c==expected);}
 using W=n::Wide;
 unsigned wide_tests=0;
 for(unsigned pow:{61u,95u,103u})for(unsigned q:{0u,25u,127u,229u,254u}){
  const W den=W(1)<<pow,num=W(q)*den+den/2;assert(n::half_up(num-1,den)==q);assert(n::half_up(num,den)==q+1);assert(n::half_up(num+1,den)==q+1);wide_tests+=3;
 }
 const W den=(W(1)<<104)-1;assert(n::half_up(W(255)*den,den)==255);assert(n::half_up(0,den)==0);
 // Independent small integer round formula for abstract area/opacity/count boundary grid.
 for(unsigned c:{0u,1u,32768u,65535u,65536u})for(unsigned m:{0u,1u,32768u,65535u,65536u})for(unsigned k:{0u,1u,127u,128u,255u,256u}){
  const std::uint64_t num=std::uint64_t(255)*c*m*k;const std::uint64_t dd=std::uint64_t(1)<<40;
  assert(n::half_up(W(num),W(dd))==(num+dd/2)/dd);++wide_tests;
 }
 // Fixed compositor over nonzero background and opacity-group integer rounding, independent integer reference.
 const unsigned sa=128,inv=127,bg[4]{11,73,141,255},foreground[4]{16,32,48,128};
 for(unsigned c=0;c<4;++c){const unsigned blended=foreground[c]+(bg[c]*inv+127)/255;const unsigned grouped=(blended*128+127)/255;assert(grouped<=128);}
 std::printf("PASS rational_vectors=%zu k256_old_equal=%zu wide_boundary_checks=%u domain_bounds=PASS\n",i,comparisons,wide_tests+2);return 0;
}

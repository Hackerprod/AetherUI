# Frozen experimental fixtures

Copied from the independently reviewed clip-aware candidate and versioned v3
contract on 2026-11-16. Only include locations were changed in unit/count tests.
The legacy helper is a test-only frozen comparator, not a second product engine.
`contract-v3.json` is curated metadata: its external absolute provenance path is
replaced by a document label; no expected byte was changed.

V3 expected SHA256: eb0a8cbdf677828248e7a0e9fdc8f676d8b0f25ef2784ead933a6c64d4bfe286.
Original contract metadata SHA256 is recorded in the integration handoff.
Rational provenance applies only to frames 9 and 25, not the other 30 frames.
Earlier v1/v2 references remain frozen and failures against ON must be reported.
No re-generation of expectations is part of building or testing.

The contract checker uses a closed v1/v2/v3 reference map. Demo coverage includes
six frozen buffers through five invocations; A-B uses A-A scene fixtures and the
unchanged resource B bytes from exact-B under the harness filename resource-A.
Neither the new matrix nor script checks imply a successful integrated render.

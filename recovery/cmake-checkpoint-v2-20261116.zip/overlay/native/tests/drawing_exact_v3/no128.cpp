#ifdef __SIZEOF_INT128__
#error test requires no128 selector
#endif
#include "image_exact_lattice.h"
#include <cstdio>
int main(){using namespace aether::rendering::software::image_exact_lattice;Context c{};const double a[]{0,0,1,1};for(std::size_t depth:{0u,1u,2u,256u})assert(!prepare(c,a,a,a,1,1,1,true,depth));std::puts("PASS no128 all tested depths select fallback");}

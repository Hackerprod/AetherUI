#ifdef NDEBUG
#error assertions required
#endif
#ifdef GEOMETRY_OLD
#include "../../src/rendering/software/software_renderer.cpp"
#else
#include "../../src/rendering/software/software_renderer.cpp"
#endif
#include <cassert>
#include <cstdio>
namespace p=aether::rendering::preparation;
using namespace aether::rendering::software;
struct Geometry{double b[4],clips[2][4],radii[2][2],inner[4];bool reverse;unsigned count,tests;};
#include "geometry.inc"
int main(){unsigned id=0;for(const auto& t:geometries){
 std::vector<p::Command> commands;
 for(unsigned i=0;i<2;++i){const auto* c=t.clips[i];const float rx=t.radii[i][0],ry=t.radii[i][1];commands.push_back(p::PushClip{{float(c[0]),float(c[1]),float(c[2]-c[0]),float(c[3]-c[1])},{rx,ry,rx,ry,rx,ry,rx,ry}});}
 commands.push_back(p::PopClip{});commands.push_back(p::PopClip{});
 auto result=p::prepare(p::Snapshot{std::move(commands)});assert(std::holds_alternative<p::PreparedFrame>(result));auto frame=std::move(std::get<p::PreparedFrame>(result));
 std::vector<ClipNode> nodes;
 for(unsigned i=0;i<2;++i){const auto* c=t.clips[i];nodes.push_back({{{c[0],c[1],c[2],c[3]},-double(i+1),1},i==0?no_clip:0,i+1});}
 Draw d{};d.original={-4,-4,8,8};d.inner_original={t.inner[0],t.inner[1],t.inner[2],t.inner[3]};d.clip_head=1;d.clip_depth=2;d.scale=1;
 if(t.reverse){nodes[0].parent=1;nodes[1].parent=no_clip;d.clip_head=0;}
 Rect b{t.b[0],t.b[1],t.b[2],t.b[3]};std::uint64_t sampled=0,tests=0,visits=0;
#ifndef GEOMETRY_OLD
 const auto k=joint_count(d,b,sampled,nodes,tests,visits,frame);assert(k==t.count&&sampled==1&&tests==t.tests&&visits==t.tests);sampled=tests=visits=0;
#endif
 const auto covered=joint_area(d,b,sampled,nodes,tests,visits,frame);const auto expected=(b.r-b.l)*(b.b-b.t)*t.count/256;
 assert(covered==expected&&sampled==1&&tests==t.tests&&visits==t.tests);
 std::uint64_t central_tests=0,central_visits=0;assert(!all_clips_central(b,d.clip_head,nodes,central_tests,central_visits));assert(central_tests==1&&central_visits==1);
 std::printf("%u %a %llu %llu %llu\n",id++,covered,(unsigned long long)sampled,(unsigned long long)tests,(unsigned long long)visits);
 }std::printf("PASS geometry=%u legacy_area_counters_and_shortcircuit\n",id);}

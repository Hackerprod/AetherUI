"""Compare whole frozen buffers. v1/v2 failures against v3 are not waived."""
from pathlib import Path
import subprocess,sys
binary,version,out=sys.argv[1:]
references = {
    '1': 'frames.reference-v1.bgra',
    '2': 'frames.reference-v2.bgra',
    '3': 'frames.expected-v3.bgra',
}
if version not in references:
    raise SystemExit('unsupported contract version: ' + version)
root=Path(__file__).resolve().parent
expected=root/references[version]
out=Path(out);out.mkdir(parents=True,exist_ok=True)
actual=out/'frames.bgra';subprocess.run([binary,str(actual)],check=True)
a=actual.read_bytes();e=expected.read_bytes()
assert len(a)==len(e)==32768, 'full frozen contract length mismatch'
assert a==e, 'full frozen contract mismatch'
print('PASS full buffer contract v'+version)

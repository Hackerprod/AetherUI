"""Run the real editable HTML pipeline, verify frozen F buffers, export PNG.
Requires only Python's standard library and the CMake-built demo.
"""
from pathlib import Path
import subprocess,sys,struct,zlib
binary,out,exact=sys.argv[1:]
if exact not in ('0','1'):
 raise SystemExit('unsupported exact mode: ' + exact)
root=Path(__file__).resolve().parent;out=Path(out);out.mkdir(parents=True,exist_ok=True)
def png(raw,path):
 def chunk(tag,data):return struct.pack('!I',len(data))+tag+data+struct.pack('!I',zlib.crc32(tag+data)&0xffffffff)
 # PNG stores straight alpha. BGRA remains the authoritative byte-exact artifact.
 def rgba(i):
  a=raw[i+3]
  return bytes((min(255,(raw[i+2]*255+a//2)//a) if a else 0,min(255,(raw[i+1]*255+a//2)//a) if a else 0,min(255,(raw[i]*255+a//2)//a) if a else 0,a))
 rows=b''.join(b'\0'+b''.join(rgba(i) for i in range(y*256,(y+1)*256,4)) for y in range(64))
 path.write_bytes(b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('!IIBBBBB',64,64,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(rows))+chunk(b'IEND',b''))
# kind names the scene; res names the resource, not the harness's file alias.
for case,kind,res,mode in [('A-A','A','A','sequence'),('B-A','B','A','single'),('A-B','A','B','sequence'),('exact-A','exact','A','single'),('exact-B','exact','B','single')]:
 dest=out/case;dest.mkdir(exist_ok=True)
 subprocess.run([binary,str(root/case),str(dest),mode],check=True)
 raw=(dest/'A.bgra').read_bytes(); assert len(raw)==16384
 assert raw==(dest/'A-retained.bgra').read_bytes()==(dest/'missing.bgra').read_bytes()
 if exact=='1' or kind=='exact':
  expected=(root/'expected'/f'{kind}.{res}.bgra').read_bytes()
  assert len(expected)==16384 and raw==expected,case
 if mode=='sequence':
  second=(dest/'B.bgra').read_bytes();assert len(second)==16384
  if exact=='1':
   expected=(root/'expected'/f'B.{res}.bgra').read_bytes()
   assert len(expected)==16384 and second==expected,case+' sequence B'
 for f in dest.glob('*.bgra'):png(f.read_bytes(),f.with_suffix('.png'))
 print('PASS',case,'exact' if exact=='1' else 'legacy retained/atomic')

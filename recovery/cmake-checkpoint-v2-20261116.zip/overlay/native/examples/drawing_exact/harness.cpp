#ifdef NDEBUG
#error Assertions required
#endif
#include <aether/aether.h>
#include "rendering/software/software_renderer.h"
#include "rendering/preparation/native_command_source.h"
#include "rendering/display_list_types.h"
#include <cassert>
#include <algorithm>
#include <cstdlib>
#include <fstream>
#include <filesystem>
#include <iomanip>
#include <sstream>
#include <stdexcept>
#include <memory>
using namespace aether::rendering;
namespace p=aether::rendering::preparation;
namespace sw=aether::rendering::software;
static std::string readfile(const std::string& path){std::ifstream f(path);assert(f);std::ostringstream s;s<<f.rdbuf();return s.str();}
static aether_text_metrics_t measure(const char*,const aether_computed_style_t*,float,void*){std::abort();}
struct Scene {
 aether_doc_t doc{};aether_style_runtime_t runtime{};aether_style_map_t styles{};aether_layout_engine_t engine{};aether_layout_result_t layout{};aether_display_list_builder_t builder{};
 Scene(const std::string& html,const std::string& css,const std::string& prefix){
 std::ofstream phase(prefix+".phases.txt");auto mark=[&](const char* name){phase<<name<<" ok\n";phase.flush();assert(phase);};
 assert(aether_doc_create(&doc)==AETHER_OK);assert(aether_doc_parse_html(doc,html.c_str())==AETHER_OK);mark("parse");
 aether_style_environment_t env{64,64,1,16,0,0,0};assert(aether_style_runtime_create(nullptr,&env,nullptr,nullptr,&runtime)==AETHER_OK);
 int64_t sheet{};int32_t rules{};assert(aether_style_runtime_add_stylesheet(runtime,css.c_str(),0,"html-s1",&sheet,&rules)==AETHER_OK);assert(rules>0);
 aether_style_update_t* updates{};auto count=aether_style_runtime_resolve_subtree(runtime,aether_doc_get_body(doc),&updates);assert(count>=0);aether_style_updates_free(updates,count);
 assert(aether_style_runtime_create_resolved_style_map(runtime,doc,&styles)==AETHER_OK);mark("style");assert(aether_layout_create(measure,nullptr,&engine)==AETHER_OK);
 assert(aether_layout_layout(engine,doc,styles,64,64,nullptr,nullptr,&layout)==AETHER_OK);mark("layout");assert(aether_display_list_builder_create(measure,nullptr,&builder)==AETHER_OK);
 }
 ~Scene(){aether_display_list_builder_destroy(builder);aether_layout_result_destroy(layout);aether_layout_destroy(engine);aether_style_map_destroy(styles);aether_style_runtime_destroy(runtime);aether_doc_destroy(doc);}
};
static void rect(std::ostream& o,p::Rect r){o<<' '<<r.x<<' '<<r.y<<' '<<r.width<<' '<<r.height;}
static void matrix(std::ostream& o,p::Matrix m){o<<' '<<m.m11<<' '<<m.m12<<' '<<m.m21<<' '<<m.m22<<' '<<m.dx<<' '<<m.dy;}
static void radii(std::ostream& o,p::Radii r){o<<' '<<r.top_left_x<<' '<<r.top_left_y<<' '<<r.top_right_x<<' '<<r.top_right_y<<' '<<r.bottom_right_x<<' '<<r.bottom_right_y<<' '<<r.bottom_left_x<<' '<<r.bottom_left_y;}
static void commands(const p::PreparedFrame& frame,const std::string& path){
 std::ofstream o(path);o<<std::setprecision(17);size_t index=0;
 for(const auto& e:frame.events()){
  assert(e.transform_depth<=4);o<<index++<<" tag "<<p::command_tag(e.command)<<" matrix";matrix(o,e.matrix);
  if(auto v=std::get_if<p::Image>(&e.command)){o<<" image source";rect(o,v->source);o<<" destination";rect(o,v->destination);o<<" opacity "<<v->opacity<<" full "<<(v->sampling_bounds==p::ImageSamplingBounds::FullResource);}
  if(auto v=std::get_if<p::PushClip>(&e.command)){o<<" clip";rect(o,v->rect);o<<" radii";radii(o,v->radii);}
  if(auto v=std::get_if<p::BeginOpacity>(&e.command))o<<" begin-opacity "<<v->opacity;
  if(std::holds_alternative<p::EndOpacity>(e.command))o<<" end-opacity";
  o<<'\n';
 }o.close();assert(o);
}
static Frame read(FrameStore& s){std::optional<Frame> f;assert(s.copy_confirmed(f)==FrameStatus::ok&&f);assert(f->viewport.width==64&&f->viewport.height==64&&f->viewport.dpi==1&&f->stride==256&&f->pixels.size()==16384);return *f;}
static void save(const std::string& path,const Frame& f){std::ofstream o(path,std::ios::binary);o.write(reinterpret_cast<const char*>(f.pixels.data()),f.pixels.size());o.close();assert(o);}
static void unchanged(const Frame& a,const Frame& b){assert(a.pixels==b.pixels&&a.sequence==b.sequence&&a.stride==b.stride&&a.viewport.width==b.viewport.width&&a.viewport.height==b.viewport.height&&a.viewport.dpi==b.viewport.dpi);}
static p::PreparedFrame prepare(p::Snapshot& s){auto result=p::prepare(s);assert(std::holds_alternative<p::PreparedFrame>(result));return std::get<p::PreparedFrame>(std::move(result));}
struct Captured {std::optional<p::Snapshot> snapshot;std::weak_ptr<const p::ImageResource> weak;};
static Captured capture(const std::string& root,const std::string& id,const std::string& resource,const std::string& out,bool positive,bool missing,std::optional<p::PreparedFrame>* live=nullptr){
 // Exactly these owners exist: copy-result variant, ref, catalog, native list,
 // snapshot-result variant, returned snapshot and optional live PreparedFrame.
 // All local strong owners die at function return. No static resource cache.
 auto encoded=readfile(root+"/resource-"+resource+".png"),literal=readfile(root+"/resource-"+resource+".bgra");
 int32_t w=0,h=0;uint8_t* decoded=nullptr;
 assert(aether_image_decode(reinterpret_cast<const uint8_t*>(encoded.data()),encoded.size(),&w,&h,&decoded)==AETHER_OK&&w==4&&h==3&&literal.size()==48);
 assert(std::equal(decoded,decoded+48,reinterpret_cast<const uint8_t*>(literal.data())));
 auto copied=p::ImageResource::copy(w,h,{decoded,48});assert(std::holds_alternative<p::ImageRef>(copied));auto ref=std::get<p::ImageRef>(std::move(copied));
 aether_image_pixels_free(decoded);decoded=nullptr;encoded.clear();literal.clear();Captured captured;captured.weak=ref;
 Scene scene(readfile(root+"/fixtures/"+id+".html"),readfile(root+"/fixtures/"+id+".css"),out);
 std::ofstream layout(out+".layout.txt");layout<<std::setprecision(17);for(const char* key:{"a","b","p","q","s"}){auto n=aether_doc_get_element_by_id(scene.doc,key);if(!n)continue;auto box=aether_layout_result_find_primary_box(scene.layout,n);assert(box);layout<<key;rect(layout,aether_layout_box_get_border_box(box));layout<<'\n';}layout.close();assert(layout);
 NativeImageCatalog catalog;if(!missing)catalog.push_back({"hero",ref});std::unique_ptr<NativePaintList> native;
 auto status=build_native_opacity(scene.builder,scene.layout,scene.styles,nullptr,NativeScrollInput{},catalog,native);
 {std::ofstream phase(out+".phases.txt",std::ios::app);phase<<"decode-literal ok\nnative "<<int(status)<<'\n';}
 if(missing){assert(status!=AETHER_OK&&!native);return captured;}
 assert(status==AETHER_OK&&native&&native->text_runs.empty()&&native->images.size()>=1&&native->images.size()<=16);
 auto raw=NativeListAccess::list(*native);assert(raw&&raw->commands.size()<=64);
 std::ofstream native_log(out+".native.txt");size_t scroll=0;for(size_t i=0;i<raw->commands.size();++i){auto& c=raw->commands[i];native_log<<i<<' '<<int(c.tag)<<'\n';scroll+=c.tag==AETHER_PAINT_PUSH_SCROLL_OFFSET;}for(const auto& image:native->images){native_log<<"image-entry "<<image.command_index<<" source "<<image.source<<" crop";rect(native_log,image.crop);native_log<<" destination";rect(native_log,image.destination);native_log<<" opacity "<<image.opacity<<'\n';}for(auto event:native->events)native_log<<"opacity-event "<<event.boundary<<' '<<event.open<<' '<<event.id<<' '<<event.parent<<' '<<event.opacity<<'\n';native_log.close();assert(native_log);if(positive)assert(scroll==0);if(id=="N11-scroll")assert(scroll>0);
 auto snapshot=p::snapshot_native_opacity(*native);assert(std::holds_alternative<p::Snapshot>(snapshot));captured.snapshot.emplace(std::get<p::Snapshot>(std::move(snapshot)));
 {std::ofstream phase(out+".phases.txt",std::ios::app);phase<<"snapshot ok\n";}
 {std::ofstream log(out+".snapshot.txt");log<<std::setprecision(17);size_t i=0;for(const auto& c:captured.snapshot->commands){log<<i++<<" tag "<<p::command_tag(c);if(auto v=std::get_if<p::Image>(&c)){log<<" image-source";rect(log,v->source);log<<" destination";rect(log,v->destination);log<<" opacity "<<v->opacity;}if(auto v=std::get_if<p::PushTransform>(&c)){log<<" transform";matrix(log,v->matrix);}if(auto v=std::get_if<p::PushClip>(&c)){log<<" clip";rect(log,v->rect);radii(log,v->radii);}if(auto v=std::get_if<p::BeginOpacity>(&c))log<<" begin-opacity "<<v->id<<' '<<v->parent<<' '<<v->opacity;if(auto v=std::get_if<p::EndOpacity>(&c))log<<" end-opacity "<<v->id;if(auto v=std::get_if<p::PushScroll>(&c))log<<" scroll "<<v->id<<' '<<v->x<<' '<<v->y;log<<'\n';}log.close();assert(log);}

 size_t images=0;for(auto& c:captured.snapshot->commands){if(auto im=std::get_if<p::Image>(&c)){++images;assert(im->sampling_bounds==p::ImageSamplingBounds::FullResource&&im->resource==ref);}}assert(images==native->images.size());
 if(live){live->emplace(prepare(*captured.snapshot));commands(**live,out+".prepared-live.txt");FrameStore st;assert(st.resize({64,64,1})==FrameStatus::ok);assert(sw::render(st,**live).status==sw::Status::ok);save(out+".live.bgra",read(st));}
 return captured;
}
// root id output-prefix positive|negative index work-upper ownership(0|1)
int main(int argc,char**argv){
 assert(argc==8);std::string root=argv[1],id=argv[2],out=argv[3];bool positive=std::string(argv[4])=="positive";size_t index=std::stoull(argv[5]),bound=std::stoull(argv[6]);bool ownership=std::string(argv[7])=="1";
 size_t allocations=0;FrameStore store([&]{++allocations;});assert(store.resize({64,64,1})==FrameStatus::ok);
 {auto cap=capture(root,"I00-control","A",out+".sentinel",true,false);auto seed=prepare(*cap.snapshot);cap.snapshot.reset();assert(sw::render(store,seed).status==sw::Status::ok);}
 auto before=read(store);assert(std::any_of(before.pixels.begin(),before.pixels.end(),[](auto b){return b!=0;}));save(out+".sentinel.bgra",before);
 std::optional<p::PreparedFrame> alive,retained;auto cap=capture(root,id,"A",out,positive,id=="N12-missing-resource",positive?&alive:nullptr);
 if(id=="N12-missing-resource"){assert(!cap.snapshot&&cap.weak.expired());unchanged(before,read(store));save(out+".actual.bgra",read(store));return 0;}
 alive.reset(); // snapshot must be sole remaining strong resource owner before preparation
 assert(cap.snapshot&&!cap.weak.expired());retained.emplace(prepare(*cap.snapshot));cap.snapshot.reset();commands(*retained,out+".prepared.txt");{std::ofstream phase(out+".phases.txt",std::ios::app);phase<<"prepare ok\n";}
 size_t allocation_before=allocations;auto result=sw::render(store,*retained);size_t allocation_after=allocations;
 {std::ofstream r(out+".render.txt");r<<"status "<<int(result.status)<<" index "<<result.command_index<<" allocations "<<allocation_before<<' '<<allocation_after<<" work "<<result.pixel_budget<<" curved-depth "<<result.max_clip_depth<<'\n';r.close();assert(r);}
 auto actual=read(store);save(out+".actual.bgra",actual);
 if(!positive){assert(result.status==sw::Status::unsupported&&result.command_index==index&&allocation_before==allocation_after);unchanged(before,actual);retained.reset();assert(cap.weak.expired());return 0;}
 assert(result.status==sw::Status::ok&&result.pixel_budget<=bound&&result.max_clip_depth<=4);auto live=readfile(out+".live.bgra");assert(live.size()==actual.pixels.size()&&std::equal(actual.pixels.begin(),actual.pixels.end(),reinterpret_cast<const uint8_t*>(live.data())));assert(actual.sequence==before.sequence+1);
 if(ownership)for(int cycle=0;cycle<16;++cycle){
  auto a=capture(root,id,"A",out+".cycleA"+std::to_string(cycle),true,false);std::optional<p::PreparedFrame> pa(prepare(*a.snapshot));a.snapshot.reset();assert(!a.weak.expired());assert(sw::render(store,*pa).status==sw::Status::ok&&read(store).pixels==actual.pixels);pa.reset();assert(a.weak.expired());
  auto b=capture(root,id,"B",out+".cycleB"+std::to_string(cycle),true,false);std::optional<p::PreparedFrame> pb(prepare(*b.snapshot));b.snapshot.reset();assert(!b.weak.expired());assert(sw::render(store,*pb).status==sw::Status::ok);auto bf=read(store);assert(bf.pixels!=actual.pixels);save(out+".cycleB"+std::to_string(cycle)+".actual.bgra",bf);pb.reset();assert(b.weak.expired());
  assert(sw::render(store,*retained).status==sw::Status::ok&&read(store).pixels==actual.pixels);
 }
 assert(sw::render(store,*retained).status==sw::Status::ok);save(out+".retained.bgra",read(store));retained.reset();assert(cap.weak.expired());
}

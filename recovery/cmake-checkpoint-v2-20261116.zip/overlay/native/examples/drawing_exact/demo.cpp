// Reuse the reviewed HTML harness verbatim, including every existing assertion.
// Its old main remains compiled but is not called by this example.
#define main historical_s1_harness_main
#include "harness.cpp"
#undef main
static void rendered(FrameStore& store, const p::PreparedFrame& frame, const std::string& out) {
 std::optional<Frame> before;assert(store.copy_confirmed(before)==FrameStatus::ok);auto result=sw::render(store,frame);
 std::ofstream status(out+".render.txt");status<<"status "<<int(result.status)<<" index "<<result.command_index<<" work "<<result.pixel_budget<<" curved-depth "<<result.max_clip_depth<<'\n';status.close();assert(status);
 assert(result.status==sw::Status::ok);auto after=read(store);assert(after.sequence==(before?before->sequence:0)+1);save(out+".bgra",after);
 std::ofstream metadata(out+".frame.txt");metadata<<"width 64 height 64 dpi 1 stride 256 bytes 16384 sequence "<<after.sequence<<'\n';metadata.close();assert(metadata);
 std::ofstream phase(out+".phases.txt",std::ios::app);phase<<"raster ok\n";
}
static p::PreparedFrame load(const std::string& root,const std::string& id,const std::string& out,std::weak_ptr<const p::ImageResource>& weak) {
 auto cap=capture(root,id,"A",out,true,false);weak=cap.weak;
 assert(cap.snapshot&&!weak.expired());auto prepared=prepare(*cap.snapshot);cap.snapshot.reset();assert(!weak.expired());
 commands(prepared,out+".prepared.txt");std::ofstream phase(out+".phases.txt",std::ios::app);phase<<"prepare ok\n";return prepared;
}
int main(int argc,char** argv) {
 assert(argc==4);std::string root=argv[1],out=argv[2];bool sequence=std::string(argv[3])=="sequence";
 FrameStore store;assert(store.resize({64,64,1})==FrameStatus::ok);
 std::weak_ptr<const p::ImageResource> wa,wb;
 std::optional<p::PreparedFrame> a(load(root,"A",out+"/A",wa));rendered(store,*a,out+"/A");auto first=read(store);
 if(sequence){std::optional<p::PreparedFrame> b(load(root,"B",out+"/B",wb));rendered(store,*b,out+"/B");assert(read(store).pixels!=first.pixels);b.reset();assert(wb.expired());}
 rendered(store,*a,out+"/A-retained");assert(read(store).pixels==first.pixels);
 auto before=read(store);auto missing=capture(root,"missing","A",out+"/missing",true,true);
 assert(!missing.snapshot&&missing.weak.expired());unchanged(before,read(store));save(out+"/missing.bgra",read(store));
 std::ofstream missing_status(out+"/missing.result.txt");missing_status<<"native rejected\nsnapshot NOT_RUN\nprepare NOT_RUN\nraster NOT_RUN\nframe bytes metadata sequence unchanged\n";
 a.reset();assert(wa.expired());std::ofstream done(out+"/ownership.txt");done<<"producer snapshot released before raster\nB resource released before A rerender\nA resource released after retained frame\n";
 return 0;
}

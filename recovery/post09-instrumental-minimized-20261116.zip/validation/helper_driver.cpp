// Synthetic observer validation ONLY. Does not create a product runtime or resolve.
#include "input/native/tests/diagnostics/post09_observer_private.h"
#include "input/native/src/style_runtime/typography_evidence.h"
#include <cstdlib>
#include <cstring>
namespace obs = aether::diagnostic::post09;
using aether::style::TypographyEvidence;

static TypographyEvidence inert_evidence() {
    TypographyEvidence v;
    v.font_style="italic";
    v.families.push_back({"Synthetic Family",false});
    v.family_state=aether::style::TypographyFieldState::known;
    v.style_state=aether::style::TypographyFieldState::known;
    v.spacing_state=aether::style::TypographyFieldState::known;
    v.spacing_px=0.5;
    v.size_state=aether::style::TypographyFieldState::known;
    v.size_px=16.0f;
    v.weight_state=aether::style::TypographyFieldState::known;
    v.weight=400;
    v.line_height_state=aether::style::TypographyFieldState::known;
    v.line_height_kind=aether::style::TypographyLineHeightKind::absolute_css_px;
    v.line_height_value=32.0f;
    v.line_height_used_px=32.0f;
    v.provenance[0].accepted_source="Synthetic Family";
    v.provenance[0].resolved_source="Synthetic Family";
    v.provenance[0].declaration=true;
    v.break_policy.fields[0].authored_property="word-break";
    v.break_policy.fields[1].authored_property="overflow-wrap";
    return v;
}
static void core_sequence(const void* target,const TypographyEvidence& v,unsigned mask) {
    obs::node_start(target);
    obs::diff(1,mask,mask,true,false);
    obs::diff(2,mask,mask,true,false);
    obs::diff(3,mask,mask,true,false);
    obs::typography(5,&v,v,false);
    obs::typography(6,&v,v,false);
    obs::branch_taken(false);
    obs::diff(7,mask,mask,true,false);
}
static void sample(obs::Token t,obs::SampleKind kind,const void* node=nullptr,int count=0,bool present=false,unsigned impact=0) {
    obs::public_result(t,kind,node,count,present,impact);
}
static bool one_scope(obs::Case which,unsigned test,int ordinal) {
    // All C++ strings/vector allocations happen before begin, outside capture.
    const auto evidence=inert_evidence();
    int identity=ordinal; const void* target=&identity;
    auto token=obs::begin(which);
    if(!token)return false;
    if(test!=3)sample(token,obs::SampleKind::BindTarget,target);
    const bool absent=test==3&&which==obs::Case::TR_NOOP;
    const unsigned mask=test==1?81u:test==2?3u:absent?0u:12u;
    core_sequence(target,evidence,mask);
    const int count=absent?0:test==2?2:1;
    sample(token,obs::SampleKind::RawCount,nullptr,count);
    if(test==2){
        sample(token,obs::SampleKind::Entry,target,0,true,1);
        sample(token,obs::SampleKind::Entry,target,1,true,2);
        sample(token,obs::SampleKind::Aggregate,target,count,true,3);
    } else if(!absent)sample(token,obs::SampleKind::Entry,target,0,true,mask);
    sample(token,obs::SampleKind::ResolveDone,nullptr,count,true);
    if(test==3)sample(token,obs::SampleKind::BindTarget,target);
    if(test==1)sample(token,obs::SampleKind::ReturnImpact,nullptr,0,false,mask);
    obs::end(token);
    return true;
}
int main(int argc,char** argv) {
    if(argc!=3||std::strcmp(argv[1],"--test-id")!=0||argv[2][0]<'1'||argv[2][0]>'5'||argv[2][1]!='\0')return 64;
    const unsigned test=static_cast<unsigned>(argv[2][0]-'0');
    const char* configured=std::getenv("AETHER_POST09_TEST_ID");
    const char* tree=std::getenv("AETHER_POST09_TREE_ID");
    if(!configured||std::strcmp(configured,argv[2])!=0||!tree||std::strcmp(tree,"2")!=0)return 64;
    if(test==1)return one_scope(obs::Case::SD_LH,test,1)?0:65;
    if(test==2)return one_scope(obs::Case::TP_EMPTY,test,1)?0:65;
    if(test==3){
        const obs::Case cases[]={obs::Case::TR_NOOP,obs::Case::TR_S1,obs::Case::TR_S2,
            obs::Case::TR_S3,obs::Case::TR_I1,obs::Case::TR_I2,obs::Case::TR_I3};
        for(int i=0;i<7;++i)if(!one_scope(cases[i],test,i+1))return 65;
    }
    // Controls intentionally use no scope. Real helper ctor/atexit still run.
    return 0;
}

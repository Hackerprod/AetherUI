import sys, os, json, hashlib, stat, re, time
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
EXPECTED_ROOT=Path('/RELOCATE/validation')
def authenticate(approved):
    if ROOT!=EXPECTED_ROOT or not re.fullmatch('[0-9a-f]{64}',approved):raise ValueError('ROOT_OR_AUTHORITY')
    def unique(items):
        d={}
        for k,v in items:
            if k in d:raise ValueError('DUPLICATE')
            d[k]=v
        return d
    def plain(p):
        for a in [p,*p.parents]:
            if a.is_symlink():raise ValueError('SYMLINK')
        if not stat.S_ISREG(p.lstat().st_mode):raise ValueError('NOT_REGULAR')
        return p.read_bytes()
    raw=plain(ROOT/'evidence.sha256.json')
    if hashlib.sha256(raw).hexdigest()!=approved:raise ValueError('UNAPPROVED')
    rows=json.loads(raw,object_pairs_hook=unique); seen=set()
    for row in rows:
        name=row['path']
        if not isinstance(name,str) or name.startswith('/') or any(s in ('','.','..') for s in name.split('/')) or '\\' in name or '\x00' in name or name in seen:raise ValueError('PATH')
        seen.add(name); data=plain(ROOT/name)
        if len(data)!=row['bytes'] or hashlib.sha256(data).hexdigest()!=row['sha256']:raise ValueError('CONTENT')
    if not {'external_collector.py','external_supervisor.py','external_writer.py','external_contract.py','external-recipe.json','validation_launcher.py'}<=seen:raise ValueError('MISSING_MODULE')
    if 'validation-tools-authority.json' not in seen:raise ValueError('MISSING_TOOL_AUTHORITY')
    authority=json.loads(plain(ROOT/'validation-tools-authority.json'),object_pairs_hook=unique)
    expected='/RELOCATE/python3'
    matches=[r for r in authority['records'] if r['path']==expected]
    if len(matches)!=1:raise ValueError('INTERPRETER_AUTHORITY')
    record=matches[0]
    if str(Path(sys.executable).resolve(strict=True))!=record['resolved'] or str(Path(expected).resolve(strict=True))!=record['resolved'] or str(Path('/proc/self/exe').resolve(strict=True))!=record['resolved']:raise ValueError('INTERPRETER_IDENTITY')
    executable=plain(Path(record['resolved']))
    if len(executable)!=record['bytes'] or hashlib.sha256(executable).hexdigest()!=record['sha256']:raise ValueError('INTERPRETER_CONTENT')
def main():
    if len(sys.argv)!=6:raise ValueError('ARGV')
    approved,t0,pid,start,readyfd=sys.argv[1:]; authenticate(approved)
    import signal, select
    from external_contract import identity,same,discover,kill_verified
    t0=float(t0); pid=int(pid); readyfd=int(readyfd)
    if not 0<=time.monotonic()-t0<30 or pid!=os.getppid():raise ValueError('ORIGIN')
    owner=identity(pid)
    if not owner or owner['start']!=start:raise ValueError('OWNER')
    os.set_blocking(readyfd,False); os.write(readyfd,b'READY\n'); os.close(readyfd)
    known={}; term=False; killed=False
    while time.monotonic()<t0+600:
        rows=discover(pid,known,(os.getpid(),))
        if not same(owner):
            for row in rows:kill_verified(row,signal.SIGKILL)
            return 0 if not rows else 2
        now=time.monotonic()
        if now>=t0+580:
            for row in rows:kill_verified(row,signal.SIGTERM)
            kill_verified(owner,signal.SIGTERM)
            term=True
        if now>=t0+590:
            for row in rows:kill_verified(row,signal.SIGKILL)
            kill_verified(owner,signal.SIGKILL)
            killed=True
        time.sleep(min(.02,max(0,t0+600-time.monotonic())))
    for row in discover(pid,known,(os.getpid(),)):kill_verified(row,signal.SIGKILL)
    kill_verified(owner,signal.SIGKILL)
    return 2
if __name__=='__main__':sys.exit(main())

import sys, os, json, hashlib, stat, re, time
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
EXPECTED_ROOT=Path('/RELOCATE/validation')
def authenticate(approved):
    if ROOT!=EXPECTED_ROOT or not re.fullmatch('[0-9a-f]{64}',approved):raise ValueError('ROOT_OR_AUTHORITY')
    def unique(items):
        d={}
        for k,v in items:
            if k in d:raise ValueError('DUPLICATE')
            d[k]=v
        return d
    def plain(p):
        for a in [p,*p.parents]:
            if a.is_symlink():raise ValueError('SYMLINK')
        if not stat.S_ISREG(p.lstat().st_mode):raise ValueError('NOT_REGULAR')
        return p.read_bytes()
    raw=plain(ROOT/'evidence.sha256.json')
    if hashlib.sha256(raw).hexdigest()!=approved:raise ValueError('UNAPPROVED')
    rows=json.loads(raw,object_pairs_hook=unique); seen=set()
    for row in rows:
        name=row['path']
        if not isinstance(name,str) or name.startswith('/') or any(s in ('','.','..') for s in name.split('/')) or '\\' in name or '\x00' in name or name in seen:raise ValueError('PATH')
        seen.add(name); data=plain(ROOT/name)
        if len(data)!=row['bytes'] or hashlib.sha256(data).hexdigest()!=row['sha256']:raise ValueError('CONTENT')
    if not {'external_collector.py','external_supervisor.py','external_writer.py','external_contract.py','external-recipe.json','validation_launcher.py'}<=seen:raise ValueError('MISSING_MODULE')
    if 'validation-tools-authority.json' not in seen:raise ValueError('MISSING_TOOL_AUTHORITY')
    authority=json.loads(plain(ROOT/'validation-tools-authority.json'),object_pairs_hook=unique)
    expected='/RELOCATE/python3'
    matches=[r for r in authority['records'] if r['path']==expected]
    if len(matches)!=1:raise ValueError('INTERPRETER_AUTHORITY')
    record=matches[0]
    if str(Path(sys.executable).resolve(strict=True))!=record['resolved'] or str(Path(expected).resolve(strict=True))!=record['resolved'] or str(Path('/proc/self/exe').resolve(strict=True))!=record['resolved']:raise ValueError('INTERPRETER_IDENTITY')
    executable=plain(Path(record['resolved']))
    if len(executable)!=record['bytes'] or hashlib.sha256(executable).hexdigest()!=record['sha256']:raise ValueError('INTERPRETER_CONTENT')
def validate_frame(raw,approved,runid,t0,rc):
    import struct
    from external_contract import unique
    if len(raw)<4:raise ValueError('MISSING_FRAME')
    size=struct.unpack('<I',raw[:4])[0]
    if size>2048 or size<2 or len(raw)!=size+4:raise ValueError('FRAME_LENGTH_OR_EXTRA')
    value=json.loads(raw[4:].decode('utf-8'),object_pairs_hook=unique)
    keys={'schema_version','manifest_sha256','run_id','work_status','work_error_code','work_error_stage','closure_status','ack_received','ack_valid','ack_payload','guard_rc','guard_reaped','pending_work_identities_count','cleanup_verified','causal_gate','monotonic_emission_start','closure_error_code'}
    if set(value)!=keys or type(value['schema_version']) is not int or value['schema_version']!=1 or value['manifest_sha256']!=approved or value['run_id']!=runid:raise ValueError('FRAME_SCHEMA')
    for key in ('ack_received','ack_valid','guard_reaped','cleanup_verified'):
        if type(value[key]) is not bool:raise ValueError('BOOL_TYPE')
    if type(value['pending_work_identities_count']) is not int or value['pending_work_identities_count']<0:raise ValueError('COUNT')
    if value['guard_rc'] is not None and type(value['guard_rc']) is not int:raise ValueError('GUARD_RC')
    emission=value['monotonic_emission_start']
    if type(emission) not in (int,float) or not t0<=emission<=min(t0+572,time.monotonic()):raise ValueError('EMISSION')
    ack={'ack':'done','identified_work_exited':True,'reaping':'LAUNCHER_RESPONSIBILITY'}
    if value['ack_payload'] is not None and (not isinstance(value['ack_payload'],dict) or set(value['ack_payload'])!=set(ack) or value['ack_payload']!=ack or type(value['ack_payload']['identified_work_exited']) is not bool):raise ValueError('ACK_PAYLOAD')
    if value['ack_valid'] and (not value['ack_received'] or value['ack_payload']!=ack):raise ValueError('ACK_CONFLICT')
    if not value['ack_received'] and value['ack_payload'] is not None:raise ValueError('ACK_CONFLICT')
    if value['work_status']=='COMPLETED':
        if rc!=0 or value['work_error_code'] is not None or value['work_error_stage'] is not None or value['causal_gate']!='CLOSED_AWAITING_D':raise ValueError('WORK_CONFLICT')
    elif value['work_status']=='REJECTED':
        if rc is None or rc==0 or value['work_error_code'] not in ('BOOTSTRAP_FAILED','WORK_FAILED') or value['work_error_stage'] not in ('bootstrap','work','persistence') or value['causal_gate']!='CLOSED_REJECTED':raise ValueError('REJECTION_CONFLICT')
    else:raise ValueError('WORK_STATUS')
    complete=(value['ack_received'] and value['ack_valid'] and value['guard_rc']==0 and value['guard_reaped'] and value['cleanup_verified'] and value['pending_work_identities_count']==0)
    if value['closure_status']=='INTERNAL_ACK_AND_REAP_OBSERVED':
        if not complete or value['closure_error_code'] is not None:raise ValueError('CLOSURE_CONFLICT')
    elif value['closure_status']=='FAILED':
        if complete or value['closure_error_code'] not in ('GUARD_UNAVAILABLE','CLEANUP_FAILED','CLOSURE_DEADLINE','CONTROL_WRITE_FAILED','ACK_OVERSIZE','ACK_INVALID','GUARD_RC_FAILED','INTERNAL_CLOSURE_FAILED','GUARD_REAP_OBSERVATION_FAILED','CLEANUP_OBSERVATION_FAILED'):raise ValueError('CLOSURE_FAILURE_CONFLICT')
    else:raise ValueError('CLOSURE_STATUS')
    return value

def main():
    if len(sys.argv)!=3 or sys.argv[1]!='--manifest-sha256':raise ValueError('ARGV')
    # Origin precedes bootstrap. Bootstrap consumes this same budget.
    t0=time.monotonic(); approved=sys.argv[2]; authenticate(approved)
    import subprocess,select,signal,ctypes,base64
    from external_contract import PYTHON,identity,same,discover,kill_verified,reap
    if time.monotonic()>=t0+30:raise ValueError('BOOTSTRAP_TOO_SLOW')
    if ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)!=0:raise RuntimeError('SUBREAPER_FAILED')
    runid=os.urandom(16).hex(); directory=ROOT/'external-output'/runid
    (ROOT/'external-output').mkdir(mode=0o700); directory.mkdir(mode=0o700)
    owner=identity(os.getpid()); ready_r,ready_w=os.pipe2(os.O_CLOEXEC|os.O_NONBLOCK)
    supervisor=subprocess.Popen([PYTHON,'-B',str(ROOT/'external_supervisor.py'),approved,repr(t0),str(owner['pid']),owner['start'],str(ready_w)],pass_fds=(ready_w,),close_fds=True,stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    supervisor_initial=identity(supervisor.pid)
    known={};children=[]
    guard_state={'external_supervisor_initial_identity':supervisor_initial,
                 'external_guard_lost':False,'external_guard_failure_stage':None,
                 'external_supervisor_rc_observed':None,'external_guard_last_check_monotonic':None}
    class GuardLost(Exception):pass
    def guard_fields():return dict(guard_state)
    def lose_guard(stage):
        if not guard_state['external_guard_lost']:
            guard_state['external_guard_lost']=True
            guard_state['external_guard_failure_stage']=stage
        raise GuardLost('EXTERNAL_GUARD_LOST')
    def check_external_guard(stage):
        if guard_state['external_guard_lost']:raise GuardLost('EXTERNAL_GUARD_LOST')
        now=time.monotonic();rc=supervisor.poll();current=identity(supervisor.pid)
        guard_state['external_guard_last_check_monotonic']=now
        guard_state['external_supervisor_rc_observed']=rc
        if rc is not None or supervisor_initial is None or current is None or current['start']!=supervisor_initial['start'] or current['state'] in ('Z','X','x'):
            lose_guard(stage)
    def guarded_run():
        os.close(ready_w); ready=b''
        while time.monotonic()<min(t0+30,t0+600):
            check_external_guard('ready_wait')
            r,_,_=select.select([ready_r],[],[],.02)
            if r:
                part=os.read(ready_r,32);ready+=part
                if ready==b'READY\n':break
                if not part:break
            if supervisor.poll() is not None:break
        os.close(ready_r)
        if ready!=b'READY\n':
            lose_guard('ready_protocol')
        check_external_guard('ready')
        # Final descriptor cannot leak to supervisor: created only now. Popen closes
        # everything except this explicitly inherited descriptor for launcher.
        final_r,final_w=os.pipe2(os.O_CLOEXEC|os.O_NONBLOCK)
        if os.fpathconf(final_w,'PC_PIPE_BUF')<2052:raise RuntimeError('PIPE_BUF')
        argv=[PYTHON,'-B',str(ROOT/'validation_launcher.py'),'--manifest-sha256',approved,'--origin-monotonic',repr(t0),'--run-id',runid,'--final-fd',str(final_w)]
        check_external_guard('before_launcher')
        launcher=subprocess.Popen(argv,pass_fds=(final_w,),close_fds=True,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        children.append(launcher)
        launch_identity=identity(launcher.pid);os.close(final_w)
        streams={final_r:('final',2052),launcher.stdout.fileno():('stdout',65536),launcher.stderr.fileno():('stderr',65536)}
        for fd in streams:os.set_blocking(fd,False)
        buffers={key:bytearray() for key in ('final','stdout','stderr')};truncated=False;read_error=False;deadline_enforced=False;term=False;killed=False
        while time.monotonic()<t0+600:
            check_external_guard('capture_loop')
            now=time.monotonic();rows=discover(os.getpid(),known,(supervisor.pid,))
            # poll performs waitpid(WNOHANG), regardless of pipe EOF.
            rc=launcher.poll()
            if now>=t0+580:
                deadline_enforced=True;term=True
                for row in rows:kill_verified(row,signal.SIGTERM)
            if now>=t0+590:
                killed=True
                for row in rows:kill_verified(row,signal.SIGKILL)
            if rc is not None:reap([row for row in rows if row['pid']!=launcher.pid])
            if rc is not None and not streams and not discover(os.getpid(),known,(supervisor.pid,)):break
            ready,_,_=select.select(list(streams),[],[],min(.02,max(0,t0+600-time.monotonic())))
            for fd in ready:
                name,quota=streams[fd]
                try:chunk=os.read(fd,8192)
                except BlockingIOError:continue
                except OSError:read_error=True;streams.pop(fd);continue
                if not chunk:streams.pop(fd);continue
                room=max(0,quota-len(buffers[name]));buffers[name].extend(chunk[:room])
                if len(chunk)>room:truncated=True
        check_external_guard('before_frame_acceptance')
        rc=launcher.poll();remaining=discover(os.getpid(),known,(supervisor.pid,));frame=None;frame_error=None
        try:frame=validate_frame(bytes(buffers['final']),approved,runid,t0,rc)
        except (ValueError,TypeError,KeyError,UnicodeError):frame_error='INVALID_OR_CONTRADICTORY_FRAME'
        raw_final=bytes(buffers['final']); frame_complete=(len(raw_final)>=4 and 2<=int.from_bytes(raw_final[:4],'little')<=2048 and len(raw_final)==4+int.from_bytes(raw_final[:4],'little') and not truncated)
        identity_match=bool(launch_identity and launch_identity['pid']==launcher.pid)
        # Identity was captured before polling; PID reuse never authorizes signalling.
        complete=bool(frame and frame['closure_status']=='INTERNAL_ACK_AND_REAP_OBSERVED' and rc is not None and identity_match and not streams and not remaining and not truncated and not read_error and not deadline_enforced)
        result={'schema_version':1,'manifest_sha256':approved,'run_id':runid,'origin_monotonic':t0,'launcher_rc':rc,'launcher_reaped':rc is not None,'launcher_identity_match':identity_match,'final_frame_complete':frame_complete,'final_frame_valid':frame is not None,'frame':frame,'frame_error':frame_error,'capture_truncated':truncated,'capture_read_error':read_error,'pipes_eof':not streams,'deadline_enforced':deadline_enforced,'remaining_identities':remaining,'collector_outcome':'CAPTURE_AND_RETURN_OBSERVED' if complete else 'UNVERIFIED','external_closure_status':'CLOSURE_PENDING','stdout_base64':base64.b64encode(buffers['stdout']).decode(),'stderr_base64':base64.b64encode(buffers['stderr']).decode(),'not_tested':['kernel-blocked IO','transient adversarial descendants','physical durability','collector own reap','external supervisor own reap']}
        result.update(guard_fields())
        # Writer gets no final-channel descriptor; closed fd inheritance by default.
        for fd in list(streams):
            try:os.close(fd)
            except OSError:pass
        if time.monotonic()>=t0+580:return 2
        check_external_guard('before_writer')
        payload=json.dumps(result,separators=(',',':')).encode();writer=subprocess.Popen([PYTHON,'-B',str(ROOT/'external_writer.py'),approved,repr(t0),runid],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,close_fds=True)
        children.append(writer)
        os.set_blocking(writer.stdin.fileno(),False);os.set_blocking(writer.stdout.fileno(),False)
        offset=0;receipt=bytearray();stdin_open=True;stdout_open=True
        while time.monotonic()<t0+580:
            check_external_guard('writer_loop')
            reads=[writer.stdout.fileno()] if stdout_open else []
            writes=[writer.stdin.fileno()] if stdin_open else []
            rr,ww,_=select.select(reads,writes,[],min(.02,max(0,t0+580-time.monotonic())))
            if ww:
                try:offset+=os.write(writer.stdin.fileno(),payload[offset:])
                except (BlockingIOError,InterruptedError):pass
                except BrokenPipeError:writer.stdin.close();stdin_open=False
                if stdin_open and offset==len(payload):writer.stdin.close();stdin_open=False
            if rr:
                try:part=os.read(writer.stdout.fileno(),4096)
                except BlockingIOError:part=None
                if part==b'':stdout_open=False
                elif part:
                    receipt.extend(part)
                    if len(receipt)>1024:break
            if writer.poll() is not None and not stdout_open:break
        check_external_guard('before_persistence_acceptance')
        writer_rc=writer.poll()
        try:expected={'bytes':len(payload),'sha256':hashlib.sha256(payload).hexdigest()};receipt_valid=json.loads(receipt)==expected
        except (ValueError,UnicodeError):receipt_valid=False
        persisted=writer_rc==0 and receipt_valid and offset==len(payload) and time.monotonic()<t0+580
        if not persisted:
            row=identity(writer.pid)
            if row:kill_verified(row,signal.SIGTERM)
            while time.monotonic()<t0+590 and writer.poll() is None:
                check_external_guard('writer_term_wait')
                time.sleep(min(.02,max(0,t0+590-time.monotonic())))
            row=identity(writer.pid)
            if row and writer.poll() is None:kill_verified(row,signal.SIGKILL)
            while time.monotonic()<t0+600 and writer.poll() is None:
                check_external_guard('writer_kill_wait')
                time.sleep(min(.02,max(0,t0+600-time.monotonic())))
        # No file IO after writer exit. stdout is bounded, nonblocking, advisory only.
        check_external_guard('before_summary')
        summary={'run_id':runid,'collector_outcome':result['collector_outcome'],'writer_reaped':writer.poll() is not None,'writer_rc':writer.poll(),'writer_receipt_valid':persisted,'external_closure_status':'CLOSURE_PENDING','external_supervisor_identity':supervisor_initial,'external_supervisor_reaped':False,'capture_bytes':len(payload),'capture_sha256':hashlib.sha256(payload).hexdigest()}
        summary.update(guard_fields())
        if time.monotonic()<t0+600:
            try:os.set_blocking(1,False);os.write(1,json.dumps(summary,separators=(',',':')).encode()+b'\n')
            except OSError:pass
        check_external_guard('before_return')
        return 0 if complete and persisted else 2
    try:return guarded_run()
    except GuardLost:
        # Irreversible rejection, including loss after capture.json was written.
        # No new child, file IO, retry, or acceptance of earlier capture/receipt.
        lost_at=time.monotonic();kill_at=min(lost_at+1,t0+590)
        while time.monotonic()<t0+600:
            rows=discover(os.getpid(),known,(supervisor.pid,))
            for row in rows:kill_verified(row,signal.SIGTERM if time.monotonic()<kill_at else signal.SIGKILL)
            for child in children:child.poll()
            direct={child.pid for child in children}
            reap([row for row in rows if row['pid'] not in direct])
            if not discover(os.getpid(),known,(supervisor.pid,)):break
            time.sleep(min(.02,max(0,t0+600-time.monotonic())))
        summary={'schema_version':1,'manifest_sha256':approved,'run_id':runid,
                 'collector_outcome':'UNVERIFIED','error_code':'EXTERNAL_GUARD_LOST',
                 'external_closure_status':'UNVERIFIED','prior_capture_valid_for_closure':False,
                 'writer_receipt_valid':False}
        summary.update(guard_fields())
        if time.monotonic()<t0+600:
            try:
                os.set_blocking(1,False)
                os.write(1,json.dumps(summary,separators=(',',':')).encode()+b'\n')
            except OSError:pass
        return 2

if __name__=='__main__':sys.exit(main())

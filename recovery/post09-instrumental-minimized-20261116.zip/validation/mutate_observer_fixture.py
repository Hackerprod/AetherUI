#!/usr/bin/env python3
"""Seven fixed negative fixtures; authoring only, NOT executed in V0.

No candidate/local module imports. Only manifest-authenticated static inputs and
launcher-authenticated synthetic positive outputs are read. No product fixtures.
"""
import argparse
import hashlib
import json
import os
import stat
import struct
from pathlib import Path, PurePosixPath

ROOT = Path('/RELOCATE/validation')
SHA_CHARS = set('0123456789abcdef')

def require(ok, reason):
    if not ok:
        raise ValueError(reason)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def valid_sha(value):
    return isinstance(value, str) and len(value) == 64 and set(value) <= SHA_CHARS

def canonical(rel):
    p = PurePosixPath(rel)
    require(isinstance(rel, str) and rel and not p.is_absolute() and
            '..' not in p.parts and str(p) == rel, 'noncanonical relative path')
    path = ROOT / rel
    current = ROOT
    require(not ROOT.is_symlink(), 'root symlink')
    for part in p.parts:
        current = current / part
        require(not current.is_symlink(), 'symlink in path')
    return path

def read_regular(path, limit):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        require(stat.S_ISREG(before.st_mode) and before.st_size <= limit, 'not bounded regular input')
        out = bytearray()
        while len(out) <= limit:
            b = os.read(fd, min(65536, limit + 1 - len(out)))
            if not b: break
            out.extend(b)
        after = os.fstat(fd)
        require(len(out) == before.st_size == after.st_size and before.st_mtime_ns == after.st_mtime_ns and
                before.st_ctime_ns == after.st_ctime_ns, 'input changed or too large')
        return bytes(out)
    finally:
        os.close(fd)

def artifact(spec, expected_path, limit):
    require(set(spec) == {'path', 'bytes', 'sha256'} and spec['path'] == expected_path and
            type(spec['bytes']) is int and 0 <= spec['bytes'] <= limit and valid_sha(spec['sha256']), 'artifact contract mismatch')
    data = read_regular(canonical(expected_path), limit)
    require(len(data) == spec['bytes'] and digest(data) == spec['sha256'], 'artifact authentication failed')
    return data

def authenticate_static(expected_sha):
    require(valid_sha(expected_sha), 'external manifest SHA invalid')
    data = read_regular(canonical('evidence.sha256.json'), 32 * 1024 * 1024)
    require(digest(data) == expected_sha, 'external manifest SHA mismatch')
    entries = json.loads(data)
    require(isinstance(entries, list), 'manifest must use list schema')
    table = {}
    for entry in entries:
        require(isinstance(entry, dict) and set(entry) == {'path', 'bytes', 'sha256'}, 'manifest row schema')
        path = entry['path']; canonical(path)
        require(path not in table and type(entry['bytes']) is int and entry['bytes'] >= 0 and valid_sha(entry['sha256']), 'manifest row invalid/duplicate')
        table[path] = entry
    # Caller authenticates this launcher before launch; this additionally verifies
    # its own bytes and every local static input used by this mutator. No local imports.
    required = ['mutate_observer_fixture.py', 'validation-phase-plan.json', 'helper_driver.cpp',
                'input/parse_post09_observer.py', 'input/native/tests/diagnostics/post09_observer.cpp',
                'input/native/tests/diagnostics/post09_observer_private.h']
    for path in required:
        require(path in table, 'missing required authority: ' + path)
        artifact(table[path], path, 16 * 1024 * 1024)

def authenticate_source(expected_sha):
    require(valid_sha(expected_sha), 'source authority SHA invalid')
    data = read_regular(canonical('run/synthetic-source-authority.json'), 65536)
    require(digest(data) == expected_sha, 'source authority changed')
    authority = json.loads(data)
    require(set(authority) == {'schema', 'source_root', 'phase', 'pairs'} and authority['schema'] == 1 and
            authority['source_root'] == str(ROOT) and authority['phase'] == 'helper-positive' and
            isinstance(authority['pairs'], list) and len(authority['pairs']) == 5, 'source authority schema')
    selected = None
    for i, pair in enumerate(authority['pairs'], 1):
        require(set(pair) == {'id','test_id','tree_id','data','close_status','parser','driver_rc','parser_rc','reaped','cleanup_verified'}, 'pair schema')
        require(pair['id'] == 'P' + str(i) and pair['test_id'] == i and pair['tree_id'] == 2 and
                pair['driver_rc'] == pair['parser_rc'] == 0 and pair['reaped'] is True and pair['cleanup_verified'] is True,
                'source not a successful reaped/cleaned positive')
        path = f'run/positive/run/observer-J-{i:02d}.bin'
        binary = artifact(pair['data'], path, 8 * 1024 * 1024)
        close = artifact(pair['close_status'], path + '.close-status', 80)
        parsed = json.loads(artifact(pair['parser'], f'run/parser/P{i}.json', 16 * 1024 * 1024))
        require(parsed.get('test_id') == i and parsed.get('tree_id') == 2 and parsed.get('missing_cases') == [] and
                all(parsed.get(k) is True for k in ['syntax_valid','protocol_valid','capture_complete','target_correlation_valid','observer_complete','not_a_product_test_verdict']),
                'positive parser not complete')
        require(parsed.get('close_evidence', {}).get('positive') is True and parsed['close_evidence'].get('record_valid') is True,
                'positive close evidence not accepted')
        if i == 1: selected = (binary, close)
    return selected

def split(data):
    require(data[:8] == b'AETHD092' and data[-16:-8] == b'ENDD092!', 'source not schema2')
    offset = 64; slots = []
    for unused in range(7):
        h = list(struct.unpack_from('<16I', data, offset)); offset += 64
        stop = offset + h[1]; records = []
        while offset < stop:
            length = struct.unpack_from('<I', data, offset + 16)[0]
            record = bytearray(data[offset:offset + 32 + length]); offset += len(record)
            records.append(record)
        require(offset == stop, 'source arena malformed')
        slots.append([h, records])
    require(offset + 16 == len(data), 'source slot framing')
    return bytearray(data[:64]), slots, bytearray(data[-16:])

def identity(r):
    return struct.unpack_from('<3I', r, 0)

def assemble(header, slots, footer):
    out = bytearray(header)
    for h, records in slots:
        for seq, record in enumerate(records): struct.pack_into('<I', record, 12, seq)
        h[1] = sum(len(record) for record in records); h[2] = len(records)
        out.extend(struct.pack('<16I', *h))
        for record in records: out.extend(record)
    out.extend(footer)
    return out

def mutate(binary, status, variant):
    header, slots, footer = split(binary); h, records = slots[0]; close = bytearray(status)
    require(h[0] == 1 and len(close) == 80 and close[:8] == b'CLSD092!', 'expected synthetic SD source')
    if variant == 'N1':
        start = next(i for i,r in enumerate(records) if identity(r)[0] == 3)
        raw = next(i for i,r in enumerate(records) if identity(r)[:2] == (2,2))
        core = records[start:raw]; del records[start:raw]
        raw = next(i for i,r in enumerate(records) if identity(r)[:2] == (2,2))
        records[raw + 1:raw + 1] = core
    elif variant == 'N2': h[7] += 1  # summary entry_count, events/end left intact
    elif variant == 'N3':
        index = next(i for i,r in enumerate(records) if identity(r)[:2] == (2,1))
        conflicting = bytearray(records[index]); struct.pack_into('<I', conflicting, 8, 2)
        records.insert(index + 1, conflicting)
    elif variant == 'N4':
        for i,r in enumerate(records):
            kind,point,node = identity(r)
            if kind != 6 or point != 5: continue
            side,idx,jdx,dtype,keylen,res = struct.unpack_from('<6I', r, 32)
            key = bytes(r[72:72 + keylen])
            if side == 1 and idx == jdx == 0 and key == b'font_style':
                del records[i]; break
        else: raise ValueError('required field not located')
    elif variant == 'N5':
        struct.pack_into('<I', header, 24, 1); struct.pack_into('<I', footer, 8, 1)
        h[3] |= 1; h[4] = 1; struct.pack_into('<I', close, 36, 1)
    elif variant not in ('N6','N7'): raise ValueError('variant not in fixed allowlist')
    output = assemble(header, slots, footer)
    if variant == 'N6': output = output[:-1]
    # Reframed mutants deliberately retain positive-looking close claims, except
    # N7. They are adversarial synthetic fixtures, not real new helper telemetry.
    struct.pack_into('<2Q', close, 40, len(output), len(output))
    if variant == 'N7':
        struct.pack_into('<I', close, 28, 0xffffffff); struct.pack_into('<I', close, 32, 5)
        struct.pack_into('<I', close, 36, 64)
    return bytes(output), bytes(close)

def write_new(path, data):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    canonical(str(path.relative_to(ROOT)))
    fd = os.open(path, os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW|os.O_CLOEXEC, 0o600)
    with os.fdopen(fd, 'wb') as stream: stream.write(data)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', required=True)
    ap.add_argument('--manifest-sha256', required=True)
    ap.add_argument('--source-authority-sha256', required=True)
    ap.add_argument('--variant', choices=[f'N{i}' for i in range(1,8)], required=True)
    args = ap.parse_args()
    require(args.root == str(ROOT), 'root is not frozen V0 root')
    authenticate_static(args.manifest_sha256)
    binary, close = authenticate_source(args.source_authority_sha256)
    output, output_close = mutate(binary, close, args.variant)
    base = f'run/negative-{args.variant[1:]}/run/observer-J-01.bin'
    write_new(canonical(base), output); write_new(canonical(base + '.close-status'), output_close)
    receipt = {'schema':1, 'variant':args.variant, 'source_authority_sha256':args.source_authority_sha256,
               'synthetic_only':True, 'does_not_certify_actual_helper_close_of_mutated_file':True,
               'outputs':[{'path':base,'bytes':len(output),'sha256':digest(output)},
                          {'path':base + '.close-status','bytes':len(output_close),'sha256':digest(output_close)}]}
    write_new(canonical(f'run/negative-{args.variant[1:]}/mutation.json'),
              (json.dumps(receipt, indent=2) + '\n').encode('utf-8'))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())

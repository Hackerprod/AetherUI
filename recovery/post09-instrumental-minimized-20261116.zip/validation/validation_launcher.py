#!/usr/bin/env python3
"""V0-authored validation launcher. No product command or candidate main entry."""
import argparse
import ctypes
import hashlib
import json
import math
import struct
import os
from pathlib import Path
import re
import select
import signal
import stat
import subprocess
import sys
import time
sys.dont_write_bytecode=True
START=None
ROOT=Path(__file__).resolve().parent
PYTHON='/RELOCATE/python3'
COMPILER='/usr/bin/x86_64-linux-gnu-g++-14'
MODULES=('supervisor.py','guard_deadlines.py','manifest_contract.py','frozen_custody.py','concurrency_preflight.py','verify_comparability.py','parse_post09_observer.py','validation_launcher.py','validation_budget_guard.py','validation_syntax.py','validation_supervision.py','validation_job.py','mutate_observer_fixture.py','external_collector.py','external_supervisor.py','external_writer.py','external_contract.py')

def digest(path):
    h=hashlib.sha256()
    with open(path,'rb') as stream:
        for chunk in iter(lambda:stream.read(1048576),b''):h.update(chunk)
    return h.hexdigest()
def plain(path):
    path=Path(path)
    for ancestor in [path,*path.parents]:
        if ancestor.is_symlink():raise RuntimeError('SYMLINK:'+str(ancestor))
    if not stat.S_ISREG(path.lstat().st_mode):raise RuntimeError('NOT_REGULAR:'+str(path))
    return path

def load_json(path):
    def unique(items):
        value={}
        for key,item in items:
            if key in value:raise RuntimeError('DUPLICATE_JSON_KEY')
            value[key]=item
        return value
    return json.loads(plain(path).read_text(),object_pairs_hook=unique)
def save(path,value):
    path=Path(path);tmp=path.with_name(path.name+'.tmp')
    with open(tmp,'x') as stream:json.dump(value,stream,indent=2);stream.write('\n');stream.flush();os.fsync(stream.fileno())
    os.replace(tmp,path)
def identity(pid):
    try:
        text=Path('/proc',str(pid),'stat').read_text();row=text[text.rfind(')')+2:].split()
        return dict(pid=pid,ppid=int(row[1]),start=row[19],state=row[0])
    except (FileNotFoundError,ProcessLookupError):return None

def same(record):
    got=identity(record['pid']);return got is not None and got['start']==record['start']
def signal_identity(record,sig):
    if not same(record):return
    try:fd=os.pidfd_open(record['pid'])
    except ProcessLookupError:return
    try:
        if same(record):signal.pidfd_send_signal(fd,sig,None,0)
    except ProcessLookupError:pass
    finally:os.close(fd)
def owned(known,exclude=()):
    rows={}
    for path in Path('/proc').iterdir():
        if path.name.isdigit():
            row=identity(int(path.name))
            if row is not None:rows[row['pid']]=row
    children={os.getpid()};change=True
    while change:
        change=False
        for pid,row in rows.items():
            if row['ppid'] in children and pid not in children:children.add(pid);change=True
    for pid in children-{os.getpid(),*exclude}:known[(pid,rows[pid]['start'])]=rows[pid]
    return [row for row in known.values() if row['pid'] not in exclude and same(row)]
def reap_adopted(rows,exclude=()):
    for row in rows:
        got=identity(row['pid'])
        if got and got['start']==row['start'] and got['ppid']==os.getpid() and row['pid'] not in exclude:
            try:os.waitpid(row['pid'],os.WNOHANG)
            except ChildProcessError:pass

class Validation:
    def __init__(self,approved):
        self.approved=approved;self.run=ROOT/'run';self.guard=None;self.children={};self.cancelled=[]
        self.work=START+480;self.deadline=START+570;self.results=[];self.driver_hash=None;self.authority_hash=None;self.used_twins=[]
        if not re.fullmatch('[0-9a-f]{64}',approved):raise RuntimeError('APPROVED_SHA_FORMAT')
        raw=plain(ROOT/'evidence.sha256.json').read_bytes()
        if hashlib.sha256(raw).hexdigest()!=approved:raise RuntimeError('MANIFEST_NOT_APPROVED')
        rows=load_json(ROOT/'evidence.sha256.json')
        if not isinstance(rows,list):raise RuntimeError('MANIFEST_LIST_REQUIRED')
        self.members={}
        for row in rows:
            if not isinstance(row,dict) or set(row)!={'path','bytes','sha256'}:raise RuntimeError('MANIFEST_SCHEMA')
            key=row['path']
            if not isinstance(key,str) or not key or key.startswith('/') or '\\' in key or '\x00' in key or any(x in ('','.','..') for x in key.split('/')) or key in self.members or key=='evidence.sha256.json' or key.split('/')[0] in ('run','external-output'):raise RuntimeError('MANIFEST_PATH')
            if type(row['bytes']) is not int or row['bytes']<0 or not isinstance(row['sha256'],str) or not re.fullmatch('[0-9a-f]{64}',row['sha256']):raise RuntimeError('MANIFEST_RECORD')
            self.members[key]=row
        # Authenticate every executable Python helper before any candidate/local import.
        # This launcher itself imports no local modules.
        for name in MODULES:self.verify_member(name)
        for name in ('validation-recipe.json','validation-phase-plan.json','validation-supervision-plan.json','validation-tools-authority.json','validation-include-authority.json','input-twin-authority.json','external-recipe.json'):self.verify_member(name)
        self.recipe=load_json(ROOT/'validation-recipe.json');self.plan=load_json(ROOT/'validation-phase-plan.json');self.supervision=load_json(ROOT/'validation-supervision-plan.json')
        if self.recipe['root']!=str(ROOT) or self.plan['root']!=str(ROOT):raise RuntimeError('ROOT_MISMATCH')
        if self.recipe['limits']!={'absolute':600,'work':480,'close_reserve':120,'syntax_bootstrap':30,'compile':180,'helper_parser':90,'supervision':180,'scenario':60}:raise RuntimeError('BUDGET_RECIPE')
        self.tools=load_json(ROOT/'validation-tools-authority.json');self.headers=load_json(ROOT/'validation-include-authority.json');self.twins=load_json(ROOT/'input-twin-authority.json')
        self.verify_tool(PYTHON);self.verify_tool(COMPILER)
        if self.run.exists() or self.run.is_symlink():raise RuntimeError('OUTPUT_ROOT_EXISTS_NO_RESUME')
        self.run.mkdir(mode=0o700)
        for name in ('logs','bin','parser','positive','home','tmp'):(self.run/name).mkdir(mode=0o700)
        (self.run/'positive/run').mkdir(mode=0o700)
        self.env={'PATH':'/usr/bin:/bin','LC_ALL':'C','LANG':'C','TZ':'UTC','HOME':str(self.run/'home'),'TMPDIR':str(self.run/'tmp'),'OMP_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','MKL_NUM_THREADS':'1','PYTHONDONTWRITEBYTECODE':'1'}
        if self.recipe['environment']!=self.env:raise RuntimeError('ENVIRONMENT_RECIPE')
        if ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)!=0:raise RuntimeError('SUBREAPER_REQUIRED')
        for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):signal.signal(sig,lambda number,frame:self.cancelled.append(number))
        self.start_guard()
        self.verify_members()
        self.verify_external_authority()
        self.check_plan()

    def verify_member(self,name):
        row=self.members.get(name)
        if row is None:raise RuntimeError('UNFROZEN_INPUT:'+name)
        p=plain(ROOT/name)
        if p.stat().st_size!=row['bytes'] or digest(p)!=row['sha256']:raise RuntimeError('FROZEN_INPUT_CHANGED:'+name)
    def verify_members(self):
        expected=set(self.members);actual=set();dirs=set()
        for directory,subdirs,names in os.walk(ROOT,followlinks=False):
            base=Path(directory)
            for name in list(subdirs):
                child=base/name
                if child.is_symlink():raise RuntimeError('INPUT_DIRECTORY_SYMLINK')
                if base==ROOT and name in ('run','external-output'):subdirs.remove(name)
                else:dirs.add(str(child.relative_to(ROOT)))
            for name in names:
                key=str((base/name).relative_to(ROOT))
                if key!='evidence.sha256.json':actual.add(key)
        wantdirs={str(parent) for key in expected for parent in Path(key).parents if str(parent)!='.'}
        if actual!=expected or dirs!=wantdirs:raise RuntimeError('INPUT_SET_CHANGED')
        for name in expected:
            self.ensure_work();self.verify_member(name)
    def verify_tool(self,path):
        rows=[row for row in self.tools['records'] if row['path']==path]
        if len(rows)!=1:raise RuntimeError('TOOL_AUTHORITY:'+path)
        row=rows[0];p=Path(path)
        if str(p.resolve(strict=True))!=row['resolved'] or p.stat().st_size!=row['bytes'] or digest(p)!=row['sha256']:raise RuntimeError('TOOL_CHANGED:'+path)
    def verify_external_authority(self):
        for row in self.tools['records']:
            self.ensure_work();self.verify_tool(row['path'])
        for path,row in self.headers['headers'].items():
            self.ensure_work();p=Path(path)
            if p.stat().st_size!=row['bytes'] or digest(p)!=row['sha256']:raise RuntimeError('HEADER_CHANGED:'+path)
        for lexical,resolved in self.headers.get('aliases',{}).items():
            if str(Path(lexical).resolve(strict=True))!=resolved:raise RuntimeError('HEADER_ALIAS_CHANGED')
    def verify_used_twins(self):
        if self.twins.get('schema')!='v0-twin-source-authority-v1':raise RuntimeError('TWIN_AUTHORITY_SCHEMA')
        origin=Path(self.twins['source_manifest'])
        if digest(plain(origin))!=self.twins['source_manifest_sha256']:raise RuntimeError('TWIN_SOURCE_MANIFEST_CHANGED')
        for relative in self.used_twins:
            row=self.twins['files'].get(relative)
            if not isinstance(row,dict) or row.get('identical') is not True or row.get('J_sha256')!=row.get('Hc_sha256'):raise RuntimeError('USED_HEADER_NOT_IDENTICAL:'+relative)
            expected=origin.parent/'Hc'/relative.removeprefix('input/')
            if row.get('Hc_path')!=str(expected):raise RuntimeError('TWIN_PATH_NOT_DERIVED')
            if digest(plain(expected))!=row['Hc_sha256'] or digest(plain(ROOT/relative))!=row['J_sha256']:raise RuntimeError('USED_TWIN_CHANGED:'+relative)

    def ensure_work(self,phase_end=None):
        if self.guard is not None and self.guard.poll() is not None:raise RuntimeError('GLOBAL_GUARD_EXITED_EARLY')
        if self.cancelled:raise RuntimeError('VALIDATION_CANCELLED:'+repr(self.cancelled))
        if time.monotonic()>=min(self.work,phase_end if phase_end is not None else self.work):raise RuntimeError('VALIDATION_WORK_OR_PHASE_CAP')
    def ack(self,cap):
        data=b''
        while b'\n' not in data:
            remaining=cap-time.monotonic()
            if remaining<=0:raise RuntimeError('GLOBAL_GUARD_ACK_CAP')
            poller=select.poll();poller.register(self.ackfd,select.POLLIN|select.POLLHUP|select.POLLERR)
            if poller.poll(max(1,int(min(.05,remaining)*1000))):
                part=os.read(self.ackfd,4096)
                if not part:raise RuntimeError('GLOBAL_GUARD_CHANNEL_LOST')
                data+=part
                if len(data)>1024:raise RuntimeError('GLOBAL_GUARD_ACK_OVERSIZE')
        if data.count(b'\n')!=1 or not data.endswith(b'\n'):raise RuntimeError('GLOBAL_GUARD_FRAMING')
        return json.loads(data)
    def start_guard(self):
        readfd,writefd=os.pipe();ackread,ackwrite=os.pipe();me=identity(os.getpid())
        argv=[PYTHON,'-B',str(ROOT/'validation_budget_guard.py'),'--manifest-sha256',self.approved,'--parent',str(os.getpid()),'--parent-start',me['start'],'--start',str(START),'--work-deadline',str(self.work),'--deadline',str(START+600),'--control-fd',str(readfd),'--ack-fd',str(ackwrite)]
        with open(self.run/'global-guard.stdout','xb') as out,open(self.run/'global-guard.stderr','xb') as err:
            self.guard=subprocess.Popen(argv,cwd=ROOT,env=self.env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,pass_fds=(readfd,ackwrite),start_new_session=True)
        os.close(readfd);os.close(ackwrite);self.controlfd=writefd;self.ackfd=ackread
        response=self.ack(min(self.work,START+30))
        if response.get('ack')!='ready' or response.get('pid')!=self.guard.pid:raise RuntimeError('GLOBAL_GUARD_NOT_READY')
        save(self.run/'global-guard-start.json',{'argv':argv,'ready':response,'budget_origin':START,'work_deadline':self.work,'deadline':self.deadline})

    def check_plan(self):
        if self.plan['totals']!={'compile_invocations':1,'driver_invocations':5,'mutator_invocations':7,'parser_invocations':12}:raise RuntimeError('PLAN_CARDINALITY')
        if [x['id'] for x in self.plan['positive_cases']]!=['P'+str(i) for i in range(1,6)] or [x['id'] for x in self.plan['negative_cases']]!=['N'+str(i) for i in range(1,8)]:raise RuntimeError('PLAN_IDS')
        argv=self.plan['compile']['argv']
        if argv[0]!=COMPILER or argv[-2:]!=['-o',str(self.run/'bin/observer-driver')] or argv.count('-o')!=1:raise RuntimeError('COMPILE_ARGV')
        allowed_flags={'-DAETHER_EXPORTS','-Daether_core_EXPORTS','-g','-std=gnu++20','-fPIC','-fvisibility=hidden','-fvisibility-inlines-hidden','-Wall','-Wextra','-pedantic','-ffp-contract=off','-save-temps=obj','-MD','-MF','-o'}
        allowed_paths={str(ROOT/'helper_driver.cpp'),str(ROOT/'input/native/tests/diagnostics/post09_observer.cpp'),str(self.run/'bin/observer-driver.d'),str(self.run/'bin/observer-driver')}
        allowed_includes={'-I'+str(ROOT/'input/native/include'),'-I'+str(ROOT/'input/native/src/rendering/preparation/include')}
        if any(x not in allowed_flags|allowed_paths|allowed_includes for x in argv[1:]):raise RuntimeError('UNAPPROVED_COMPILER_OPTION')
        for i,case in enumerate(self.plan['positive_cases'],1):
            expected=[str(self.run/'bin/observer-driver'),'--test-id',str(i)]
            if case['driver']['argv']!=expected or case['driver']['environment_overlay']!={'AETHER_POST09_TEST_ID':str(i),'AETHER_POST09_TREE_ID':'2','AETHER_POST09_OUTPUT':str(self.run/'positive/run'/('observer-J-'+str(i).zfill(2)+'.bin'))}:raise RuntimeError('POSITIVE_RECIPE')
            self.check_parser(case['parser'],case['id'])
        for i,case in enumerate(self.plan['negative_cases'],1):
            expected=[PYTHON,'-B',str(ROOT/'mutate_observer_fixture.py'),'--root',str(ROOT),'--manifest-sha256','${APPROVED_MANIFEST_SHA256}','--source-authority-sha256','${SYNTHETIC_SOURCE_AUTHORITY_SHA256}','--variant','N'+str(i)]
            if case['mutator']['argv']!=expected:raise RuntimeError('MUTATOR_RECIPE')
            self.check_parser(case['parser'],case['id'])
        if self.recipe['supervision_scenarios']!=['S1','S2','S3'] or [x['id'] for x in self.supervision['scenarios']]!=['S1','S2','S3']:raise RuntimeError('SCENARIO_RECIPE')
        for item in self.supervision['scenarios']:
            scenario=item['id']
            expected=[PYTHON,str(ROOT/'validation_supervision.py'),'--scenario',scenario,'--manifest-sha256','{APPROVED_MANIFEST_SHA256}','--deadline','{EFFECTIVE_SCENARIO_DEADLINE}']
            if item['argv']!=expected or item['cap_seconds']!=60 or item['expected_exit']!=0 or item['expected_report_status']!='EXPECTED_SCENARIO_OBSERVED_CLOSURE_PENDING' or item['expected_causal_gate']!='CLOSED_AWAITING_D' or item['report']!=str(self.run/'scenarios'/scenario/'run/REPORT.json'):raise RuntimeError('SCENARIO_CONTRACT')
    def check_parser(self,spec,caseid):
        data=(self.run/'positive/run'/('observer-J-'+caseid[1:].zfill(2)+'.bin')) if caseid.startswith('P') else (self.run/('negative-'+caseid[1:])/'run/observer-J-01.bin')
        argv=[PYTHON,'-B',str(ROOT/'input/parse_post09_observer.py'),'--input',str(data),'--close-status',str(data)+'.close-status','--output',str(self.run/'parser'/(caseid+'.json'))]
        if spec['argv']!=argv or spec['output']!=argv[-1] or spec['cap_seconds']!=10:raise RuntimeError('PARSER_RECIPE')

    def stop_work(self):
        exclude=(self.guard.pid,) if self.guard else ()
        for row in owned(self.children,exclude):signal_identity(row,signal.SIGTERM)
        cutoff=min(time.monotonic()+2,self.deadline)
        while time.monotonic()<cutoff:
            rows=owned(self.children,exclude);reap_adopted(rows,exclude)
            if not rows:return
            time.sleep(.02)
        for row in owned(self.children,exclude):signal_identity(row,signal.SIGKILL)
        while time.monotonic()<self.deadline:
            rows=owned(self.children,exclude);reap_adopted(rows,exclude)
            if not owned(self.children,exclude):return
            time.sleep(.02)
        raise RuntimeError('VALIDATION_CLEANUP_CAP')
    def invoke(self,ident,spec,phase_end,kind,substitutions=None):
        self.ensure_work(phase_end)
        for name in MODULES:self.verify_member(name)
        argv=[(substitutions or {}).get(x,x) for x in spec['argv']]
        if any('${' in x for x in argv):raise RuntimeError('UNRESOLVED_SUBSTITUTION')
        if kind=='compile':self.verify_tool(COMPILER)
        elif kind=='driver':
            if self.driver_hash is None or digest(self.run/'bin/observer-driver')!=self.driver_hash:raise RuntimeError('DRIVER_BINARY_CHANGED')
        else:self.verify_tool(PYTHON)
        if spec.get('cwd',str(ROOT))!=str(ROOT):raise RuntimeError('INVOCATION_CWD')
        env=dict(self.env);env.update(spec.get('environment_overlay',{}))
        cap=min(time.monotonic()+spec['cap_seconds'],self.work,phase_end)
        outpath=self.run/'logs'/(ident+'.stdout');errpath=self.run/'logs'/(ident+'.stderr')
        self.ensure_work(phase_end)
        start=time.monotonic();child=None;termination=None
        with open(outpath,'xb') as out,open(errpath,'xb') as err:
            child=subprocess.Popen(argv,cwd=ROOT,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
            first=identity(child.pid)
            if first:self.children[(first['pid'],first['start'])]=first
            while child.poll() is None:
                owned(self.children,(self.guard.pid,))
                if self.guard.poll() is not None:
                    termination='GLOBAL_GUARD_LOST';break
                if self.cancelled or time.monotonic()>=cap:
                    termination='CANCELLED' if self.cancelled else 'EFFECTIVE_CAP';break
                time.sleep(.02)
            if termination:self.stop_work()
            rc=child.wait(timeout=max(.001,self.deadline-time.monotonic()))
        rows=owned(self.children,(self.guard.pid,));reap_adopted(rows,(self.guard.pid,child.pid))
        remaining=owned(self.children,(self.guard.pid,))
        if remaining:
            self.stop_work();termination=termination or 'DESCENDANTS_AFTER_RETURN'
        cleanup=not owned(self.children,(self.guard.pid,))
        result={'id':ident,'kind':kind,'argv':argv,'environment':env,'start_monotonic':start,'end_monotonic':time.monotonic(),'effective_deadline':cap,'rc':rc,'reaped':True,'cleanup_verified':cleanup,'termination':termination,'stdout':str(outpath),'stderr':str(errpath),'stdout_bytes':outpath.stat().st_size,'stdout_sha256':digest(outpath),'stderr_bytes':errpath.stat().st_size,'stderr_sha256':digest(errpath),'direct_identity':first,'observed_descendants':[x for x in self.children.values() if x['pid']!=self.guard.pid]}
        self.results.append(result);save(self.run/'logs'/(ident+'.json'),result)
        if termination or not cleanup:raise RuntimeError('INVOCATION_OPERATIONAL_FAILURE:'+ident)
        self.ensure_work(phase_end)
        return result
    def expect(self,result,expected):
        if result['rc']!=expected:raise RuntimeError('EXIT_EXPECTATION:'+result['id']+':'+str(result['rc'])+'!='+str(expected))
    def parser_expect(self,spec,result):
        self.expect(result,spec['expected']['exit_code']);report=load_json(spec['output'])
        for pointer,expected in spec['expected']['json_equals'].items():
            actual=report
            for key in pointer.split('/')[1:]:actual=actual[int(key)] if isinstance(actual,list) else actual[key]
            if type(actual)!=type(expected) or actual!=expected:raise RuntimeError('PARSER_EXPECTATION:'+spec['id']+':'+pointer)
        return report

    def dependency_gate(self,phase_end):
        self.ensure_work(phase_end);gate=self.plan['dependency_gate'];paths=set();cwd_metadata=[]
        translations={str(self.run/'bin/observer-driver-helper_driver.ii'):str(ROOT/'helper_driver.cpp'),
                      str(self.run/'bin/observer-driver-post09_observer.ii'):str(ROOT/'input/native/tests/diagnostics/post09_observer.cpp')}
        if len(gate['required_preprocessed'])!=2 or set(gate['required_preprocessed'])!=set(translations):raise RuntimeError('PREPROCESSOR_TU_SET')
        for filename in gate['required_preprocessed']:
            text=plain(Path(filename)).read_text();lines=text.splitlines();markers=[]
            for index,line in enumerate(lines):
                match=re.fullmatch(r'#\s+(\d+)\s+"([^"\n]+)"((?:\s+\d+)*)\s*',line)
                if match:markers.append((index,match.group(1),match.group(2),match.group(3)))
                elif re.match(r'^#\s+\d+',line):raise RuntimeError('MALFORMED_LINE_MARKER')
            if not markers:raise RuntimeError('PREPROCESSOR_LINE_MARKERS_MISSING')
            first=markers[0];tu=translations[filename]
            if lines[first[0]]!='# 0 "'+tu+'"':raise RuntimeError('PREPROCESSOR_FIRST_TU_MARKER')
            position=first[0]+1;cwd='# 1 "'+str(ROOT)+'//"'
            if position>=len(lines) or lines[position]!=cwd or sum(line==cwd for line in lines)!=1:raise RuntimeError('CWD_MARKER_POSITION_OR_COUNT')
            cwd_metadata.append({'preprocessed':filename,'translation_unit':tu,'line':position+1,'marker':cwd,'classification':'CWD_METADATA_NOT_DEPENDENCY'})
            for index,number,value,flags in markers:
                if index==position:continue
                if value in ('<built-in>','<command-line>'):continue
                if value.startswith('<'):raise RuntimeError('UNKNOWN_PREPROCESSOR_SOURCE')
                # No other directory-looking marker is exempted from file authority.
                paths.add(str(Path(value) if Path(value).is_absolute() else ROOT/value))
        dep=plain(Path(gate['depfile'])).read_text().replace('\\\n',' ')
        if ':' not in dep:raise RuntimeError('DEPFILE_FORMAT')
        # The frozen root and toolchain paths have no spaces. Reject escapes or
        # exotic Make syntax rather than silently dropping a dependency.
        rhs=dep.split(':',1)[1]
        if '\\' in rhs or '$' in rhs or '#' in rhs:raise RuntimeError('UNSUPPORTED_DEPFILE_ESCAPE')
        paths.update(str(Path(value) if Path(value).is_absolute() else ROOT/value) for value in rhs.split())
        required={str(ROOT/'helper_driver.cpp'),str(ROOT/'input/native/tests/diagnostics/post09_observer.cpp')}
        if not required<=paths:raise RuntimeError('BOTH_TRANSLATION_UNITS_REQUIRED')
        evidence=[]
        for name in sorted(paths):
            self.ensure_work(phase_end);p=Path(name);resolved=str(p.resolve(strict=True))
            if Path(resolved).is_relative_to(ROOT):
                relative=str(Path(resolved).relative_to(ROOT));self.verify_member(relative);record=self.members[relative]
                if relative.startswith('input/native/') and relative not in self.used_twins:self.used_twins.append(relative)
            else:
                target=self.headers.get('aliases',{}).get(name,name)
                if target!=resolved or target not in self.headers['headers']:raise RuntimeError('UNKNOWN_EXTERNAL_HEADER:'+name)
                record=self.headers['headers'][target]
                if p.stat().st_size!=record['bytes'] or digest(p)!=record['sha256']:raise RuntimeError('EXTERNAL_HEADER_CHANGED')
            evidence.append({'path':name,'resolved':resolved,'bytes':record['bytes'],'sha256':record['sha256']})
        self.verify_external_authority();self.verify_used_twins();save(self.run/'dependency-gate.json',{'status':'PASS','inputs':evidence,'cwd_metadata':cwd_metadata,'both_translation_units':True,'no_posthoc_authority':True})
        self.driver_hash=digest(plain(self.run/'bin/observer-driver'))
        save(self.run/'driver-authority.json',{'path':str(self.run/'bin/observer-driver'),'bytes':(self.run/'bin/observer-driver').stat().st_size,'sha256':self.driver_hash,'compile_invocations':1})
    def freeze_synthetic(self):
        def record(path):
            p=plain(Path(path));return {'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':digest(p)}
        pairs=[]
        for i,case in enumerate(self.plan['positive_cases'],1):
            dr=next(x for x in self.results if x['id']==case['id']+'-driver');pr=next(x for x in self.results if x['id']==case['id']+'-parser')
            if any(x['rc']!=0 or x['reaped'] is not True or x['cleanup_verified'] is not True for x in (dr,pr)):raise RuntimeError('POSITIVE_AUTHORITY_PRECONDITION')
            data=case['driver']['environment_overlay']['AETHER_POST09_OUTPUT']
            pairs.append({'id':case['id'],'test_id':i,'tree_id':2,'data':record(data),'close_status':record(data+'.close-status'),'parser':record(case['parser']['output']),'driver_rc':0,'parser_rc':0,'reaped':True,'cleanup_verified':True})
        path=self.run/'synthetic-source-authority.json'
        with open(path,'x') as stream:json.dump({'schema':1,'source_root':str(ROOT),'phase':'helper-positive','pairs':pairs},stream,indent=2);stream.write('\n');stream.flush();os.fsync(stream.fileno())
        self.authority_hash=digest(path)
        save(self.run/'synthetic-source-authority-pin.json',{'sha256':self.authority_hash,'created_after_five_complete_positive_pairs':True})

    def execute(self):
        syntax_end=min(START+30,self.work)
        spec={'argv':[PYTHON,'-B',str(ROOT/'validation_syntax.py'),'--manifest-sha256',self.approved],'cap_seconds':30}
        self.expect(self.invoke('syntax-bootstrap',spec,syntax_end,'syntax'),0)
        compile_end=min(time.monotonic()+180,self.work)
        self.expect(self.invoke('compile-driver',self.plan['compile'],compile_end,'compile'),0)
        helper_end=min(time.monotonic()+90,self.work)
        expected_outputs={Path(x) for x in self.plan['compile']['outputs']}
        if set((self.run/'bin').iterdir())!=expected_outputs:raise RuntimeError('COMPILE_OUTPUT_SET')
        for path in expected_outputs:plain(path)
        self.dependency_gate(helper_end)
        for case in self.plan['positive_cases']:
            self.expect(self.invoke(case['id']+'-driver',case['driver'],helper_end,'driver'),0)
            result=self.invoke(case['id']+'-parser',case['parser'],helper_end,'parser');self.parser_expect(case['parser'],result)
        self.freeze_synthetic()
        for case in self.plan['negative_cases']:
            if digest(self.run/'synthetic-source-authority.json')!=self.authority_hash:raise RuntimeError('SYNTHETIC_AUTHORITY_CHANGED')
            replace={'${APPROVED_MANIFEST_SHA256}':self.approved,'${SYNTHETIC_SOURCE_AUTHORITY_SHA256}':self.authority_hash}
            self.expect(self.invoke(case['id']+'-mutator',case['mutator'],helper_end,'mutator',replace),0)
            result=self.invoke(case['id']+'-parser',case['parser'],helper_end,'parser');self.parser_expect(case['parser'],result)
        supervision_end=min(time.monotonic()+180,self.work)
        for item in self.supervision['scenarios']:
            scenario=item['id'];cap=min(time.monotonic()+60,supervision_end,self.work)
            replacements={'{APPROVED_MANIFEST_SHA256}':self.approved,'{EFFECTIVE_SCENARIO_DEADLINE}':str(cap)}
            spec={'argv':item['argv'],'cap_seconds':60}
            result=self.invoke(scenario,spec,supervision_end,'supervision',replacements);self.expect(result,item['expected_exit'])
            report=load_json(item['report'])
            if report.get('scenario')!=scenario or report.get('status')!=item['expected_report_status'] or report.get('causal_gate')!=item['expected_causal_gate'] or report.get('not_a_product_test_verdict') is not True:raise RuntimeError('SCENARIO_EXPECTATION:'+scenario)
            ackpath=self.run/'scenarios'/scenario/'run/closure-ack.json'
            if digest(plain(ackpath))!=report.get('closure_ack_sha256'):raise RuntimeError('SCENARIO_ACK_HASH')
            closure=load_json(ackpath)
            if closure.get('guard_alive_before_persistence') is not True or closure.get('ack')!={'ack':'done','identified_work_exited':True,'reaping':'NOT_OBSERVED_BY_GUARD'}:raise RuntimeError('SCENARIO_ACK_CONTRACT')
        self.verify_members();self.verify_external_authority();self.verify_used_twins()
    def finish(self,success,error):
        if not success:self.stop_work()
        status='READY_FOR_D_REVIEW' if success else 'REJECTED'
        planned=['syntax-bootstrap','compile-driver']+[x for i in range(1,6) for x in ('P'+str(i)+'-driver','P'+str(i)+'-parser')]+[x for i in range(1,8) for x in ('N'+str(i)+'-mutator','N'+str(i)+'-parser')]+['S1','S2','S3']
        not_run=[name for name in planned if name not in {x['id'] for x in self.results}]
        report={'not_run':not_run,'status':status,'closure':'CLOSURE_PENDING','causal_gate':'CLOSED_AWAITING_D' if success else 'CLOSED_REJECTED','not_a_product_test':True,'error':error,'invocations':self.results,'limits':self.recipe['limits'],'authority_sha256':self.authority_hash,'not_tested':self.plan['not_tested_variants']+['Coordinator product preflight/invoke/observe_test','G1 product behavior','V2/V3','adversarial transient file replacement','storage durability or close of close-status fd']}
        save(self.run/'validation-results.json',report)
        runtime=[]
        for path in sorted(self.run.rglob('*')):
            if time.monotonic()>=self.deadline:raise RuntimeError('RUNTIME_MANIFEST_CLOSURE_CAP')
            if path.is_symlink():raise RuntimeError('RUNTIME_SYMLINK')
            if path.is_file() and path.name!='runtime-artifacts.json':runtime.append({'path':str(path.relative_to(ROOT)),'bytes':path.stat().st_size,'sha256':digest(path)})
        save(self.run/'runtime-artifacts.json',{'closure':'BEFORE_GUARD_RELEASE','self_excluded':True,'files':runtime})
        # Internal guard release occurs only in close_internal(), including failures.

    def close_internal(self,frame):
        try:
            if self.guard is None:raise RuntimeError('GUARD_UNAVAILABLE')
            self.stop_work()
            remaining=owned(self.children,(self.guard.pid,))
            frame['pending_work_identities_count']=len(remaining)
            frame['cleanup_verified']=not remaining
            if remaining:raise RuntimeError('CLEANUP_FAILED')
            if time.monotonic()>=START+570:raise RuntimeError('CLOSURE_DEADLINE')
            os.set_blocking(self.controlfd,False)
            if os.write(self.controlfd,b'{"done":true}\n')!=14:raise RuntimeError('CONTROL_WRITE_FAILED')
            response=self.ack(START+570)
            frame['ack_received']=True
            # Preserve bounded JSON ACK exactly; unexpected shapes are invalid.
            if len(json.dumps(response,separators=(',',':')).encode())>512:raise RuntimeError('ACK_OVERSIZE')
            frame['ack_valid']=response=={'ack':'done','identified_work_exited':True,'reaping':'LAUNCHER_RESPONSIBILITY'}
            frame['ack_payload']=response if frame['ack_valid'] else None
            if not frame['ack_valid']:raise RuntimeError('ACK_INVALID')
            remaining_time=START+570-time.monotonic()
            if remaining_time<=0:raise RuntimeError('CLOSURE_DEADLINE')
            frame['guard_rc']=self.guard.wait(timeout=remaining_time)
            frame['guard_reaped']=True
            if frame['guard_rc']!=0:raise RuntimeError('GUARD_RC_FAILED')
            if time.monotonic()>=START+570:raise RuntimeError('CLOSURE_DEADLINE')
            frame['closure_status']='INTERNAL_ACK_AND_REAP_OBSERVED'
        except BaseException as exc:
            code=str(exc)
            allowed={'GUARD_UNAVAILABLE','CLEANUP_FAILED','CLOSURE_DEADLINE','CONTROL_WRITE_FAILED','ACK_OVERSIZE','ACK_INVALID','GUARD_RC_FAILED'}
            frame['closure_error_code']=code if code in allowed else 'INTERNAL_CLOSURE_FAILED'
            frame['closure_status']='FAILED'
            # Collector remains responsible for live identities until the common ceiling.
            if self.guard is not None:
                try:
                    rc=self.guard.poll()
                    if rc is not None:frame['guard_rc']=rc;frame['guard_reaped']=True
                except BaseException:
                    frame['closure_error_code']='GUARD_REAP_OBSERVATION_FAILED'
            try:
                pending=owned(self.children,(self.guard.pid,) if self.guard else ())
                frame['pending_work_identities_count']=len(pending)
                frame['cleanup_verified']=not pending
            except BaseException:
                frame['pending_work_identities_count']=0;frame['cleanup_verified']=False
                frame['closure_error_code']='CLEANUP_OBSERVATION_FAILED'

def emit_final(fd,frame):
    start=time.monotonic();frame['monotonic_emission_start']=start
    payload=json.dumps(frame,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode('utf-8')
    if len(payload)>2048:return False
    wire=struct.pack('<I',len(payload))+payload;offset=0;deadline=min(START+572,start+2)
    poller=select.poll();poller.register(fd,select.POLLOUT|select.POLLERR|select.POLLHUP)
    while offset<len(wire) and time.monotonic()<deadline:
        try:
            size=os.write(fd,wire[offset:])
            if size<=0:return False
            offset+=size
        except (BlockingIOError,InterruptedError):
            remaining=deadline-time.monotonic()
            if remaining<=0:return False
            poller.poll(max(0,int(min(.02,remaining)*1000)))
        except OSError:return False
    return offset==len(wire)

def main():
    global START
    p=argparse.ArgumentParser()
    p.add_argument('--manifest-sha256',required=True)
    p.add_argument('--origin-monotonic',required=True,type=float)
    p.add_argument('--run-id',required=True)
    p.add_argument('--final-fd',required=True,type=int)
    args=p.parse_args();START=args.origin_monotonic;fd=args.final_fd
    # Invalid ingress cannot produce an authenticated success frame.
    if not math.isfinite(START) or not 0<=time.monotonic()-START<30:raise RuntimeError('EXTERNAL_ORIGIN_INVALID')
    if not re.fullmatch('[0-9a-f]{32}',args.run_id):raise RuntimeError('RUN_ID_INVALID')
    if fd<=2 or not stat.S_ISFIFO(os.fstat(fd).st_mode):raise RuntimeError('FINAL_PIPE_INVALID')
    os.set_inheritable(fd,False) # pass_fds below contains only candidate guard channels.
    os.set_blocking(fd,False)
    if os.fpathconf(fd,'PC_PIPE_BUF')<2052:raise RuntimeError('FINAL_PIPE_BUF_TOO_SMALL')
    frame={'schema_version':1,'manifest_sha256':args.manifest_sha256,'run_id':args.run_id,
           'work_status':'REJECTED','work_error_code':'BOOTSTRAP_FAILED','work_error_stage':'bootstrap',
           'closure_status':'FAILED','ack_received':False,'ack_valid':False,'ack_payload':None,
           'guard_rc':None,'guard_reaped':False,'pending_work_identities_count':0,'cleanup_verified':False,
           'causal_gate':'CLOSED_REJECTED','monotonic_emission_start':None,'closure_error_code':None}
    run=Validation.__new__(Validation);run.guard=None;run.children={}
    initialized=False;work_complete=False;work_detail=None
    try:
        run.__init__(args.manifest_sha256);initialized=True
        frame['work_error_code']='WORK_FAILED';frame['work_error_stage']='work'
        run.execute();work_complete=True
    except BaseException as exc:
        # Diagnostic detail remains local and bounded; never enters the final frame.
        work_detail=(type(exc).__name__+':'+str(exc))[:1024]
        work_complete=False
    if initialized:
        try:run.finish(work_complete,None if work_complete else work_detail)
        except BaseException:
            if work_complete:frame['work_error_code']='WORK_FAILED';frame['work_error_stage']='persistence'
            work_complete=False
    if work_complete:
        frame['work_status']='COMPLETED';frame['work_error_code']=None;frame['work_error_stage']=None
        frame['causal_gate']='CLOSED_AWAITING_D'
    run.close_internal(frame)
    emitted=False
    try:emitted=emit_final(fd,frame)
    finally:os.close(fd)
    return 0 if work_complete and frame['closure_status']=='INTERNAL_ACK_AND_REAP_OBSERVED' and emitted else 1
if __name__=='__main__':sys.exit(main())

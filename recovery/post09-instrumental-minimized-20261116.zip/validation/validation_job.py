#!/usr/bin/env python3
"""Closed harmless workload for V1 supervision scenarios. Never product."""
import json
import os
import pathlib
import sys
import time

def identity():
    text=pathlib.Path('/proc/self/stat').read_text();parts=text[text.rfind(')')+2:].split()
    return {'pid':os.getpid(),'start':parts[19]}

def append(path,role):
    with open(path,'a',encoding='utf-8') as stream:
        stream.write(json.dumps(dict(role=role,**identity()))+'\n');stream.flush();os.fsync(stream.fileno())

if __name__=='__main__':
    if sys.argv[1:]==['noop']:
        print('VALIDATION_NOOP');raise SystemExit(0)
    if len(sys.argv)==3 and sys.argv[1]=='hang-descendant':
        path=pathlib.Path(sys.argv[2])
        expected=pathlib.Path(__file__).resolve().parent/'run/scenarios/S2/run/descendant-identities.jsonl'
        if path!=expected or path.exists() or path.is_symlink():raise SystemExit('UNAPPROVED_IDENTITY_OUTPUT')
        with open(path,'x'):pass
        child=os.fork()
        append(path,'child' if child==0 else 'parent')
        time.sleep(120)
        raise SystemExit(0)
    raise SystemExit('CLOSED_WORKLOAD_ARGUMENTS_REQUIRED')

import sys, os, json, hashlib, stat, re, time
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path(__file__).resolve().parent
EXPECTED_ROOT=Path('/RELOCATE/validation')
def authenticate(approved):
    if ROOT!=EXPECTED_ROOT or not re.fullmatch('[0-9a-f]{64}',approved):raise ValueError('ROOT_OR_AUTHORITY')
    def unique(items):
        d={}
        for k,v in items:
            if k in d:raise ValueError('DUPLICATE')
            d[k]=v
        return d
    def plain(p):
        for a in [p,*p.parents]:
            if a.is_symlink():raise ValueError('SYMLINK')
        if not stat.S_ISREG(p.lstat().st_mode):raise ValueError('NOT_REGULAR')
        return p.read_bytes()
    raw=plain(ROOT/'evidence.sha256.json')
    if hashlib.sha256(raw).hexdigest()!=approved:raise ValueError('UNAPPROVED')
    rows=json.loads(raw,object_pairs_hook=unique); seen=set()
    for row in rows:
        name=row['path']
        if not isinstance(name,str) or name.startswith('/') or any(s in ('','.','..') for s in name.split('/')) or '\\' in name or '\x00' in name or name in seen:raise ValueError('PATH')
        seen.add(name); data=plain(ROOT/name)
        if len(data)!=row['bytes'] or hashlib.sha256(data).hexdigest()!=row['sha256']:raise ValueError('CONTENT')
    if not {'external_collector.py','external_supervisor.py','external_writer.py','external_contract.py','external-recipe.json','validation_launcher.py'}<=seen:raise ValueError('MISSING_MODULE')
    if 'validation-tools-authority.json' not in seen:raise ValueError('MISSING_TOOL_AUTHORITY')
    authority=json.loads(plain(ROOT/'validation-tools-authority.json'),object_pairs_hook=unique)
    expected='/RELOCATE/python3'
    matches=[r for r in authority['records'] if r['path']==expected]
    if len(matches)!=1:raise ValueError('INTERPRETER_AUTHORITY')
    record=matches[0]
    if str(Path(sys.executable).resolve(strict=True))!=record['resolved'] or str(Path(expected).resolve(strict=True))!=record['resolved'] or str(Path('/proc/self/exe').resolve(strict=True))!=record['resolved']:raise ValueError('INTERPRETER_IDENTITY')
    executable=plain(Path(record['resolved']))
    if len(executable)!=record['bytes'] or hashlib.sha256(executable).hexdigest()!=record['sha256']:raise ValueError('INTERPRETER_CONTENT')
def main():
    if len(sys.argv)!=4:raise ValueError('ARGV')
    approved,t0,runid=sys.argv[1:]; authenticate(approved); t0=float(t0)
    if not re.fullmatch('[0-9a-f]{32}',runid):raise ValueError('RUNID')
    deadline=t0+580
    if time.monotonic()>=deadline:return 2
    # File IO may block. Independent parent/supervisor enforce termination.
    raw=sys.stdin.buffer.read(262145)
    if len(raw)>262144 or time.monotonic()>=deadline:return 2
    value=json.loads(raw)
    if value['run_id']!=runid or value['manifest_sha256']!=approved or value['external_closure_status']!='CLOSURE_PENDING':raise ValueError('IDENTITY')
    directory=ROOT/'external-output'/runid
    partial=directory/'capture.partial'; final=directory/'capture.json'
    if final.exists() or final.is_symlink():raise ValueError('EXISTS')
    with open(partial,'xb') as stream:
        stream.write(raw);stream.flush();os.fsync(stream.fileno())
    if time.monotonic()>=deadline:return 2
    if partial.read_bytes()!=raw or time.monotonic()>=deadline:return 2
    os.rename(partial,final)
    if time.monotonic()>=deadline:return 2
    receipt=json.dumps({'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()},separators=(',',':')).encode()+b'\n'
    os.set_blocking(1,False); os.write(1,receipt)
    return 0
if __name__=='__main__':sys.exit(main())

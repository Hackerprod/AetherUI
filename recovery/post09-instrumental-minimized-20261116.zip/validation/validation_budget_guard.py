#!/usr/bin/env python3
"""Validation-only budget guardian; materialized, never executed during V0."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import select
import signal
import stat
import sys
import time
sys.dont_write_bytecode=True

def identity(pid):
    try:
        s=Path('/proc',str(pid),'stat').read_text();x=s[s.rfind(')')+2:].split()
        return {'pid':pid,'ppid':int(x[1]),'start':x[19],'state':x[0]}
    except (FileNotFoundError,ProcessLookupError):return None

def same(record):
    value=identity(record['pid'])
    return value is not None and value['start']==record['start']

def scan(parent,known):
    rows={}
    for path in Path('/proc').iterdir():
        if path.name.isdigit():
            value=identity(int(path.name))
            if value is not None:rows[value['pid']]=value
    descendants={parent};changed=True
    while changed:
        changed=False
        for pid,row in rows.items():
            if row['ppid'] in descendants and pid not in descendants:
                descendants.add(pid);changed=True
    for pid in descendants-{parent,os.getpid()}:known[(pid,rows[pid]['start'])]=rows[pid]
    return [row for row in known.values() if same(row)]

def send(row,sig):
    if not same(row):return
    try:fd=os.pidfd_open(row['pid'])
    except ProcessLookupError:return
    try:
        if same(row):signal.pidfd_send_signal(fd,sig,None,0)
    except ProcessLookupError:pass
    finally:os.close(fd)

def authenticate(root,expected):
    raw=(root/'evidence.sha256.json').read_bytes()
    if hashlib.sha256(raw).hexdigest()!=expected:raise RuntimeError('GUARD_MANIFEST_HASH')
    rows=json.loads(raw)
    entries=[x for x in rows if x.get('path')=='validation_budget_guard.py']
    if len(entries)!=1:raise RuntimeError('GUARD_AUTHORITY')
    p=root/'validation_budget_guard.py';record=entries[0]
    if p.is_symlink() or not stat.S_ISREG(p.lstat().st_mode):raise RuntimeError('GUARD_TYPE')
    data=p.read_bytes()
    if len(data)!=record['bytes'] or hashlib.sha256(data).hexdigest()!=record['sha256']:raise RuntimeError('GUARD_BYTES')

def main():
    p=argparse.ArgumentParser();p.add_argument('--manifest-sha256',required=True)
    p.add_argument('--parent',type=int,required=True);p.add_argument('--parent-start',required=True)
    p.add_argument('--start',type=float,required=True);p.add_argument('--work-deadline',type=float,required=True);p.add_argument('--deadline',type=float,required=True)
    p.add_argument('--control-fd',type=int,required=True);p.add_argument('--ack-fd',type=int,required=True)
    args=p.parse_args();root=Path(__file__).resolve().parent;authenticate(root,args.manifest_sha256)
    if args.work_deadline-args.start!=480 or args.deadline-args.start!=600 or not time.monotonic()<args.work_deadline:raise RuntimeError('GUARD_BUDGET')
    parent=identity(args.parent)
    if parent is None or parent['start']!=args.parent_start:raise RuntimeError('GUARD_PARENT')
    parent_fd=os.pidfd_open(args.parent);known={};stopped=False;buffer=b''
    os.set_blocking(args.control_fd,False)
    def ack(value):
        raw=(json.dumps(value)+'\n').encode()
        if len(raw)>4096 or os.write(args.ack_fd,raw)!=len(raw):raise RuntimeError('GUARD_ACK_WRITE')
    ack({'ack':'ready','parent':parent,'pid':os.getpid()})
    try:
        while True:
            now=time.monotonic();rows=scan(args.parent,known)
            if now>=args.deadline:
                for row in rows:send(row,signal.SIGKILL)
                if same(parent):signal.pidfd_send_signal(parent_fd,signal.SIGKILL,None,0)
                return 124
            if not same(parent):
                for row in rows:send(row,signal.SIGKILL)
                return 124
            if now>=args.work_deadline and not stopped:
                stopped=True
                for row in rows:send(row,signal.SIGTERM)
                signal.pidfd_send_signal(parent_fd,signal.SIGTERM,None,0)
            poller=select.poll();poller.register(args.control_fd,select.POLLIN|select.POLLHUP|select.POLLERR)
            if poller.poll(20):
                data=os.read(args.control_fd,4096)
                if not data:
                    for row in rows:send(row,signal.SIGKILL)
                    return 124
                buffer+=data
                if len(buffer)>4096:raise RuntimeError('GUARD_CONTROL_OVERFLOW')
                if b'\n' in buffer:
                    line,buffer=buffer.split(b'\n',1)
                    if buffer or json.loads(line)!={'done':True}:raise RuntimeError('GUARD_CONTROL')
                    rows=scan(args.parent,known)
                    for row in rows:
                        current=identity(row['pid'])
                        if current is not None and current['start']==row['start'] and current['state']!='Z':raise RuntimeError('GUARD_DONE_WITH_LIVE_WORK')
                    ack({'ack':'done','identified_work_exited':True,'reaping':'LAUNCHER_RESPONSIBILITY'})
                    return 0
    except BaseException:
        for row in scan(args.parent,known):
            try:send(row,signal.SIGKILL)
            except Exception:pass
        if same(parent):signal.pidfd_send_signal(parent_fd,signal.SIGTERM,None,0)
        while time.monotonic()<args.deadline:time.sleep(.02)
        if same(parent):signal.pidfd_send_signal(parent_fd,signal.SIGKILL,None,0)
        raise
    finally:os.close(parent_fd)
if __name__=='__main__':sys.exit(main())

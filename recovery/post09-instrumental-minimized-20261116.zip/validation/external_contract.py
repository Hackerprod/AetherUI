"""V8 stdlib-only observation helpers. No candidate imports."""
import os, signal, json, time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
PYTHON='/RELOCATE/python3'
def unique(pairs):
    out={}
    for k,v in pairs:
        if k in out: raise ValueError('DUPLICATE_KEY')
        out[k]=v
    return out
def identity(pid):
    try:
        s=Path('/proc',str(pid),'stat').read_text(); p=s[s.rfind(')')+2:].split()
        return {'pid':pid,'ppid':int(p[1]),'start':p[19],'state':p[0]}
    except (FileNotFoundError,ProcessLookupError): return None
def same(row):
    now=identity(row['pid']); return bool(now and now['start']==row['start'])
def discover(root,known,exclude=()):
    rows={}
    for p in Path('/proc').iterdir():
        if p.name.isdigit():
            row=identity(int(p.name))
            if row: rows[row['pid']]=row
    ids={root}; more=True
    while more:
        more=False
        for pid,row in rows.items():
            if row['ppid'] in ids and pid not in ids and pid not in exclude: ids.add(pid); more=True
    for pid in ids-{root,*exclude}:
        if pid in rows: known[(pid,rows[pid]['start'])]=rows[pid]
    return [r for r in known.values() if same(r)]
def kill_verified(row,sig):
    if not same(row): return
    try: fd=os.pidfd_open(row['pid'])
    except ProcessLookupError:return
    try:
        if same(row):signal.pidfd_send_signal(fd,sig,None,0)
    except ProcessLookupError:pass
    finally:os.close(fd)
def reap(rows):
    for row in rows:
        now=identity(row['pid'])
        if now and same(row) and now['ppid']==os.getpid():
            try: os.waitpid(row['pid'],os.WNOHANG)
            except ChildProcessError:pass

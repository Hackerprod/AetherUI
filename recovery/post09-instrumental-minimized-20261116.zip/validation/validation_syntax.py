#!/usr/bin/env python3
"""Future syntax/bootstrap validation only. Does not run candidate main bodies."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import stat
import sys
sys.dont_write_bytecode=True

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def plain(path):
    if path.is_symlink() or not stat.S_ISREG(path.lstat().st_mode):raise RuntimeError('INPUT_TYPE')
    return path

def main():
    p=argparse.ArgumentParser();p.add_argument('--manifest-sha256',required=True);args=p.parse_args()
    root=Path(__file__).resolve().parent;raw=plain(root/'evidence.sha256.json').read_bytes()
    if hashlib.sha256(raw).hexdigest()!=args.manifest_sha256:raise RuntimeError('MANIFEST_HASH')
    records={}
    for row in json.loads(raw):
        key=row['path']
        if key in records or key.startswith('/') or any(x in ('','.','..') for x in key.split('/')) or '\\' in key or '\x00' in key:raise RuntimeError('MANIFEST_PATH')
        records[key]=row
    for key,row in records.items():
        path=plain(root/key)
        if path.stat().st_size!=row['bytes'] or sha(path)!=row['sha256']:raise RuntimeError('MEMBER_HASH:'+key)
    modules=sorted(k for k in records if k.endswith('.py') and ('/' not in k or k=='input/parse_post09_observer.py'))
    for name in modules:compile((root/name).read_bytes(),str(root/name),'exec',dont_inherit=True)
    required=['supervisor.py','guard_deadlines.py','manifest_contract.py','frozen_custody.py','concurrency_preflight.py','verify_comparability.py','parse_post09_observer.py']
    out=root/'run/bootstrap';out.mkdir(exist_ok=False)
    results=[]
    for variant in ('positive','wrong-manifest-sha','altered-module'):
        folder=out/variant;folder.mkdir()
        rows=[]
        for name in required:
            data=(root/name).read_bytes();(folder/name).write_bytes(data)
            rows.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
        manifest=json.dumps(rows,indent=2).encode()+b'\n';(folder/'evidence.sha256.json').write_bytes(manifest)
        expected=hashlib.sha256(manifest).hexdigest()
        if variant=='wrong-manifest-sha':expected='0'*64
        if variant=='altered-module':
            with open(folder/'manifest_contract.py','ab') as f:f.write(b'\n# deterministic synthetic byte mutation; never imported\n')
        # Authenticate the only imported module independently using original,
        # already authenticated authority. Other local modules are not imported.
        if sha(folder/'supervisor.py')!=records['supervisor.py']['sha256']:raise RuntimeError('BOOTSTRAP_IMPORT_NOT_AUTHENTICATED')
        module_name='validation_bootstrap_'+variant.replace('-','_')
        spec=importlib.util.spec_from_file_location(module_name,folder/'supervisor.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        try:
            module.bootstrap_authority(expected)
            observed='ACCEPTED'
        except RuntimeError as exc:observed=str(exc)
        wanted={'positive':'ACCEPTED','wrong-manifest-sha':'BOOTSTRAP_MANIFEST_SHA','altered-module':'BOOTSTRAP_HELPER_HASH:manifest_contract.py'}[variant]
        results.append({'variant':variant,'expected':wanted,'observed':observed,'pass':observed==wanted,'candidate_main_executed':False,'untrusted_helper_imported':False})
        if observed!=wanted:raise RuntimeError('BOOTSTRAP_EXPECTATION:'+variant)
    report={'status':'PASS','syntax_modules':modules,'bootstrap':results,'not_a_product_test':True}
    with open(root/'run/syntax-bootstrap.json','x') as f:json.dump(report,f,indent=2);f.write('\n')
    return 0
if __name__=='__main__':sys.exit(main())

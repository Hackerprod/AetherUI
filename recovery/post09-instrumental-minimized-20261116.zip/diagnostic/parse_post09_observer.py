#!/usr/bin/env python3
"""Bounded, read-only protocol decoder; candidate NOT executed during authoring.

Only explicit CLI paths are opened. Binary payloads never choose a path or code.
Output is an observation assessment, never a product-test verdict.
"""
import argparse
import base64
import json
import os
import stat
import struct
from pathlib import Path

MAX_BYTES = 8 * 1024 * 1024
ARENA = 1179648 - 32
MAX_RECORDS = 4096
ERROR_MASK = 127  # overflow, protocol, other thread, init, partial, string, IO
CASES = {1: 'SD_LH', 2: 'TP_EMPTY', 3: 'TR_NOOP', 4: 'TR_S1', 5: 'TR_S2',
         6: 'TR_S3', 7: 'TR_I1', 8: 'TR_I2', 9: 'TR_I3'}
KINDS = {1: 'begin', 2: 'public_result', 3: 'node_start', 4: 'diff',
         5: 'dependency', 6: 'field', 7: 'end', 8: 'typography', 9: 'branch_taken'}
PUBLIC = {1: 'BindTarget', 2: 'RawCount', 3: 'Entry', 4: 'ResolveDone',
          5: 'ReturnImpact', 6: 'Aggregate'}
PROV_BOOL = {'declaration', 'inherited', 'important', 'inline_style'}
PROV_INT = {'layer', 'source_order', 'declaration_order'}
PROV_STR = {'accepted_source', 'resolved_source'}
STATE_FIELDS = {'family_state', 'style_state', 'spacing_state', 'size_state',
                'weight_state', 'line_height_state'}
BOOL_FIELDS = {'spacing_normal', 'coverage_complete'}
INT_FIELDS = STATE_FIELDS | BOOL_FIELDS | {'weight', 'line_height_kind', 'size_dependencies',
              'line_height_dependencies', 'coverage_gaps', 'families.count'}
FLOAT_WIDTHS = {'spacing_px': 8, 'size_px': 4, 'line_height_value': 4,
                'line_height_used_px': 4}

class Invalid(ValueError):
    pass

def need(condition, message):
    if not condition:
        raise Invalid(message)

def signed32(value):
    return value - (1 << 32) if value & (1 << 31) else value

def signed32_in_u64(value):
    return value <= 0x7fffffff or value >= (1 << 64) - (1 << 31)

def bounded_regular(path, maximum):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        need(stat.S_ISREG(before.st_mode) and before.st_size <= maximum, 'not a bounded regular file')
        chunks = []
        remaining = maximum + 1
        while remaining:
            chunk = os.read(fd, min(remaining, 65536))
            if not chunk:
                break
            chunks.append(chunk)
            remaining -= len(chunk)
        data = b''.join(chunks)
        after = os.fstat(fd)
        need(before.st_size == after.st_size == len(data) and
             before.st_mtime_ns == after.st_mtime_ns and before.st_ctime_ns == after.st_ctime_ns,
             'input changed while reading')
        need(len(data) <= maximum, 'input exceeds bound')
        return data
    finally:
        os.close(fd)

def field_decode(payload):
    need(len(payload) >= 40, 'field header shorter than40')
    side, i, j, dtype, keylen, reserved, original, stored = struct.unpack_from('<6I2Q', payload, 0)
    need(reserved == 0 and keylen <= 128 and stored <= 65536, 'invalid field limits/reserved')
    need(side in (0, 1) and dtype in (1, 2, 3), 'invalid field side/type')
    need(len(payload) == 40 + keylen + stored, 'field payload length mismatch')
    need(original == stored or (original > 65536 and stored == 0), 'unmarked field truncation')
    key = payload[40:40 + keylen].decode('ascii', 'strict')
    raw = payload[40 + keylen:]
    item = {'side': side, 'index0': i, 'index1': j, 'field': key, 'type': dtype,
            'original_length': original, 'captured_length': stored,
            'capture_complete': original == stored}
    if original != stored:
        need(dtype == 3, 'nonstring may not be truncated')
        item['value'] = None
    elif dtype == 1:
        need(stored == 8, 'invalid integer width')
        item['value_u64'] = struct.unpack('<Q', raw)[0]
    elif dtype == 2:
        need(stored in (4, 8), 'invalid float width')
        item['bits_le_hex'] = raw.hex()
    else:
        item['bytes_base64'] = base64.b64encode(raw).decode('ascii')
        item['text_utf8_display_only'] = raw.decode('utf-8', 'replace')
    return item

def parse_syntax(data):
    need(80 <= len(data) <= MAX_BYTES and data[:8] == b'AETHD092', 'bad file header/length')
    version, test, tree, nslots, errors = struct.unpack_from('<5I', data, 8)
    need(version == 2 and nslots == 7 and 1 <= test <= 5 and tree in (1, 2), 'invalid file header')
    need(errors & ~ERROR_MASK == 0 and data[28:64] == bytes(36), 'unknown errors/reserved bytes')
    offset = 64
    slots = []
    for index in range(7):
        need(offset + 64 <= len(data), 'truncated slot header')
        h = struct.unpack_from('<16I', data, offset)
        offset += 64
        case, used, count, flags, omitted, target, raw, entries, returned, aggregate, raw_seen, done, ended, return_seen, agg_seen, agg_present = h
        need(used <= ARENA and count <= MAX_RECORDS and target <= 256, 'slot limits exceeded')
        need(flags & ~ERROR_MASK == 0 and flags & ~errors == 0, 'unknown/unreported slot error')
        need(all(x in (0, 1) for x in h[10:]), 'invalid slot booleans')
        need(offset + used <= len(data), 'truncated arena')
        summary = dict(case_id=case, target=target, raw_count=signed32(raw), entries=entries,
                       returned=returned, aggregate=aggregate, raw_seen=bool(raw_seen), done=bool(done),
                       ended=bool(ended), return_seen=bool(return_seen), aggregate_seen=bool(agg_seen),
                       aggregate_present=bool(agg_present))
        records = []
        stop = offset + used
        while offset < stop:
            need(offset + 32 <= stop, 'truncated record header')
            kind, point, node, seq, length, reserved, token = struct.unpack_from('<6IQ', data, offset)
            offset += 32
            need(kind in KINDS and node <= 256 and seq == len(records) and reserved == 0 and token > 0,
                 'invalid record header')
            need(offset + length <= stop, 'record payload exceeds arena')
            payload = data[offset:offset + length]
            offset += length
            record = {'kind': KINDS[kind], 'kind_id': kind, 'point': point, 'node_ordinal': node,
                      'sequence': seq, 'token': token}
            if kind == 6:
                record.update(field_decode(payload))
            else:
                need(length == 16, 'fixed payload length not16')
                record['values'] = list(struct.unpack('<4I', payload))
            records.append(record)
        need(offset == stop and len(records) == count, 'arena/record-count mismatch')
        if not case:
            need(h == (0,) * 16 and not records, 'unused slot contains evidence')
        slots.append({'slot': index, 'case': CASES.get(case), 'summary': summary,
                      'flags': flags, 'omitted': omitted, 'records': records})
    need(len(data) == offset + 16 and data[offset:offset + 8] == b'ENDD092!', 'missing/trailing footer')
    footer_flags, reserved = struct.unpack_from('<2I', data, offset + 8)
    need(reserved == 0 and footer_flags == errors, 'footer flags differ')
    return {'schema': version, 'test_id': test, 'tree_id': tree, 'observer_errors': errors, 'slots': slots}

def validate_field(f, dependency=False):
    key, i, j, dtype = f['field'], f['index0'], f['index1'], f['type']
    expected_type = None
    constraint = None
    if dependency:
        need(key == 'dependency.name' and i == j == 0 and dtype == 3, 'invalid dependency field')
        return
    if key.startswith('provenance.'):
        name = key[len('provenance.'):]
        need((j == 0 and i < 6) or (j == 1 and i < 2), 'provenance index out of range')
        if name in PROV_BOOL:
            expected_type, constraint = 1, lambda v: v in (0, 1)
        elif name in PROV_INT:
            expected_type, constraint = 1, signed32_in_u64
        elif name in PROV_STR:
            expected_type = 3
    elif key.startswith('break.'):
        need(j == 1 and i < 2, 'break index out of range')
        if key == 'break.known': expected_type, constraint = 1, lambda v: v in (0, 1)
        elif key == 'break.computed': expected_type, constraint = 1, signed32_in_u64
        elif key == 'break.reason': expected_type, constraint = 1, lambda v: v <= 4
        elif key == 'break.authored_property': expected_type = 3
    elif key in ('families.name', 'families.generic'):
        need(j == 0 and i < MAX_RECORDS, 'family index out of range')
        expected_type = 3 if key.endswith('name') else 1
        if expected_type == 1: constraint = lambda v: v in (0, 1)
    else:
        need(i == j == 0, 'scalar indices must be zero')
        if key in INT_FIELDS:
            expected_type = 1
            if key in STATE_FIELDS or key == 'line_height_kind': constraint = lambda v: v <= 2
            elif key in BOOL_FIELDS: constraint = lambda v: v in (0, 1)
            elif key == 'weight': constraint = signed32_in_u64
            elif key == 'families.count': constraint = lambda v: v <= MAX_RECORDS
            else: constraint = lambda v: v <= 0xffffffff
        elif key in FLOAT_WIDTHS:
            expected_type = 2
            need(f['original_length'] == FLOAT_WIDTHS[key], 'float width disagrees with field')
        elif key == 'font_style': expected_type = 3
    need(expected_type is not None and dtype == expected_type, 'unknown field/wrong type')
    if constraint is not None:
        need(f['capture_complete'] and constraint(f['value_u64']), 'invalid field numeric/enum/bool value')

def expected_keys(side, families):
    out = {(side, key, 0, 0) for key in INT_FIELDS | set(FLOAT_WIDTHS) | {'font_style'}}
    for i in range(2):
        out.update((side, 'break.' + key, i, 1) for key in ('known', 'computed', 'reason', 'authored_property'))
        out.update((side, 'provenance.' + key, i, 1) for key in PROV_BOOL | PROV_INT | PROV_STR)
    for i in range(6):
        out.update((side, 'provenance.' + key, i, 0) for key in PROV_BOOL | PROV_INT | PROV_STR)
    for i in range(families):
        out.add((side, 'families.name', i, 0)); out.add((side, 'families.generic', i, 0))
    return out

def reconstruct(slot, test, used_tokens):
    h = slot['summary']; case = h['case_id']; recs = slot['records']
    if not case:
        slot.update(protocol_valid=True, capture_complete=False, target_correlation_valid=False,
                    observation='UNOBSERVED')
        return
    need(case in CASES, 'unknown case')
    index = slot['slot']
    need((test == 1 and case == 1 and index == 0) or (test == 2 and case == 2 and index == 0) or
         (test == 3 and case == index + 3), 'case/test/slot mismatch')
    if not recs:
        need(slot['flags'] or slot['omitted'], 'used slot has no begin')
        slot.update(protocol_valid=True, capture_complete=False, target_correlation_valid=False,
                    observation='PARTIAL', incompleteness=['begin not captured'])
        return
    token = recs[0]['token']; need(token not in used_tokens, 'scope token reused'); used_tokens.add(token)
    state = 'INIT'; target = None; current = None; raw = None; entries = []; prepared = set(); known = set()
    returned = None; aggregate = None; ended = False; snapshot = None; dependency_pending = None
    snapshots = []; diffs = {}; branches = {}; incomplete = []; current_block = 0; blocks = {}
    def ordinal(n):
        need(1 <= n <= 256, 'zero/out-of-range ordinal for identity event')
        if n not in known:
            need(n == len(known) + 1, 'ordinal assignment gap')
            known.add(n)
    def finish_snapshot():
        nonlocal snapshot
        if snapshot is None: return
        seen = snapshot['fields']; required = set(); ok = True
        for side in ([0, 1] if snapshot['previous_present'] else [1]):
            count = seen.get((side, 'families.count', 0, 0))
            if count is None:
                ok = False; continue
            required |= expected_keys(side, count['value_u64'])
        if set(seen) != required or any(not f['capture_complete'] for f in seen.values()): ok = False
        snapshot['complete'] = ok
        if not ok: incomplete.append('incomplete typography snapshot')
        snapshot['fields'] = list(seen.values()); snapshots.append(snapshot); snapshot = None
    for r in recs:
        need(r['token'] == token and state != 'ENDED', 'token changed or records after end')
        k, point, n = r['kind_id'], r['point'], r['node_ordinal']
        if k != 6:
            finish_snapshot()
            need(dependency_pending is None, 'dependency lacks immediately following name')
        if k == 1:
            need(state == 'INIT' and r['sequence'] == 0 and point == n == 0 and
                 r['values'] == [case, 0, 0, 0], 'invalid/repeated begin')
            state = 'RESOLVING'; continue
        need(state != 'INIT', 'event before begin')
        if k == 2:
            a, b, impact, reserved = r['values']
            need(point in PUBLIC and b in (0, 1) and reserved == 0 and impact <= 127, 'invalid public sample')
            count = signed32(a)
            if point == 1:
                ordinal(n); need(count == 0 and b == impact == 0, 'BindTarget fields not neutral')
                need(target is None or target == n, 'conflicting target bindings'); target = n
                if test == 3: need(state == 'DONE', 'transform bind must use post-resolve lookup')
            elif point == 2:
                need(state == 'RESOLVING' and raw is None and n == b == impact == 0, 'invalid/repeated RawCount')
                raw = count; state = 'ENUMERATING'
            elif point == 3:
                need(state == 'ENUMERATING' and raw is not None and raw >= 0 and count == len(entries) and
                     count < raw and b == 1 and aggregate is None, 'ENTRY order/count invalid')
                ordinal(n); entries.append((n, impact))
            elif point == 4:
                need(state == 'ENUMERATING' and raw is not None and raw >= 0 and count == raw == len(entries) and
                     n == impact == 0 and b == 1, 'ResolveDone without complete successful enumeration')
                if test == 2: need(aggregate is not None, 'transition ResolveDone without Aggregate')
                state = 'DONE'
            elif point == 5:
                need(test == 1 and state == 'DONE' and returned is None and n == count == b == 0,
                     'unexpected/repeated ReturnImpact'); returned = impact
            elif point == 6:
                need(test == 2 and state == 'ENUMERATING' and aggregate is None and target == n and n > 0 and
                     raw is not None and raw >= 0 and count == raw == len(entries), 'invalid Aggregate order/count/target')
                matching = [v for node, v in entries if node == target]; combined = 0
                for v in matching: combined |= v
                need(b == bool(matching) and impact == combined, 'Aggregate differs from original ENTRY evidence')
                aggregate = (bool(b), impact)
            continue
        if k == 7:
            need(state == 'DONE' and target is not None and n == target and point == 0, 'end before done/target')
            if test == 1: need(returned is not None, 'semantic end lacks ReturnImpact')
            if test == 2: need(aggregate is not None, 'transition end lacks Aggregate')
            matching = [v for node, v in entries if node == target]
            if test == 1: need(returned == (matching[-1] if matching else 0), 'ReturnImpact not pre-insertion evidence result')
            need(r['values'] == [int(target in prepared), 2 if matching else 1, len(entries), 0],
                 'end summary conflicts with reconstructed nodes/entries')
            ended = True; state = 'ENDED'; continue
        need(state == 'RESOLVING', 'core event after RawCount or outside resolve')
        if k == 3:
            ordinal(n); need(point == 0 and r['values'] == [0, 0, 0, 0], 'invalid node_start')
            current = n; current_block += 1; blocks[current_block] = n; prepared.add(n); continue
        need(current is not None and n == current, 'core event lacks matching node_start')
        if k == 4:
            a, b, storage, unclassified = r['values']
            need(point in (1, 2, 3, 4, 7) and a <= 127 and b <= 127 and
                 storage in (0, 1) and unclassified in (0, 1), 'invalid diff fields')
            node_diffs = diffs.setdefault(current_block, {})
            need(point not in node_diffs, 'duplicate diff point')
            if point == 2: need(1 in node_diffs, 'fallback post without pre')
            if point == 3: need(1 in node_diffs and 2 in node_diffs and 4 not in node_diffs, 'classifier without fallback points')
            if point == 4: need(not node_diffs, 'new-node diff mixed with classifier')
            if point == 7: need((3 in node_diffs or 4 in node_diffs) and current_block in branches, 'post-OR before classifier/branch')
            node_diffs[point] = r['values']
        elif k == 5:
            flags, unknown_name, unknown_flags, reserved = r['values']
            need(point in (0, 1) and unknown_name in (0, 1) and unknown_flags in (0, 1) and reserved == 0 and
                 (unknown_name or unknown_flags) and unknown_flags == bool(flags & ~31), 'invalid dependency flags')
            dependency_pending = (n, point)
        elif k == 8:
            previous, discarded, c, d = r['values']
            need(point in (5, 6) and previous in (0, 1) and discarded in (0, 1) and c == d == 0,
                 'invalid typography marker')
            need(not any(x['block'] == current_block and x['point'] == point for x in snapshots), 'duplicate snapshot')
            node_diffs = diffs.get(current_block, {})
            need(3 in node_diffs or 4 in node_diffs, 'typography before classifier/new node')
            if point == 6: need(any(x['block'] == current_block and x['point'] == 5 for x in snapshots), 'post-reset snapshot before pre-reset')
            snapshot = {'node': n, 'block': current_block, 'point': point, 'previous_present': bool(previous),
                        'discarded': bool(discarded), 'fields': {}}
        elif k == 6:
            if dependency_pending is not None:
                need(point == 100 and n == dependency_pending[0] and r['side'] == dependency_pending[1], 'dependency name not correlated')
                validate_field(r, True)
                if not r['capture_complete']: incomplete.append('dependency name incomplete')
                dependency_pending = None
            else:
                need(snapshot is not None and point == snapshot['point'] and n == snapshot['node'], 'field outside snapshot')
                validate_field(r)
                need(r['side'] == 1 or snapshot['previous_present'], 'previous fields without previous evidence')
                key = (r['side'], r['field'], r['index0'], r['index1'])
                need(key not in snapshot['fields'], 'duplicate field in snapshot')
                snapshot['fields'][key] = r
        elif k == 9:
            a, b, c, d = r['values']
            need(point == 0 and a in (0, 1) and b == c == d == 0 and current_block not in branches, 'invalid/repeated branch')
            need(any(x['block'] == current_block and x['point'] == 6 for x in snapshots), 'branch before post-reset snapshot')
            branches[current_block] = bool(a)
        else:
            raise Invalid('unexpected event type')
    finish_snapshot()
    if dependency_pending is not None: incomplete.append('dependency name not captured')
    if state != 'ENDED': incomplete.append('scope not ended')
    reconstructed = dict(target=target or 0, raw_count=raw if raw is not None else -1,
                         entries=len(entries), returned=returned if returned is not None else 0,
                         aggregate=aggregate[1] if aggregate else 0, raw_seen=raw is not None,
                         done=state in ('DONE', 'ENDED'), ended=ended, return_seen=returned is not None,
                         aggregate_seen=aggregate is not None, aggregate_present=aggregate[0] if aggregate else False)
    for key, value in reconstructed.items():
        need(h[key] == value, 'slot summary disagrees with events: ' + key)
    if slot['flags'] or slot['omitted']: incomplete.append('slot error or omitted records')
    target_blocks = [block for block, node_id in blocks.items() if node_id == target]
    # Chosen signatures require complete existing-node capture; repeated preparation
    # is retained as separate blocks rather than aliased by ordinal or discarded.
    coverage = bool(target_blocks) and all(
        set(diffs.get(block, {})) == {1, 2, 3, 7} and block in branches and
        {x['point'] for x in snapshots if x['block'] == block and x['complete']} == {5, 6}
        for block in target_blocks)
    if not coverage: incomplete.append('selected target classifier/fallback/typography coverage incomplete')
    matching = [v for node, v in entries if node == target]
    correlation = ended and target is not None and target in known and raw is not None and raw >= 0 and raw == len(entries)
    slot.update(protocol_valid=True, target_correlation_valid=bool(correlation),
                capture_complete=not incomplete and bool(correlation),
                observation='COMPLETE' if not incomplete and correlation else 'PARTIAL',
                incompleteness=incomplete, reconstructed=reconstructed,
                target_prepared_seen=target in prepared,
                target_public_presence=('PRESENT' if matching else 'ABSENT') if correlation else 'UNKNOWN',
                target_last_entry_impact=matching[-1] if matching else None,
                target_core_coverage=bool(coverage), target_preparation_blocks=target_blocks, snapshots=snapshots)

def close_decode(data, document, data_length):
    need(len(data) == 80 and data[:8] == b'CLSD092!', 'close-status missing/truncated/magic')
    version, test, tree, write_ok, footer_ok, rc, error, flags = struct.unpack_from('<8I', data, 8)
    planned, written = struct.unpack_from('<2Q', data, 40)
    need(version == 2 and test == document['test_id'] and tree == document['tree_id'], 'close-status identity mismatch')
    need(write_ok in (0, 1) and footer_ok in (0, 1) and flags & ~ERROR_MASK == 0 and
         data[56:] == bytes(24), 'invalid close-status values/reserved')
    close_rc = signed32(rc)
    need(close_rc in (0, -1) and ((close_rc == 0 and error == 0) or (close_rc == -1 and error > 0)), 'invalid close rc/errno pair')
    need(planned <= MAX_BYTES and written <= planned, 'close-status size out of bounds')
    need(not footer_ok or write_ok, 'footer success without write success')
    need(not write_ok or (footer_ok and written == planned), 'write success lacks complete footer/size')
    positive = bool(write_ok and footer_ok and close_rc == 0 and error == 0 and
                    flags == document['observer_errors'] and planned == written == data_length)
    return {'record_valid': True, 'positive': positive, 'data_write_complete': bool(write_ok),
            'data_footer_complete': bool(footer_ok), 'data_close_rc': close_rc, 'data_close_errno': error,
            'observer_errors': flags, 'planned_bytes': planned, 'written_bytes': written,
            'status_channel_close': 'NOT_CERTIFIED', 'fsync_crash_durability': 'NOT_CERTIFIED',
            'requires_external_process_termination_and_reaping': True}

def assess(data, close_data, close_error=None):
    result = {'syntax_valid': False, 'protocol_valid': False, 'capture_complete': False,
              'target_correlation_valid': False, 'missing_cases': [], 'close_evidence': None,
              'observer_complete': False, 'not_a_product_test_verdict': True}
    try:
        document = parse_syntax(data)
    except (Invalid, UnicodeError, struct.error) as exc:
        result['syntax_error'] = str(exc)
        result['close_evidence'] = {'record_valid': False, 'positive': False,
                                   'error': close_error or 'cannot correlate close evidence with invalid data header'}
        return result
    result.update(document); result['syntax_valid'] = True
    expected = {1: {1}, 2: {2}, 3: set(range(3, 10)), 4: set(), 5: set()}[document['test_id']]
    observed = {s['summary']['case_id'] for s in document['slots'] if s['summary']['case_id']}
    result['missing_cases'] = [CASES[c] for c in sorted(expected - observed)]
    used_tokens = set(); protocol_valid = True
    for slot in document['slots']:
        try:
            reconstruct(slot, document['test_id'], used_tokens)
        except (Invalid, UnicodeError, struct.error) as exc:
            slot.update(protocol_valid=False, capture_complete=False, target_correlation_valid=False,
                        observation='INVALID', protocol_error=str(exc), target_public_presence='UNKNOWN')
            protocol_valid = False
    if document['test_id'] in (4, 5) and observed:
        protocol_valid = False; result['protocol_error'] = 'control contains scopes'
    result['protocol_valid'] = protocol_valid
    active = [s for s in document['slots'] if s['summary']['case_id']]
    result['target_correlation_valid'] = protocol_valid and document['observer_errors'] == 0 and not result['missing_cases'] and \
        all(s.get('target_correlation_valid', False) and not s['flags'] and not s['omitted'] for s in active)
    result['capture_complete'] = protocol_valid and document['observer_errors'] == 0 and \
        observed == expected and all(s.get('capture_complete', False) for s in active)
    try:
        need(close_error is None and close_data is not None, close_error or 'close-status absent')
        result['close_evidence'] = close_decode(close_data, document, len(data))
    except (Invalid, UnicodeError, struct.error) as exc:
        result['close_evidence'] = {'record_valid': False, 'positive': False, 'error': str(exc)}
    result['observer_complete'] = bool(result['syntax_valid'] and result['protocol_valid'] and
        result['capture_complete'] and result['target_correlation_valid'] and result['close_evidence']['positive'])
    return result

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--input', required=True, type=Path)
    ap.add_argument('--close-status', required=True, type=Path)
    ap.add_argument('--output', required=True, type=Path)
    args = ap.parse_args()
    # Sidecar is an explicit supervisor argument, with an exact pair-name contract.
    close_error = None; close_data = None
    try:
        need(args.close_status == Path(str(args.input) + '.close-status'), 'close-status path does not match explicit data path')
        close_data = bounded_regular(args.close_status, 80)
    except (OSError, Invalid) as exc:
        close_error = str(exc)
    try:
        data = bounded_regular(args.input, MAX_BYTES)
        result = assess(data, close_data, close_error)
    except (OSError, Invalid) as exc:
        result = {'syntax_valid': False, 'protocol_valid': False, 'capture_complete': False,
                  'target_correlation_valid': False, 'missing_cases': [],
                  'close_evidence': {'record_valid': False, 'positive': False, 'error': close_error},
                  'observer_complete': False, 'not_a_product_test_verdict': True, 'input_error': str(exc)}
    encoded = (json.dumps(result, ensure_ascii=True, indent=2) + '\n').encode('utf-8')
    fd = os.open(args.output, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC, 0o600)
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(encoded)
    except BaseException:
        # fdopen owns the fd; no duplicate close and no success result on IO failure.
        raise
    return 0 if result['observer_complete'] else 2

if __name__ == '__main__':
    raise SystemExit(main())

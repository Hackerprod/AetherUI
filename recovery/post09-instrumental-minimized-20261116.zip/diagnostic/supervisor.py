#!/usr/bin/env python3
"""STATIC, NOT EXECUTED. Closed one-shot diagnostic supervisor for D review.
The watchdog owns all commands and is a Linux child subreaper. No shell runs.
"""
import ctypes
import datetime
import fcntl
import hashlib
import json
import os
import pathlib
import select
import signal
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
sys.dont_write_bytecode = True

def bootstrap_authority(expected):
    # This code deliberately uses only stdlib already loaded above. No local
    # module is imported until every executable helper has been authenticated.
    import stat
    if len(expected)!=64 or any(c not in '0123456789abcdef' for c in expected):raise RuntimeError('BOOTSTRAP_SHA_SCHEMA')
    root=pathlib.Path(__file__).resolve().parent
    mp=root/'evidence.sha256.json'
    if mp.is_symlink() or not stat.S_ISREG(mp.lstat().st_mode):raise RuntimeError('BOOTSTRAP_MANIFEST_TYPE')
    raw=mp.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=expected:raise RuntimeError('BOOTSTRAP_MANIFEST_SHA')
    def no_duplicate_keys(items):
        result={}
        for key,value in items:
            if key in result:raise RuntimeError('BOOTSTRAP_DUPLICATE_JSON_KEY')
            result[key]=value
        return result
    rows=json.loads(raw,object_pairs_hook=no_duplicate_keys)
    if not isinstance(rows,list):raise RuntimeError('BOOTSTRAP_MANIFEST_LIST')
    records={}
    for row in rows:
        if not isinstance(row,dict) or set(row)!={'path','bytes','sha256'}:raise RuntimeError('BOOTSTRAP_ROW_SCHEMA')
        key=row['path']
        if not isinstance(key,str) or not key or '\\' in key or '\x00' in key or key.startswith('/') or any(x in ('','.','..') for x in key.split('/')):raise RuntimeError('BOOTSTRAP_PATH')
        if key in records or key=='evidence.sha256.json':raise RuntimeError('BOOTSTRAP_DUPLICATE')
        if type(row['bytes']) is not int or row['bytes']<0 or not isinstance(row['sha256'],str) or len(row['sha256'])!=64 or any(c not in '0123456789abcdef' for c in row['sha256']):raise RuntimeError('BOOTSTRAP_SIZE_SHA')
        records[key]=row
    required=('supervisor.py','guard_deadlines.py','manifest_contract.py','frozen_custody.py','concurrency_preflight.py','verify_comparability.py','parse_post09_observer.py')
    for name in required:
        row=records.get(name);p=root/name
        if row is None or p.is_symlink() or not stat.S_ISREG(p.lstat().st_mode):raise RuntimeError('BOOTSTRAP_HELPER_TYPE:'+name)
        data=p.read_bytes()
        if len(data)!=row['bytes'] or hashlib.sha256(data).hexdigest()!=row['sha256']:raise RuntimeError('BOOTSTRAP_HELPER_HASH:'+name)
    return records

START = time.monotonic()
HERE = pathlib.Path(__file__).resolve().parent
WATCHDOG_KNOWN = {}

def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1024*1024), b''): h.update(b)
    return h.hexdigest()
def save(p,data):
    p=pathlib.Path(p); tmp=p.with_name(p.name+'.tmp')
    with open(tmp,'w') as f: json.dump(data,f,indent=2); f.write('\n'); f.flush(); os.fsync(f.fileno())
    os.replace(tmp,p)
def event(p, data):
    with open(p,'a') as f: f.write(json.dumps(dict(utc=utc(),mono=time.monotonic(),**data))+'\n');f.flush();os.fsync(f.fileno())
def proc(pid):
    try:
        s=pathlib.Path('/proc',str(pid),'stat').read_text(); r=s[s.rfind(')')+2:].split()
        return dict(pid=int(pid),ppid=int(r[1]),pgid=int(r[2]),start=r[19],state=r[0],rss_bytes=int(r[21])*os.sysconf('SC_PAGE_SIZE'))
    except (FileNotFoundError,ProcessLookupError): return None

def allprocs():
    out={}
    for p in pathlib.Path('/proc').iterdir():
        if p.name.isdigit():
            v=proc(p.name)
            if v: out[int(p.name)]=v
    return out

def same(x):
    v=proc(x['pid']); return v is not None and v['start']==x['start']
def alive(x):
    v=proc(x['pid']);return v is not None and v['start']==x['start'] and v['state']!='Z'
def owned(me,known):
    ps=allprocs(); ids={me}; change=True
    while change:
        change=False
        for pid,p in ps.items():
            if p['ppid'] in ids and pid not in ids: ids.add(pid);change=True
    for pid in ids-{me}:known[pid]=ps[pid]
    return [x for x in known.values() if same(x)]
def send_signal(x,sig):
    # pidfd pins the target identity; never signal a reusable integer PID/PGID.
    if not same(x):return
    try:fd=os.pidfd_open(x['pid'],0)
    except ProcessLookupError:return
    try:
        if same(x):signal.pidfd_send_signal(fd,sig,None,0)
    except ProcessLookupError:pass
    finally:os.close(fd)

def wait_readable(fds,timeout):
    # poll accepts descriptors above FD_SETSIZE; timeout is seconds or None.
    poller=select.poll()
    for fd in fds:poller.register(fd,select.POLLIN|select.POLLHUP|select.POLLERR|select.POLLNVAL)
    milliseconds=None if timeout is None else max(0,int(timeout*1000))
    events=poller.poll(milliseconds)
    if any(mask & select.POLLNVAL for fd,mask in events):raise RuntimeError('INVALID_CONTROL_FD')
    return [fd for fd,mask in events]

def namespace_identity():
    return dict(pid=os.getpid(),identity=proc(os.getpid()),namespaces={n:os.readlink('/proc/self/ns/'+n) for n in ['pid','mnt','user']})

def resources(root):
    mem={a:int(b.split()[0])*1024 for a,b in (line.split(':',1) for line in pathlib.Path('/proc/meminfo').read_text().splitlines())}
    d=os.statvfs(root)
    return dict(available_bytes=d.f_bavail*d.f_frsize,mem_available_bytes=mem['MemAvailable'],load=os.getloadavg())
def resource_ok(x): return x['available_bytes']>=12*1024**3 and x['mem_available_bytes']>=4*1024**3

def subreaper():
    libc=ctypes.CDLL(None,use_errno=True)
    if libc.prctl(36,1,0,0,0)!=0: raise OSError(ctypes.get_errno(),'PR_SET_CHILD_SUBREAPER failed')

def watchdog(rfd,wfd,deadline,work_deadline,parent_pid,parent_start,root,guardfd,ackfd):
    """Owns subprocesses; watches deadlines even if coordinator is blocked."""
    subreaper(); os.set_blocking(rfd,False)
    run=pathlib.Path(root)/'run'; log=run/'watchdog.jsonl'
    global WATCHDOG_KNOWN
    active=None; known={}; WATCHDOG_KNOWN=known; buf=b''; stopped=None; stop_at=None; last_resource=0; main_open=True
    phase='BEFORE_TESTS';tests_start=None;tests_deadline=None;test_count=0;last_test=None;last_parser=None
    sigstate=[]
    for sig in [signal.SIGINT,signal.SIGTERM,signal.SIGHUP]: signal.signal(sig,lambda s,f:sigstate.append(s))
    def reply(x):
        try:os.write(wfd,(json.dumps(x)+'\n').encode())
        except BrokenPipeError:pass
    def phase_limit():return min(work_deadline,tests_deadline) if phase=='TESTS' else work_deadline
    def guard_exchange(message,expected):
        os.write(guardfd,(json.dumps(message)+'\n').encode())
        ack=b''
        while b'\n' not in ack:
            remaining=phase_limit()-time.monotonic()
            if remaining<=0:raise RuntimeError('TESTS_AGGREGATE_CAP' if phase=='TESTS' else 'GLOBAL_WORK_CAP')
            ready_ack=wait_readable([ackfd],remaining)
            if not ready_ack:raise RuntimeError('GUARD_ACK_TIMEOUT')
            part=os.read(ackfd,4096)
            if not part:raise RuntimeError('GUARD_LOST')
            ack+=part
        if json.loads(ack.split(b'\n')[0])!=expected:raise RuntimeError('GUARD_ACK_MISMATCH')
        if time.monotonic()>=phase_limit():raise RuntimeError('TESTS_AGGREGATE_CAP' if phase=='TESTS' else 'GLOBAL_WORK_CAP')
    def cleanup(reason):
        nonlocal stopped,stop_at,phase
        if stopped is None:
            stopped=reason;stop_at=time.monotonic();phase='STOPPED';event(log,dict(action='stop',reason=reason))
            for x in owned(os.getpid(),known):
                if alive(x):
                    try:
                        send_signal(x,signal.SIGTERM)
                        event(log,dict(action='TERM',identity=x))
                    except ProcessLookupError:pass
    reply(dict(type='ready',pid=os.getpid(),execution_identity=namespace_identity()))
    while True:
        now=time.monotonic()
        p=proc(parent_pid)
        if not p or p['start']!=parent_start:main_open=False;cleanup('PARENT_LOST')
        if phase=='TESTS' and now>=tests_deadline:cleanup('DIAGNOSTIC_CAP:TESTS_AGGREGATE_CAP')
        if now>=work_deadline:cleanup('GLOBAL_WORK_CAP')
        if active and now>=active['effective_deadline']:cleanup('DIAGNOSTIC_CAP')
        if sigstate:cleanup('WATCHDOG_SIGNAL_'+str(sigstate[0]))
        if now-last_resource>=1:
            last_resource=now
            try:
                sample=resources(root);sample['owned']=owned(os.getpid(),known)
                event(run/'resources.jsonl',sample)
                if not resource_ok(sample):cleanup('RESOURCE_PRESSURE')
            except Exception as e:cleanup('RESOURCE_READ_ERROR:'+type(e).__name__)
        if stopped:
            survivors=owned(os.getpid(),known)
            if now>=min(stop_at+5,deadline-2):
                for x in survivors:
                    if alive(x) and same(x):
                        try:send_signal(x,signal.SIGKILL);event(log,dict(action='KILL',identity=x))
                        except ProcessLookupError:pass
        if active:
            rc=active['p'].poll()
            # Popen reaps direct child. Adopted grandchildren are reaped separately.
            if rc is not None:
                reaped_all=False
                while True:
                    try:
                        pid,status=os.waitpid(-1,os.WNOHANG)
                        if not pid:break
                        event(log,dict(action='reaped_adopted',pid=pid,status=status))
                    except ChildProcessError:reaped_all=True;break
                rest=[x for x in owned(os.getpid(),known) if alive(x)]
                if rest and not stopped:cleanup('DESCENDANTS_AFTER_PARENT_EXIT')
                if not owned(os.getpid(),known) and reaped_all:
                    result={k:v for k,v in active.items() if k not in ['p','handles']}
                    result.update(rc=rc,signal=(-rc if rc<0 else None),end_utc=utc(),end_mono=now,termination_reason=stopped,cleanup_verified=True)
                    for f in active['handles']:f.close()
                    result['stdout_sha256']=digest(result['stdout']);result['stderr_sha256']=digest(result['stderr'])
                    save(run/(result['id']+'.json'),result)
                    if result['stage']=='test':
                        test_count+=1;last_test=result['id']
                    active=None
                    # Clearing a command deadline NEVER clears the persistent tests phase.
                    if not stopped:guard_exchange({'deadline':None},{'ack':'deadline','deadline':None})
                    reply(dict(type='result',result=result))
        if now>=deadline:
            remaining=[x for x in owned(os.getpid(),known) if alive(x)]
            event(log,dict(action='HARD_DEADLINE',remaining=remaining,cleanup_verified=not remaining))
            if p and p['start']==parent_start:
                try:send_signal(p,signal.SIGKILL)
                except ProcessLookupError:pass
            os._exit(124)
        if stopped and active is None:
            reply(dict(type='stopped',reason=stopped));return 124
        ready=wait_readable([rfd],0.05)
        if not ready:continue
        data=os.read(rfd,65536)
        if not data:main_open=False;cleanup('CONTROL_EOF');continue
        buf+=data
        while b'\n' in buf:
            line,buf=buf.split(b'\n',1);msg=json.loads(line)
            if msg['type']=='stop':cleanup(msg.get('reason','CANCELLED'));continue
            if msg['type']=='tests_begin':
                start_value=msg.get('tests_start');end_value=msg.get('tests_deadline')
                if phase!='BEFORE_TESTS' or active or stopped or test_count or msg.get('session')!=root or not isinstance(start_value,(int,float)) or not isinstance(end_value,(int,float)) or end_value-start_value!=900 or start_value>time.monotonic() or not time.monotonic()<min(end_value,work_deadline):
                    cleanup('INVALID_TESTS_BEGIN');continue
                tests_start=start_value;tests_deadline=end_value;phase='TESTS'
                expected=dict(ack='tests_begin',phase='TESTS',tests_start=tests_start,tests_deadline=tests_deadline,session=root)
                guard_exchange(msg,expected)
                if time.monotonic()>=phase_limit():cleanup('DIAGNOSTIC_CAP:TESTS_AGGREGATE_CAP');continue
                reply(dict(type='tests_begin_ack',**expected));continue
            if msg['type']=='tests_end':
                if phase!='TESTS' or active or stopped or test_count!=10 or last_test!='test-J-05' or last_parser!=last_test or msg!=dict(type='tests_end',tests_deadline=tests_deadline,session=root,completed=10,last_id=last_test) or not time.monotonic()<phase_limit():
                    cleanup('INVALID_OR_EXPIRED_TESTS_END');continue
                expected=dict(ack='tests_end',phase='AFTER_TESTS',tests_deadline=tests_deadline,session=root,completed=10,last_id=last_test)
                guard_exchange(msg,expected)
                if time.monotonic()>=phase_limit():cleanup('DIAGNOSTIC_CAP:TESTS_AGGREGATE_CAP');continue
                phase='AFTER_TESTS'
                reply(dict(type='tests_end_ack',**expected));continue
            if msg['type']=='close':
                if phase!='AFTER_TESTS' or active or owned(os.getpid(),known):cleanup('INVALID_CLOSE');continue
                guard_exchange({'closure_begin':True,'success':True},{'ack':'closure_begin','success':True})
                reply(dict(type='closed',cleanup_verified=True));return 0
            if msg['type']!='run' or active or stopped:cleanup('PROTOCOL_ERROR');continue
            spec=msg['spec']
            if spec['stage']=='test':
                if phase!='TESTS' or test_count>=10 or (last_test is not None and last_parser!=last_test):cleanup('TEST_OUTSIDE_PHASE_OR_OBSERVER_PENDING');continue
                expected_id='test-'+('Hc' if test_count<5 else 'J')+'-'+str(test_count%5+1).zfill(2)
                if spec['id']!=expected_id:cleanup('TEST_SEQUENCE_MISMATCH');continue
            elif phase=='TESTS':
                if spec['stage']!='observer' or spec['id']!='observe-'+str(last_test) or not last_test or last_parser==last_test:cleanup('NON_OBSERVER_INSIDE_TESTS_PHASE');continue
                last_parser=last_test
            eff=min(time.monotonic()+spec['cap_seconds'],phase_limit())
            if eff<=time.monotonic():cleanup('NO_BUDGET');continue
            guard_exchange(dict(deadline=eff),dict(ack='deadline',deadline=eff))
            if time.monotonic()>=eff:cleanup('DIAGNOSTIC_CAP');continue
            stdout=run/(spec['id']+'.stdout');stderr=run/(spec['id']+'.stderr')
            handles=[open(stdout,'xb'),open(stderr,'xb')]
            # Handlers only append a flag; no exception interrupts spawn/registration.
            old=None
            try:
                child=subprocess.Popen(spec['argv'],cwd=spec['cwd'],env=msg['env'],stdin=subprocess.DEVNULL,stdout=handles[0],stderr=handles[1],start_new_session=True)
                ident=proc(child.pid)
                if ident:known[child.pid]=ident
                active=dict(id=spec['id'],stage=spec['stage'],tree=spec.get('tree'),argv=spec['argv'],cwd=spec['cwd'],environment=msg['env'],start_utc=utc(),start_mono=now,effective_deadline=eff,pid=child.pid,identity=ident,stdout=str(stdout),stderr=str(stderr),p=child,handles=handles)
                event(log,dict(action='spawn',id=spec['id'],identity=ident,effective_deadline=eff))
                reply(dict(type='started',id=spec['id'],pid=child.pid,effective_deadline=eff))
            finally:pass

class Coordinator:
    def __init__(self,policy,approved_manifest_sha256):
        self.approved_manifest_sha256=approved_manifest_sha256
        self.policy=policy;self.root=pathlib.Path(policy['root'])
        if self.root!=HERE:raise RuntimeError('EXECUTION_ROOT_MISMATCH')
        self.run=self.root/'run';self.run.mkdir(exist_ok=False)
        self.deadline=START+4800;self.work_deadline=START+4500;self.buf=b'';self.matrix=json.loads((self.root/'matrix-NOT_RUN.json').read_text());self.tests_deadline=None;self.tests_start=None;self.tests_phase='BEFORE_TESTS';self.observed_tests=0;self.last_observed=None;self.gate=False;self.frozen=None;self.custody_complete=False;self._stopping=False;self.live_expected=None;self.git_expected=None;self.campaign_state='PENDING_CHECKS';self.campaign_reasons=[];self.rejection_persistence_failed=False
        self.lock=open(self.root.parent/'.causal-G1-campaign.lock','a+')
        fcntl.flock(self.lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        r,w=os.pipe();rr,ww=os.pipe();gr,gw=os.pipe();ar,aw=os.pipe();tr,tw=os.pipe();self.telemetryfd=tr;self.telemetry_open=True;self.telemetry_buffer=b'';os.set_blocking(tr,False);os.set_blocking(gw,False);self.guardfd=gw;self.guardack=ar;parent=proc(os.getpid())
        self.wd=subprocess.Popen([sys.executable,str(HERE/'supervisor.py'),'--watchdog',str(r),str(ww),str(self.deadline),str(self.work_deadline),str(os.getpid()),parent['start'],str(self.root),str(gw),str(ar),self.approved_manifest_sha256],pass_fds=(r,ww,gw,ar),stdin=subprocess.DEVNULL,stdout=open(self.run/'watchdog.stdout','xb'),stderr=open(self.run/'watchdog.stderr','xb'),start_new_session=True)
        os.close(r);os.close(ww);self.sendfd=w;self.readfd=rr
        wd_identity=proc(self.wd.pid)
        self.guard=subprocess.Popen([sys.executable,str(HERE/'guard_deadlines.py'),'--parent',str(os.getpid()),parent['start'],'--watchdog',str(self.wd.pid),wd_identity['start'],'--deadline',str(self.deadline),'--work-deadline',str(self.work_deadline),'--control-fd',str(gr),'--ack-fd',str(aw),'--telemetry-fd',str(tw),'--manifest-sha256',self.approved_manifest_sha256],pass_fds=(gr,aw,tw),stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=open(self.run/'guard.stderr','xb'),start_new_session=True)
        os.close(gr);os.close(aw);os.close(tw)
        ready_guard=b''
        while b'\n' not in ready_guard:
            rd=wait_readable([ar],max(0,self.work_deadline-time.monotonic()))
            if not rd:raise RuntimeError('GUARD_START_TIMEOUT')
            piece=os.read(ar,4096)
            if not piece:raise RuntimeError('GUARD_START_FAILED')
            ready_guard+=piece
        guard_ready=json.loads(ready_guard.split(b'\n')[0])
        if guard_ready.get('ack')!='ready':raise RuntimeError('GUARD_START_PROTOCOL')
        gi=guard_ready['execution_identity']
        self.guard_namespace=gi['namespaces']['pid']+'/pid:'+str(gi['pid'])+'/start:'+gi['identity']['start']
        self.final_snapshot_seen=False
        self.env=dict(policy['fixed_environment'])
        for directory in ('home','tmp'):(self.root/directory).mkdir(mode=0o700,exist_ok=False)
        save(self.run/'matrix.json',self.matrix)
        save(self.run/'campaign-status.json',dict(status='PENDING_CHECKS',causal_gate='CLOSED_AWAITING_D',closure='NOT_OBSERVED',reasons=[]))
        save(self.run/'custody-final-summary.json',dict(custody_complete=False,status='NOT_OBSERVED',components={n:'NOT_OBSERVED' for n in ['H','Hc','J','expediente_v1','executed_v4','references','tools','tool_alias_resolution','gate_inputs','live_git_and_files']}))
        for sig in [signal.SIGINT,signal.SIGTERM,signal.SIGHUP]:signal.signal(sig,self.cancel)
        watchdog_ready=self.receive()
        if watchdog_ready['type']!='ready':raise RuntimeError('WATCHDOG_NOT_READY')
        save(self.run/'execution-identities.json',dict(coordinator=namespace_identity(),watchdog=watchdog_ready,guard=guard_ready))
    def cancel(self,sig,frame):
        if self._stopping:return
        try:self.send(dict(type='stop',reason='COORDINATOR_SIGNAL_'+str(sig)))
        except OSError:pass
        raise RuntimeError('CANCELLED:'+str(sig))
    def send(self,x):os.write(self.sendfd,(json.dumps(x)+'\n').encode())
    def receive(self):
        while b'\n' not in self.buf:
            if self.tests_phase=='TESTS' and time.monotonic()>=self.tests_deadline:raise RuntimeError('DIAGNOSTIC_CAP:TESTS_AGGREGATE_CAP')
            if time.monotonic()>=self.work_deadline:raise RuntimeError('GLOBAL_WORK_CAP')
            ready=wait_readable([self.readfd]+([self.telemetryfd] if self.telemetry_open else []),0.1)
            if self.telemetryfd in ready:self.drain_telemetry()
            if self.readfd in ready:
                d=os.read(self.readfd,65536)
                if not d:raise RuntimeError('WATCHDOG_LOST')
                self.buf+=d
        line,self.buf=self.buf.split(b'\n',1);return json.loads(line)
    def drain_telemetry(self):
        if not self.telemetry_open:return
        while True:
            try:chunk=os.read(self.telemetryfd,65536)
            except BlockingIOError:break
            if not chunk:
                self.telemetry_open=False
                if self.telemetry_buffer:raise RuntimeError('TRUNCATED_GUARD_TELEMETRY')
                break
            self.telemetry_buffer+=chunk
            if len(self.telemetry_buffer)>1048576:raise RuntimeError('TELEMETRY_OVERFLOW')
            while b'\n' in self.telemetry_buffer:
                line,self.telemetry_buffer=self.telemetry_buffer.split(b'\n',1)
                record=json.loads(line)
                if record.get('namespace')!=self.guard_namespace:raise RuntimeError('GUARD_TELEMETRY_IDENTITY_MISMATCH')
                with open(self.run/'guard-telemetry.jsonl','ab') as out:out.write(line+b'\n');out.flush();os.fsync(out.fileno())
                if record.get('event')=='final_snapshot':self.final_snapshot_seen=True
    def guard_snapshot(self):
        if self.final_snapshot_seen:return
        os.write(self.guardfd,b'{"telemetry_snapshot":true}\n')
        ack=b''
        while b'\n' not in ack:
            remaining=self.deadline-time.monotonic()
            if remaining<=0:raise RuntimeError('GLOBAL_CAP_DURING_SNAPSHOT')
            ready=wait_readable([self.guardack]+([self.telemetryfd] if self.telemetry_open else []),min(.1,remaining))
            if self.telemetryfd in ready:self.drain_telemetry()
            if self.guardack in ready:
                data=os.read(self.guardack,4096)
                if not data:raise RuntimeError('GUARD_SNAPSHOT_CHANNEL_LOST')
                ack+=data
        if json.loads(ack.split(b'\n')[0])!={'ack':'telemetry_snapshot'}:raise RuntimeError('GUARD_SNAPSHOT_ACK')
        self.drain_telemetry()
        if not self.final_snapshot_seen:raise RuntimeError('FINAL_GUARD_SNAPSHOT_NOT_PERSISTED')
    def reject_campaign(self,reasons,row=None):
        self.campaign_state='REJECTED'
        for reason in reasons:
            if reason not in self.campaign_reasons:self.campaign_reasons.append(reason)
        if row is not None:
            local=row.setdefault('rejection_reasons',[])
            for reason in reasons:
                if reason not in local:local.append(reason)
        for item in self.matrix:
            item['causal_gate']='CLOSED_REJECTED';item['analysis_eligibility']='REJECTED'
            if 'CAMPAIGN_REJECTED' not in item.setdefault('rejection_reasons',[]):item['rejection_reasons'].append('CAMPAIGN_REJECTED')
        errors=[]
        for path,value in ((self.run/'campaign-status.json',dict(status='REJECTED',causal_gate='CLOSED_REJECTED',closure='NOT_VERIFIED',reasons=self.campaign_reasons,rejection_persistence_failed=self.rejection_persistence_failed)),(self.run/'matrix.json',self.matrix)):
            try:save(path,value)
            except BaseException as exc:errors.append(type(exc).__name__+':'+str(exc))
        if errors:
            self.rejection_persistence_failed=True
            raise RuntimeError('REJECTION_PERSISTENCE_FAILED:'+repr(errors))

    def recheck_negative(self,label,closing=False,persist=True):
        if self.frozen is None:return
        deadline=self.deadline if closing else min(self.work_deadline,self.tests_deadline if self.tests_phase=='TESTS' else self.work_deadline)
        self.frozen.check_negative_paths(label,deadline,persist=persist)

    def invoke(self,spec):
        self.recheck_negative('before-'+spec['id'])
        try:
            result=self._invoke(spec)
        except BaseException as primary:
            try:self.recheck_negative('after-'+spec['id'])
            except BaseException as secondary:
                raise RuntimeError('INVOCATION_AND_NEGATIVE_CUSTODY_FAILED:'+type(primary).__name__+':'+str(primary)+'; '+type(secondary).__name__+':'+str(secondary)) from primary
            raise
        self.recheck_negative('after-'+spec['id'])
        return result

    def _invoke(self,spec):
        bootstrap_authority(self.approved_manifest_sha256)
        if spec['stage']=='test' and not self.gate:raise RuntimeError('COMPARABILITY_NOT_PASS')
        if spec['stage']=='test' and self.tests_phase=='BEFORE_TESTS':self.begin_tests()
        if spec['stage']=='test' and self.tests_phase!='TESTS':raise RuntimeError('TESTS_PHASE_CLOSED')
        invocation_env=dict(self.env)
        if spec['stage']=='test':
            additions=spec['environment_additions']
            if set(additions)!={'AETHER_POST09_TEST_ID','AETHER_POST09_TREE_ID','AETHER_POST09_OUTPUT'}:raise RuntimeError('OBSERVER_ENV_KEYS')
            for output in (pathlib.Path(spec['observer_output']),pathlib.Path(spec['observer_output']+'.close-status')):
                if output.exists() or output.is_symlink():raise RuntimeError('OBSERVER_OUTPUT_EXISTS')
            invocation_env.update(additions)
        if spec['stage'] in ('inventory-gate','comparability'):
            spec=dict(spec,argv=[*spec['argv'],'--manifest-sha256',self.approved_manifest_sha256])
        self.send(dict(type='run',spec=spec,env=invocation_env,tests_deadline=self.tests_deadline if self.tests_phase=='TESTS' else self.work_deadline))
        while True:
            reply=self.receive()
            if reply['type']=='result':
                r=reply['result']
                if r['id']!=spec['id']:raise RuntimeError('RESULT_ID_MISMATCH')
                if r['termination_reason']:
                    if spec['stage']=='test':
                        row=next(x for x in self.matrix if x['invocation_id']==spec['id'])
                        row.update(status='DIAGNOSTIC_CAP' if 'CAP' in r['termination_reason'] else 'INTERRUPTED',termination_reason=r['termination_reason'],executable_signal='UNOBSERVED')
                        save(self.run/'matrix.json',self.matrix)
                    raise RuntimeError(r['termination_reason'])
                return r
            if reply['type']!='started':raise RuntimeError(str(reply))
            if spec['stage']=='test':
                row=next(x for x in self.matrix if x['invocation_id']==spec['id']);row.update(status='RUNNING',start_monotonic=time.monotonic())
                save(self.run/'matrix.json',self.matrix)
    def begin_tests(self):
        if self.tests_phase!='BEFORE_TESTS' or not self.gate:raise RuntimeError('INVALID_TESTS_BEGIN')
        self.tests_start=time.monotonic();self.tests_deadline=self.tests_start+900;self.tests_phase='TESTS'
        self.send(dict(type='tests_begin',tests_start=self.tests_start,tests_deadline=self.tests_deadline,session=str(self.root)))
        expected=dict(type='tests_begin_ack',ack='tests_begin',phase='TESTS',tests_start=self.tests_start,tests_deadline=self.tests_deadline,session=str(self.root))
        if self.receive()!=expected or time.monotonic()>=min(self.tests_deadline,self.work_deadline):raise RuntimeError('TESTS_BEGIN_NOT_CONFIRMED')
    def end_tests(self):
        if self.tests_phase!='TESTS' or self.observed_tests!=10 or self.last_observed!='test-J-05' or time.monotonic()>=min(self.tests_deadline,self.work_deadline):raise RuntimeError('TESTS_END_NOT_ELIGIBLE')
        msg=dict(type='tests_end',tests_deadline=self.tests_deadline,session=str(self.root),completed=10,last_id=self.last_observed)
        self.send(msg)
        expected=dict(type='tests_end_ack',ack='tests_end',phase='AFTER_TESTS',tests_deadline=self.tests_deadline,session=str(self.root),completed=10,last_id=self.last_observed)
        if self.receive()!=expected or time.monotonic()>=min(self.tests_deadline,self.work_deadline):raise RuntimeError('TESTS_END_NOT_CONFIRMED')
        self.tests_phase='AFTER_TESTS'
    def custody(self):
        s=self.policy['source_root'];live=pathlib.Path(self.policy['live']);expected=self.git_expected
        if expected is None or self.live_expected is None:raise RuntimeError('LIVE_CUSTODY_AUTHORITY_UNAVAILABLE')
        def git(*args):
            spec=dict(id='custody-'+str(time.monotonic_ns()),stage='custody',cap_seconds=10,cwd=str(live),argv=[self.policy['tools']['git']['path'],'--no-optional-locks','-C',str(live),*args])
            result=self.invoke(spec)
            if result['rc']!=0:raise RuntimeError('GIT_CUSTODY_READ_FAILED')
            return pathlib.Path(result['stdout']).read_bytes()
        ix=pathlib.Path(git('rev-parse','--git-path','index').decode().strip());ix=ix if ix.is_absolute() else live/ix
        got=dict(head=git('rev-parse','HEAD').decode().strip(),branch=git('branch','--show-current').decode().strip(),index_sha256=digest(ix),patch_sha256=hashlib.sha256(git('diff','--binary')).hexdigest(),status=git('status','--porcelain=v1','--untracked-files=all').decode(),cached_bytes=len(git('diff','--cached')))
        got['status_entries']=len(got['status'].splitlines())
        if got!=expected:raise RuntimeError('LIVE_CUSTODY_DIVERGENCE')
        for rel,h in self.live_expected.items():
            if digest(live/rel)!=h:raise RuntimeError('LIVE_FILE_DIVERGENCE:'+rel)
        return got
    def preflight(self):
        self.frozen=FrozenCustody(self.policy,save,self.approved_manifest_sha256)
        self.frozen.check('preflight',self.work_deadline)
        self.live_expected=self.frozen.approved_json('live-files-before.json')
        self.git_expected=self.frozen.approved_json('custody-before.json')
        for k in self.policy['forbidden_environment']:
            if os.environ.get(k):raise RuntimeError('UNAPPROVED_ENVIRONMENT:'+k)
        for p,row in load_list(self.root,self.approved_manifest_sha256).items():
            if digest(self.root/p)!=row['sha256']:raise RuntimeError('NEW_HASH_DIVERGENCE:'+p)
        for p,h in self.policy['references'].items():
            if digest(p)!=h:raise RuntimeError('REFERENCE_DIVERGENCE:'+p)
        old=pathlib.Path(self.policy['source_root'])
        for p,h in json.loads((old/'evidence.sha256.json').read_text()).items():
            if digest(old/p)!=h:raise RuntimeError('V1_HASH_DIVERGENCE:'+p)
        for t in self.policy['tools'].values():
            if digest(t['path'])!=t['sha256']:raise RuntimeError('TOOL_DIVERGENCE')
        for name,t in self.policy['tool_aliases'].items():
            effective=shutil.which(name,path=self.env.get('PATH',''))
            if not effective or str(pathlib.Path(effective).resolve())!=t['resolved'] or digest(effective)!=t['sha256'] or digest(t['path'])!=t['sha256']:raise RuntimeError('TOOL_ALIAS_DIVERGENCE:'+name)
        for p in self.policy['builds'].values():
            if pathlib.Path(p).exists() or pathlib.Path(p).is_symlink():raise RuntimeError('BUILD_EXISTS')
        sample=resources(self.root)
        if not resource_ok(sample):raise RuntimeError('INSUFFICIENT_RESOURCES')
        # The classifier validates its own approved bytes and derives the launch
        # contract solely from entry.json plus the externally approved digest.
        from concurrency_preflight import scan
        own_records=json.loads((self.run/'execution-identities.json').read_text())
        scan(self.policy,self.approved_manifest_sha256,own_records,
             lambda report:save(self.run/'concurrency-preflight.json',report),
             entry_filename='entry.json')
        loc=self.invoke(dict(id='locales',stage='preflight',cap_seconds=10,cwd=str(self.root),argv=[self.policy['tools']['locale']['path'],'-a']))
        if loc['rc']!=0:raise RuntimeError('LOCALE_DISCOVERY_FAILED')
        if os.uname().machine!=self.policy['architecture']:raise RuntimeError('ARCHITECTURE_DIFFERENCE')
        save(self.run/'preflight.json',dict(status='PASS',architecture=os.uname().machine,uname=list(os.uname()),environment=self.env,resources=sample,custody=self.custody(),utc=utc()))
    def observe_test(self,spec,r):
        row=next(x for x in self.matrix if x['tree']==spec['tree'] and x['name']==spec['name'])
        row.update(causal_gate='CLOSED_AWAITING_D',analysis_eligibility='PENDING_CHECKS')
        try:
            self._observe_test_details(spec,r)
        except BaseException as exc:
            if self.campaign_state!='REJECTED':self.reject_campaign([type(exc).__name__+':'+str(exc)],row)
            raise

    def _observe_test_details(self,spec,r):
        # CTest JUnit is explicitly requested; it records observed one-test status.
        xml=pathlib.Path(spec['junit']);root=ET.parse(xml).getroot();cases=root.findall('.//testcase')
        if len(cases)!=1 or cases[0].get('name')!=spec['name']:raise RuntimeError('TEST_NOT_EXACTLY_ONE')
        c=cases[0]
        if c.find('skipped') is not None:raise RuntimeError('UNEXPECTED_SKIP')
        if c.find('error') is not None:raise RuntimeError('TEST_INFRASTRUCTURE_ERROR')
        fail=c.find('failure');text='' if fail is None else ET.tostring(fail,encoding='unicode')
        if c.get('status','run').lower() in ['notrun','disabled'] or any(x in text for x in ['Not Run','Unable to find executable','Failed to change working directory']):raise RuntimeError('TEST_NOT_EXECUTED')
        status='PASS' if fail is None else ('TIMEOUT' if 'Timeout' in text else ('ABORT' if 'Subprocess aborted' in text or 'Exception' in text else 'FAIL'))
        if r['rc'] not in [0,8] or (status=='PASS')!=(r['rc']==0):raise RuntimeError('CTEST_RC_STATUS_MISMATCH')
        row=next(x for x in self.matrix if x['tree']==spec['tree'] and x['name']==spec['name'])
        row.update(status=status,ctest_rc=r['rc'],ctest_signal=r['signal'],executable_signal='UNOBSERVED',assertions_not_emitted='UNOBSERVED',junit=str(xml),junit_sha256=digest(xml),stdout=r['stdout'],stderr=r['stderr'])
        save(self.run/'matrix.json',self.matrix)
        row['product_status']=status
        row['operational_status']='TEST_REAPED_CLEANUP_VERIFIED' if r.get('cleanup_verified') else 'INCOMPLETE'
        row['observer_status']='NOT_PARSED'
        historical=json.loads((self.root/'signatures-09.json').read_text())
        matches=[x for x in historical if x['name']==spec['name'] and ('test-'+spec['tree']+'-') in x['path']]
        if len(matches)!=1:raise RuntimeError('HISTORICAL_SIGNATURE_NOT_UNIQUE')
        expected=matches[0]
        got_text=c.findtext('system-out') or ''
        got_failure=None if fail is None else fail.attrib
        row['signature_comparison']={'status':'MATCH' if got_text==(expected.get('system_out') or '') and got_failure==expected.get('failure') and c.get('status')==expected.get('status') else 'DIVERGED','original_system_out':got_text,'original_failure':got_failure,'historical_sha256':expected['sha256'],'normalization':'NONE'}
        save(self.run/'matrix.json',self.matrix)
        self.observed_tests+=1;self.last_observed=spec['id']
        reasons=[]
        if not r.get('cleanup_verified'):reasons.append('TEST_CLEANUP_UNVERIFIED')
        if spec['name'] in ['aether.smoke','aether.abi-c'] and status!='PASS':reasons.append('CONTROL_FAILED')
        if row['signature_comparison']['status']!='MATCH':reasons.append('PRODUCT_SIGNATURE_DIVERGED')
        if r.get('cleanup_verified'):
            try:self.observe_instrumentation(spec,row)
            except BaseException as exc:reasons.append('OBSERVER_OR_OPERATIONAL_FAILURE:'+type(exc).__name__+':'+str(exc))
        else:
            row.update(observer_status='UNOBSERVED',observer_reason='CLEANUP_UNVERIFIED_NO_PARSER_LAUNCH')
        if reasons:
            self.reject_campaign(reasons,row)
            raise RuntimeError('ROW_CHECKS_REJECTED:'+repr(reasons))
        row.update(analysis_eligibility='ROW_CHECKS_SATISFIED',causal_gate='CLOSED_AWAITING_D')
        save(self.run/'matrix.json',self.matrix)
    def observe_instrumentation(self,spec,row):
        data=pathlib.Path(spec['observer_output']);close=pathlib.Path(str(data)+'.close-status')
        def plain(path):
            import stat
            return not path.is_symlink() and path.is_file() and stat.S_ISREG(path.lstat().st_mode)
        if not plain(data) or not plain(close):
            row.update(observer_status='UNOBSERVED',observer_reason='MISSING_OR_NONREGULAR_DATA_OR_CLOSE_STATUS')
            save(self.run/'matrix.json',self.matrix);raise RuntimeError('OBSERVER_FILES_UNAVAILABLE')
        if data.stat().st_size>8388608 or close.stat().st_size!=80:
            row.update(observer_status='INVALID',observer_reason='DATA_OR_CLOSE_SIZE')
            save(self.run/'matrix.json',self.matrix);raise RuntimeError('OBSERVER_SIZE')
        before={str(p):dict(bytes=p.stat().st_size,sha256=digest(p)) for p in (data,close)}
        output=self.run/('observer-report-'+spec['id']+'.json')
        parser_spec=dict(id='observe-'+spec['id'],stage='observer',tree=spec['tree'],cap_seconds=120,cwd=str(self.root),argv=[self.policy['tools']['python3']['path'],str(self.root/'parse_post09_observer.py'),'--input',str(data),'--close-status',str(close),'--output',str(output)])
        parsed=self.invoke(parser_spec)
        for path,record in before.items():
            if not plain(pathlib.Path(path)) or pathlib.Path(path).stat().st_size!=record['bytes'] or digest(path)!=record['sha256']:raise RuntimeError('OBSERVER_INPUT_MUTATED')
        if not plain(output):
            row.update(observer_status='INVALID',observer_reason='NO_REGULAR_PARSER_REPORT')
            save(self.run/'matrix.json',self.matrix);raise RuntimeError('PARSER_REPORT_UNAVAILABLE')
        report=json.loads(output.read_text())
        complete=(parsed['rc']==0 and parsed.get('cleanup_verified') is True and all(report.get(k) is True for k in ('syntax_valid','protocol_valid','capture_complete','target_correlation_valid','observer_complete')) and report.get('missing_cases')==[] and isinstance(report.get('close_evidence'),dict) and report['close_evidence'].get('record_valid') is True and report['close_evidence'].get('positive') is True and report['close_evidence'].get('data_close_rc')==0 and report.get('not_a_product_test_verdict') is True and type(report.get('test_id')) is int and type(report.get('tree_id')) is int and report.get('test_id')==int(spec['environment_additions']['AETHER_POST09_TEST_ID']) and report.get('tree_id')==int(spec['environment_additions']['AETHER_POST09_TREE_ID']))
        row.update(observer_status='COMPLETE' if complete else ('INVALID' if report.get('syntax_valid') is not True or report.get('protocol_valid') is not True else 'INCOMPLETE'),observer_report=str(output),observer_report_sha256=digest(output),observer_inputs=before,close_evidence=report.get('close_evidence'),observer_coverage=report.get('slots'))
        save(self.run/'matrix.json',self.matrix)
        if not complete:raise RuntimeError('OBSERVER_CAPTURE_NOT_COMPLETE')

    def guard_read_ack(self):
        raw=b''
        while b'\n' not in raw:
            remaining=self.deadline-time.monotonic()
            if remaining<=0:raise RuntimeError('GUARD_CLOSURE_CAP')
            ready=wait_readable([self.guardack]+([self.telemetryfd] if self.telemetry_open else []),min(.1,remaining))
            if self.telemetryfd in ready:self.drain_telemetry()
            if self.guardack in ready:
                part=os.read(self.guardack,4096)
                if not part:raise RuntimeError('GUARD_CLOSURE_CHANNEL_LOST')
                raw+=part
        if raw.count(b'\n')!=1 or not raw.endswith(b'\n'):raise RuntimeError('GUARD_CLOSURE_FRAMING')
        return json.loads(raw),raw

    def freeze_runtime_artifacts(self):
        import stat
        records=[]
        for dirname in ('run','build-Hc','build-J','home','tmp'):
            folder=self.root/dirname
            if not folder.exists():continue
            if folder.is_symlink():raise RuntimeError('RUNTIME_ROOT_SYMLINK')
            for directory,dirs,names in os.walk(folder,followlinks=False):
                for name in dirs:
                    if (pathlib.Path(directory)/name).is_symlink():raise RuntimeError('RUNTIME_DIRECTORY_SYMLINK')
                for name in sorted(names):
                    path=pathlib.Path(directory)/name
                    if path==self.run/'runtime-artifacts.sha256.json':continue
                    if time.monotonic()>=self.deadline:raise RuntimeError('RUNTIME_MANIFEST_CLOSURE_CAP')
                    rel=str(path.relative_to(self.root));mode=path.lstat().st_mode
                    if stat.S_ISREG(mode):records.append(dict(path=rel,type='regular',bytes=path.stat().st_size,sha256=digest(path)))
                    elif stat.S_ISLNK(mode) and dirname.startswith('build-'):
                        resolved=path.resolve()
                        if not resolved.is_relative_to(folder) or not resolved.is_file():raise RuntimeError('RUNTIME_LINK_OUTSIDE_BUILD')
                        records.append(dict(path=rel,type='symlink',target=os.readlink(path),resolved=str(resolved.relative_to(self.root)),bytes=resolved.stat().st_size,sha256=digest(resolved)))
                    else:raise RuntimeError('RUNTIME_FILE_TYPE:'+rel)
        save(self.run/'runtime-artifacts.sha256.json',dict(status='SNAPSHOT_AFTER_DONE_ACK_BEFORE_GUARD_RELEASE',records=records,self_excluded=True,guard_returncode='NOT_YET_OBSERVED'))

    def persist_guard_done(self,success):
        self.recheck_negative('closure-before-done',closing=True)
        os.write(self.guardfd,b'{"done":true}\n')
        ack,raw=self.guard_read_ack()
        expected={'ack':'done','identified_work_exited':True,'reaping':'NOT_OBSERVED_BY_GUARD'}
        if ack!=expected:raise RuntimeError('GUARD_DONE_ACK')
        # The guard remains alive with parent pinned until the next message.
        ackpath=self.run/'closure-ack.json'
        save(ackpath,dict(ack=ack,raw_utf8=raw.decode('utf-8'),received_monotonic=time.monotonic(),campaign_success=bool(success),guard_rc='NOT_YET_OBSERVED',durability='file fsync before guard release; no storage-failure guarantee'))
        if time.monotonic()>=self.deadline:raise RuntimeError('ACK_PERSISTENCE_CAP')
        self.recheck_negative('closure-before-runtime-snapshot',closing=True)
        self.freeze_runtime_artifacts()
        self.recheck_negative('closure-after-runtime-snapshot',closing=True,persist=False)
        msg={'ack_persisted':True,'sha256':digest(ackpath)}
        os.write(self.guardfd,(json.dumps(msg)+'\n').encode())
        persisted,_=self.guard_read_ack()
        if persisted!={'ack':'ack_persisted','sha256':msg['sha256']}:raise RuntimeError('GUARD_PERSISTED_ACK')
        if self.guard.wait(timeout=max(.001,self.deadline-time.monotonic()))!=0:raise RuntimeError('GUARD_FINAL_RC')
        self.closure_confirmed=True # no required IO after guard exit; external return remains separate

    def execute(self):
        self.preflight()
        for spec in json.loads((self.root/'argv.json').read_text()):
            r=self.invoke(spec)
            if spec['stage']=='test':self.observe_test(spec,r)
            elif r['rc']!=0:raise RuntimeError('STAGE_FAILED:'+spec['id'])
            if spec['stage'] in ['inventory-gate','comparability']:
                result=json.loads(pathlib.Path(spec['output']).read_text())
                if result.get('status')!='PASS':raise RuntimeError('GATE_NOT_PASS')
                if spec['stage']=='comparability':
                    self.frozen.freeze_gate(result);self.gate=True
        self.end_tests()
        final_frozen=self.frozen.check('final',self.work_deadline)
        save(self.run/'custody-after.json',self.custody())
        self.custody_complete=True
        save(self.run/'custody-final-summary.json',dict(custody_complete=True,status='PASS',components={**{n:c['status'] for n,c in final_frozen['components'].items()},'live_git_and_files':'PASS'}))
        self.send(dict(type='close'))
        if self.receive()['type']!='closed':raise RuntimeError('CLEANUP_NOT_VERIFIED')
        self.wd.wait(timeout=max(.1,self.deadline-time.monotonic()))
        self.guard_snapshot()
        save(self.run/'outcome.json',dict(status='DIAGNOSTIC_RESULTS_RECORDED_CLOSURE_PENDING',custody_complete=self.custody_complete,cleanup_verified=False,end=utc(),wall=time.monotonic()-START,note='Final guard ACK and rc are checked before supervisor returns; this pre-exit record does not certify closure'))
        save(self.run/'campaign-status.json',dict(status='READY_FOR_D_REVIEW',causal_gate='CLOSED_AWAITING_D',closure='CLOSURE_PENDING',required_evidence=['closure-ack.json','external supervisor return and guard rc observation'],note='not a terminal closure certificate or causal approval'))
        self.persist_guard_done(True)
    def stop(self,error):
        self._stopping=True;self.tests_phase='STOPPED'
        try:self.send(dict(type='stop',reason=str(error)))
        except OSError:pass
        rejection_error=None
        try:self.reject_campaign([type(error).__name__+':'+str(error)])
        except BaseException as exc:rejection_error=type(exc).__name__+':'+str(exc)
        save(self.run/'outcome.json',dict(status='STOPPED/INCOMPLETE_CUSTODY',reason=str(error),end=utc(),wall=time.monotonic()-START,cleanup_verified=False,custody_complete=False,frozen_components='See incremental custody-frozen reports; unreported components NOT_OBSERVED'))
        # Pending rows remain NOT_RUN; a started capped test is separately marked.
        for p in self.run.glob('test-*.json'):
            r=json.loads(p.read_text())
            if r.get('termination_reason'):
                for row in self.matrix:
                    if row.get('invocation_id')==r['id']:row.update(status='DIAGNOSTIC_CAP' if 'CAP' in r['termination_reason'] else 'INTERRUPTED',termination_reason=r['termination_reason'])
        save(self.run/'matrix.json',self.matrix)
        try:
            live=pathlib.Path(self.policy['live']);old=pathlib.Path(self.policy['source_root'])
            if self.live_expected is None:raise RuntimeError('LIVE_CUSTODY_AUTHORITY_UNAVAILABLE')
            mismatches=[p for p,h in self.live_expected.items() if not (live/p).is_file() or digest(live/p)!=h]
            save(self.run/'custody-stop.json',dict(file_mismatches=mismatches,git_metadata='UNOBSERVED_AFTER_STOP',status='INCOMPLETE_CUSTODY_CHECK'))
        except Exception as e:event(self.run/'errors.jsonl',dict(custody_stop_error=type(e).__name__))
        try:self.wd.wait(timeout=max(.1,self.deadline-time.monotonic()-1))
        except subprocess.TimeoutExpired:pass
        secondary=[] if rejection_error is None else [rejection_error]
        try:self.drain_telemetry()
        except Exception as exc:secondary.append('telemetry:'+type(exc).__name__+':'+str(exc))
        if self.wd.poll() is not None:
            try:
                os.write(self.guardfd,b'{"closure_begin":true,"success":false}\n')
                ack,_=self.guard_read_ack()
                if ack!={'ack':'closure_begin','success':False}:raise RuntimeError('ABORT_CLOSURE_BEGIN_ACK')
                self.guard_snapshot()
                save(self.run/'closure-errors.json',dict(primary=str(error),secondary=secondary,guard_returncode=self.guard.poll(),cleanup_verified=False))
                self.persist_guard_done(False)
            except Exception as exc:
                # A failed persistence/protocol must never release the guard.
                secondary.append(type(exc).__name__+':'+str(exc))
                try:save(self.run/'closure-errors.json',dict(primary=str(error),secondary=secondary,cleanup_verified=False))
                except Exception:pass
                try:self.guard.wait(timeout=max(.001,self.deadline-time.monotonic()))
                except subprocess.TimeoutExpired:pass

if __name__=='__main__':
    # D requires this unconditional lock throughout materialization. A reviewed
    # source/hash delta, not a policy flag, is needed even after implementation.
    raise SystemExit('MATERIALIZATION_ONLY: D execution gate remains closed')
    if len(sys.argv)>1 and sys.argv[1]=='--watchdog':
        bootstrap_authority(sys.argv[11])
        try:sys.exit(watchdog(int(sys.argv[2]),int(sys.argv[3]),float(sys.argv[4]),float(sys.argv[5]),int(sys.argv[6]),sys.argv[7],sys.argv[8],int(sys.argv[9]),int(sys.argv[10])))
        except BaseException:
            known=WATCHDOG_KNOWN
            try:owned(os.getpid(),known)
            except Exception:pass
            for identity in list(known.values()):
                try:send_signal(identity,signal.SIGKILL)
                except Exception:pass
            raise
    if len(sys.argv)!=3 or sys.argv[1]!='--manifest-sha256':raise SystemExit('Required approved --manifest-sha256')
    c=None
    try:
        approved_manifest=sys.argv[2]
        bootstrap_authority(approved_manifest)
        from manifest_contract import load_list
        approved_files=load_list(HERE,approved_manifest)
        for name in ('run','build-Hc','build-J','home','tmp'):
            if (HERE/name).exists() or (HERE/name).is_symlink():raise RuntimeError('OUTPUT_ALREADY_EXISTS:'+name)
        from frozen_custody import FrozenCustody
        policy_bytes=(HERE/'policy.json').read_bytes()
        if len(policy_bytes)!=approved_files['policy.json']['bytes'] or hashlib.sha256(policy_bytes).hexdigest()!=approved_files['policy.json']['sha256']:raise RuntimeError('POLICY_NOT_APPROVED')
        c=Coordinator(json.loads(policy_bytes),approved_manifest);c.execute()
    except BaseException as e:
        if c is not None:c.stop(e)
        raise

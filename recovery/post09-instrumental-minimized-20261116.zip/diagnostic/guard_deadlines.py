#!/usr/bin/env python3
"""STATIC-PREPARED, NOT EXECUTED. Minimal independent deadline guard.
No files written, fsync, subprocesses, product execution or killpg.
Bootstrap reads/hashes approved helper files before starting protection.
A coordinator must wait for the deadline ACK before every watchdog spawn.
Exit status never certifies reaping: only the watchdog/subreaper can reap its children.
"""
import hashlib
import pathlib
import argparse
import errno
import json
import math
import os
from pathlib import Path
import select
import signal
import sys
import time


def identity(pid):
    try:
        text=Path('/proc',str(pid),'stat').read_text()
        fields=text[text.rfind(')')+2:].split()
        return {'pid':int(pid),'ppid':int(fields[1]),'start':fields[19],'state':fields[0]}
    except (FileNotFoundError, ProcessLookupError):
        return None



def execution_identity():
    pid=os.getpid()
    return dict(pid=pid,identity=identity(pid),
                namespaces={name:os.readlink('/proc/self/ns/'+name) for name in ('pid','mnt','user')})


class TelemetryError(RuntimeError):
    """A required telemetry event could not be delivered; no silent continuation."""

class PidfdError(RuntimeError):
    """Observation/handle error, not proof of process exit."""


def poll_readable(fd,timeout_ms=0):
    if not hasattr(select,'poll'):
        raise PidfdError('POLL_REQUIRED')
    poller=select.poll()
    poller.register(fd,select.POLLIN|select.POLLHUP|select.POLLERR)
    events=poller.poll(timeout_ms)
    for observed,mask in events:
        if mask & select.POLLNVAL:
            raise PidfdError('POLL_INVALID_FD:'+str(fd))
        if mask & select.POLLERR and not mask & (select.POLLIN|select.POLLHUP):
            raise PidfdError('POLL_ERROR:'+str(fd))
    return bool(events)


class HandleLedger:
    """Public production handle lifecycle, also used directly by the synthetic harness.
    `live` counts open pidfds, not unreaped child processes. Metadata is retained
    after retirement, but fd is set to None BEFORE close and never used again.
    """
    def __init__(self,emit=None):
        self.execution_identity=execution_identity()
        self.namespace=self.execution_identity['namespaces']['pid']+'/pid:'+str(os.getpid())+'/start:'+self.execution_identity['identity']['start']
        self.emit_callback=emit
        self.records={}
        self.opened=0;self.retired=0;self.live=0;self.peak=0
        self.errors=[];self.evidence_incomplete=False;self.primary_error=None;self.emission_disabled=False

    def stats(self):
        return dict(namespace=self.namespace,pidfd_namespace=self.execution_identity['namespaces']['pid'],
                    namespaces=self.execution_identity['namespaces'],opened=self.opened,live=self.live,
                    retired=self.retired,peak=self.peak,evidence_incomplete=self.evidence_incomplete,
                    error_count=len(self.errors))

    def emit(self,event,record=None,**extra):
        if self.emission_disabled:return
        data=dict(event=event,namespace=self.namespace,mono=time.monotonic(),stats=self.stats(),**extra)
        if record is not None:
            data['identity']={k:record[k] for k in ('pid','start','role','token','initial_fd','state','exit_observed')}
            data['fd']=record['fd']
        if self.emit_callback is not None:
            try:self.emit_callback(data)
            except Exception as exc:
                error=dict(operation='telemetry',error=type(exc).__name__+':'+str(exc))
                self.errors.append(error);self.evidence_incomplete=True
                if self.primary_error is None:self.primary_error=error
                raise TelemetryError('TELEMETRY_FAILED') from exc

    def record_error(self,record,operation,exc):
        error=dict(operation=operation,error=type(exc).__name__+':'+str(exc),
                   errno=getattr(exc,'errno',None),pid=record.get('pid'),start=record.get('start'))
        record['errors'].append(error);self.errors.append(error);self.evidence_incomplete=True
        if self.primary_error is None:self.primary_error=error
        # Cleanup must proceed through all records even if this event also fails.
        try:self.emit('error',record,error=error)
        except TelemetryError:pass

    def adopted(self,pid,start,fd,role):
        self.opened+=1;self.live+=1;self.peak=max(self.peak,self.live)
        rec=dict(pid=pid,start=str(start),fd=fd,initial_fd=fd,role=role,
                 token=self.opened,state='PINNED',exit_observed=False,identity_validated=False,errors=[],
                 signal_counts={},_ledger=self)
        self.records[rec['token']]=rec
        self.emit('init',rec)
        return rec


def pin(pid,start,ledger=None,role='descendant'):
    ledger=ledger if ledger is not None else HandleLedger()
    before=identity(pid)
    if before is None or before['start']!=str(start):
        return None
    try:fd=os.pidfd_open(pid,0)
    except ProcessLookupError:return None
    # Register ownership immediately, even if telemetry/identity validation fails.
    try:
        rec=ledger.adopted(pid,start,fd,role)
    except BaseException:
        rec=ledger.records[ledger.opened]
        try:retire(rec,'PIN_REGISTRATION_FAILURE',exit_observed=False)
        except BaseException:pass
        raise
    after=identity(pid)
    if after is None or before['pid']!=after['pid'] or before['start']!=after['start']:
        retire(rec,'IDENTITY_CHANGED_DURING_PIN',exit_observed=False)
        return None
    rec['identity_validated']=True
    return rec


def retire(record,reason='EXIT_OBSERVED',exit_observed=False,already_closed=False):
    """Close at most once. Repeated calls return False and never touch an integer fd."""
    fd=record.get('fd')
    if fd is None:return False
    ledger=record['_ledger']
    record['fd']=None;record['state']='RETIRED';record['exit_observed']=bool(exit_observed)
    record['retirement_reason']=reason
    ledger.live-=1;ledger.retired+=1
    if not already_closed:
        try:os.close(fd)
        except OSError as exc:ledger.record_error(record,'close',exc)
    ledger.emit('retire',record,reason=reason)
    return True


def exited(record):
    """Observe via poll, retire immediately on exit. Never use FD_SETSIZE APIs."""
    if record.get('fd') is None:
        if record['exit_observed']:return True
        raise PidfdError('RETIRED_WITHOUT_EXIT_OBSERVATION')
    try:ready=poll_readable(record['fd'],0)
    except Exception as exc:
        record['_ledger'].record_error(record,'poll',exc)
        raise
    if ready:
        retire(record,'EXIT_OBSERVED',exit_observed=True)
        return True
    return False


def safe_signal(record,sig):
    """Signal directly through the pinned pidfd. No exit poll in this path.
    Always returns per-record metadata; errors never abort another record's attempt.
    """
    if record.get('fd') is None:
        return dict(status='RETIRED_NO_SIGNAL',pid=record['pid'],start=record['start'])
    try:
        signal.pidfd_send_signal(record['fd'],sig,None,0)
        key=str(int(sig));record['signal_counts'][key]=record['signal_counts'].get(key,0)+1
        return dict(status='SENT',signal=int(sig),pid=record['pid'],start=record['start'])
    except OSError as exc:
        if exc.errno==errno.ESRCH:
            # ESRCH is terminal but is NOT reaping evidence. Retirement is bounded.
            try:retire(record,'SIGNAL_ESRCH',exit_observed=True)
            except Exception as secondary:record['_ledger'].record_error(record,'retire_after_ESRCH',secondary)
            return dict(status='ESRCH',signal=int(sig),pid=record['pid'],start=record['start'])
        record['_ledger'].record_error(record,'pidfd_send_signal',exc)
        if exc.errno==errno.EBADF:
            # The numeric fd has already ceased to be ours. Detach immediately;
            # never close/reuse that integer after the invalid-handle observation.
            try:retire(record,'INVALID_FD_EBADF',exit_observed=False,already_closed=True)
            except Exception as secondary:record['_ledger'].record_error(record,'retire_after_EBADF',secondary)
        return dict(status='ERROR',signal=int(sig),errno=exc.errno,pid=record['pid'],start=record['start'])
    except Exception as exc:
        record['_ledger'].record_error(record,'pidfd_send_signal',exc)
        return dict(status='ERROR',signal=int(sig),errno=None,pid=record['pid'],start=record['start'])


def bootstrap_authority(expected):
    # This code deliberately uses only stdlib already loaded above. No local
    # module is imported until every executable helper has been authenticated.
    import stat
    if len(expected)!=64 or any(c not in '0123456789abcdef' for c in expected):raise RuntimeError('BOOTSTRAP_SHA_SCHEMA')
    root=pathlib.Path(__file__).resolve().parent
    mp=root/'evidence.sha256.json'
    if mp.is_symlink() or not stat.S_ISREG(mp.lstat().st_mode):raise RuntimeError('BOOTSTRAP_MANIFEST_TYPE')
    raw=mp.read_bytes()
    if hashlib.sha256(raw).hexdigest()!=expected:raise RuntimeError('BOOTSTRAP_MANIFEST_SHA')
    def no_duplicate_keys(items):
        result={}
        for key,value in items:
            if key in result:raise RuntimeError('BOOTSTRAP_DUPLICATE_JSON_KEY')
            result[key]=value
        return result
    rows=json.loads(raw,object_pairs_hook=no_duplicate_keys)
    if not isinstance(rows,list):raise RuntimeError('BOOTSTRAP_MANIFEST_LIST')
    records={}
    for row in rows:
        if not isinstance(row,dict) or set(row)!={'path','bytes','sha256'}:raise RuntimeError('BOOTSTRAP_ROW_SCHEMA')
        key=row['path']
        if not isinstance(key,str) or not key or '\\' in key or '\x00' in key or key.startswith('/') or any(x in ('','.','..') for x in key.split('/')):raise RuntimeError('BOOTSTRAP_PATH')
        if key in records or key=='evidence.sha256.json':raise RuntimeError('BOOTSTRAP_DUPLICATE')
        if type(row['bytes']) is not int or row['bytes']<0 or not isinstance(row['sha256'],str) or len(row['sha256'])!=64 or any(c not in '0123456789abcdef' for c in row['sha256']):raise RuntimeError('BOOTSTRAP_SIZE_SHA')
        records[key]=row
    required=('supervisor.py','guard_deadlines.py','manifest_contract.py','frozen_custody.py','concurrency_preflight.py','verify_comparability.py','parse_post09_observer.py')
    for name in required:
        row=records.get(name);p=root/name
        if row is None or p.is_symlink() or not stat.S_ISREG(p.lstat().st_mode):raise RuntimeError('BOOTSTRAP_HELPER_TYPE:'+name)
        data=p.read_bytes()
        if len(data)!=row['bytes'] or hashlib.sha256(data).hexdigest()!=row['sha256']:raise RuntimeError('BOOTSTRAP_HELPER_HASH:'+name)
    return records

class Guard:
    def __init__(self,args):
        if not hasattr(os,'pidfd_open') or not hasattr(signal,'pidfd_send_signal') or not hasattr(select,'poll'):
            raise RuntimeError('PIDFD_REQUIRED')
        self.args=args
        self.telemetry_fd=getattr(args,'telemetry_fd',None)
        if self.telemetry_fd is not None:os.set_blocking(self.telemetry_fd,False)
        self.ledger=HandleLedger(self.telemetry)
        self.telemetry_finalized=False
        self.parent=pin(args.parent[0],args.parent[1],self.ledger,role='parent')
        self.wd=pin(args.watchdog[0],args.watchdog[1],self.ledger,role='watchdog')
        if self.parent is None or self.wd is None:
            raise RuntimeError('INITIAL_IDENTITY_NOT_PRESENT')
        self.known={}
        self.phase_deadline=None
        self.phase="BEFORE_TESTS"
        self.tests_start=None
        self.tests_deadline=None
        self.tests_session=None
        self.stopping=None
        self.kill_at=None
        self.pipe_open=True
        self.buf=b''
        self.signals=[]
        self.done=False
        self.done_ack_sent=False
        self.closure_started=False
        self.ackfd=args.ack_fd
        os.set_blocking(args.control_fd,False)
        if self.ackfd is not None:
            os.set_blocking(self.ackfd,False)
        for sig in (signal.SIGINT,signal.SIGTERM,signal.SIGHUP):
            signal.signal(sig,lambda s,f:self.signals.append(s))

    def telemetry(self,event):
        if self.telemetry_fd is None:return
        payload=(json.dumps(event)+'\n').encode()
        if len(payload)>4096:raise TelemetryError('TELEMETRY_EVENT_TOO_LARGE')
        # No blocking writer or disk IO in the guard. Reader persists elsewhere.
        if os.write(self.telemetry_fd,payload)!=len(payload):
            raise TelemetryError('TELEMETRY_PARTIAL_WRITE')

    def stats(self):
        return self.ledger.stats()

    def ack(self,kind,cutoff=None,**fields):
        if self.ackfd is None:
            return
        payload=(json.dumps(dict(ack=kind,**fields))+'\n').encode()
        if len(payload)>4096:
            raise RuntimeError('ACK_TOO_LARGE')
        # Atomic small writes only. Failure means no new spawn can be authorized.
        if cutoff is not None and time.monotonic()>=cutoff:
            raise RuntimeError('ACK_DEADLINE_EXPIRED')
        written=os.write(self.ackfd,payload)
        if written!=len(payload):
            raise RuntimeError('ACK_INCOMPLETE')
        if cutoff is not None and time.monotonic()>=cutoff:
            raise RuntimeError('ACK_CROSSED_DEADLINE')

    def scan(self):
        # Retire observed exits first; retain their identities but never open handles.
        for rec in [self.parent,self.wd,*self.known.values()]:
            if rec.get('fd') is not None:exited(rec)
        rows={}
        for entry in Path('/proc').iterdir():
            if entry.name.isdigit():
                row=identity(entry.name)
                if row is not None:rows[row['pid']]=row
        parents=set()
        for rec in [self.wd,*self.known.values()]:
            row=rows.get(rec['pid'])
            if rec.get('fd') is not None and row and row['start']==rec['start']:
                parents.add(rec['pid'])
        while True:
            added=False
            for pid,row in rows.items():
                key=(pid,row['start'])
                if pid==os.getpid() or pid==self.parent['pid'] or pid in parents:
                    continue
                # Do not repeatedly reopen the same terminated/zombie identity.
                if key in self.known and self.known[key].get('fd') is None:
                    continue
                if row['ppid'] in parents:
                    rec=pin(pid,row['start'],self.ledger)
                    if rec is not None:
                        self.known[key]=rec;parents.add(pid);added=True
            if not added:break
        if self.ledger.evidence_incomplete:
            raise TelemetryError('HANDLE_EVIDENCE_INCOMPLETE')

    def targets(self):
        return [r for r in self.ledger.records.values() if r['role']!='parent' and r['identity_validated']]

    def stop(self,reason,now):
        if self.stopping is None:
            self.stopping=reason
            self.phase="STOPPED"
            self.kill_at=min(now+5,self.args.deadline)
            # Freeze the ancestor before inventorying its fork-capable descendants.
            safe_signal(self.wd,signal.SIGSTOP)
            stable=0
            previous=None
            freeze_limit=min(now+1,self.args.deadline)
            while time.monotonic()<freeze_limit:
                self.scan()
                current=set()
                all_stopped=True
                for rec in self.targets():
                    if exited(rec):
                        continue
                    safe_signal(rec,signal.SIGSTOP)
                    row=identity(rec['pid'])
                    if row is None or row['start']!=rec['start']:
                        continue
                    current.add((rec['pid'],rec['start']))
                    if row['state'] not in ('T','t','Z'):
                        all_stopped=False
                stable=stable+1 if all_stopped and current==previous else 0
                previous=current
                if stable>=2:
                    break
                time.sleep(.005)
            # Stable inventory is a containment aid, not a reaping certification.
            # Queue TERM while stopped, then CONT: watchdog signal handler must
            # enter its own stopped state and reap; it must never spawn again.
            for rec in self.targets():
                safe_signal(rec,signal.SIGTERM)
            for rec in self.targets():
                safe_signal(rec,signal.SIGCONT)
            # One notification, pinned by the existing pidfd, interrupts coordinator
            # JUnit/hash/fsync work when possible. Do not repeatedly reenter its
            # signal handler during evidence closure; absolute KILL remains at 4800.
            if reason in ('DEADLINE','TESTS_AGGREGATE_CAP','GUARD_SIGNAL'):
                safe_signal(self.parent,signal.SIGTERM)

    def effective_deadline(self):
        if self.phase in ('CLOSING','WAIT_ACK_PERSISTED'):return self.args.deadline
        limits=[self.args.work_deadline]
        if self.phase_deadline is not None:
            limits.append(self.phase_deadline)
        if self.phase=='TESTS':
            if self.tests_deadline is None:
                raise RuntimeError('MISSING_TESTS_LATCH')
            limits.append(self.tests_deadline)
        return min(limits)

    @staticmethod
    def finite_clock(value):
        return not isinstance(value,bool) and isinstance(value,(int,float)) and math.isfinite(value)

    def control(self):
        if not self.pipe_open:
            return
        if not poll_readable(self.args.control_fd,0):
            return
        data=os.read(self.args.control_fd,65536)
        if not data:
            self.pipe_open=False
            self.stop('CONTROL_EOF',time.monotonic())
            return
        self.buf+=data
        if len(self.buf)>65536:
            raise RuntimeError('CONTROL_OVERFLOW')
        while b'\n' in self.buf:
            raw,self.buf=self.buf.split(b'\n',1)
            msg=json.loads(raw)
            if not isinstance(msg,dict):
                raise RuntimeError('CONTROL_NOT_OBJECT')
            if set(msg)=={'deadline'}:
                value=msg['deadline']
                now=time.monotonic()
                if self.stopping or self.phase=='STOPPED' or now>=self.effective_deadline():
                    raise RuntimeError('DEADLINE_ALREADY_EXPIRED')
                if value is not None and (not self.finite_clock(value) or not now<value<=self.args.work_deadline):
                    raise RuntimeError('DEADLINE_OUTSIDE_WORK_BUDGET')
                # None clears the individual invocation only. The TESTS latch
                # remains immutable and independently participates in the minimum.
                self.phase_deadline=value
                self.ack('deadline',cutoff=self.effective_deadline(),deadline=value)
            elif msg.get('type')=='tests_begin':
                if set(msg)!={'type','tests_start','tests_deadline','session'}:
                    raise RuntimeError('BAD_TESTS_BEGIN_FIELDS')
                start=msg['tests_start'];deadline=msg['tests_deadline'];session=msg['session']
                now=time.monotonic()
                if self.stopping or self.phase!='BEFORE_TESTS' or self.tests_deadline is not None:
                    raise RuntimeError('TESTS_BEGIN_DUPLICATE_OR_STOPPED')
                if not self.finite_clock(start) or not self.finite_clock(deadline):
                    raise RuntimeError('BAD_TESTS_CLOCK')
                if start<0 or start>now or deadline-start!=900 or not now<min(deadline,self.effective_deadline()):
                    raise RuntimeError('INVALID_TESTS_BEGIN_BUDGET')
                if not isinstance(session,str) or not session or len(session)>256:
                    raise RuntimeError('INVALID_TESTS_SESSION')
                # Store once before ACK/other work: a blocked handshake is covered.
                self.tests_start=start;self.tests_deadline=deadline;self.tests_session=session
                self.phase='TESTS'
                self.ack('tests_begin',cutoff=self.effective_deadline(),phase='TESTS',
                         tests_start=start,tests_deadline=deadline,session=session)
            elif msg.get('type')=='tests_end':
                if set(msg)!={'type','tests_deadline','session','completed','last_id'}:
                    raise RuntimeError('BAD_TESTS_END_FIELDS')
                now=time.monotonic()
                if self.stopping or self.phase!='TESTS' or now>=self.effective_deadline():
                    raise RuntimeError('TESTS_END_LATE_OR_STOPPED')
                if msg['session']!=self.tests_session or msg['tests_deadline']!=self.tests_deadline:
                    raise RuntimeError('TESTS_END_LATCH_MISMATCH')
                if type(msg['completed']) is not int or msg['completed']!=10 or msg['last_id']!='test-J-05':
                    raise RuntimeError('TESTS_END_NOT_FULL_SEQUENCE')
                # The watchdog independently proves no active child and all 10
                # completed/reaped results. Guard only accepts its exact protocol.
                cutoff=self.effective_deadline()
                self.ack('tests_end',cutoff=cutoff,phase='AFTER_TESTS',
                         tests_deadline=self.tests_deadline,session=self.tests_session,
                         completed=10,last_id='test-J-05')
                # ACK is emitted under TESTS deadline, including its post-write check.
                # A failed/late ACK never releases the latch or allows another begin.
                self.phase='AFTER_TESTS'
            elif set(msg)=={'closure_begin','success'} and msg['closure_begin'] is True and type(msg['success']) is bool:
                if self.closure_started or self.done_ack_sent:raise RuntimeError('CLOSURE_ALREADY_STARTED')
                if msg['success'] and (self.stopping or self.phase!='AFTER_TESTS'):raise RuntimeError('SUCCESS_CLOSURE_NOT_ELIGIBLE')
                self.scan()
                if any(not exited(x) for x in self.targets() if not (msg['success'] and x['role']=='watchdog')):raise RuntimeError('CLOSURE_WITH_LIVE_WORK')
                self.closure_started=True;self.phase='CLOSING';self.phase_deadline=None
                self.ack('closure_begin',cutoff=self.args.deadline,success=msg['success'])
            elif msg=={'telemetry_snapshot':True}:
                if self.telemetry_finalized:
                    raise RuntimeError('DUPLICATE_FINAL_TELEMETRY_SNAPSHOT')
                self.scan()
                if any(not exited(x) for x in self.targets()):
                    raise RuntimeError('SNAPSHOT_WITH_LIVE_IDENTIFIED_WORK')
                # Parent identity remains pinned for the absolute deadline until done.
                pending=[{k:r[k] for k in ('pid','start','role','initial_fd','token')}
                         for r in self.ledger.records.values() if r.get('fd') is not None]
                self.ledger.emit('final_snapshot',pending_final_close=pending,
                                 primary=self.ledger.primary_error,reaping='NOT_OBSERVED_BY_GUARD')
                self.ack('telemetry_snapshot',cutoff=self.args.deadline)
                self.telemetry_finalized=True
            elif msg=={'done':True}:
                # Caller persists snapshot+final record before this last ACK.
                if self.telemetry_fd is not None and not self.telemetry_finalized:
                    raise RuntimeError('FINAL_TELEMETRY_NOT_PERSISTED')
                # Caller sends only after its final persistent record and WD wait().
                # A live TESTS phase cannot be silently completed using generic done.
                if self.phase=='TESTS':
                    raise RuntimeError('DONE_WITHOUT_TESTS_END')
                self.scan()
                if any(not exited(x) for x in self.targets()):
                    raise RuntimeError('DONE_WITH_LIVE_IDENTIFIED_WORK')
                if not self.closure_started or self.done_ack_sent:raise RuntimeError('DONE_CLOSURE_STATE')
                self.ack('done',cutoff=self.args.deadline,identified_work_exited=True,
                         reaping='NOT_OBSERVED_BY_GUARD')
                self.done_ack_sent=True;self.phase='WAIT_ACK_PERSISTED'
                self.ledger.emission_disabled=True
            elif set(msg)=={'ack_persisted','sha256'} and msg['ack_persisted'] is True:
                h=msg['sha256']
                if not self.done_ack_sent or self.phase!='WAIT_ACK_PERSISTED' or not isinstance(h,str) or len(h)!=64 or any(c not in '0123456789abcdef' for c in h):raise RuntimeError('PERSISTED_ACK_STATE')
                self.ack('ack_persisted',cutoff=self.args.deadline,sha256=h)
                self.done=True
            else:
                raise RuntimeError('UNKNOWN_CONTROL')

    def run(self):
        self.scan()
        self.ack('ready',pid=os.getpid(),deadline=self.args.deadline,execution_identity=self.ledger.execution_identity)
        while True:
            now=time.monotonic()
            # The absolute kill check precedes scanning/pipe processing.
            if now>=self.args.deadline:
                for rec in self.targets():
                    safe_signal(rec,signal.SIGKILL)
                safe_signal(self.parent,signal.SIGKILL)
                return 124
            self.scan()
            if exited(self.parent):
                self.stop('PARENT_LOST',now)
            if exited(self.wd) and not self.done and not self.closure_started:
                self.stop('WATCHDOG_LOST',now)
            if self.signals:
                self.stop('GUARD_SIGNAL',now)
            # Re-read after /proc scanning: aggregation includes all inter-test IO.
            now=time.monotonic()
            if self.phase=='TESTS' and now>=self.tests_deadline:
                self.stop('TESTS_AGGREGATE_CAP',now)
            if now>=self.effective_deadline():
                self.stop('DEADLINE',now)
            if self.stopping:
                # Also signal newly discovered descendants while cancellation propagates.
                sig=signal.SIGKILL if now>=self.kill_at else signal.SIGTERM
                for rec in self.targets():
                    safe_signal(rec,sig)
            try:
                self.control()
            except (Exception,) as exc:
                self.stop(type(exc).__name__,time.monotonic())
                self.pipe_open=False
            if self.done:
                return 0
            if exited(self.parent) and all(exited(x) for x in self.targets()):
                return 124
            # Continue guarding the coordinator even if WD has already exited.
            time.sleep(min(.02,max(0,self.args.deadline-time.monotonic())))


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--manifest-sha256',required=True)
    p.add_argument('--parent',nargs=2,required=True,metavar=('PID','STARTTIME'))
    p.add_argument('--watchdog',nargs=2,required=True,metavar=('PID','STARTTIME'))
    p.add_argument('--deadline',type=float,required=True)
    p.add_argument('--work-deadline',type=float,required=True)
    p.add_argument('--control-fd',type=int,required=True)
    p.add_argument('--ack-fd',type=int,required=True)
    p.add_argument('--telemetry-fd',type=int)
    args=p.parse_args()
    bootstrap_authority(args.manifest_sha256)
    args.parent=(int(args.parent[0]),args.parent[1])
    args.watchdog=(int(args.watchdog[0]),args.watchdog[1])
    if not time.monotonic()<args.work_deadline<args.deadline:
        raise RuntimeError('INVALID_INITIAL_BUDGET')
    guard=Guard(args)
    try:
        return guard.run()
    except BaseException as primary:
        # Never depend on the poll/observation path that may have failed.
        # safe_signal catches errors per record; continue through the full ledger.
        for rec in guard.targets():
            safe_signal(rec,signal.SIGKILL)
        safe_signal(guard.parent,signal.SIGTERM)
        guard.ledger.evidence_incomplete=True
        if guard.ledger.primary_error is None:
            guard.ledger.primary_error=dict(operation='guard',error=type(primary).__name__+':'+str(primary))
        try:guard.ledger.emit('error',primary=guard.ledger.primary_error)
        except Exception:pass
        # A broken query must not break the absolute-deadline fallback. No exited()
        # calls here: retain parent's pinned identity until final KILL or timeout.
        while time.monotonic()<args.deadline:
            time.sleep(min(.02,max(0,args.deadline-time.monotonic())))
        safe_signal(guard.parent,signal.SIGKILL)
        raise
    finally:
        for rec in list(guard.ledger.records.values()):
            try:retire(rec,'GUARD_FINAL_CLOSE',exit_observed=rec['exit_observed'])
            except Exception as secondary:
                # Isolate close/telemetry failure; never abandon the next handle.
                guard.ledger.record_error(rec,'final_retirement',secondary)
        if not guard.done:
            try:guard.ledger.emit('final',primary=guard.ledger.primary_error)
            except Exception:pass


if __name__=='__main__':
    sys.exit(main())

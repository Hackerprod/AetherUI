"""Static-prepared custody implementation. Not executed or imported during preparation."""
import hashlib
import json
import os
from pathlib import Path
import stat
import time
import math
from manifest_contract import load_list, load_historical_map, verify_list_members

class CustodyFailure(RuntimeError):pass

def sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()

def files(root,excluded=()):
    root=Path(root)
    if root.is_symlink() or root.resolve()!=root or not root.is_dir():raise CustodyFailure('ROOT_TYPE_OR_LOCATION:'+str(root))
    result={};observed_dirs=set()
    def walk_error(error):raise error
    for directory,dirs,names in os.walk(root,followlinks=False,onerror=walk_error):
        base=Path(directory)
        for n in excluded:
            p=root/n
            if (p.exists() or p.is_symlink()) and (p.is_symlink() or not p.is_dir()):raise CustodyFailure('EXCLUDED_OUTPUT_TYPE:'+str(p))
        dirs[:]=[n for n in dirs if not (base==root and n in excluded)]
        for name in dirs:
            p=base/name
            if not stat.S_ISDIR(p.lstat().st_mode):raise CustodyFailure('DIRECTORY_TYPE:'+str(p))
            observed_dirs.add(str(p.relative_to(root)))
        for name in names:
            if base==root and name in excluded:continue
            p=base/name
            if not stat.S_ISREG(p.lstat().st_mode):raise CustodyFailure('FILE_TYPE:'+str(p))
            result[str(p.relative_to(root))]=p
    return result,observed_dirs

def verified_json(path,expected):
    data=Path(path).read_bytes()
    if hashlib.sha256(data).hexdigest()!=expected:raise CustodyFailure('MANIFEST_AUTHORITY_CHANGED:'+str(path))
    return json.loads(data)

class FrozenCustody:
    def __init__(self,policy,save,approved_manifest_sha256):
        self.policy=policy;self.save=save;self.root=Path(policy['root']);self.old=Path(policy['source_root'])
        self.groups={};self.reports={};self.gate_inputs=None;self.gate_locations=None;self.negative_path_assertions=None
        # Read authoritative manifests once, after checking approved parent references.
        # External D gate approves this v4 evidence hash; the launch preflight also
        # checks every member. Later checks use this memory snapshot, never reload authority.
        for path,h in policy['references'].items():
            if sha(path)!=h:raise CustodyFailure('APPROVED_REFERENCE_CHANGED:'+path)
        self.refs=dict(policy['references'])
        old_manifest=self.old/'evidence.sha256.json'
        if sha(old_manifest)!=self.refs[str(old_manifest)]:raise CustodyFailure('V1_MANIFEST_CHANGED')
        old=load_historical_map(old_manifest,self.refs[str(old_manifest)]);old['evidence.sha256.json']=self.refs[str(old_manifest)]
        self.groups['expediente_v1']=(self.old,old,())
        for tree in ('H','Hc','J'):
            mp=self.old/('manifest-'+tree+'.json')
            if sha(mp)!=old[mp.name]:raise CustodyFailure('TREE_MANIFEST_CHANGED:'+tree)
            self.groups[tree]=(self.old/tree,load_historical_map(mp,old[mp.name]),())
        self_manifest=self.root/'evidence.sha256.json';self_hash=approved_manifest_sha256
        if sha(self_manifest)!=self_hash:raise CustodyFailure('V4_MANIFEST_NOT_APPROVED')
        self.own_records=load_list(self.root,self_hash)
        own={p:row['sha256'] for p,row in self.own_records.items()};own['evidence.sha256.json']=self_hash
        self.groups['executed_v4']=(self.root,own,('run','build-Hc','build-J','home','tmp'))
        self.tools={}
        for v in policy['tools'].values():self.tools[v['path']]=v['sha256']
        for v in policy['tool_aliases'].values():self.tools[v['path']]=v['sha256']
        self.save(self.root/'run/custody-authority.json',dict(manifests={n:expected for n,(r,expected,ex) in self.groups.items()},references=self.refs,tools=self.tools))

    def approved_json(self,name):
        return verified_json(self.old/name,self.groups['expediente_v1'][1][name])

    def _negative_parent(self,parent):
        # lstat the entire accepted absolute directory chain; never follow an
        # unexpected alias and never treat an inspection error as absence.
        parent=Path(parent)
        for part in reversed([parent,*parent.parents]):
            st=part.lstat()
            if not stat.S_ISDIR(st.st_mode):raise CustodyFailure('NEGATIVE_PARENT_NOT_DIRECTORY:'+str(part))
        if parent.resolve(strict=True)!=parent:raise CustodyFailure('NEGATIVE_PARENT_NOT_CANONICAL')
        st=parent.lstat()
        return dict(path=str(parent),canonical_path=str(parent),device=st.st_dev,inode=st.st_ino,type='directory')

    def _negative_observation(self,row):
        parent=Path(row['parent']['path']);path=parent/'glibc-hwcaps'
        before=self._negative_parent(parent)
        if before!=row['parent']:raise CustodyFailure('NEGATIVE_PARENT_IDENTITY_CHANGED:'+str(parent))
        try:
            st=path.lstat()
        except FileNotFoundError:
            pass
        except OSError as exc:
            raise CustodyFailure('NEGATIVE_PATH_INSPECTION_ERROR:'+str(path)+':'+str(exc)) from exc
        else:
            raise CustodyFailure('RUNPATH_GLIBC_HWCAPS_UNMODELED:'+str(path)+':type='+str(stat.S_IFMT(st.st_mode)))
        if self._negative_parent(parent)!=before:raise CustodyFailure('NEGATIVE_PARENT_CHANGED_DURING_CHECK')
        return dict(path=str(path),expected='ABSENT',method='lstat',parent=before,observed_monotonic=time.monotonic())

    def check_negative_paths(self,label,deadline,persist=True):
        if self.negative_path_assertions is None:return dict(status='NOT_FROZEN',checks=[])
        report=dict(status='INCOMPLETE',label=label,checks=[],scope='defined observation points; not proof against transient adversarial replacement')
        destination=self.root/'run'/('custody-negative-'+label+'.json')
        try:
            for row in self.negative_path_assertions:
                if time.monotonic()>=deadline:raise CustodyFailure('NEGATIVE_CUSTODY_BUDGET_EXHAUSTED')
                report['checks'].append(self._negative_observation(row))
            if time.monotonic()>=deadline:raise CustodyFailure('NEGATIVE_CUSTODY_BUDGET_EXHAUSTED')
            report['status']='PASS'
        except BaseException as exc:
            report.update(status='CUSTODY_DIVERGENCE',error=type(exc).__name__+':'+str(exc))
            if persist:self.save(destination,report)
            raise
        if persist:self.save(destination,report)
        return report

    def _freeze_negative(self,report):
        rows=report.get('negative_path_assertions')
        if not isinstance(rows,list) or len(rows)!=2:raise CustodyFailure('NEGATIVE_ASSERTIONS_REQUIRE_EXACTLY_TWO')
        expected=[str(Path(self.policy['builds'][tree])/'glibc-hwcaps') for tree in ('Hc','J')]
        if [row.get('path') if isinstance(row,dict) else None for row in rows]!=expected:raise CustodyFailure('NEGATIVE_ASSERTION_PATHS_OR_ORDER')
        for tree,row in zip(('Hc','J'),rows):
            if set(row)!={'path','expected','method','parent','observed_monotonic'} or row['expected']!='ABSENT' or row['method']!='lstat':raise CustodyFailure('NEGATIVE_ASSERTION_SCHEMA')
            parent=row['parent'];build=str(Path(self.policy['builds'][tree]))
            if not isinstance(parent,dict) or set(parent)!={'path','canonical_path','device','inode','type'} or parent['path']!=build or parent['canonical_path']!=build or parent['type']!='directory':raise CustodyFailure('NEGATIVE_PARENT_SCHEMA')
            if type(parent['device']) is not int or parent['device']<0 or type(parent['inode']) is not int or parent['inode']<0:raise CustodyFailure('NEGATIVE_PARENT_IDENTITY_SCHEMA')
            at=row['observed_monotonic']
            if type(at) not in (int,float) or not math.isfinite(at) or at<0 or at>time.monotonic():raise CustodyFailure('NEGATIVE_OBSERVATION_CLOCK')
            self._negative_observation(row)
        # Deep copy of the accepted values. Never rederive authority from a
        # later report or accept arbitrary paths supplied by subsequent input.
        self.negative_path_assertions=json.loads(json.dumps(rows))

    def freeze_gate(self,report):
        if report.get('status')!='PASS':raise CustodyFailure('GATE_NOT_PASS')
        if self.gate_inputs is not None:raise CustodyFailure('GATE_AUTHORITY_ALREADY_FIXED')
        persisted_path=self.root/'run/comparability.json'
        persisted_hash=sha(persisted_path)
        if verified_json(persisted_path,persisted_hash)!=report:raise CustodyFailure('GATE_REPORT_CHANGED')
        self._freeze_negative(report)
        self.gate_inputs=dict(report['inputs'])
        self.gate_inputs[str(self.root/'run/comparability.json')]=persisted_hash
        self.gate_locations={path:dict(type=stat.S_IFMT(Path(path).lstat().st_mode),resolved=str(Path(path).resolve()),link=os.readlink(path) if Path(path).is_symlink() else None) for path in self.gate_inputs}
        # Gate inputs include exact ELF/source/flags/inventory/configuration used.
        for path,h in self.gate_inputs.items():
            if sha(path)!=h:raise CustodyFailure('GATE_INPUT_CHANGED_BEFORE_TEST:'+path)
        self.save(self.root/'run/custody-gate-authority.json',dict(inputs=self.gate_inputs,locations=self.gate_locations,negative_path_assertions=self.negative_path_assertions,report_sha256=persisted_hash))

    def check(self,label,deadline):
        report=dict(status='INCOMPLETE_CUSTODY',custody_complete=False,started=time.monotonic(),components={})
        dest=self.root/'run'/('custody-frozen-'+label+'.json')
        def persist():self.save(dest,report)
        def check_deadline():
            if time.monotonic()>=deadline:raise CustodyFailure('CUSTODY_BUDGET_EXHAUSTED')
        self.check_negative_paths('custody-'+label+'-before',deadline)
        verify_list_members(self.root,self.own_records)
        names=list(self.groups)+['references','tools','tool_alias_resolution']+(['gate_inputs'] if self.gate_inputs is not None else [])
        report['components']={n:dict(status='NOT_OBSERVED',verified=0) for n in names};persist()
        try:
            for name,(root,expected,excluded) in self.groups.items():
                check_deadline();component=report['components'][name];component.update(expected=len(expected),started=time.monotonic())
                try:actual,actual_dirs=files(root,excluded)
                except CustodyFailure as exc:
                    component.update(status='DIVERGENCE',type_error=str(exc));raise
                expected_dirs={str(parent) for rel in expected for parent in Path(rel).parents if str(parent)!='.'}
                extra=sorted(set(actual)-set(expected));missing=sorted(set(expected)-set(actual))
                extra_dirs=sorted(actual_dirs-expected_dirs);missing_dirs=sorted(expected_dirs-actual_dirs)
                component.update(extra_directories=extra_dirs,missing_directories=missing_dirs)
                component.update(extra=extra,missing=missing)
                if extra or missing or extra_dirs or missing_dirs:component['status']='DIVERGENCE';raise CustodyFailure('FILE_SET_DIVERGENCE:'+name)
                for rel,h in expected.items():
                    check_deadline()
                    if sha(actual[rel])!=h:
                        component.update(status='DIVERGENCE',path=rel);raise CustodyFailure('HASH_DIVERGENCE:'+name+'/'+rel)
                    component['verified']+=1
                    if component['verified']%100==0:persist()
                component.update(status='PASS',ended=time.monotonic());persist()
            flat=[('references',self.refs),('tools',self.tools)]
            if self.gate_inputs is not None:flat.append(('gate_inputs',self.gate_inputs))
            for name,expected in flat:
                component=report['components'][name];component.update(expected=len(expected),started=time.monotonic())
                for path,h in expected.items():
                    check_deadline()
                    if name=='gate_inputs':
                        observed=dict(type=stat.S_IFMT(Path(path).lstat().st_mode),resolved=str(Path(path).resolve()),link=os.readlink(path) if Path(path).is_symlink() else None)
                        if observed!=self.gate_locations[path]:component.update(status='DIVERGENCE',path=path);raise CustodyFailure('GATE_INPUT_PROVENANCE_DIVERGENCE')
                    if sha(path)!=h:component.update(status='DIVERGENCE',path=path);raise CustodyFailure('HASH_DIVERGENCE:'+name)
                    component['verified']+=1
                component.update(status='PASS',ended=time.monotonic());persist()
            component=report['components']['tool_alias_resolution'];component['expected']=len(self.policy['tool_aliases'])
            for name,item in self.policy['tool_aliases'].items():
                check_deadline()
                if str(Path(item['path']).resolve())!=item['resolved']:component.update(status='DIVERGENCE',alias=name);raise CustodyFailure('ALIAS_RESOLUTION_DIVERGENCE:'+name)
                component['verified']+=1
            component.update(status='PASS',ended=time.monotonic());persist()
            self.check_negative_paths('custody-'+label+'-after',deadline)
            report.update(status='PASS',custody_complete=True,ended=time.monotonic());persist();return report
        except BaseException as exc:
            report.update(error=type(exc).__name__+':'+str(exc),ended=time.monotonic())
            if any(c.get('status')=='DIVERGENCE' for c in report['components'].values()):report['status']='CUSTODY_DIVERGENCE'
            persist();raise

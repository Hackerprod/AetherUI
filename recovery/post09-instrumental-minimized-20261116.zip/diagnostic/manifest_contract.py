"""Strict, explicitly versioned authority loaders. Materialized only; not imported here."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat

class ManifestError(RuntimeError): pass

def digest(path):
    h=hashlib.sha256()
    with open(path,'rb') as stream:
        for chunk in iter(lambda:stream.read(1048576),b''):h.update(chunk)
    return h.hexdigest()

def sha_value(value):
    return isinstance(value,str) and len(value)==64 and all(c in '0123456789abcdef' for c in value)

def relative(value):
    if not isinstance(value,str) or not value or '\\' in value or '\x00' in value:raise ManifestError('PATH_SCHEMA')
    p=PurePosixPath(value)
    if p.is_absolute() or any(x in ('','..','.') for x in value.split('/')) or str(p)!=value:raise ManifestError('NONCANONICAL_PATH:'+value)
    return value

def plain(path):
    path=Path(path)
    for p in [path,*path.parents]:
        if p.is_symlink():raise ManifestError('SYMLINK:'+str(p))
    if not stat.S_ISREG(path.lstat().st_mode):raise ManifestError('NOT_REGULAR:'+str(path))
    return path

def checked_json(path,expected):
    if not sha_value(expected):raise ManifestError('SHA_SCHEMA')
    raw=plain(path).read_bytes()
    if hashlib.sha256(raw).hexdigest()!=expected:raise ManifestError('AUTHORITY_HASH:'+str(path))
    def pairs(items):
        out={}
        for k,v in items:
            if k in out:raise ManifestError('DUPLICATE_JSON_KEY:'+k)
            out[k]=v
        return out
    return json.loads(raw,object_pairs_hook=pairs)

def load_list(root,expected_manifest_sha256,excluded=('run','build-Hc','build-J','home','tmp'),verify_members=True):
    root=Path(root)
    if root.is_symlink() or root.resolve()!=root or not root.is_dir():raise ManifestError('ROOT_LOCATION')
    value=checked_json(root/'evidence.sha256.json',expected_manifest_sha256)
    if not isinstance(value,list):raise ManifestError('LIST_MANIFEST_REQUIRED')
    result={}
    for row in value:
        if not isinstance(row,dict) or set(row)!={'path','bytes','sha256'}:raise ManifestError('ROW_SCHEMA')
        key=relative(row['path'])
        if key=='evidence.sha256.json' or key.split('/')[0] in excluded or key in result:raise ManifestError('DUPLICATE_OR_EXCLUDED_PATH:'+key)
        if type(row['bytes']) is not int or row['bytes']<0 or not sha_value(row['sha256']):raise ManifestError('ROW_SIZE_SHA')
        result[key]={'bytes':row['bytes'],'sha256':row['sha256']}
    if verify_members:verify_list_members(root,result,excluded)
    return result

def verify_list_members(root,records,excluded=('run','build-Hc','build-J','home','tmp')):
    root=Path(root); actual=set(); dirs=set()
    def failure(error):raise error
    for directory,subdirs,filenames in os.walk(root,followlinks=False,onerror=failure):
        base=Path(directory)
        for name in list(subdirs):
            path=base/name
            if path.is_symlink() or not stat.S_ISDIR(path.lstat().st_mode):raise ManifestError('DIRECTORY_TYPE:'+str(path))
            if base==root and name in excluded:subdirs.remove(name)
            else:dirs.add(str(path.relative_to(root)))
        for name in filenames:
            path=plain(base/name); key=str(path.relative_to(root))
            if key=='evidence.sha256.json':continue
            if base==root and name in excluded:raise ManifestError('EXCLUSION_NOT_DIRECTORY:'+name)
            actual.add(key)
    expected=set(records)
    expected_dirs={str(parent) for key in expected for parent in Path(key).parents if str(parent)!='.'}
    if actual!=expected or dirs!=expected_dirs:raise ManifestError('EXACT_FILE_DIRECTORY_SET')
    for key,row in records.items():
        p=plain(root/key)
        if p.stat().st_size!=row['bytes'] or digest(p)!=row['sha256']:raise ManifestError('MEMBER_MISMATCH:'+key)

def load_historical_map(path,expected_sha):
    value=checked_json(path,expected_sha)
    if not isinstance(value,dict):raise ManifestError('HISTORICAL_MAP_REQUIRED')
    out={}
    for key,h in value.items():
        relative(key)
        if not sha_value(h):raise ManifestError('HISTORICAL_SHA_SCHEMA')
        out[key]=h
    return out

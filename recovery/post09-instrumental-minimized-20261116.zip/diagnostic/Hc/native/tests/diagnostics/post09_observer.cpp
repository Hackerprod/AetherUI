// Diagnostic-only TU. Never install this interface or link it into production.
#include "post09_observer_private.h"
#include "../../src/style_runtime/typography_evidence.h"
#include <atomic>
#include <cerrno>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

namespace aether::diagnostic::post09 {
namespace {
constexpr unsigned Slots=7, Arena=1179648-32, MaxRecords=4096, MaxNodes=256;
enum Error : unsigned { Overflow=1, Protocol=2, Thread=4, Init=8, Partial=16, StringLimit=32, IO=64 };
struct Node { const void* key; bool prepared, entry; };
struct Slot {
    unsigned case_id, used, records, flags, omitted, target, nodes_count;
    int raw_count;
    unsigned entry_count, return_impact, aggregate_impact;
    bool raw_seen, done, ended, return_seen, aggregate_seen, aggregate_present;
};
struct State {
    std::atomic<unsigned> errors;
    unsigned test, tree, current, current_node;
    Token serial, token;
    int fd, status_fd;
    uint64_t written;
    bool enabled, active, core_open;
    Node nodes[MaxNodes];
    Slot slots[Slots];
    unsigned char arenas[Slots][Arena];
};
static State s{};
static_assert(sizeof(State)<=8u*1024u*1024u);
static_assert(std::atomic<unsigned>::is_always_lock_free);
static thread_local bool main_thread=false;
struct PreserveErrno { int value=errno; ~PreserveErrno(){errno=value;} };
void fault(unsigned e) noexcept {
    s.errors.fetch_or(e,std::memory_order_relaxed);
    if(main_thread && s.active) s.slots[s.current].flags |= e;
}
bool allowed() noexcept {
    if(!s.enabled) return false;
    if(!main_thread) { fault(Thread); return false; }
    return true;
}
void u32(unsigned char* p,uint32_t v) noexcept { for(unsigned i=0;i<4;++i)p[i]=static_cast<unsigned char>(v>>(8*i)); }
void u64(unsigned char* p,uint64_t v) noexcept { for(unsigned i=0;i<8;++i)p[i]=static_cast<unsigned char>(v>>(8*i)); }
void omitted() noexcept { auto& q=s.slots[s.current];q.flags|=Overflow;if(q.omitted!=UINT32_MAX)++q.omitted;fault(Overflow); }
unsigned char* record(unsigned kind,unsigned point,unsigned node,unsigned length) noexcept {
    auto& q=s.slots[s.current];
    if(q.records>=MaxRecords || length>Arena-32 || q.used>Arena-32-length){omitted();return nullptr;}
    auto* p=s.arenas[s.current]+q.used;
    u32(p,kind);u32(p+4,point);u32(p+8,node);u32(p+12,q.records);u32(p+16,length);
    u32(p+20,0);u64(p+24,s.token);
    q.used+=32+length;++q.records;return p+32;
}
unsigned node(const void* key) noexcept {
    if(!key){fault(Protocol);return 0;}
    auto& q=s.slots[s.current];
    for(unsigned i=0;i<q.nodes_count;++i)if(s.nodes[i].key==key)return i+1;
    if(q.nodes_count==MaxNodes){fault(Overflow);return 0;}
    const unsigned i=q.nodes_count++;s.nodes[i]={key,false,false};return i+1;
}
bool core() noexcept { return allowed() && s.active && s.core_open; }
void simple(unsigned kind,unsigned point,unsigned ordinal,uint32_t a,uint32_t b,uint32_t c,uint32_t d) noexcept {
    if(auto* p=record(kind,point,ordinal,16)){u32(p,a);u32(p+4,b);u32(p+8,c);u32(p+12,d);}
}
// Field payload: side,index0,index1,type,keylen,reserved (u32), original/stored
// byte lengths (u64), then ASCII key and raw little-endian value bytes.
void field(unsigned point,unsigned side,unsigned i,unsigned j,const char* key,unsigned type,const void* value,size_t length) noexcept {
    const size_t keylen=std::strlen(key);
    const bool over=length>65536;
    if(over)fault(StringLimit);
    const unsigned stored=over?0:static_cast<unsigned>(length);
    auto* p=record(6,point,s.current_node,40+static_cast<unsigned>(keylen)+stored);
    if(!p)return;
    u32(p,side);u32(p+4,i);u32(p+8,j);u32(p+12,type);u32(p+16,static_cast<unsigned>(keylen));u32(p+20,0);
    u64(p+24,length);u64(p+32,stored);
    std::memcpy(p+40,key,keylen);
    if(stored)std::memcpy(p+40+keylen,value,stored);
}
void integer(unsigned point,unsigned side,unsigned i,unsigned j,const char* key,uint64_t value) noexcept {
    unsigned char b[8];u64(b,value);field(point,side,i,j,key,1,b,8);
}
void f32(unsigned point,unsigned side,const char* key,const float& v) noexcept {
    uint32_t bits;std::memcpy(&bits,&v,4);unsigned char b[4];u32(b,bits);field(point,side,0,0,key,2,b,4);
}
void f64(unsigned point,unsigned side,const char* key,const double& v) noexcept {
    uint64_t bits;std::memcpy(&bits,&v,8);unsigned char b[8];u64(b,bits);field(point,side,0,0,key,2,b,8);
}
void str(unsigned point,unsigned side,unsigned i,unsigned j,const char* key,const std::string& v) noexcept {
    field(point,side,i,j,key,3,v.data(),v.size());
}
void provenance(unsigned point,unsigned side,unsigned i,unsigned j,const aether::style::TypographyProvenance& v) noexcept {
#define V(name) integer(point,side,i,j,"provenance." #name,static_cast<uint64_t>(v.name))
    V(declaration);V(inherited);V(important);V(inline_style);V(layer);V(source_order);V(declaration_order);
#undef V
    str(point,side,i,j,"provenance.accepted_source",v.accepted_source);
    str(point,side,i,j,"provenance.resolved_source",v.resolved_source);
}
void evidence(unsigned point,unsigned side,const aether::style::TypographyEvidence& v) noexcept {
    for(unsigned i=0;i<2;++i){const auto& b=v.break_policy.fields[i];
        integer(point,side,i,1,"break.known",b.known);integer(point,side,i,1,"break.computed",static_cast<uint64_t>(b.computed));
        integer(point,side,i,1,"break.reason",static_cast<uint64_t>(b.reason));str(point,side,i,1,"break.authored_property",b.authored_property);
        provenance(point,side,i,1,b.provenance);
    }
    for(unsigned i=0;i<6;++i)provenance(point,side,i,0,v.provenance[i]);
#define V(name) integer(point,side,0,0,#name,static_cast<uint64_t>(v.name))
    V(family_state);V(style_state);V(spacing_state);V(spacing_normal);V(size_state);V(weight_state);V(line_height_state);
    V(weight);V(line_height_kind);V(size_dependencies);V(line_height_dependencies);V(coverage_complete);V(coverage_gaps);
#undef V
    integer(point,side,0,0,"families.count",v.families.size());
    // Record cap also bounds loop work, without walking unbounded families.
    for(size_t i=0;i<v.families.size();++i){
        if(i>=MaxRecords){fault(Overflow);break;}
        str(point,side,static_cast<unsigned>(i),0,"families.name",v.families[i].name);
        integer(point,side,static_cast<unsigned>(i),0,"families.generic",v.families[i].generic);
    }
    str(point,side,0,0,"font_style",v.font_style);f64(point,side,"spacing_px",v.spacing_px);
    f32(point,side,"size_px",v.size_px);f32(point,side,"line_height_value",v.line_height_value);f32(point,side,"line_height_used_px",v.line_height_used_px);
}
bool write_all(int fd,const unsigned char* p,size_t n,bool data) noexcept {
    while(n){const ssize_t k=::write(fd,p,n);if(k<0&&errno==EINTR)continue;if(k<=0)return false;
        if(data)s.written+=static_cast<uint64_t>(k);p+=k;n-=static_cast<size_t>(k);}return true;
}
void flush() noexcept {
    PreserveErrno preserve;
    if(!s.enabled||s.fd<0||s.status_fd<0)return;
    if(s.active){fault(Partial);for(auto& n:s.nodes)n={};}
    uint64_t planned=64+16+Slots*64;
    for(const auto& q:s.slots)planned+=q.used;
    unsigned char h[64]{};std::memcpy(h,"AETHD092",8);u32(h+8,2);u32(h+12,s.test);u32(h+16,s.tree);u32(h+20,Slots);u32(h+24,s.errors.load(std::memory_order_relaxed));
    bool ok=write_all(s.fd,h,sizeof(h),true);
    for(unsigned i=0;ok&&i<Slots;++i){const auto& q=s.slots[i];unsigned char sh[64]{};
        u32(sh,q.case_id);u32(sh+4,q.used);u32(sh+8,q.records);u32(sh+12,q.flags);u32(sh+16,q.omitted);u32(sh+20,q.target);
        u32(sh+24,static_cast<uint32_t>(q.raw_count));u32(sh+28,q.entry_count);u32(sh+32,q.return_impact);u32(sh+36,q.aggregate_impact);
        u32(sh+40,q.raw_seen);u32(sh+44,q.done);u32(sh+48,q.ended);u32(sh+52,q.return_seen);u32(sh+56,q.aggregate_seen);u32(sh+60,q.aggregate_present);
        ok=write_all(s.fd,sh,sizeof(sh),true)&&write_all(s.fd,s.arenas[i],q.used,true);
    }
    bool footer_ok=false;
    if(ok){unsigned char footer[16]{};std::memcpy(footer,"ENDD092!",8);u32(footer+8,s.errors.load(std::memory_order_relaxed));
        footer_ok=write_all(s.fd,footer,sizeof(footer),true);ok=footer_ok;}
    if(!ok)fault(IO);
    const int close_rc=::close(s.fd);const int close_error=close_rc<0?errno:0;s.fd=-1;
    if(close_rc<0)fault(IO);
    // Separate evidence for data close; never retries close, including EINTR.
    unsigned char status[80]{};std::memcpy(status,"CLSD092!",8);u32(status+8,2);u32(status+12,s.test);u32(status+16,s.tree);
    u32(status+20,ok);u32(status+24,footer_ok);u32(status+28,static_cast<uint32_t>(close_rc));u32(status+32,static_cast<uint32_t>(close_error));
    u32(status+36,s.errors.load(std::memory_order_relaxed));u64(status+40,planned);u64(status+48,s.written);
    write_all(s.status_fd,status,sizeof(status),false);
    // Status-channel close and crash durability intentionally are not certified.
    ::close(s.status_fd);s.status_fd=-1;
}
unsigned decimal(const char* p) noexcept {if(!p||!*p)return 0;unsigned v=0;for(;*p;++p){if(*p<'0'||*p>'9'||v>100)return 0;v=v*10+static_cast<unsigned>(*p-'0');}return v;}
struct Initializer {
    Initializer() noexcept {
        PreserveErrno preserve;main_thread=true;s.fd=-1;s.status_fd=-1;
        const char* test=std::getenv("AETHER_POST09_TEST_ID");const char* tree=std::getenv("AETHER_POST09_TREE_ID");const char* path=std::getenv("AETHER_POST09_OUTPUT");
        if(!test&&!tree&&!path)return;
        s.test=decimal(test);s.tree=decimal(tree);s.enabled=true;
        if(!path||path[0]!='/'||s.test<1||s.test>5||s.tree<1||s.tree>2){fault(Init);return;}
        static const char* const names[2][5]={
            {"observer-Hc-01.bin","observer-Hc-02.bin","observer-Hc-03.bin","observer-Hc-04.bin","observer-Hc-05.bin"},
            {"observer-J-01.bin","observer-J-02.bin","observer-J-03.bin","observer-J-04.bin","observer-J-05.bin"}};
        const size_t path_length=std::strlen(path);
        const char* tail=std::strrchr(path,'/');
        if(!tail || path_length<5 || tail-path<4 || std::memcmp(tail-4,"/run",4)!=0 ||
           std::strcmp(tail+1,names[s.tree-1][s.test-1])!=0){fault(Init);return;}
        s.fd=::open(path,O_WRONLY|O_CREAT|O_EXCL|O_NOFOLLOW|O_CLOEXEC,0600);
        if(s.fd<0){fault(Init);return;}
        struct stat st{};if(::fstat(s.fd,&st)!=0||!S_ISREG(st.st_mode)||st.st_uid!=::geteuid()||st.st_size!=0){fault(Init);::close(s.fd);s.fd=-1;return;}
        constexpr char suffix[]=".close-status";
        char status_path[4096]{};
        if(path_length+sizeof(suffix)>sizeof(status_path)){fault(Init);::close(s.fd);s.fd=-1;return;}
        std::memcpy(status_path,path,path_length);std::memcpy(status_path+path_length,suffix,sizeof(suffix));
        s.status_fd=::open(status_path,O_WRONLY|O_CREAT|O_EXCL|O_NOFOLLOW|O_CLOEXEC,0600);
        if(s.status_fd<0){fault(Init);::close(s.fd);s.fd=-1;return;}
        struct stat ss{};
        if(::fstat(s.status_fd,&ss)!=0||!S_ISREG(ss.st_mode)||ss.st_uid!=::geteuid()||ss.st_size!=0){
            fault(Init);::close(s.fd);::close(s.status_fd);s.fd=-1;s.status_fd=-1;return;}
        if(std::atexit(flush)!=0){fault(Init);::close(s.fd);::close(s.status_fd);s.fd=-1;s.status_fd=-1;}
    }
};
static Initializer initializer;
}
Token begin(Case id) noexcept {
    PreserveErrno preserve;if(!allowed())return 0;
    if(s.active){fault(Protocol);s.core_open=false;return 0;}
    const unsigned c=static_cast<unsigned>(id);
    unsigned slot=0;
    if(s.test==1&&c!=1){fault(Protocol);return 0;}
    if(s.test==2&&c!=2){fault(Protocol);return 0;}
    if(s.test==3){if(c<3||c>9){fault(Protocol);return 0;}slot=c-3;}
    if(s.test>3){fault(Protocol);return 0;}
    if(s.slots[slot].case_id){fault(Protocol);return 0;}
    s.current=slot;s.current_node=0;s.active=true;s.core_open=true;s.token=++s.serial;
    for(auto& n:s.nodes)n={};s.slots[slot].case_id=c;s.slots[slot].raw_count=-1;
    simple(1,0,0,c,0,0,0);return s.token;
}
void public_result(Token t,SampleKind kind,const void* identity,int count,bool present,unsigned impact) noexcept {
    PreserveErrno preserve;if(!t||!allowed())return;
    if(!s.active||t!=s.token){fault(Protocol);return;}
    auto& q=s.slots[s.current];unsigned n=0;
    if(identity)n=node(identity);
    switch(kind){
    case SampleKind::BindTarget:
        if(!n){fault(Protocol);break;}if(q.target&&q.target!=n)fault(Protocol);else q.target=n;break;
    case SampleKind::RawCount:
        if(q.raw_seen||q.done)fault(Protocol);q.raw_count=count;q.raw_seen=true;s.core_open=false;break;
    case SampleKind::Entry:
        if(!q.raw_seen||q.done||count<0||static_cast<unsigned>(count)!=q.entry_count||!n||!present)fault(Protocol);
        if(n)s.nodes[n-1].entry=true;++q.entry_count;break;
    case SampleKind::ResolveDone:
        if(q.done||!q.raw_seen||count!=q.raw_count||count<0||!present||q.entry_count!=static_cast<unsigned>(count))fault(Partial);
        q.done=true;s.core_open=false;break;
    case SampleKind::ReturnImpact:if(!q.done||q.return_seen)fault(Protocol);q.return_seen=true;q.return_impact=impact;break;
    case SampleKind::Aggregate:if(q.aggregate_seen)fault(Protocol);q.aggregate_seen=true;q.aggregate_present=present;q.aggregate_impact=impact;break;
    default:fault(Protocol);break;
    }
    simple(2,static_cast<unsigned>(kind),n,static_cast<uint32_t>(count),present,impact,0);
}
void end(Token t) noexcept {
    PreserveErrno preserve;if(!t||!allowed())return;
    if(!s.active||s.token!=t){fault(Protocol);return;}
    auto& q=s.slots[s.current];if(!q.done||!q.raw_seen||!q.target || (s.test==1&&!q.return_seen) || (s.test==2&&!q.aggregate_seen))fault(Partial);
    unsigned presence=0,prepared=0;
    if(q.target){prepared=s.nodes[q.target-1].prepared;
        if(q.done&&q.raw_count>=0&&q.entry_count==static_cast<unsigned>(q.raw_count))presence=s.nodes[q.target-1].entry?2:1;}
    simple(7,0,q.target,prepared,presence,q.entry_count,0);q.ended=true;
    for(auto& n:s.nodes)n={};s.active=false;s.core_open=false;s.current_node=0;s.token=0;
}
void node_start(const void* p) noexcept {
    PreserveErrno preserve;if(!core())return;s.current_node=node(p);if(s.current_node)s.nodes[s.current_node-1].prepared=true;
    simple(3,0,s.current_node,0,0,0,0);
}
void diff(unsigned point,unsigned own,unsigned inherited,bool storage,bool unclassified) noexcept {
    PreserveErrno preserve;if(!core())return;if(!s.current_node)fault(Protocol);simple(4,point,s.current_node,own,inherited,storage,unclassified);
}
void dependency(unsigned side,std::string_view name,unsigned flags,bool unknown_name,bool unknown_flags) noexcept {
    PreserveErrno preserve;if(!core())return;if(!unknown_name&&!unknown_flags)return;if(!s.current_node)fault(Protocol);
    simple(5,side,s.current_node,flags,unknown_name,unknown_flags,0);field(100,side,0,0,"dependency.name",3,name.data(),name.size());
}
void typography(unsigned point,const aether::style::TypographyEvidence* previous,const aether::style::TypographyEvidence& candidate,bool discarded) noexcept {
    PreserveErrno preserve;if(!core())return;if(!s.current_node)fault(Protocol);simple(8,point,s.current_node,previous!=nullptr,discarded,0,0);
    if(previous)evidence(point,0,*previous);evidence(point,1,candidate);
}
void branch_taken(bool taken) noexcept {PreserveErrno preserve;if(core()){if(!s.current_node)fault(Protocol);simple(9,0,s.current_node,taken,0,0,0);}}
}

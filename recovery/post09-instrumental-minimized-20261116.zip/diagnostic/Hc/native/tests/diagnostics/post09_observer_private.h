#pragma once
#include <string_view>
namespace aether::style { struct TypographyEvidence; }
namespace aether::diagnostic::post09 {
enum class Case : unsigned { SD_LH=1, TP_EMPTY=2, TR_NOOP=3, TR_S1=4, TR_S2=5, TR_S3=6, TR_I1=7, TR_I2=8, TR_I3=9 };
using Token = unsigned long long;
enum class SampleKind : unsigned { BindTarget=1, RawCount=2, Entry=3, ResolveDone=4, ReturnImpact=5, Aggregate=6 };
__attribute__((visibility("default"))) Token begin(Case) noexcept;
__attribute__((visibility("default"))) void public_result(Token, SampleKind, const void*, int, bool, unsigned) noexcept;
__attribute__((visibility("default"))) void end(Token) noexcept;
__attribute__((visibility("hidden"))) void node_start(const void*) noexcept;
__attribute__((visibility("hidden"))) void diff(unsigned, unsigned, unsigned, bool, bool) noexcept;
__attribute__((visibility("hidden"))) void dependency(unsigned, std::string_view, unsigned, bool, bool) noexcept;
__attribute__((visibility("hidden"))) void typography(unsigned, const aether::style::TypographyEvidence*, const aether::style::TypographyEvidence&, bool) noexcept;
__attribute__((visibility("hidden"))) void branch_taken(bool) noexcept;
}

#!/usr/bin/env python3
"""Post09 v5 closed gate. STATIC MATERIALIZATION ONLY, NOT EXECUTED/IMPORTED.
Never executes product. Inspection children inherit supervisor's process group.
The supervisor owns the phase/global deadline and must reap all descendants.
Only standard-library imports precede external-manifest verification.
"""
import argparse
import difflib
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import shlex
import stat
import subprocess
import sys
import time

class Blocked(RuntimeError):
    pass

def require(ok, why):
    if not ok:
        raise Blocked(why)

def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def valid_hash(value):
    return isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) is not None

def unique_json(text):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, 'Duplicate JSON key: '+str(key))
            result[key] = value
        return result
    return json.loads(text, object_pairs_hook=pairs)

def safe_rel(value):
    require(isinstance(value, str) and value and '\\' not in value, 'Invalid relative name')
    p = PurePosixPath(value)
    require(not p.is_absolute() and str(p) == value and '..' not in p.parts and '.' not in p.parts,
            'Noncanonical relative name: '+value)
    return value

def regular(path):
    path = Path(path)
    require(stat.S_ISREG(path.lstat().st_mode), 'Not a regular file: '+str(path))
    return path

def bootstrap(root, digest):
    """No local helper imports. External digest is authority, not self-asserted policy."""
    require(valid_hash(digest), 'Missing external manifest digest')
    path = regular(root/'evidence.sha256.json')
    data = path.read_bytes()
    require(hashlib.sha256(data).hexdigest() == digest, 'Manifest external digest mismatch')
    rows = unique_json(data)
    require(isinstance(rows, list), 'Expected list manifest')
    out = {}
    for row in rows:
        require(isinstance(row, dict) and set(row) == {'path','bytes','sha256'}, 'Invalid manifest row')
        rel = safe_rel(row['path'])
        require(rel not in out and rel != 'evidence.sha256.json', 'Duplicate/self manifest member')
        require(type(row['bytes']) is int and row['bytes'] >= 0 and valid_hash(row['sha256']), 'Invalid member metadata')
        p = regular(root/rel)
        require(p.resolve() == p and p.stat().st_size == row['bytes'] and sha(p) == row['sha256'], 'Manifest member mismatch: '+rel)
        out[rel] = row
    excluded = {'run','build-Hc','build-J','home','tmp'}
    actual = set(); actual_dirs = set()
    for directory, dirs, names in os.walk(root, followlinks=False):
        base = Path(directory)
        dirs[:] = [n for n in dirs if not (base == root and n in excluded)]
        for name in dirs:
            require(stat.S_ISDIR((base/name).lstat().st_mode), 'Unexpected directory symlink')
            actual_dirs.add(str((base/name).relative_to(root)))
        for name in names:
            rel = str((base/name).relative_to(root))
            if rel != 'evidence.sha256.json':
                regular(base/name); actual.add(rel)
    require(actual == set(out), 'New root manifest file set mismatch')
    expected_dirs = {str(parent) for rel in out for parent in Path(rel).parents if str(parent) != '.'}
    require(actual_dirs == expected_dirs, 'New root directory set mismatch')
    require('verify_comparability.py' in out and sha(Path(__file__).resolve()) == out['verify_comparability.py']['sha256'], 'Gate program not approved')
    return out

NAMES = ['aether.style-semantic-diff','aether.transition-property-pipeline','aether.transform-runtime','aether.smoke','aether.abi-c']
TARGETS = ['aether_style_semantic_diff_test','aether_transition_property_pipeline_test','aether_transform_runtime_test','aether_smoke_test','aether_abi_c_smoke_test']
HELPER = 'tests/diagnostics/post09_observer.cpp'
HEADER = 'tests/diagnostics/post09_observer_private.h'
CHANGED = {'native/CMakeLists.txt','native/'+HELPER,'native/'+HEADER,
           'native/src/style_runtime/style_diff.cpp','native/src/style_runtime/style_runtime_core.cpp',
           'native/tests/test_style_semantic_diff.cpp','native/tests/test_transition_property_pipeline.cpp',
           'native/tests/test_transform_runtime.cpp'}
EXPORTS = {
 'aether::diagnostic::post09::begin(aether::diagnostic::post09::Case)',
 'aether::diagnostic::post09::public_result(unsigned long long, aether::diagnostic::post09::SampleKind, void const*, int, bool, unsigned int)',
 'aether::diagnostic::post09::end(unsigned long long)'}

class Gate:
    def __init__(self, root, policy, approved, digest):
        self.root, self.policy, self.approved = root, policy, approved
        self.inputs = {str(root/'evidence.sha256.json'):digest}
        self.negative_paths = {}
        self.negative_parents = {}
        self.checks, self.tools_log, self.elf_records = [], [], {}
        self.old = Path(policy['source_root'])
        self.hist = Path(policy['historical_run_root'])
        require(policy['root'] == str(root) and policy['run_root'] == str(root), 'Policy root mismatch')
        require(policy['selected_names'] == NAMES and policy['selected_targets'] == TARGETS, 'Selection changed')
        self.closure = TARGETS + ['aether_core']
        self.runtime_path = Path(policy['historical_runtime_manifest'])
        require(valid_hash(policy['historical_runtime_manifest_sha256']), 'No historical runtime authority')
        require(sha(self.runtime_path) == policy['historical_runtime_manifest_sha256'], 'Historical runtime manifest changed')
        self.runtime = self.read_json(self.runtime_path)
        self.hist_report = self.read_hist_json(self.hist/'run/comparability.json')
        require(self.hist_report.get('status') == 'PASS', 'Historical comparison not PASS')
        self.source_manifests = {}
        old_evidence_path = self.old/'evidence.sha256.json'
        old_digest = policy['references'].get(str(old_evidence_path))
        require(valid_hash(old_digest) and sha(old_evidence_path) == old_digest, 'Historical source authority absent/changed')
        old_evidence = self.read_json(old_evidence_path)
        for tree in ('Hc','J'):
            require(policy['trees'][tree] == str(root/tree), 'Wrong instrumental tree')
            require(policy['builds'][tree] == str(root/('build-'+tree)), 'Wrong build')
            if 'historical_builds' in policy:
                require(policy['historical_builds'][tree] == str(self.hist/('build-'+tree)), 'Wrong historical build')
            p = self.old/('manifest-'+tree+'.json')
            require(sha(p) == old_evidence[p.name], 'Source manifest hash changed')
            self.source_manifests[tree] = self.read_json(p)
        self.external = self.read_json(root/'external-header-authority.json')['headers']
        require(isinstance(self.external, dict), 'External header authority malformed')
        self.compiler_aliases = {}
        for key in ('cc','c++'):
            a = policy['tool_aliases'][key]; tool = policy['tools'][key]
            require(Path(a['path']).resolve() == Path(a['resolved']) and a['resolved'] == tool['path'], 'Compiler alias resolution differs')
            require(sha(a['path']) == a['sha256'] == tool['sha256'] == sha(tool['path']), 'Compiler alias identity differs')
            self.compiler_aliases[a['path']] = tool['path']
            self.inputs[a['path']] = a['sha256']; self.inputs[tool['path']] = tool['sha256']
        self.checks.append({'check':'compiler_alias_identity','status':'PASS','aliases':self.compiler_aliases,
                            'environment_equivalence_with_09':'NOT_PROVEN'})

    def read_text(self, p):
        p = regular(p); before = sha(p); text = p.read_text()
        require(sha(p) == before, 'Read race: '+str(p))
        self.inputs[str(p)] = before
        return text

    def read_json(self, p):
        return unique_json(self.read_text(p))

    def hist_authorize(self, p):
        p = Path(p)
        key = str(p.relative_to(self.hist.parent))
        require(key in self.runtime, 'Historical artifact absent from approved runtime manifest: '+key)
        row = self.runtime[key]
        require(p.stat().st_size == row['size'] and sha(p) == row['sha256'], 'Historical artifact hash/size differs: '+key)
        self.inputs[str(p)] = row['sha256']

    def read_hist(self, p):
        self.hist_authorize(p)
        return self.read_text(p)

    def read_hist_json(self, p):
        return unique_json(self.read_hist(p))

    def norm(self, v, tree, historical=False):
        if isinstance(v, list): return [self.norm(x,tree,historical) for x in v]
        if isinstance(v, dict): return {k:self.norm(x,tree,historical) for k,x in v.items()}
        if not isinstance(v, str): return v
        source = self.old/tree if historical else self.root/tree
        build = self.hist/('build-'+tree) if historical else self.root/('build-'+tree)
        return v.replace(str(source),'<SOURCE>').replace(str(build),'<BUILD>')

    def compiler_norm(self, words):
        require(words and words[0] in set(self.compiler_aliases)|set(self.compiler_aliases.values()), 'Unexpected compiler driver')
        return [self.compiler_aliases.get(words[0],words[0]),*words[1:]]

    def sources(self):
        patches = {}
        for tree in ('Hc','J'):
            baseline = self.source_manifests[tree]
            actual = {str(p.relative_to(self.root/tree)):p for p in (self.root/tree).rglob('*') if p.is_file()}
            expected = set(baseline) | {'native/'+HELPER,'native/'+HEADER}
            require(set(actual) == expected, tree+' source file set differs beyond two helper files')
            changed = set(); patches[tree] = {}
            for rel in sorted(expected):
                p = regular(actual[rel]); full = tree+'/'+rel
                require(full in self.approved and sha(p) == self.approved[full]['sha256'], 'Unapproved source: '+full)
                self.inputs[str(p)] = sha(p)
                before = b''
                if rel in baseline:
                    oldp = regular(self.old/tree/rel)
                    require(sha(oldp) == baseline[rel], 'Historical source drift: '+str(oldp))
                    self.inputs[str(oldp)] = baseline[rel]; before = oldp.read_bytes()
                after = p.read_bytes()
                if before != after:
                    changed.add(rel)
                    patch = difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True))
                    patches[tree][rel] = ''.join(x for x in patch if not x.startswith(('---','+++','@@')))
            require(changed == CHANGED, tree+' exact eight-path delta differs')
        require(patches['Hc'] == patches['J'], 'Instrumental hunks asymmetric')
        self.checks.append({'check':'source_closure_and_symmetric_exact_delta','status':'PASS','changed_paths':sorted(CHANGED)})

    def testfile(self, p, historical=False):
        text = self.read_hist(p) if historical else self.read_text(p)
        tests, props = {}, {}
        for raw in text.splitlines():
            line = raw.strip()
            if not line or line.startswith('#'): continue
            m = re.fullmatch(r'(add_test|set_tests_properties)\((.*)\)',line)
            require(m is not None, 'Unsupported generated CTest syntax')
            words = shlex.split(m.group(2)); require(words, 'Empty CTest command')
            name = words[0]
            if name not in NAMES: continue
            if m.group(1) == 'add_test':
                require(name not in tests and len(words)>1, 'Duplicate/empty selected test'); tests[name] = words[1:]
            else:
                require(name not in props and words[1:2] == ['PROPERTIES'] and len(words[2:])%2 == 0, 'Selected properties syntax')
                props[name] = dict(zip(words[2::2],words[3::2])); props[name].pop('_BACKTRACE_TRIPLES',None)
        require(set(tests) == set(NAMES), 'Missing selected CTest test')
        return {n:{'command':tests[n],'properties':props.get(n,{})} for n in NAMES}

    def inventories(self, built):
        for tree in ('Hc','J'):
            build = self.root/('build-'+tree); hb = self.hist/('build-'+tree)
            oldmeta = self.testfile(hb/'CTestTestfile.cmake',True)
            meta = self.testfile(build/'CTestTestfile.cmake')
            require(self.norm(meta,tree) == self.norm(oldmeta,tree,True), 'Selected command/properties differ '+tree)
            inv = self.read_json(self.policy['inventories'][tree])['tests']
            oldinv = self.read_hist_json(self.hist/('run/inventory-'+tree+'.stdout'))['tests']
            for name,target in zip(NAMES,TARGETS):
                rows = [x for x in inv if x['name'] == name]; older = [x for x in oldinv if x['name'] == name]
                require(len(rows) == len(older) == 1, 'Selected inventory cardinality '+name)
                after,before = rows[0],older[0]
                require(meta[name]['command'] == [str(build/target)], 'Unexpected selected argv '+name)
                require(self.norm(after.get('properties',[]),tree) == self.norm(before.get('properties',[]),tree,True), 'Selected inventory properties differ')
                if 'command' in after:
                    require(after['command'] == meta[name]['command'], 'Inventory/generated command disagreement')
                else:
                    require(not built and not (build/target).exists(), 'Missing command with built executable')
                if built:
                    p = regular(build/target); require(os.access(p,os.X_OK), 'Executable mode missing'); self.inputs[str(p)] = sha(p)
        self.checks.append({'check':'five_selected_test_names_argv_properties','status':'PASS','built':built,'unselected_tests_not_counted':True})

    def compile_map(self, tree, historical=False):
        build = (self.hist if historical else self.root)/('build-'+tree)
        data = self.read_hist_json(build/'compile_commands.json') if historical else self.read_json(build/'compile_commands.json')
        result = {}
        sourcebase = (self.old if historical else self.root)/tree/'native'
        for row in data:
            words = row.get('arguments') or shlex.split(row['command'])
            require('-o' in words and '-c' in words, 'Unsupported compile command')
            obj = words[words.index('-o')+1]
            m = re.fullmatch(r'(?:.*/)?CMakeFiles/([^/]+)\.dir/(.*)\.o',obj)
            require(m, 'Unsupported object naming')
            target,rel = m.groups()
            if target not in self.closure: continue
            key = (target,rel); require(key not in result, 'Duplicate compile key')
            require(Path(row['file']) == sourcebase/rel and Path(row['directory']) == build, 'Compile source/directory mismatch')
            result[key] = self.norm(self.compiler_norm(words),tree,historical)
        require(set(t for t,r in result) == set(self.closure), 'Missing compile target')
        return result

    def deps(self, p, historical=False):
        text = (self.read_hist(p) if historical else self.read_text(p)).replace('\\\n',' ')
        require(':' in text and '$' not in text and '\x00' not in text, 'Unsupported make dependency data')
        target,body = text.split(':',1)
        require('\n' not in target and target.strip(), 'Invalid dependency target')
        paths = shlex.split(body)
        require(paths and all(Path(x).is_absolute() for x in paths), 'Relative/unproven dependency')
        return set(Path(x).resolve() for x in paths)

    def capture_headers(self, tree, oldmap, newmap):
        oldsrc = self.old/tree/'native'; newsrc = self.root/tree/'native'
        for key in newmap:
            target,rel = key
            build = self.root/('build-'+tree)
            deps = self.deps(build/'CMakeFiles'/(target+'.dir')/(rel+'.o.d'))
            if key in oldmap:
                olddeps = self.deps(self.hist/('build-'+tree)/'CMakeFiles'/(target+'.dir')/(rel+'.o.d'),True)
                normalized_old = {str(p).replace(str(oldsrc),'<SOURCE>') for p in olddeps}
                normalized_new = {str(p).replace(str(newsrc),'<SOURCE>') for p in deps}
                # A private header can introduce already approved system headers. No original header may disappear.
                require(normalized_old <= normalized_new, 'Historical include dependency removed '+str(key))
                added_project = {x for x in normalized_new-normalized_old if x.startswith('<SOURCE>')}
                require(added_project <= {'<SOURCE>/'+HEADER}, 'Unexpected project include addition '+str(key))
            for p in deps:
                if p.is_relative_to(newsrc):
                    k = str(p.relative_to(self.root))
                    require(k in self.approved and sha(p) == self.approved[k]['sha256'], 'Unapproved project header '+str(p))
                else:
                    require(str(p) in self.external, 'External header not statically approved '+str(p))
                    entry = self.external[str(p)]
                    require(p.stat().st_size == entry['bytes'] and sha(p) == entry['sha256'], 'External header drift '+str(p))
                self.inputs[str(p)] = sha(p)
        self.checks.append({'check':'header_closure_'+tree,'status':'PASS','external_header_historical_identity':'NOT_PROVEN_CURRENT_AUTHORITY_ONLY'})

    def configuration(self, tree):
        def cache(text):
            result = {}
            for line in text.splitlines():
                if not line or line.startswith(('#','//')): continue
                m = re.fullmatch(r'([^:]+):([^=]+)=(.*)', line)
                require(m is not None, 'Unsupported CMake cache row')
                key, kind, value = m.groups()
                require(key not in result, 'Duplicate CMake cache key')
                result[key] = (kind, value)
            return result
        before = cache(self.read_hist(self.hist/('build-'+tree)/'CMakeCache.txt'))
        after = cache(self.read_text(self.root/('build-'+tree)/'CMakeCache.txt'))
        required = {'CMAKE_BUILD_TYPE':('STRING','Debug'), 'AETHERUI_BUILD_TESTS':('BOOL','ON'),
                    'BUILD_TESTING':('BOOL','ON'), 'AETHER_EFFECT_CAPTURE':('BOOL','OFF')}
        for key,value in required.items():
            require(before.get(key) == after.get(key) == value, 'Configuration contract differs '+key)
        for key,tool in (('CMAKE_C_COMPILER','cc'),('CMAKE_CXX_COMPILER','c++')):
            require(key in before and key in after, 'Compiler cache entry missing')
            b,a = before[key][1],after[key][1]
            require(self.compiler_aliases.get(b,b) == self.compiler_aliases.get(a,a) == self.policy['tools'][tool]['path'], 'Configured compiler identity differs')
        self.checks.append({'check':'configuration_contract_'+tree,'status':'PASS',
                            'all_other_cache_bytes_captured_not_asserted_identical':True})

    def compile_and_link(self):
        for tree in ('Hc','J'):
            self.configuration(tree)
            old = self.compile_map(tree,True); new = self.compile_map(tree)
            require(set(new) == set(old)|{('aether_core',HELPER)}, 'Compile closure differs beyond helper '+tree)
            for key in old: require(new[key] == old[key], 'Compile flags drift '+tree+'/'+str(key))
            template = 'src/style_runtime/style_diff.cpp'
            helper = [x.replace(HELPER,template) for x in new[('aether_core',HELPER)]]
            require(helper == new[('aether_core',template)], 'Helper command has extra flags/options')
            self.capture_headers(tree,old,new)
            for target in self.closure:
                bd = self.root/('build-'+tree)/'CMakeFiles'/(target+'.dir')
                hd = self.hist/('build-'+tree)/'CMakeFiles'/(target+'.dir')
                before = self.norm(self.read_hist(hd/'flags.make'),tree,True)
                after = self.norm(self.read_text(bd/'flags.make'),tree)
                for alias,resolved in self.compiler_aliases.items():
                    before = before.replace('with '+alias+'\n','with '+resolved+'\n')
                    after = after.replace('with '+alias+'\n','with '+resolved+'\n')
                require(after == before, 'flags.make drift '+tree+'/'+target)
                oldlink = self.norm(self.compiler_norm(shlex.split(self.read_hist(hd/'link.txt'))),tree,True)
                newlink = self.norm(self.compiler_norm(shlex.split(self.read_text(bd/'link.txt'))),tree)
                helperobj = 'CMakeFiles/aether_core.dir/'+HELPER+'.o'
                if target == 'aether_core':
                    require(newlink.count(helperobj) == 1, 'Helper object missing/duplicate')
                    newlink = [x for x in newlink if x != helperobj]
                require(newlink == oldlink, 'Link order/options/objects drift '+tree+'/'+target)
                # CMake's declarative dependency metadata may only gain the one helper tuple.
                olddi = self.norm(self.read_hist(hd/'DependInfo.cmake'),tree,True)
                newdi = self.norm(self.read_text(bd/'DependInfo.cmake'),tree)
                if target == 'aether_core':
                    line = '  "<SOURCE>/native/'+HELPER+'" "CMakeFiles/aether_core.dir/'+HELPER+'.o" "gcc" "CMakeFiles/aether_core.dir/'+HELPER+'.o.d"\n'
                    require(newdi.count(line) == 1, 'Helper DependInfo tuple mismatch')
                    newdi = newdi.replace(line,'')
                require(newdi == olddi, 'DependInfo closure drift '+tree+'/'+target)
        self.checks.append({'check':'compile_flags_link_order_dependency_metadata','status':'PASS','extra_tu':HELPER})

    def tool(self,name,args):
        require(name in ('readelf','ldconfig'), 'Inspection tool not allowed')
        tool = self.policy['tools'][name]; path = Path(tool['path'])
        require(sha(path) == tool['sha256'], 'Inspection tool hash drift '+name)
        self.inputs[str(path)] = tool['sha256']; start = time.monotonic()
        p = subprocess.run([str(path),*args],capture_output=True,text=True,timeout=15,
                           env={'PATH':'/usr/bin:/usr/sbin:/bin','LC_ALL':'C'})
        self.tools_log.append({'argv':[str(path),*args],'start':start,'end':time.monotonic(),'rc':p.returncode,
                               'stdout':p.stdout,'stderr':p.stderr})
        require(p.returncode == 0, 'Inspection failed '+name)
        return p.stdout

    def elf(self,p,historical=False):
        p = Path(p).resolve()
        if str(p) in self.elf_records: return self.elf_records[str(p)]
        regular(p)
        if historical: self.hist_authorize(p)
        header = self.tool('readelf',['-h',str(p)])
        require('ELF64' in header and 'Advanced Micro Devices X86-64' in header, 'Unsupported ELF architecture')
        dynamic = self.tool('readelf',['-d',str(p)]); program = self.tool('readelf',['-l',str(p)])
        require(not re.search(r'\((?:AUDIT|DEPAUDIT|FILTER|AUXILIARY)\)',dynamic) and 'NODEFLIB' not in dynamic, 'Loader redirection unsupported')
        tags = {k:re.findall(r'\('+k+r'\).*?\[(.*?)\]',dynamic) for k in ('NEEDED','RPATH','RUNPATH','SONAME')}
        require(len(tags['RUNPATH'])<=1 and not tags['RPATH'] and len(tags['SONAME'])<=1, 'Unsupported ELF path tags')
        interpreter = re.findall(r'Requesting program interpreter:\s*([^\]]+)',program)
        require(len(interpreter)<=1, 'Multiple ELF interpreters')
        rec = {'sha256':sha(p),'needed':tags['NEEDED'],'soname':tags['SONAME'],
               'runpath':tags['RUNPATH'][0].split(':') if tags['RUNPATH'] else [],'interpreter':interpreter[0] if interpreter else None}
        self.inputs[str(p)] = rec['sha256']; self.elf_records[str(p)] = rec
        return rec

    def symbols(self,p,historical=False):
        if historical:self.hist_authorize(p)
        raw = self.tool('readelf',['--dyn-syms','--wide',str(p)])
        demangled = self.tool('readelf',['--dyn-syms','--wide','--demangle',str(p)])
        def parse(text):
            result = {}
            for line in text.splitlines():
                m = re.match(r'\s*(\d+):\s+([0-9a-fA-F]+)\s+(\d+)\s+(\S+)\s+(\S+)\s+(\S+)\s+(\S+)\s*(.*)$',line)
                if not m: continue
                idx,value,size,typ,bind,vis,ndx,name = m.groups()
                if ndx == 'UND' or not name: continue
                if vis not in ('DEFAULT','PROTECTED'): continue
                require(int(idx) not in result, 'Duplicate dynsym index')
                result[int(idx)] = (name,typ,bind,vis)
            return result
        a,b = parse(raw),parse(demangled)
        require(a.keys()==b.keys(), 'Raw/demangled symbol sets differ')
        symbols = {}
        for idx,(name,typ,bind,vis) in a.items():
            require(name not in symbols and (typ,bind,vis)==b[idx][1:], 'Ambiguous symbol identity')
            symbols[name] = {'type':typ,'binding':bind,'visibility':vis,'demangled':b[idx][0]}
        return symbols

    def exports(self):
        for tree in ('Hc','J'):
            oldp = self.hist/('build-'+tree)/'libaether_core.so.0.1.0'
            newp = self.root/('build-'+tree)/'libaether_core.so.0.1.0'
            old,new = self.symbols(oldp,True),self.symbols(newp)
            require(set(old)<=set(new), 'Public symbol removed '+tree)
            for name in old: require(old[name]==new[name], 'Public symbol metadata/version changed '+name)
            extras = {name:new[name] for name in set(new)-set(old)}
            require(len(extras)==3 and {x['demangled'] for x in extras.values()}==EXPORTS, 'Extra exports not exactly three approved private signatures')
            require(all(x['type']=='FUNC' and x['binding']=='GLOBAL' and x['visibility']=='DEFAULT' for x in extras.values()), 'Private export attributes differ')
            self.checks.append({'check':'exact_private_exports_'+tree,'status':'PASS','new_symbols':extras,'public_symbols_preserved':len(old)})

    def directory_identity(self, directory):
        """Reject aliases anywhere in the accepted absolute parent chain."""
        directory = Path(directory)
        require(directory.is_absolute() and '..' not in directory.parts and '.' not in directory.parts,
                'RUNPATH_PARENT_NONCANONICAL')
        current = Path(directory.anchor)
        chain = [current]
        for part in directory.parts[1:]:
            current = current/part; chain.append(current)
        for component in chain:
            try:
                info = component.lstat()
            except OSError as exc:
                raise Blocked('RUNPATH_PARENT_INSPECTION_FAILED:'+str(component)+':'+type(exc).__name__) from exc
            require(stat.S_ISDIR(info.st_mode), 'RUNPATH_PARENT_NOT_PLAIN_DIRECTORY:'+str(component))
        # strict resolution is supplementary, never substitutes lstat absence checks.
        require(directory.resolve(strict=True) == directory, 'RUNPATH_PARENT_ALIAS')
        info = directory.lstat()
        require(stat.S_ISDIR(info.st_mode), 'RUNPATH_PARENT_CHANGED_TYPE')
        return {'path':str(directory),'canonical_path':str(directory),'device':info.st_dev,
                'inode':info.st_ino,'type':'directory'}

    def negative_path(self, tree, stage, needed=None, requesting_object=None):
        require(tree in ('Hc','J') and stage in ('initial','runpath','final'), 'Negative assertion context invalid')
        directory = self.root/('build-'+tree)
        require(self.policy['builds'][tree] == str(directory), 'Negative path build mismatch')
        path = directory/'glibc-hwcaps'
        event = {'check':'runpath_glibc_hwcaps_absence','tree':tree,'stage':stage,
                 'path':str(path),'directory':str(directory),'needed':needed,
                 'requesting_object':requesting_object,'method':'lstat','status':'BLOCKED'}
        self.checks.append(event)
        before = self.directory_identity(directory)
        try:
            entry = path.lstat()
        except FileNotFoundError:
            # The only absence outcome. A dangling symlink instead returns lstat.
            pass
        except OSError as exc:
            event['inspection_error'] = type(exc).__name__+': '+str(exc)
            raise Blocked('RUNPATH_GLIBC_HWCAPS_INSPECTION_FAILED:'+str(path)) from exc
        else:
            event['observed_type_mode'] = stat.S_IFMT(entry.st_mode)
            event['observed_device'] = entry.st_dev
            event['observed_inode'] = entry.st_ino
            raise Blocked('RUNPATH_GLIBC_HWCAPS_UNMODELED:'+tree+':'+str(path)+':needed='+str(needed))
        after = self.directory_identity(directory)
        require(before == after, 'RUNPATH_PARENT_CHANGED_DURING_NEGATIVE_OBSERVATION')
        if stage == 'initial':
            require(tree not in self.negative_parents, 'Duplicate initial negative assertion')
            self.negative_parents[tree] = dict(after)
        else:
            require(tree in self.negative_parents and self.negative_parents[tree] == after,
                    'RUNPATH_NEGATIVE_PARENT_IDENTITY_CHANGED')
        observed = time.monotonic()
        event.update(status='PASS',parent=dict(after),observed_monotonic=observed)
        self.negative_paths[tree] = {'path':str(path),'expected':'ABSENT','method':'lstat',
                                    'parent':dict(after),'observed_monotonic':observed}

    def negative_checkpoint(self, stage):
        for tree in ('Hc','J'):
            self.negative_path(tree,stage)
        require(set(self.negative_paths) == {'Hc','J'}, 'Negative assertion set incomplete')

    def dependencies(self):
        for key in ('LD_PRELOAD','LD_LIBRARY_PATH','LD_AUDIT','GLIBC_TUNABLES'):
            require(not os.environ.get(key), 'Unexpected loader environment '+key)
        preload = Path('/etc/ld.so.preload')
        require(not preload.exists() or not self.read_text(preload).strip(), 'System preload prevents proof')
        cachefile = regular('/etc/ld.so.cache'); self.inputs[str(cachefile)] = sha(cachefile)
        historic_inputs = self.hist_report['inputs']
        require(str(cachefile) in historic_inputs and self.inputs[str(cachefile)] == historic_inputs[str(cachefile)], 'Loader cache drift from09')
        cache = {}
        for line in self.tool('ldconfig',['-p']).splitlines():
            m = re.match(r'\s*(\S+)\s+\(([^)]+)\)\s+=>\s+(\S+)\s*$',line)
            if m and 'x86-64' in m.group(2): cache.setdefault(m.group(1),[]).append(Path(m.group(3)))
        require(cache, 'Empty loader cache')
        systems = {}
        for tree in ('Hc','J'):
            build = self.root/('build-'+tree); hb = self.hist/('build-'+tree)
            names = TARGETS+['libaether_core.so.0.1.0']
            for name in names:
                previous,current = self.elf(hb/name,True),self.elf(build/name)
                keys = ('needed','soname','runpath','interpreter')
                require(self.norm({k:previous[k] for k in keys},tree,True)==self.norm({k:current[k] for k in keys},tree), 'ELF dynamic contract changed '+tree+'/'+name)
            queue = [build/n for n in names]; visited=set(); system={};edges=[]
            while queue:
                p=queue.pop(0).resolve()
                if p in visited:continue
                visited.add(p);rec=self.elf(p);dirs=[]
                for raw in rec['runpath']:
                    require(raw and '$LIB' not in raw and '$PLATFORM' not in raw, 'Unsupported runpath token')
                    expanded=raw.replace('${ORIGIN}',str(p.parent)).replace('$ORIGIN',str(p.parent))
                    require('$' not in expanded and Path(expanded).is_absolute(), 'Unproven runpath')
                    directory=Path(expanded)
                    require(directory==build, 'Cross-tree/non-own-build runpath')
                    self.negative_path(tree,'runpath',requesting_object=str(p))
                    dirs.append(directory)
                for needed in rec['needed']:
                    require('/' not in needed, 'NEEDED path unsupported')
                    # Check EVERY accepted RUNPATH before any base-file lookup.
                    # An empty directory, regular file, FIFO or broken symlink at
                    # glibc-hwcaps blocks exactly like a populated variant tree.
                    for directory in dirs:
                        require(directory==build, 'RUNPATH build identity lost')
                        self.negative_path(tree,'runpath',needed=needed,requesting_object=str(p))
                    local=[]
                    for directory in dirs:
                        candidate=directory/needed
                        try:
                            candidate.lstat()
                        except FileNotFoundError:
                            continue
                        except OSError as exc:
                            raise Blocked('RUNPATH_BASE_INSPECTION_FAILED:'+str(candidate)) from exc
                        # Existing symlinks are not treated as absent. Resolution
                        # failure (including dangling link) blocks rather than
                        # falling through to the cache.
                        local.append(candidate)
                    if local:
                        resolved=local[0].resolve(strict=True)
                    else:
                        candidates=cache.get(needed,[])
                        require(len(candidates)==1 and 'glibc-hwcaps' not in str(candidates[0]), 'Ambiguous/unapproved loader resolution '+needed)
                        resolved=candidates[0].resolve()
                    regular(resolved)
                    if needed.startswith('libaether_core'):
                        require(resolved==build/'libaether_core.so.0.1.0','Wrong core resolved')
                    else:
                        require(str(resolved).startswith(('/usr/lib/','/lib/')),'Unexpected dependent library origin')
                        require(str(resolved) in historic_inputs and sha(resolved)==historic_inputs[str(resolved)], 'System dependency not identical to09 '+str(resolved))
                        system[str(resolved)]=sha(resolved)
                    self.inputs[str(resolved)]=sha(resolved);edges.append({'object':str(p),'needed':needed,'resolved':str(resolved),'sha256':sha(resolved)});queue.append(resolved)
                if rec['interpreter']:
                    loader=Path(rec['interpreter']).resolve();regular(loader)
                    require(str(loader) in historic_inputs and sha(loader)==historic_inputs[str(loader)], 'Interpreter differs from09')
                    system[str(loader)]=sha(loader);self.inputs[str(loader)]=sha(loader);queue.append(loader)
            systems[tree]=system
            self.checks.append({'check':'loader_resolution_'+tree,'status':'PASS','edges':edges,'system_hashes':system})
        require(systems['Hc']==systems['J'], 'Arms use different system closure')

    def unchanged(self):
        for path,digest in self.inputs.items():require(sha(path)==digest,'Gate input mutated '+path)
        self.negative_checkpoint('final')


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--phase',required=True,choices=('inventory','comparability'))
    ap.add_argument('--policy',required=True);ap.add_argument('--output',required=True)
    ap.add_argument('--manifest-sha256',required=True)
    args=ap.parse_args(); root=Path(__file__).resolve().parent
    report={'status':'BLOCKED','phase':args.phase,'attribution':'UNDETERMINED','environment_equivalence_with_09':'NOT_PROVEN'}
    gate=None
    try:
        approved=bootstrap(root,args.manifest_sha256)
        require(Path(args.policy)==root/'policy.json','Policy outside approved root')
        policy=unique_json((root/'policy.json').read_text())
        gate=Gate(root,policy,approved,args.manifest_sha256)
        gate.inputs[str(root/'policy.json')]=approved['policy.json']['sha256']
        gate.negative_checkpoint('initial')
        gate.sources();gate.inventories(args.phase=='comparability')
        if args.phase=='comparability':
            gate.compile_and_link();gate.dependencies();gate.exports()
        gate.unchanged();report['status']='PASS'
    except Exception as exc:
        report['error']=type(exc).__name__+': '+str(exc)
    if gate is not None:
        report.update(inputs=gate.inputs,checks=gate.checks,elf=gate.elf_records,tool_invocations=gate.tools_log,
                      negative_path_assertions=[gate.negative_paths[t] for t in ('Hc','J') if t in gate.negative_paths])
    # No output path from untrusted candidate data; only this designated run file.
    output=root/'run'/('inventory.json' if args.phase=='inventory' else 'comparability.json')
    require(Path(args.output)==output and output.parent.is_dir() and not output.parent.is_symlink(),'Invalid report path')
    temporary=output.with_suffix('.json.tmp')
    with open(temporary,'x') as f:
        json.dump(report,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
    require(not output.exists() and not output.is_symlink(),'Report already exists')
    os.replace(temporary,output)
    return 0 if report['status']=='PASS' else 2

if __name__=='__main__':
    sys.exit(main())

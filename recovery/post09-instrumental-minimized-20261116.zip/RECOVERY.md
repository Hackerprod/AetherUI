# Minimized technical source snapshot

Only diagnostic and validation source code is included. Internal absolute paths have been replaced by /RELOCATE placeholders. These are templates, not runnable or accepted artifacts. Configure local tool paths, reconstruct required policy/recipe files and independently revalidate before use. Prior confidential operational files and their hashes are deliberately not carried over.

The diagnostic Hc/J subdirectories are source deltas, not full repositories. Apply them to the corresponding base source snapshots from earlier backups. The validation input/native directory is likewise a delta against the integration candidate. Preserve missing unchanged base files. This package does not preserve the execution environment or original test evidence.

TECHNICAL_STATUS.json is a deliberately limited, anonymized summary. It does not assert PASS. No logs, process/session records, environment snapshots, internal plans or coordination records are included. Generic environment keys and standard system paths inside source code are programming logic, not captured user environment values.

Changed anonymization templates:
- diagnostic/concurrency_preflight.py
- validation/concurrency_preflight.py
- validation/external_collector.py
- validation/external_contract.py
- validation/external_supervisor.py
- validation/external_writer.py
- validation/mutate_observer_fixture.py
- validation/validation_launcher.py

#!/usr/bin/env python3
"""E1 adapter candidate. NOT RUN. No retries; missing authority stops pre-spawn.
One implementation, separate outer/worker processes. No local module imports.
"""
import argparse,ctypes,errno,fcntl,hashlib,json,os,resource,selectors,signal,stat,struct,subprocess,sys,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
PYTHON='/RELOCATE/python3'
MAX_META=65536
DEADLINE=float('inf')
class Stop(RuntimeError):pass

def check(ok,why):
 if not ok:raise Stop(why)
def mono():return time.monotonic()
def checkpoint():
 check(mono()<DEADLINE,'PROTECTED_IO_DEADLINE')
 check(not globals().get('CANCEL',False),'CANCELLED')
 # Self RSS is checked during custody as well as workload monitoring. Linux
 # ru_maxrss catches a peak between checkpoints; this is observation, not AS.
 check(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024<=268435456,'SUPERVISOR_RSS_PEAK_STOP')
 row=proc(os.getpid());check(row is not None and row['rss']<=268435456,'SUPERVISOR_RSS_STOP')
def digest(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  while True:
   checkpoint();b=f.read(1048576)
   if not b:break
   h.update(b)
 return h.hexdigest()
def unique(items):
 d={}
 for k,v in items:
  check(k not in d,'DUPLICATE_JSON_KEY');d[k]=v
 return d
def read_json(path,limit=MAX_META):
 checkpoint();p=Path(path);s=p.lstat();check(stat.S_ISREG(s.st_mode) and s.st_size<=limit,'JSON_TYPE_QUOTA')
 with p.open('rb') as f:value=json.loads(f.read(limit+1),object_pairs_hook=unique)
 checkpoint();return value
def safe_chain(path):
 p=Path(path);check(p.is_absolute(),'ABSOLUTE_REQUIRED')
 for x in reversed([p,*p.parents]):
  s=x.lstat();check(not stat.S_ISLNK(s.st_mode),'UNAPPROVED_PATH_SYMLINK')
 return p
def atomic_json(path,value,limit=MAX_META):
 raw=json.dumps(value,sort_keys=True,separators=(',',':')).encode()+b'\n';check(len(raw)<=limit,'METADATA_QUOTA')
 p=Path(path);tmp=p.with_name(p.name+'.tmp');fd=os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 try:
  with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
  check(not p.exists(),'OUTPUT_ALREADY_EXISTS');os.rename(tmp,p)
 finally:
  # No deletion of evidence, even when a partial temporary remains.
  pass

def bounded_walk(root,ordered=False):
 # Avoid unbounded comprehensions during authority scans. Check per entry.
 entries=[]
 for item in Path(root).rglob('*'):
  checkpoint();check(len(entries)<100000,'TREE_ENTRY_QUOTA');entries.append(item)
 if ordered:entries.sort(key=lambda p:str(p.relative_to(root)))
 checkpoint();return entries

def tree_digest(root):
 p=safe_chain(root);h=hashlib.sha256()
 for f in bounded_walk(p,ordered=True):
  checkpoint();s=f.lstat();check(not stat.S_ISLNK(s.st_mode),'SOURCE_SYMLINK')
  if stat.S_ISREG(s.st_mode):h.update(str(f.relative_to(p)).encode()+b'\0'+digest(f).encode()+b'\n')
  else:check(stat.S_ISDIR(s.st_mode),'SOURCE_SPECIAL_FILE')
 return h.hexdigest()
def file_record(path):
 p=Path(path);s=p.lstat()
 if stat.S_ISLNK(s.st_mode):return dict(path=str(p),kind='symlink',target=os.readlink(p),resolved=str(p.resolve(strict=True)))
 check(stat.S_ISREG(s.st_mode),'DEPENDENCY_SPECIAL_FILE')
 return dict(path=str(p),kind='file',bytes=s.st_size,sha256=digest(p))

def verify_authority(authority):
 check(authority['state']=='APPROVED_COMPLETE','DEPENDENCY_AUTHORITY_INCOMPLETE')
 check(set(authority['covered_classes'])==set(authority['required_classes']),'DEPENDENCY_CLASSES_INCOMPLETE')
 records=authority['files'];check(0<len(records)<=authority['limits']['files'],'DEPENDENCY_COUNT')
 expected={r['path']:r for r in records};check(len(expected)==len(records),'DUPLICATE_DEPENDENCY')
 directories=authority.get('directories',[]);check(directories,'DIRECTORY_AUTHORITY_MISSING')
 for d in directories:
  q=Path(d['path']);st=q.lstat();check(stat.S_ISDIR(st.st_mode) and not q.is_symlink(),'DEPENDENCY_DIRECTORY_TYPE')
  check((st.st_dev,st.st_ino,str(q.resolve(strict=True)))==(d['device'],d['inode'],d['canonical']),'DEPENDENCY_DIRECTORY_IDENTITY')
 for r in records:
  checkpoint();check(file_record(r['path'])==r,'DEPENDENCY_CHANGED:'+r['path'])
 for r in records:
  if r['kind']=='symlink':check(r['resolved'] in expected and expected[r['resolved']]['kind']=='file','UNPINNED_SYMLINK_TARGET')
 for root in authority['roots']:
  p=Path(root);actual={str(x) for x in bounded_walk(p) if x.is_file() or x.is_symlink()}
  declared={name for name in expected if Path(name).is_relative_to(p)}
  check(actual==declared,'DEPENDENCY_ROOT_SET_CHANGED:'+root)
 for name in authority['absent']:
  try:Path(name).lstat()
  except FileNotFoundError:continue
  raise Stop('ABSENT_DEPENDENCY_APPEARED:'+name)
 # Require a fail-closed preload policy. Empty regular file may be pinned.
 preload=Path('/etc/ld.so.preload')
 if preload.exists():check(str(preload) in expected and preload.stat().st_size==0,'PRELOAD_NOT_EMPTY_OR_UNPINNED')
 else:check(str(preload) in authority['absent'],'PRELOAD_ABSENCE_UNPINNED')
 return expected

def custody(expected_manifest):
 mpath=HERE/'adapter-manifest.json';check(digest(mpath)==expected_manifest,'ADAPTER_MANIFEST_CHANGED')
 m=read_json(mpath)
 check(digest(mpath)==expected_manifest,'ADAPTER_MANIFEST_REREAD_CHANGED')
 for name,sha in m['files'].items():
  check('/' not in name and name not in ('.','..'),'MANIFEST_PATH');check(digest(HERE/name)==sha,'ADAPTER_FILE_CHANGED:'+name)
 recipe=read_json(HERE/'recipe.json');auth=read_json(HERE/'dependency-authority.json',16777216)
 check(digest(HERE/'recipe.json')==m['files']['recipe.json'] and digest(HERE/'dependency-authority.json')==m['files']['dependency-authority.json'],'CUSTODY_READ_RACE')
 check(recipe.get('probe_authority',{}).get('state')=='APPROVED_ENUMERATED','CONFIGURE_PROBE_AUTHORITY_BLOCKED')
 check(recipe.get('probe_authority',{}).get('paths'),'CONFIGURE_PROBE_PATHS_EMPTY')
 check(recipe.get('execution_ready') is True and recipe.get('state')=='APPROVED_FOR_SINGLE_E1','RECIPE_NOT_AUTHORIZED')
 pinned=verify_authority(auth)
 check(tree_digest(recipe['source_root'])==recipe['source_tree_sha256'],'SOURCE_TREE_CHANGED')
 source=Path(recipe['source_root']).parent
 check(digest(source/'analyze_e1.py')==recipe['analyzer_sha256'],'ANALYZER_CHANGED')
 check(digest(source/'E1-diagnostic.patch')==recipe['patch_sha256'],'PATCH_CHANGED')
 return recipe,pinned

def proc(pid):
 try:
  raw=Path('/proc',str(pid),'stat').read_text();v=raw[raw.rfind(')')+2:].split()
  return dict(pid=int(pid),ppid=int(v[1]),start=v[19],state=v[0],rss=int(v[21])*os.sysconf('SC_PAGE_SIZE'))
 except (FileNotFoundError,ProcessLookupError):return None
def same(row):
 p=proc(row['pid']);return bool(p and p['start']==row['start'])
def discover(root,known):
 rows={}
 for p in Path('/proc').iterdir():
  if p.name.isdigit():
   x=proc(int(p.name))
   if x:rows[x['pid']]=x
 ids={root};change=True
 while change:
  change=False
  for pid,x in rows.items():
   if x['ppid'] in ids and pid not in ids:ids.add(pid);change=True
 for pid in ids-{root}:known[(pid,rows[pid]['start'])]=rows[pid]
 return [x for x in known.values() if same(x)]
def send_verified(row,sig):
 if not same(row):return False
 try:fd=os.pidfd_open(row['pid'])
 except ProcessLookupError:return False
 try:
  if same(row):signal.pidfd_send_signal(fd,sig,None,0);return True
 except ProcessLookupError:return False
 finally:os.close(fd)
 return False

def tighten(which,wanted):
 soft,hard=resource.getrlimit(which)
 values=[wanted]+[x for x in (soft,hard) if x!=resource.RLIM_INFINITY]
 target=min(values);resource.setrlimit(which,(target,target));return target

def no_network_namespace():
 # Private, empty network namespace; do not assume existing restrictions suffice.
 libc=ctypes.CDLL(None,use_errno=True)
 check(libc.unshare(0x40000000)==0,'NETWORK_ISOLATION_UNAVAILABLE:'+str(ctypes.get_errno()))
 interfaces={line.split(':',1)[0].strip() for line in Path('/proc/net/dev').read_text().splitlines()[2:] if ':' in line}
 check(interfaces<={'lo'},'NETWORK_NAMESPACE_NOT_EMPTY')
 return os.readlink('/proc/self/ns/net')
def subreaper():
 libc=ctypes.CDLL(None,use_errno=True);check(libc.prctl(36,1,0,0,0)==0,'SUBREAPER_UNAVAILABLE')
def memory_available():
 for line in Path('/proc/meminfo').read_text().splitlines():
  if line.startswith('MemAvailable:'):return int(line.split()[1])*1024
 raise Stop('MEMAVAILABLE_MISSING')
def soname_link(path,build_root,policy):
 root=Path(build_root);p=Path(path);check(p.parent==root,'SONAME_LOCATION')
 allowed=policy['links'];check(p.name in allowed,'SONAME_NOT_ALLOWED')
 observed=[];seen=set();current=p
 for _ in range(policy['max_chain']):
  checkpoint();check(current not in seen,'SONAME_CYCLE');seen.add(current)
  check(current.parent==root,'SONAME_PARENT_ESCAPE');safe_chain(root)
  st=current.lstat()
  if stat.S_ISREG(st.st_mode):
   check(current.name==policy['regular_target'],'SONAME_FINAL_NAME')
   return dict(path=str(p),chain=observed,resolved=str(current),device=st.st_dev,inode=st.st_ino)
  check(stat.S_ISLNK(st.st_mode),'SONAME_FINAL_NOT_REGULAR')
  target=os.readlink(current)
  check(current.name in allowed and target==allowed[current.name],'SONAME_TARGET_NOT_ALLOWED')
  check(target and not Path(target).is_absolute() and Path(target).name==target and target not in ('.','..'),'SONAME_TARGET_PATH')
  observed.append(dict(path=str(current),target=target,device=st.st_dev,inode=st.st_ino))
  current=root/target
 raise Stop('SONAME_CHAIN_LIMIT')

def size_tree(root,soname_policy=None):
 total=0;root=Path(root)
 if not root.exists():return total
 for p in bounded_walk(root):
  st=p.lstat()
  if stat.S_ISLNK(st.st_mode):
   check(soname_policy is not None,'TMP_SYMLINK_FORBIDDEN');soname_link(p,root,soname_policy)
  elif stat.S_ISREG(st.st_mode):total+=st.st_size
  else:check(stat.S_ISDIR(st.st_mode),'OUTPUT_TREE_SPECIAL_FILE')
 return total

def mapped_files(rows):
 out=set()
 for row in rows:
  if not same(row):continue
  try:
   for line in Path('/proc',str(row['pid']),'maps').read_text().splitlines():
    fields=line.split(None,5)
    if len(fields)==6 and fields[5].startswith('/'):
     check(not fields[5].endswith(' (deleted)'),'DELETED_MAPPED_FILE');out.add(fields[5])
  except FileNotFoundError:continue
 return out

def verify_maps(rows,pinned,outputs):
 for name in mapped_files(rows):
  canonical=str(Path(name).resolve(strict=True))
  if canonical in outputs:check(digest(canonical)==outputs[canonical],'BUILD_MAPPING_CHANGED')
  else:check(canonical in pinned and pinned[canonical]['kind']=='file','UNPINNED_MAPPING:'+canonical)
 # Sampling detects deviation, not proof of every transient mapping.

def cleanup(root,known,deadline,grace=5):
 signals=[];remaining=discover(root,known)
 for row in remaining:
  if send_verified(row,signal.SIGTERM):signals.append([row['pid'],row['start'],'TERM'])
 end=min(mono()+grace,deadline)
 while mono()<end:
  remaining=discover(root,known)
  for row in remaining:
   try:os.waitpid(row['pid'],os.WNOHANG)
   except (ChildProcessError,ProcessLookupError):pass
  if not any(same(r) for r in remaining):break
  time.sleep(.1)
 for row in discover(root,known):
  if send_verified(row,signal.SIGKILL):signals.append([row['pid'],row['start'],'KILL'])
 end=min(mono()+5,deadline)
 while mono()<end:
  for row in discover(root,known):
   try:os.waitpid(row['pid'],os.WNOHANG)
   except (ChildProcessError,ProcessLookupError):pass
  if not discover(root,known):break
  time.sleep(.1)
 return dict(signals=signals,remaining=discover(root,known))

CANCEL=False
def cancel(*unused):
 global CANCEL;CANCEL=True

def invoke(spec,recipe,pinned,outputs,origin,latch,approved_hash):
 # No retry. All output paths are exclusive and only within this new run root.
 global DEADLINE
 root=Path(recipe['run_root']);lim=recipe['limits']
 deadline=min(origin+lim['absolute_work_seconds'],mono()+spec['cap_seconds'],latch or float('inf'))
 DEADLINE=deadline;custody(approved_hash)
 check(not CANCEL and mono()<deadline,'SPAWN_STOP_OR_DEADLINE')
 stdout=root/spec['stdout_file'];stderr=root/spec['stderr_file']
 check(stdout.parent==root and stderr.parent==root,'OUTPUT_PATH')
 handles=[open(stdout,'xb',buffering=0),open(stderr,'xb',buffering=0)]
 applied={}
 for name,which,wanted in (('AS',resource.RLIMIT_AS,spec['rlimit_as_bytes']),('CORE',resource.RLIMIT_CORE,lim['rlimit_core_bytes']),('NOFILE',resource.RLIMIT_NOFILE,lim['rlimit_nofile']),('FSIZE',resource.RLIMIT_FSIZE,lim['rlimit_fsize_bytes'])):
  soft,hard=resource.getrlimit(which);applied[name]=dict(inherited_soft=soft,inherited_hard=hard,selected=min([wanted]+[x for x in (soft,hard) if x!=resource.RLIM_INFINITY]))
 atomic_json(root/(spec['id']+'.limits-plan.json'),applied)
 def child_limits():
  # Never raise inherited soft/hard limits. No shared-UID RLIMIT_NPROC changes.
  tighten(resource.RLIMIT_AS,spec['rlimit_as_bytes'])
  tighten(resource.RLIMIT_CORE,lim['rlimit_core_bytes']);tighten(resource.RLIMIT_NOFILE,lim['rlimit_nofile']);tighten(resource.RLIMIT_FSIZE,lim['rlimit_fsize_bytes'])
 known={};p=None;sel=selectors.DefaultSelector();rc=None;error=None;total=0;counts=[0,0];streams_closed=False
 try:
  p=subprocess.Popen(spec['argv'],cwd=spec['cwd'],env=recipe['environment'],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,close_fds=True,preexec_fn=child_limits)
  for i,pipe in enumerate((p.stdout,p.stderr)):os.set_blocking(pipe.fileno(),False);sel.register(pipe,selectors.EVENT_READ,i)
  while True:
   check(not CANCEL,'CANCELLED');check(mono()<deadline,'PHASE_DEADLINE')
   rows=discover(os.getpid(),known);check(len(rows)<=lim['identified_processes_max'],'PROCESS_QUOTA')
   check(sum((proc(r['pid']) or {}).get('rss',0) for r in rows)+(proc(os.getpid()) or {}).get('rss',0)<=lim['aggregate_rss_stop_bytes'],'RSS_STOP')
   check(size_tree(root/'build',recipe['soname_policy'])+size_tree(root/'tmp')<=lim['build_and_tmp_stop_bytes'],'BUILD_DISK_STOP')
   verify_maps(rows,pinned,outputs)
   for key,_ in sel.select(.1):
    index=key.data;chunk=os.read(key.fileobj.fileno(),65536)
    if not chunk:sel.unregister(key.fileobj);key.fileobj.close();continue
    total+=len(chunk);counts[index]+=len(chunk)
    check(total<=lim['stdout_stderr_combined_per_phase_bytes'],'STREAM_OVERFLOW')
    if spec['id']=='analyze' and index==0:check(counts[0]<=lim['analysis_stdout_bytes'],'ANALYSIS_QUOTA')
    handles[index].write(chunk)
   rc=p.poll()
   if rc is not None:
    check(rc==0,'PHASE_RC:'+str(rc))
    for row in rows:
     if row['pid']!=p.pid:
      try:os.waitpid(row['pid'],os.WNOHANG)
      except ChildProcessError:pass
    check(not discover(os.getpid(),known),'DESCENDANTS_AFTER_MAIN_EXIT')
    if not sel.get_map():streams_closed=True;break
  check(rc==0,'PHASE_RC:'+str(rc))
 except BaseException as ex:error=type(ex).__name__+':'+str(ex)
 finally:
  closure=cleanup(os.getpid(),known,min(origin+4800,mono()+10)) if error else dict(signals=[],remaining=[])
  if p is not None:
   rc=p.poll()
  for key in list(sel.get_map().values()):
   sel.unregister(key.fileobj);key.fileobj.close()
  sel.close()
  for h in handles:h.close()
 result=dict(id=spec['id'],rc=rc,error=error,EOF=streams_closed,counts=counts,closure=closure,limits_plan=applied)
 atomic_json(root/(spec['id']+'.status.json'),result)
 custody(approved_hash)
 check(error is None and streams_closed and not closure['remaining'],'PHASE_FAILED:'+str(error))
 return result

def freeze_build(root,policy):
 files={};links=[];build=Path(root)/'build'
 for p in bounded_walk(build,ordered=True):
  st=p.lstat()
  if stat.S_ISLNK(st.st_mode):links.append(soname_link(p,build,policy))
  elif stat.S_ISREG(st.st_mode):files[str(p)]=digest(p)
  else:check(stat.S_ISDIR(st.st_mode),'BUILD_SPECIAL_FILE')
 check({Path(x['path']).name for x in links}==set(policy['links']),'SONAME_SET_INCOMPLETE')
 check(str(build/policy['regular_target']) in files,'SONAME_TARGET_MISSING')
 return files,links

def recheck_build_links(root,policy,frozen):
 build=Path(root)/'build';actual=[]
 for p in bounded_walk(build):
  if p.is_symlink():actual.append(soname_link(p,build,policy))
 check(sorted(actual,key=lambda x:x['path'])==sorted(frozen,key=lambda x:x['path']),'SONAME_CUSTODY_CHANGED')

def elf(path):
 p=Path(path);check(p.stat().st_size<=134217728,'ELF_INSPECTION_QUOTA');b=p.read_bytes()
 check(b[:6]==b'\x7fELF\x02\x01' and len(b)>=64,'ELF64_LE_REQUIRED')
 phoff=struct.unpack_from('<Q',b,32)[0];phent,phnum=struct.unpack_from('<HH',b,54)
 check(phent==56 and phnum<=256 and phoff+phent*phnum<=len(b),'ELF_PHDR')
 loads=[];dynamic=None;interpreter=None
 for i in range(phnum):
  typ,flags,off,va,pa,filesz,memsz,align=struct.unpack_from('<II6Q',b,phoff+i*phent)
  check(off+filesz<=len(b),'ELF_SEGMENT')
  if typ==1:loads.append((va,filesz,off))
  elif typ==2:dynamic=(off,filesz)
  elif typ==3:interpreter=b[off:off+filesz].rstrip(b'\0').decode('ascii')
 check(dynamic is not None,'ELF_DYNAMIC_REQUIRED')
 tags=[]
 for off in range(dynamic[0],dynamic[0]+dynamic[1],16):
  check(off+16<=len(b),'ELF_DYNAMIC_RANGE');tag,value=struct.unpack_from('<qQ',b,off)
  if tag==0:break
  tags.append((tag,value))
 addresses=[v for t,v in tags if t==5];sizes=[v for t,v in tags if t==10]
 check(len(addresses)==len(sizes)==1,'ELF_STRTAB')
 table=[(o+addresses[0]-v) for v,n,o in loads if v<=addresses[0]<v+n]
 check(len(table)==1 and table[0]+sizes[0]<=len(b),'ELF_STRTAB_RANGE')
 def string(index):
  check(index<sizes[0],'ELF_STRING_INDEX');start=table[0]+index;end=b.find(b'\0',start,table[0]+sizes[0]);check(end>=0,'ELF_STRING_END');return b[start:end].decode('ascii')
 needed=[string(v) for t,v in tags if t==1];paths=[string(v) for t,v in tags if t in (15,29)]
 check(len(paths)<=1,'ELF_RPATH_RUNPATH_AMBIGUOUS')
 return interpreter,needed,paths[0].split(':') if paths else []

def verify_build_elf(executable,pinned,outputs,authority):
 resolution=authority.get('library_resolution',{});check(resolution,'LIBRARY_RESOLUTION_AUTHORITY_MISSING')
 pending=[str(executable.resolve())];seen=set();core=False
 while pending:
  path=pending.pop()
  if path in seen:continue
  seen.add(path);check(len(seen)<=256,'ELF_CLOSURE_QUOTA')
  check(path in outputs or path in pinned,'ELF_UNPINNED')
  interpreter,needed,search=elf(path)
  if interpreter:
   canonical=str(Path(interpreter).resolve(strict=True));check(canonical in pinned,'ELF_INTERPRETER_UNPINNED')
  dirs=[]
  for value in search:
   value=value.replace('${ORIGIN}',str(Path(path).parent)).replace('$ORIGIN',str(Path(path).parent))
   check(value and '$' not in value and Path(value).is_absolute(),'ELF_SEARCH_UNSUPPORTED');dirs.append(Path(value))
  for name in needed:
   check('/' not in name,'ELF_NEEDED_PATH')
   candidates=[str((d/name).resolve(strict=True)) for d in dirs if (d/name).exists()]
   check(len(set(candidates))<=1,'ELF_SEARCH_AMBIGUOUS')
   chosen=candidates[0] if candidates else resolution.get(name)
   check(chosen is not None,'ELF_DEPENDENCY_UNRESOLVED:'+name)
   if name.startswith('libaether_core'):
    check(chosen in outputs,'CORE_NOT_FROM_BUILD');core=True
   else:check(chosen in outputs or (chosen==resolution.get(name) and chosen in pinned),'ELF_EXTERNAL_DEPENDENCY_NOT_APPROVED')
   pending.append(chosen)
 check(core,'CORE_DEPENDENCY_MISSING')
 return sorted(seen)

def write_manifest_chunks(root,outputs):
 chunks=[];current=[]
 for path,sha in sorted(outputs.items()):
  row=dict(path=path,sha256=sha)
  if len(json.dumps(current+[row]).encode())>60000:
   name='build-output-'+str(len(chunks))+'.json';atomic_json(root/name,current);chunks.append(dict(path=name,sha256=digest(root/name)));current=[]
  current.append(row)
 if current:
  name='build-output-'+str(len(chunks))+'.json';atomic_json(root/name,current);chunks.append(dict(path=name,sha256=digest(root/name)))
 atomic_json(root/'build-output-manifest.json',chunks)

def worker(approved_hash,origin):
 tighten(resource.RLIMIT_AS,2147483648)
 global DEADLINE
 DEADLINE=origin+120
 recipe,pinned=custody(approved_hash);lim=recipe['limits'];root=Path(recipe['run_root']);known={};outcome='NOT_PROVEN';error=None;results=[];outputs={};output_links=[];network=None
 subreaper()
 try:
  network=no_network_namespace() # Must succeed BEFORE configure/build/driver/parser.
  check(mono()<origin+120,'PREFLIGHT_DEADLINE')
  DEADLINE=origin+4500
  for spec in recipe['phases']:
   DEADLINE=origin+4500;checkpoint()
   if spec['id']=='configure':
    raise Stop('CONFIGURE_PROBE_REGIME_NOT_MATERIALIZED')
   if spec['id']=='E1':
    outputs,output_links=freeze_build(root,recipe['soname_policy'])
    atomic_json(root/'build-soname-manifest.json',output_links)
    executable=Path(spec['argv'][0]);check(executable.is_file() and str(executable.resolve()) in outputs,'EXECUTABLE_MISSING')
    closure_files=verify_build_elf(executable,pinned,outputs,read_json(HERE/'dependency-authority.json',16777216))
    write_manifest_chunks(root,outputs)
    # No accepting externally discovered dependency: all mappings must be in
    # approved authority or outputs built by this authorized invocation.
    check(not Path(spec['argv'][1]).exists(),'CAPTURE_EXISTS')
    atomic_json(root/'build-output-summary.json',dict(count=len(outputs),tree_sha256=hashlib.sha256(json.dumps(outputs,sort_keys=True).encode()).hexdigest()))
    latch=mono()+900
   elif spec['id']=='analyze':
    binary=root/'E1.bin';st=binary.lstat();check(stat.S_ISREG(st.st_mode) and st.st_size<=lim['capture_file_bytes'],'CAPTURE_QUOTA_TYPE')
    capture_hash=digest(binary)
    check((root/'E1.stdout').read_bytes()==b'E1_CAPTURE_WRITTEN_NOT_PRODUCT_PASS\n','DRIVER_MARKER')
   else:latch=None
   if outputs:recheck_build_links(root,recipe['soname_policy'],output_links)
   results.append(invoke(spec,recipe,pinned,outputs,origin,latch,approved_hash))
   if outputs:recheck_build_links(root,recipe['soname_policy'],output_links)
   if spec['id']=='configure':
    cache=(root/'build/CMakeCache.txt').read_text()
    required={'CMAKE_BUILD_TYPE':'Debug','CMAKE_C_COMPILER':'/usr/bin/x86_64-linux-gnu-gcc-14','CMAKE_CXX_COMPILER':'/usr/bin/x86_64-linux-gnu-g++-14','CMAKE_MAKE_PROGRAM':'/usr/bin/make','AETHERUI_BUILD_TESTS':'OFF','BUILD_TESTING':'OFF','AETHERUI_DIAGNOSTIC_E1':'ON'}
    values={line.split(':',1)[0]:line.split('=',1)[1] for line in cache.splitlines() if line and not line.startswith(('#','//')) and ':' in line and '=' in line}
    for name,value in required.items():check(values.get(name)==value,'CACHE_MISMATCH:'+name)
    commands=read_json(root/'build/compile_commands.json',16777216)
    targets=[row for row in commands if row['file'].endswith(('style_runtime_core.cpp','test_typography_e1_capture.cpp','e1_capture.cpp'))]
    check(len(targets)==3,'COMPILE_COMMAND_TARGETS')
    for row in targets:
     command=row.get('command','');check('-DAETHER_DIAGNOSTIC_E1=1' in command and '-DNDEBUG' not in command and '-include' not in command and '-fplugin' not in command,'COMPILE_FLAGS')
   if spec['id']=='analyze':
    check(digest(root/'E1.bin')==capture_hash,'CAPTURE_MUTATED')
    answer=read_json(root/'analysis.json',262144);check(answer.get('status')=='CAPTURE_ORACLE_VALID_NOT_PRODUCT_PASS','ANALYSIS_STATUS')
  outcome='CAPTURE_ORACLE_VALID_NOT_PRODUCT_PASS'
 except BaseException as ex:error=type(ex).__name__+':'+str(ex)
 # Separate closure record; failure remains failure even if descendants close.
 DEADLINE=origin+4800
 closure=cleanup(os.getpid(),known,min(origin+4800,mono()+10))
 if closure['remaining']:outcome='NOT_PROVEN'
 custody_error=None
 try:custody(approved_hash)
 except BaseException as ex:custody_error=str(ex);outcome='NOT_PROVEN'
 final=dict(status=outcome,error=error,custody_error=custody_error,network_namespace=network,phases=results,closure=closure,noninterference='NOT_PROVEN',supervisor_self_reaped=False)
 atomic_json(root/'worker-final.json',final)
 return 0 if outcome=='CAPTURE_ORACLE_VALID_NOT_PRODUCT_PASS' and error is None and custody_error is None else 2

def concurrency_preflight():
 # Observation, not proof against another workload starting immediately after it.
 ancestors=set();row=proc(os.getpid())
 while row and row['pid'] not in ancestors:
  ancestors.add(row['pid']);row=proc(row['ppid'])
 bad=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdigit() or int(p.name) in ancestors:continue
  try:
   comm=(p/'comm').read_text().strip();cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ')
  except (FileNotFoundError,ProcessLookupError):continue
  if comm in ('cmake','ctest','make','cc1','cc1plus','collect2','as','ld','g++','gcc') or b'aether_typography_e1_capture' in cmd or (b'--manifest-sha256' in cmd and any(x in cmd for x in (b'post09-',b'E1-adapter-',b'causal-G1-'))):bad.append(int(p.name))
 check(not bad,'CONCURRENT_WORKLOAD_OBSERVED:'+str(bad[:64]))

def outer(approved_hash):
 global DEADLINE
 origin=mono();DEADLINE=origin+120;tighten(resource.RLIMIT_AS,2147483648)
 recipe,pinned=custody(approved_hash);root=Path(recipe['run_root']);lim=recipe['limits']
 check(recipe['driver_invocations']==1 and recipe['retries']==0,'RECIPE_SCOPE')
 check([s['id'] for s in recipe['phases']]==['configure','build','E1','analyze'],'PHASE_SET')
 concurrency_preflight()
 check(memory_available()>=lim['memavailable_preflight_bytes'],'PREFLIGHT_MEMORY')
 safe_chain(root.parent);fs=os.statvfs(root.parent);check(fs.f_bavail*fs.f_frsize>=lim['free_disk_preflight_bytes'],'PREFLIGHT_DISK')
 # Exclusive lock never waits and never kills another owner. This is E1-local;
 # parent/coordinator must separately grant the global no-other-tanda gate.
 lockfd=os.open(HERE/'execution.lock',os.O_CREAT|os.O_RDWR,0o600)
 fcntl.flock(lockfd,fcntl.LOCK_EX|fcntl.LOCK_NB)
 check(not root.exists(),'RUN_ROOT_EXISTS');root.mkdir(mode=0o700);(root/'home').mkdir();(root/'tmp').mkdir()
 subreaper();check(mono()<origin+120,'PREFLIGHT_DEADLINE')
 p=subprocess.Popen([PYTHON,'-I','-B',str(HERE/'adapter.py'),'--manifest-sha256',approved_hash,'--worker','--origin',str(origin)],cwd=str(root),env=recipe['environment'],stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,close_fds=True)
 known={};error=None;DEADLINE=origin+lim['absolute_total_seconds']
 try:
  while p.poll() is None:
   check(not CANCEL,'CANCELLED');check(mono()<origin+lim['absolute_total_seconds'],'OUTER_DEADLINE')
   checkpoint()
   rows=discover(os.getpid(),known);worker_row=proc(p.pid)
   check(worker_row is None or worker_row['rss']<=268435456,'WORKER_RSS_STOP')
   check(sum((proc(r['pid']) or {}).get('rss',0) for r in rows)+(proc(os.getpid()) or {}).get('rss',0)<=lim['aggregate_rss_stop_bytes'],'OUTER_AGGREGATE_RSS_STOP')
   time.sleep(.1)
 except BaseException as ex:error=str(ex)
 DEADLINE=origin+4800
 closure=cleanup(os.getpid(),known,min(origin+4800,mono()+10))
 rc=p.poll();remaining=discover(os.getpid(),known)
 final=dict(worker_rc=rc,worker_reaped=rc is not None,error=error,remaining=remaining,closure=closure,noninterference='NOT_PROVEN',outer_termination_independently_observed=False)
 atomic_json(root/'outer-final.json',final)
 print(json.dumps(final,separators=(',',':')))
 os.close(lockfd)
 return 0 if rc==0 and not remaining and error is None else 2

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--manifest-sha256',required=True);ap.add_argument('--worker',action='store_true');ap.add_argument('--origin',type=float);a=ap.parse_args()
 for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):signal.signal(sig,cancel)
 if a.worker:check(a.origin is not None,'ORIGIN_REQUIRED');return worker(a.manifest_sha256,a.origin)
 return outer(a.manifest_sha256)
if __name__=='__main__':
 try:sys.exit(main())
 except BaseException as ex:
  if isinstance(ex,SystemExit):raise
  print(json.dumps(dict(status='BLOCKED_NOT_PROVEN',error=type(ex).__name__+':'+str(ex),noninterference='NOT_PROVEN'),separators=(',',':')));sys.exit(2)

#include "e1_capture.h"
#include "../../src/style_runtime/typography_evidence.h"
#include "../../src/style_runtime/style_source_accounting.h"
#include <fcntl.h>
#include <unistd.h>
#include <cerrno>
#include <cstring>
#include <type_traits>
#if AETHER_DIAGNOSTIC_E1
namespace aether::diagnostic::e1 {
namespace {
struct Event { uint64_t value[5]{}; uint32_t stage=0,node=0,fixture=0,call=0; };
struct Snapshot { uint32_t offset=0,size=0,kind=0,reserved=0; };
struct Identity { const void* pointer=nullptr; uint32_t fixture=0,id=0; };
struct Storage {
 char arena[2097152]{};
 Event events[2048]{};
 Snapshot snapshots[1024]{};
 Identity identities[256]{};
 uint32_t bytes=0,events_used=0,snapshots_used=0,identities_used=0;
 uint32_t fixture_id=0,call_id=0,fixture_calls=0,flags=0,commits=0;
 uint32_t additional_events=0;
 bool active=false,fixture_open=false,setup_done=false;
};
static_assert(sizeof(Event)==56 && sizeof(Snapshot)==16 && sizeof(Identity)<=32);
static_assert(sizeof(Storage)+32768<=3145728,"all capture storage plus bounded scratch");
Storage s;
// Flags: 1 capacity, 2 lifecycle/correlation, 4 I/O. Never repairs product state.
void fail(unsigned reason) noexcept {s.flags|=reason;}
void emit(unsigned stage,uint32_t node,uint32_t call,uint64_t a=0,uint64_t b=0,uint64_t c=0,uint64_t d=0,uint64_t e=0) noexcept {
 if(stage==120||stage==130||stage==131||stage==132){if(s.additional_events>=108){fail(1);return;}++s.additional_events;}
 if(s.events_used==2048){fail(1);return;}
 s.events[s.events_used++]={{a,b,c,d,e},stage,node,s.fixture_id,call};
}
uint32_t node_id(const void* p) noexcept {
 if(!p)return 0;
 for(uint32_t i=0;i<s.identities_used;++i)if(s.identities[i].pointer==p&&s.identities[i].fixture==s.fixture_id)return s.identities[i].id;
 unsigned count=0;for(uint32_t i=0;i<s.identities_used;++i)count+=s.identities[i].fixture==s.fixture_id;
 if(count>=16||s.identities_used==256){fail(1);return 0;}
 auto& x=s.identities[s.identities_used++];x={p,s.fixture_id,s.identities_used};return x.id;
}
struct Writer {
 uint32_t start=s.bytes; bool ok=true;
 void bytes(const void* p,size_t n) noexcept {
  if(!ok)return;
  if(n>16384u-(s.bytes-start)||n>sizeof(s.arena)-s.bytes){ok=false;fail(1);return;}
  std::memcpy(s.arena+s.bytes,p,n);s.bytes+=static_cast<uint32_t>(n);
 }
 template<class T> void scalar(T v) noexcept {static_assert(std::is_trivially_copyable_v<T>);bytes(&v,sizeof(v));}
 void str(const std::string& v) noexcept {if(v.size()>16384){ok=false;fail(1);return;}scalar(uint32_t(v.size()));bytes(v.data(),v.size());}
 void cstr(const char* p) noexcept {if(!p){scalar(uint32_t(0));return;}size_t n=0;while(n<=16384&&p[n])++n;if(n>16384){ok=false;fail(1);return;}scalar(uint32_t(n));bytes(p,n);}
 uint32_t finish(uint32_t kind) noexcept {
  if(!ok||s.snapshots_used==1024){s.bytes=start;fail(1);return 0;}
  auto& d=s.snapshots[s.snapshots_used++];d={start,s.bytes-start,kind,0};return s.snapshots_used;
 }
};
void provenance(Writer& w,const aether::style::TypographyProvenance& p) noexcept {
 w.scalar(uint8_t(p.declaration));w.scalar(uint8_t(p.inherited));w.scalar(uint8_t(p.important));w.scalar(uint8_t(p.inline_style));
 w.scalar(p.layer);w.scalar(p.source_order);w.scalar(p.declaration_order);w.str(p.resolved_source);w.str(p.accepted_source);
}
uint32_t type(const aether::style::TypographyEvidence& t) noexcept {
 Writer w;
 for(const auto& b:t.break_policy.fields){w.scalar(uint8_t(b.known));w.scalar(b.computed);w.scalar(uint32_t(b.reason));provenance(w,b.provenance);w.str(b.authored_property);}
 for(const auto& p:t.provenance)provenance(w,p);
 w.scalar(uint32_t(t.family_state));w.scalar(uint32_t(t.families.size()));
 if(t.families.size()>256){w.ok=false;fail(1);}else for(const auto& f:t.families){w.str(f.name);w.scalar(uint8_t(f.generic));}
 w.scalar(uint32_t(t.style_state));w.str(t.font_style);w.scalar(uint32_t(t.spacing_state));w.scalar(uint8_t(t.spacing_normal));w.scalar(t.spacing_px);
 w.scalar(uint32_t(t.size_state));w.scalar(uint32_t(t.weight_state));w.scalar(uint32_t(t.line_height_state));w.scalar(t.size_px);w.scalar(t.weight);
 w.scalar(uint32_t(t.line_height_kind));w.scalar(t.line_height_value);w.scalar(t.line_height_used_px);w.scalar(t.size_dependencies);w.scalar(t.line_height_dependencies);
 w.scalar(uint8_t(t.coverage_complete));w.scalar(t.coverage_gaps);return w.finish(1);
}
}
void reset() noexcept { // Before product setup only. No heap allocation.
 s.bytes=s.events_used=s.snapshots_used=s.identities_used=0;s.fixture_id=s.call_id=s.fixture_calls=s.flags=s.commits=0;s.active=s.fixture_open=s.setup_done=false;s.additional_events=0;
}
bool fixture(unsigned n) noexcept {
 if(s.active||s.fixture_open||n!=s.fixture_id+1||n>2||(s.fixture_id&&s.fixture_calls!=3)){fail(2);return false;}
 s.fixture_id=n;s.fixture_calls=0;s.fixture_open=true;s.setup_done=false;emit(130,0,0);return true;
}
bool setup_complete() noexcept {
 if(!s.fixture_open||s.setup_done||s.active){fail(2);return false;}
 s.setup_done=true;emit(131,0,0);return s.flags==0;
}
bool finish_fixture() noexcept {
 if(!s.fixture_open||!s.setup_done||s.active||s.fixture_calls!=3){fail(2);return false;}
 emit(132,0,0);s.fixture_open=false;return s.flags==0;
}
bool begin_call() noexcept {
 if(s.active||!s.fixture_open||!s.setup_done||!s.fixture_id||s.fixture_calls>=3||s.call_id>=6){fail(2);return false;}
 ++s.call_id;++s.fixture_calls;s.active=true;s.commits=0;mark(100,nullptr);return true;
}
void mark(unsigned stage,const void* node,uint64_t a,uint64_t b,uint64_t c,uint64_t d,uint64_t e) noexcept {
 if(!s.active){fail(2);return;}
 emit(stage,node_id(node),s.call_id,a,b,c,d,e);
 if(stage==93&&++s.commits!=1)fail(2);
}
void typography(unsigned stage,const void* node,const aether::style::TypographyEvidence* before,const aether::style::TypographyEvidence& after) noexcept {
 if(!s.active){fail(2);return;}auto a=before?type(*before):0;auto b=type(after);mark(stage,node,a,b);
}
void accounting(unsigned stage,const void* node,const style_source_accounting_s* p,bool limited) noexcept {
 if(!s.active){fail(2);return;}
 if(!p){mark(stage,node,0,limited);return;}
 Writer w;w.scalar(uint64_t(p->source_bytes));w.scalar(uint64_t(p->declarations));w.scalar(uint64_t(p->rules));
 w.scalar(uint64_t(p->compiled_rules));w.scalar(uint64_t(p->expanded_declarations));w.scalar(uint64_t(p->compiled_bytes));
 w.scalar(p->losses);w.scalar(uint8_t(p->inputs_accounted));w.scalar(uint8_t(p->external_pending));
 auto id=w.finish(2);mark(stage,node,id,limited,p->losses!=0,!p->inputs_accounted,p->external_pending);
}
void diagnostic(const char* a,const char* b,const char* c,const char* d) noexcept {
 // Setup diagnostics are also captured with call=0, never promoted to a commit.
 if(!s.fixture_open||(!s.active&&s.setup_done)||(s.active&&s.commits!=1)){fail(2);return;}
 Writer w;w.cstr(a);w.cstr(b);w.cstr(c);w.cstr(d);auto id=w.finish(3);
 emit(110,0,s.active?s.call_id:0,id);
}
bool end_call(int count) noexcept {
 if(!s.active){fail(2);return false;}mark(101,nullptr,uint64_t(count),s.commits);
 if(count<0||s.commits!=1)fail(2);s.active=false;return s.flags==0;
}
bool dump(const char* path) noexcept {
 if(s.active||s.fixture_open||s.call_id!=6||s.fixture_id!=2||s.fixture_calls!=3)fail(2);
 // Native scalar format, magic/endian/width fields explicit. No raw Identity dump.
 uint32_t h[]={0x45314331u,1,0x01020304u,sizeof(float),sizeof(double),sizeof(int),s.flags,s.call_id,s.events_used,s.snapshots_used,s.bytes};
 int fd=::open(path,O_WRONLY|O_CREAT|O_EXCL,0600);if(fd<0){fail(4);return false;}
 auto write_all=[&](const void* data,size_t length) noexcept {
  auto* p=static_cast<const char*>(data);
  while(length){auto n=::write(fd,p,length);if(n<0&&errno==EINTR)continue;if(n<=0)return false;p+=n;length-=static_cast<size_t>(n);}return true;
 };
 bool ok=write_all(h,sizeof(h));
 ok=write_all(s.events,sizeof(Event)*s.events_used)&&ok;
 ok=write_all(s.snapshots,sizeof(Snapshot)*s.snapshots_used)&&ok;
 ok=write_all(s.arena,s.bytes)&&ok;
 if(::close(fd)!=0)ok=false;if(!ok)fail(4);return ok&&s.flags==0;
}
}
#endif

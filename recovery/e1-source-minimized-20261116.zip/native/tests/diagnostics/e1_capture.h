#pragma once
#include <cstdint>
namespace aether::style { struct TypographyEvidence; }
struct style_source_accounting_s;
#ifndef AETHER_DIAGNOSTIC_E1
#define AETHER_DIAGNOSTIC_E1 0
#endif
#if AETHER_DIAGNOSTIC_E1
namespace aether::diagnostic::e1 {
// Private experiment API. One sequential driver; no runtime ownership/storage.
__attribute__((visibility("default"))) void reset() noexcept;
__attribute__((visibility("default"))) bool fixture(unsigned) noexcept;
__attribute__((visibility("default"))) bool begin_call() noexcept;
__attribute__((visibility("default"))) bool setup_complete() noexcept;
__attribute__((visibility("default"))) bool finish_fixture() noexcept;
__attribute__((visibility("default"))) void mark(unsigned,const void*,uint64_t=0,uint64_t=0,uint64_t=0,uint64_t=0,uint64_t=0) noexcept;
__attribute__((visibility("default"))) void typography(unsigned,const void*,const aether::style::TypographyEvidence*,const aether::style::TypographyEvidence&) noexcept;
__attribute__((visibility("default"))) void accounting(unsigned,const void*,const style_source_accounting_s*,bool=false) noexcept;
__attribute__((visibility("default"))) void diagnostic(const char*,const char*,const char*,const char*) noexcept;
__attribute__((visibility("default"))) bool end_call(int) noexcept;
__attribute__((visibility("default"))) bool dump(const char*) noexcept;
}
#define E1_MARK(...) ::aether::diagnostic::e1::mark(__VA_ARGS__)
#define E1_TYPE(...) ::aether::diagnostic::e1::typography(__VA_ARGS__)
#define E1_ACCOUNT(...) ::aether::diagnostic::e1::accounting(__VA_ARGS__)
#else
#define E1_MARK(...) ((void)0)
#define E1_TYPE(...) ((void)0)
#define E1_ACCOUNT(...) ((void)0)
#endif

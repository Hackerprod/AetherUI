// Observation only. No historical test assertion is modified by this driver.
#include <aether/aether.h>
#include "diagnostics/e1_capture.h"
#include <cstdio>
namespace cap=aether::diagnostic::e1;
static void diagnostic(const char* a,const char* b,const char* c,const char* d,void*) {cap::diagnostic(a,b,c,d);}
static bool run(unsigned which) {
 if(!cap::fixture(which))return false;
 aether_doc_t doc{};aether_style_runtime_t runtime{};
 auto cleanup=[&] {if(runtime)aether_style_runtime_destroy(runtime);if(doc)aether_doc_destroy(doc);cap::finish_fixture();};
 const char* html=which==1?"<html><body><div id='parent'><div id='box'></div></div></body></html>":"<html><body><div id='p'><div id='c' class='target'><div id='g'></div></div></div></body></html>";
 if(aether_doc_create(&doc)!=AETHER_OK||aether_doc_parse_html(doc,html)!=AETHER_OK){cleanup();return false;}
 aether_style_runtime_options_t options{};aether_style_environment_t env{800,600,1,16,0,0,0};
 if(aether_style_runtime_create(&options,&env,which==1?nullptr:diagnostic,nullptr,&runtime)!=AETHER_OK){cleanup();return false;}
 int64_t sheet=0;
 auto add=[&](const char* css){return aether_style_runtime_add_stylesheet(runtime,css,which==1?2:0,which==1?"transition-pipeline.css":"transform-runtime.css",&sheet,nullptr)==AETHER_OK;};
 bool ok=which==1?add("#parent { transition: transform 0.8s ease; } #box { transition: opacity 0.7s ease-in 0.2s; transition: ;}"):
  add("#p{transform:scale(7)}#c{transform:scale(2)}")&&add("#c{transform:scale(2 3);}");
 if(!ok){cleanup();return false;}
 auto* root=aether_doc_get_document_element(doc);
 auto* target=aether_doc_get_element_by_id(doc,which==1?"box":"c");
 if(!root||!target){cleanup();return false;}
 if(!cap::setup_complete()){cleanup();return false;}
 // Exactly three calls including initialization. No mutation, destruction or new
 // nodes inside this fixture lifetime; id=(fixture,node ordinal), never address.
 for(unsigned i=0;i<3;++i){
  if(!cap::begin_call()){cleanup();return false;}
  cap::mark(102,target,i);
  aether_style_update_t* updates=nullptr;
  const int count=aether_style_runtime_resolve_subtree(runtime,root,&updates);
  // Legacy API has no out_revision. Count=0 alone never proves successful commit.
  // end_call requires exactly one matching D9c, even for a zero-update result.
  bool public_ok=count>=0;
  for(int j=0;j<count;++j){
   aether_node_t node{};aether_computed_style_handle_t handle{};uint32_t impact=0;
   auto status=aether_style_runtime_get_update(updates[j],&node,&handle,&impact);
   cap::mark(103,node,j,impact,status);public_ok=public_ok&&status==AETHER_OK;
   if(handle)aether_computed_style_handle_destroy(handle);
  }
  aether_style_updates_free(updates,count);
  bool captured=cap::end_call(count);
  if(!captured||!public_ok){cleanup();return false;}
 }
 cleanup();return true;
}
int main(int argc,char** argv){
 if(argc!=2){std::fputs("usage: aether_typography_e1_capture OUTPUT.bin\n",stderr);return 64;}
 cap::reset();bool ok=run(1);if(ok)ok=run(2);bool saved=cap::dump(argv[1]);
 std::puts(ok&&saved?"E1_CAPTURE_WRITTEN_NOT_PRODUCT_PASS":"E1_CAPTURE_INCOMPLETE_NOT_PROVEN");return ok&&saved?0:2;
}

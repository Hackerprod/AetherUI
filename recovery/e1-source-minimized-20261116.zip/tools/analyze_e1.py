#!/usr/bin/env python3
"""Private raw oracle, NOT RUN. No synthesized accounting and no product verdict.
Read only one bounded binary, print compact differences, never repeat full slots.
This initial reader supports the explicitly identified little-endian ABI only.
"""
import json,struct,sys
from pathlib import Path
MAX=3145728
p=Path(sys.argv[1])
if p.stat().st_size>MAX: raise ValueError('CAPTURE_QUOTA')
data=p.read_bytes()
def require(x,why):
 if not x: raise ValueError(why)
require(len(data)>=44,'HEADER_MISSING')
h=struct.unpack_from('<11I',data)
magic,version,endian,fs,ds,ints,flags,calls,ne,ns,nb=h
require((magic,version,endian,fs,ds,ints)==(0x45314331,1,0x01020304,4,8,4),'UNSUPPORTED_ABI')
require(flags==0 and calls==6 and ne<=2048 and ns<=1024 and nb<=2097152,'INCOMPLETE_HEADER')
require(len(data)==44+ne*56+ns*16+nb,'FILE_LENGTH')
events=[];pos=44
for i in range(ne):
 v=struct.unpack_from('<5Q4I',data,pos);pos+=56
 events.append(dict(value=v[:5],stage=v[5],node=v[6],fixture=v[7],call=v[8]))
desc=[]
for i in range(ns): desc.append(struct.unpack_from('<4I',data,pos));pos+=16
arena=memoryview(data)[pos:]
class Reader:
 def __init__(self,b): self.b=b; self.p=0
 def take(self,n):
  require(self.p+n<=len(self.b),'SNAPSHOT_TRUNCATED');v=self.b[self.p:self.p+n];self.p+=n;return v
 def scalar(self,f): return struct.unpack('<'+f,self.take(struct.calcsize('<'+f)))[0]
 def text(self):
  n=self.scalar('I');require(n<=16384,'STRING_QUOTA');return bytes(self.take(n)).hex()
 def bits(self,n): return bytes(self.take(n)).hex()
def provenance(r):
 d={k:r.scalar('B') for k in ('declaration','inherited','important','inline_style')}
 d.update({k:r.scalar('i') for k in ('layer','source_order','declaration_order')})
 d.update({k:r.text() for k in ('resolved_source','accepted_source')});return d
cache={}
def snapshot(index,kind):
 require(index>0 and index<=ns,'MISSING_SNAPSHOT')
 if index in cache:
  require(desc[index-1][2]==kind,'KIND');return cache[index]
 off,n,k,res=desc[index-1];require(k==kind and n<=16384 and off+n<=nb and res==0,'DESCRIPTOR')
 r=Reader(arena[off:off+n]);d={}
 if kind==2:
  d={k:r.scalar('Q') for k in ('source_bytes','declarations','rules','compiled_rules','expanded_declarations','compiled_bytes')}
  d.update(losses=r.scalar('I'),inputs_accounted=r.scalar('B'),external_pending=r.scalar('B'))
 elif kind==1:
  breaks=[]
  for i in range(2):
   b=dict(known=r.scalar('B'),computed=r.scalar('i'),reason=r.scalar('I'));b['provenance']=provenance(r);b['authored_property']=r.text();breaks.append(b)
  d['break_policy']=breaks;d['provenance']=[provenance(r) for _ in range(6)]
  d['family_state']=r.scalar('I');count=r.scalar('I');require(count<=256,'FAMILIES')
  d['families']=[dict(name=r.text(),generic=r.scalar('B')) for _ in range(count)]
  d['style_state']=r.scalar('I');d['font_style']=r.text();d['spacing_state']=r.scalar('I');d['spacing_normal']=r.scalar('B');d['spacing_px_bits']=r.bits(8)
  for k in ('size_state','weight_state','line_height_state'):d[k]=r.scalar('I')
  d['size_px_bits']=r.bits(4);d['weight']=r.scalar('i');d['line_height_kind']=r.scalar('I')
  d['line_height_value_bits']=r.bits(4);d['line_height_used_px_bits']=r.bits(4)
  d['size_dependencies']=r.scalar('I');d['line_height_dependencies']=r.scalar('I');d['coverage_complete']=r.scalar('B');d['coverage_gaps']=r.scalar('I')
 elif kind==3:
  d={k:r.text() for k in ('code','property','value','message')}
 else: raise ValueError('UNEXPECTED_SNAPSHOT_KIND')
 require(r.p==n,'UNCONSUMED_SNAPSHOT')
 def bools(obj):
  if isinstance(obj,dict):
   for key,val in obj.items():
    if key in ('declaration','inherited','important','inline_style','known','generic','spacing_normal','coverage_complete','inputs_accounted','external_pending'):require(val in (0,1),'INVALID_BOOLEAN')
    if key in ('family_state','style_state','spacing_state','size_state','weight_state','line_height_state','line_height_kind'):require(val in (0,1,2),'INVALID_ENUM')
    if key=='reason':require(val in range(5),'INVALID_REASON')
    bools(val)
  elif isinstance(obj,list):
   for val in obj:bools(val)
 bools(d);cache[index]=d;return d

def diff(a,b,path=''):
 if isinstance(a,dict) and isinstance(b,dict):
  out=[]
  for k in a.keys()|b.keys():out+=diff(a.get(k),b.get(k),path+'.'+k)
  return out
 if isinstance(a,list) and isinstance(b,list) and len(a)==len(b):
  return [x for i,(aa,bb) in enumerate(zip(a,b)) for x in diff(aa,bb,path+f'[{i}]')]
 return [] if a==b else [dict(field=path,previous=a,current=b)]
# Full descriptor/arena coverage, including callbacks, before semantic comparison.
offset=0
for i,(off,n,k,res) in enumerate(desc,1):
 require(off==offset and 0<n<=16384 and k in (1,2,3) and res==0,'ARENA_DESCRIPTOR_COVERAGE')
 snapshot(i,k);offset+=n
require(offset==nb,'ARENA_ORPHAN_BYTES')
# Each descriptor is written once and referenced by exactly one event field.
# Repeated *content* is allowed; repeated descriptor refs are not.
refs=[0]*(ns+1)
reference_schema={2:((0,1,True),(1,1,False)),3:((0,1,True),(1,1,False)),6:((0,1,False),(1,1,False)),7:((0,1,False),(1,1,False)),96:((1,1,False),),25:((0,2,True),),5:((0,2,False),),75:((0,2,False),),95:((0,2,False),),110:((0,3,False),)}
used_fields={0:5,1:5,2:2,22:1,25:5,3:2,40:1,4:4,5:5,6:2,7:2,75:5,8:4,90:2,91:2,93:5,95:5,96:2,100:0,101:2,102:1,103:3,110:1,120:3,130:0,131:0,132:0}
zero_nodes={90,91,93,100,101,110,130,131,132}
for e in events:
 stage=e['stage'];v=e['value']
 require(stage in used_fields,'UNKNOWN_STAGE')
 require(all(x==0 for x in v[used_fields[stage]:]),'RESERVED_EVENT_VALUES')
 require((e['node']==0)==(stage in zero_nodes),'EVENT_NODE_SHAPE')
 if stage==96:require(v[0]==0,'FINAL_PREVIOUS_RESERVED')
 for field,kind,nullable in reference_schema.get(stage,()):
  ref=v[field]
  if nullable and ref==0:continue
  require(0<ref<=ns and desc[ref-1][2]==kind,'REFERENCE_KIND_OR_RANGE');refs[ref]+=1
 if stage in (1,4):require(all(x in (0,1) for x in v[2:]),'DIFF_BOOLEAN')
 if stage in (22,40):require(v[0] in (0,1),'BRANCH_BOOLEAN')
 if stage in (25,5,75,95):require(all(x in (0,1) for x in v[1:]),'ACCOUNT_EVENT_BOOLEAN')
 if stage==8:require(v[1] in (0,1),'UPDATE_BOOLEAN')
 if stage==120:require(v[2]==0,'GENERATED_NODE_FORBIDDEN')
require(all(n==1 for n in refs[1:]),'DESCRIPTOR_REFERENCE_NOT_UNIQUE_OR_ORPHAN')
require(sum(e['stage'] in (120,130,131,132) for e in events)<=108,'ADDITIONAL_EVENT_QUOTA')

# Exact grammar consumes every event once; no filtering can hide orphan events.
cursor=0
current_fixture=0
current_call=0
def peek():return events[cursor]['stage'] if cursor<len(events) else None
def take(stage,call,node=None):
 global cursor
 require(cursor<len(events),'EVENT_MISSING')
 e=events[cursor];cursor+=1
 require(e['stage']==stage,'EVENT_ORDER_'+str(stage))
 require(e['fixture']==current_fixture and e['call']==call,'EVENT_FIXTURE_CALL')
 if node is not None:require(e['node']==node,'EVENT_NODE_PAIR')
 return e
def val(e):return e['value']
def account(e):
 v=val(e)
 if not v[0]:
  require(v==(0,0,0,0,0),'NULL_ACCOUNT_OPERANDS');return None
 a=snapshot(v[0],2)
 require(v[2:]==(int(bool(a['losses'])),int(not a['inputs_accounted']),a['external_pending']),'PREDICATE_OPERANDS')
 return a
def plus_one(v):
 require(v<(1<<64)-1,'EPOCH_INCREMENT_OVERFLOW');return v+1
rows=[];prior={};seen_ids=set()
for fixture in (1,2):
 current_fixture=fixture
 take(130,0)
 while peek()==110:take(110,0)
 take(131,0)
 previous_stamp=None;fixture_nodes=None;fixture_document=None;fixture_target=None
 expected_n=4 if fixture==1 else 5
 for repeat in range(3):
  current_call+=1;call=current_call
  take(100,call)
  target=take(102,call);require(val(target)[0]==repeat,'TARGET_REPEAT')
  d0=take(0,call);base=val(d0)
  if fixture_document is None:fixture_document=d0['node'];fixture_target=target['node']
  require(d0['node']==fixture_document and target['node']==fixture_target,'FIXTURE_DOCUMENT_TARGET')
  pre_nodes={}
  for _ in range(expected_n):
   one=take(1,call);node=one['node'];require(node not in pre_nodes,'DUPLICATE_PREPARATION_NODE')
   two=take(2,call,node);discard=take(22,call,node);old_ac=take(25,call,node);three=take(3,call,node);branch=take(40,call,node);four=take(4,call,node)
   require(val(one)[4]==(1 if repeat==0 else 0),'NEW_NODE_FLAG')
   require(bool(val(two)[0])==bool(val(three)[0])==(repeat!=0),'PREVIOUS_PRESENCE')
   before=snapshot(val(three)[0],1) if val(three)[0] else None
   if before is not None:require(before==snapshot(val(two)[0],1),'PREVIOUS_OPERAND_CHANGED')
   pre=snapshot(val(two)[1],1);prepared=snapshot(val(three)[1],1)
   # Model the exact existing discard operation from TypographyEvidence{};
   # break-policy survives, then computed slots are assigned independently.
   if val(discard)[0]:
    zprov=dict(declaration=0,inherited=0,important=0,inline_style=0,layer=0,source_order=0,declaration_order=0,resolved_source='',accepted_source='')
    a=dict(break_policy=pre['break_policy'],provenance=[dict(zprov) for _ in range(6)],family_state=0,families=[],style_state=0,font_style='',spacing_state=0,spacing_normal=0,spacing_px_bits='00'*8,size_state=0,weight_state=0,line_height_state=0,size_px_bits='00'*4,weight=0,line_height_kind=0,line_height_value_bits='00'*4,line_height_used_px_bits='00'*4,size_dependencies=0,line_height_dependencies=0,coverage_complete=0,coverage_gaps=3)
   else:a=dict(pre)
   b=dict(prepared);a['break_policy']=[dict(x) for x in a['break_policy']];b['break_policy']=[dict(x) for x in prepared['break_policy']]
   for x in a['break_policy']+b['break_policy']:x.pop('computed')
   require(a==b,'PRE_POST_DISCARD_FIELDS')
   require(val(branch)[0]==int(repeat!=0 and before!=prepared),'COMPARATOR_BRANCH')
   require(val(four)[0]==(val(one)[0]|(19 if val(branch)[0] else 0)),'OWN_OR')
   require(val(four)[1]==(val(one)[1]|(19 if val(branch)[0] else 0)),'INHERITED_OR')
   require(val(one)[2:4]==val(four)[2:4],'DIFF_FLAGS_CHANGED')
   pre_nodes[node]=dict(one=one,four=four,prepared=prepared,before=before,old_account=account(old_ac))
  order=[]
  for index in range(expected_n):
   e=take(120,call);require(val(e)==(index,expected_n,0,0,0),'ORDER_MANIFEST')
   require(e['node'] not in order,'DUPLICATE_ORDER_NODE');order.append(e['node'])
  require(set(order)==set(pre_nodes) and target['node'] in order,'NODE_SET_PREPARATION')
  require(fixture_document not in order,'DOCUMENT_STYLED_UNEXPECTEDLY')
  if fixture_nodes is None:
   fixture_nodes=set(order);ids=fixture_nodes|{fixture_document}
   require(not(ids&seen_ids),'IDENTITY_REUSED_ACROSS_FIXTURES');seen_ids|=ids
  require(set(order)==fixture_nodes,'NODE_SET_CONTINUITY')
  d5=take(5,call,fixture_document);final_account=account(d5)
  finals={}
  for node in order:
   six=take(6,call,node);seven=take(7,call,node);a75=take(75,call,node)
   prepared=pre_nodes[node]['prepared']
   require(prepared==snapshot(val(six)[0],1)==snapshot(val(six)[1],1)==snapshot(val(seven)[0],1),'PREPARED_STAGE_MISMATCH')
   require(account(a75)==final_account,'ACCOUNTING_RAW_CANDIDATE')
   expect=dict(prepared);expect['coverage_gaps']=prepared['coverage_gaps']|(4 if final_account['losses'] or not final_account['inputs_accounted'] else 0)
   final=snapshot(val(seven)[1],1);require(final==expect,'PUBLICATION_EVIDENCE')
   finals[node]=final
  entries={}
  for node in order:
   eight=take(8,call,node);require(val(eight)[0]==val(pre_nodes[node]['four'])[0],'ENTRY_IMPACT')
   require(val(eight)[1]==int(val(eight)[0]!=0),'ENTRY_UPDATE_FLAG');entries[node]=eight
  prep=take(90,call);require(val(prep)==(6,0,0,0,0),'PREPARE_NOT_SUCCESS')
  commit=take(93,call);stamp=val(commit)
  require(stamp==(plus_one(base[0]),base[2],base[4],plus_one(base[3]),base[1]),'D0_D9_STAMPS')
  for eight in entries.values():require(val(eight)[2:4]==(stamp[0],stamp[3]),'D8_D9_STAMPS')
  if previous_stamp is not None:
   require(base==(previous_stamp[0],previous_stamp[4],previous_stamp[1],previous_stamp[3],previous_stamp[2]),'GENERATION_EPOCH_CONTINUITY')
  # runtime->states is unordered: require adjacent 95/96 pairs, exact set,
  # but never require iteration order to equal prepare_tree's order.
  published_nodes=set()
  for _ in range(expected_n):
   a95=take(95,call);node=a95['node'];require(node in finals and node not in published_nodes,'PUBLISHED_NODE_SET')
   p96=take(96,call,node);require(account(a95)==final_account,'ACCOUNTING_RAW_PUBLISHED')
   require(snapshot(val(p96)[1],1)==finals[node],'FINAL_RECORD_MISMATCH');published_nodes.add(node)
  require(published_nodes==set(order),'PUBLISHED_NODES_MISSING')
  while peek()==110:take(110,call)
  public={}
  while peek()==103:
   e=take(103,call);v=val(e);node=e['node']
   require(v[0]==len(public) and v[2]==0 and node in entries and node not in public,'PUBLIC_ENTRY')
   require(v[1]==val(entries[node])[0],'PUBLIC_IMPACT');public[node]=v[1]
  require(set(public)=={n for n,e in entries.items() if val(e)[1]},'PUBLIC_UPDATE_SET')
  end=take(101,call);require(val(end)==(len(public),1,0,0,0),'LEGACY_COUNT_COMMIT')
  pending={}
  for node in order:
   n=pre_nodes[node];previous=prior.get((fixture,node))
   require((previous is None)==(repeat==0),'PREVIOUS_CHAIN_PRESENCE')
   if previous:
    require(previous['stamp']==previous_stamp and previous['final']==n['before'] and previous['accounting']==n['old_account'],'PRIOR_PUBLICATION_LINK')
   else:require(n['before'] is None and n['old_account'] is None,'INITIAL_PREVIOUS_NOT_ABSENT')
   rows.append(dict(fixture=fixture,call=call,node=node,base=val(n['one'])[:2],after=val(n['four'])[:2],Pprev_missing=previous is None,prepared_diff=diff(previous['prepared'],n['prepared']) if previous else None,heterogeneous_diff=diff(n['before'],n['prepared']) if n['before'] else None,accounting_diff=diff(n['old_account'],final_account) if n['old_account'] else None,raw_accounting=final_account))
   pending[(fixture,node)]=dict(prepared=n['prepared'],final=finals[node],accounting=final_account,stamp=stamp)
  # Nothing becomes eligible as Pprev until the entire call has validated.
  prior.update(pending);previous_stamp=stamp
 take(132,0)
require(cursor==len(events),'ORPHAN_EVENTS')
report=json.dumps(dict(status='CAPTURE_ORACLE_VALID_NOT_PRODUCT_PASS',rows=rows),ensure_ascii=True,separators=(',',':'))
require(len(report.encode())<=262144,'SUMMARY_QUOTA')
print(report)

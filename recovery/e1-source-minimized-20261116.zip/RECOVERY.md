# Isolated typography diagnostic source snapshot

Includes five isolated native source/build-definition changes, their source patch, a binary-capture analyzer and an execution-adapter template. This is technical source recovery, not an executable bundle or proof of behavioral validity.

The native overlay is not a full repository. Restore against the matching baseline source tree and verify the patch before applying. The patch is diagnostic-only; its private CMake option is OFF by default. No integration or product acceptance is implied.

The adapter's interpreter location is replaced by /RELOCATE/python3. Its original recipes, authority records, environment observations, process/session data and internal reviews are deliberately absent. Reconstruct local configuration and independently review and validate before use. Do not run this template merely because it is archived. The analyzer supports only its explicitly checked binary ABI and is not a product verdict.

All included source bytes except the documented interpreter-path replacement are preserved. Packaging checks cover stable reads, archive integrity, source hashes and Python syntax only. No build, diagnostic execution or assertion of test success is included.

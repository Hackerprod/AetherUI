import pathlib,subprocess,json,hashlib,re,sys
O=pathlib.Path(__file__).parent;B=O/'default';reports={}
def call(name,args):
 p=subprocess.run(list(map(str,args)),capture_output=True)
 (O/(name+'.stdout')).write_bytes(p.stdout);(O/(name+'.stderr')).write_bytes(p.stderr)
 (O/(name+'.json')).write_text(json.dumps(dict(argv=list(map(str,args)),rc=p.returncode),indent=2)+'\n');assert p.returncode==0,name
 return p.stdout.decode()
def symbols(s):
 return {r[0]:r[1] for line in s.splitlines() if len(r:=line.split())>=2 and len(r[1])==1}
def abi_names(s):return {name for name,typ in symbols(s).items() if name.startswith('aether_') and typ not in ('U','u','w','v')}
archive=B/'libaether_hit_oom_private.a';members=call('abi-support-members',['ar','t',archive]).splitlines();assert sorted(members)==['frozen_style.cpp.o','stacking.cpp.o','style_lookup_box.cpp.o'],members
support=call('abi-support-nm',['nm','-P','--defined-only',archive]);support_syms=symbols(support)
assert not abi_names(support),abi_names(support)
allocation_replacements={'_Znwm','_Znam','_ZdlPv','_ZdaPv','_ZdlPvm','_ZdaPvm','_ZnwmRKSt9nothrow_t','_ZnamRKSt9nothrow_t'}
assert not (set(support_syms)&allocation_replacements)
reports['support']=dict(members=members,defined_abi_c=sorted(abi_names(support)),defined_allocation_replacements=sorted(set(support_syms)&allocation_replacements),sha256=hashlib.sha256(archive.read_bytes()).hexdigest())
new_dso=B/'libaether_core.so.0.1.0';old_dso=O.parent/'drawing-cmake-validation-C-20261116-02/default/libaether_core.so.0.1.0'
new_exports=call('abi-core-new-dynamic',['nm','-D','-P','--defined-only',new_dso]);old_exports=call('abi-core-prior-dynamic',['nm','-D','-P','--defined-only',old_dso]);assert abi_names(new_exports)==abi_names(old_exports)
private_need=['aether::layout::StyleLookup::lookup_box(','aether::style::ComputedStyleReadView::transforms()','aether::stacking::classify_element_paint(aether::style::StyleScalars const&)','aether::stacking::stable_sort_stack_items(']
new_core_all=call('abi-core-new-all',['nm','-C',new_dso]);new_core_dynamic_dem=call('abi-core-new-dynamic-demangled',['nm','-D','-C',new_dso])
for needle in private_need:
 assert any(needle in line and re.search(r'\bt\b',line) for line in new_core_all.splitlines()),needle
 assert needle not in new_core_dynamic_dem,needle
for name in ['aether_inline_hanging_oom_test','aether_inline_units_oom_test']:
 binary=B/name;raw=call('abi-'+name+'-dynamic',['nm','-D','-P',binary]);syms=symbols(raw)
 allraw=call('abi-'+name+'-all',['nm','-P',binary]);allsyms=symbols(allraw)
 dem=call('abi-'+name+'-demangled',['nm','-C',binary]);needed=call('abi-'+name+'-elf',['readelf','-d',binary])
 assert 'Shared library: [libaether_core.so.0]' in needed
 assert not abi_names(raw),abi_names(raw)
 for symbol in ['aether_layout_layout','aether_layout_result_destroy','aether_display_list_build']:
  assert syms.get(symbol)=='U',(name,symbol,syms.get(symbol))
 for symbol in ['aether_layout_layout','aether_layout_result_destroy','aether_layout_clone_snapshot','aether_display_list_build']:
  assert allsyms.get(symbol) in (None,'U'),(name,symbol,allsyms.get(symbol))
 for symbol in ['_Znwm','_Znam']:assert syms.get(symbol)=='T',(name,symbol,syms.get(symbol))
 for needle in private_need:assert any(needle in line and re.search(r'\b[tT]\b',line) for line in dem.splitlines()),(name,needle)
 link=(B/'CMakeFiles'/(name+'.dir')/'link.txt').read_text();assert 'libaether_hit_oom_private.a' in link and 'libaether_core.so' in link
 assert all(x not in link for x in ['aether_core.dir/','aether_flex_text_test_core.dir/','layout_box.cpp.o','libaether_core.a'])
 reports[name]=dict(sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),required_abi_imports={s:syms.get(s) for s in ['aether_layout_layout','aether_layout_result_destroy','aether_display_list_build']},new_replacements={s:syms.get(s) for s in ['_Znwm','_Znam']},private_symbols_resolved=True,needed_core=True,link_command=link)
reports['state']='PASS_STATIC_ABI_INTERPOSITION_PREREQUISITES';reports['runtime_note']='No runtime claim yet; OOM CTest still required.'
(O/'abi-gate-report.json').write_text(json.dumps(reports,indent=2)+'\n');print(json.dumps(reports,indent=2))

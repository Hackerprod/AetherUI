import pathlib,subprocess,json,hashlib,shutil,sys,time,os
R=pathlib.Path('/workspace/scratch/2ac40fb4b2af'); S=R/'aetherui-drawing-integration-C-20261116-01'; O=pathlib.Path(__file__).parent; BIN=R/'tooling-cmake-20261116/install/cmake/data/bin'
os.environ['GIT_OPTIONAL_LOCKS']='0'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,x): (O/n).write_text(json.dumps(x,indent=2)+'\n')
def run(n,args,expected=0):
 t=time.time();args=list(map(str,args));print(n,flush=True)
 with (O/(n+'.stdout')).open('wb') as out,(O/(n+'.stderr')).open('wb') as err:
  p=subprocess.run(args,stdout=out,stderr=err,cwd=S)
 write(n+'.json',dict(argv=args,cwd=str(S),rc=p.returncode,start=t,end=time.time(),expected=expected))
 if (expected==0 and p.returncode!=0) or (expected=='nonzero' and p.returncode==0):
  write('STOP.json',dict(stage=n,rc=p.returncode));sys.exit(1)
 return p.returncode
def git(*a):return subprocess.check_output(['git','--no-optional-locks',*a],cwd=S)
def custody(label):
 patch=git('diff','--binary');(O/(label+'.patch')).write_bytes(patch)
 status=git('status','--porcelain=v1','-uall');(O/(label+'.status')).write_bytes(status)
 h=json.loads((R/'drawing-cmake-lookup-correction-C-20261116-01/after.changed-files.sha256.json').read_text())
 actual={k:sha(S/k) for k in h};write(label+'.changed.json',actual)
 d=dict(head=git('rev-parse','HEAD').decode().strip(),branch=git('branch','--show-current').decode().strip(),patch_sha256=hashlib.sha256(patch).hexdigest(),index_sha256=sha(S/'.git/index'),status_entries=len(status.splitlines()),cached_bytes=len(git('diff','--cached','--binary')),changed_match=actual==h)
 write(label+'.json',d)
 assert d['head']=='22fba13df2dc7775d4e091dac432c3e4b2960c46' and d['branch']=='local/drawing-exact-v3' and d['status_entries']==63 and d['changed_match'] and d['patch_sha256']=='e9be892505ebd453c5a6867cc9dbc241d33e593afd2e10c07690a34ed5c5387a' and d['index_sha256']=='be7b51333cf41b08f39b6a73c21f8a933daa45cece43b42595cc9f7bc3b49361'
if sys.argv[1]=='g0':
 custody('before');write('native-sources-references.sha256.json',{str(p.relative_to(S)):sha(p) for p in sorted((S/'native').rglob('*')) if p.is_file()})
 refs=['dictamen-delta-lookup-oom-G1-cmake-v3-D-20261116.md','propuesta-extraccion-lookup-oom-G1-cmake-v3-C-20261116.md','acta-materializacion-lookup-oom-G1-cmake-v3-C-20261116.md','dictamen-delta-includes-G1-cmake-v3-v2-D-20261116.md','propuesta-correccion-includes-G1-cmake-v3-v2-C-20261116.md','acta-materializacion-includes-G1-cmake-v3-v2-C-20261116.md','plan-validacion-cmake-integracion-v3-A-20261116.md','dictamen-plan-validacion-cmake-integracion-v3-B-20261116.md','dictamen-G0-validacion-cmake-integracion-v3-D-20261116.md','plan-integracion-local-dibujo-v3-A-20261116.md','dictamen-integracion-local-dibujo-v3-D-20261116.md','dictamen-controles-scripts-integracion-v3-D-20261116.md']
 write('documents.sha256.json',{n:sha(R/n) for n in refs})
 tools={n:pathlib.Path(shutil.which(n)).resolve() for n in ['cc','c++','python3','make']};tools.update(cmake=BIN/'cmake',ctest=BIN/'ctest')
 write('tools.sha256.json',{n:dict(path=str(p),sha256=sha(p)) for n,p in tools.items()})
 for n,p in tools.items():run('version-'+n,[p,'--version'])
elif sys.argv[1] in ['default-build','drawing']:
 for mode in (['default'] if sys.argv[1]=='default-build' else ['off','on']):
  dest=O/mode; assert not dest.exists()
  args=[BIN/'cmake','-S',S/'native','-B',dest,'-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DAETHERUI_BUILD_TESTS=ON']
  if mode!='default': args+=['-DAETHER_BUILD_DRAWING_EXAMPLE=ON','-DAETHER_EXPERIMENTAL_IMAGE_EXACT_LATTICE='+mode.upper()]
  run(mode+'-configure',args)
  run(mode+'-consumer-gate',[sys.executable,O/'consumer_gate.py',mode])
  build=[BIN/'cmake','--build',dest,'--parallel','2','--verbose']
  if mode!='default':
   build+=['--target','aether_drawing_demo','aether_drawing_contract_v1','aether_drawing_no128']
   if mode=='on':build+=['aether_drawing_contract_v2','aether_drawing_contract_v3','aether_drawing_unit_v3','aether_drawing_count_v3']
  run(mode+'-build',build)
  if mode=='default':
   custody('after-default-build');sys.exit(0)
  args=[BIN/'ctest','--test-dir',dest]
  if mode!='default':args+=['-R','^drawing\\.']
  run(mode+'-inventory',args+['--show-only=json-v1'])
  inventory=json.loads((O/(mode+'-inventory.stdout')).read_text()); assert len(inventory['tests'])>0
  if mode!='default':
   names={t['name'] for t in inventory['tests']};expected={'drawing.demo-F','drawing.no128-selector','drawing.contract-v'+('1' if mode=='off' else '3')}
   if mode=='on':expected|={'drawing.unit-v3','drawing.count-v3'}
   assert names==expected,(names,expected)
  run(mode+'-ctest',args+['--output-on-failure'])
 custody('after-g1')

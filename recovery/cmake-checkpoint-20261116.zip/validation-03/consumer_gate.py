from pathlib import Path
import json,re,sys,collections
O=Path(__file__).parent;mode=sys.argv[1];rows=json.loads((O/mode/'compile_commands.json').read_text());groups=collections.defaultdict(list)
for r in rows:groups[re.search(r'CMakeFiles/([^/]+)\.dir/',r['command']).group(1)].append(r['file'])
old=json.loads((O.parent/'drawing-cmake-validation-C-20261116-02/default/compile_commands.json').read_text());expected={re.search(r'CMakeFiles/([^/]+)\.dir/',r['command']).group(1) for r in old if r['file'].endswith('/src/layout/layout_box.cpp')};assert len(expected)==13
if mode!='default':expected.add('aether_drawing_private')
actual={t for t,files in groups.items() if any(f.endswith('/src/layout/layout_box.cpp') for f in files)};assert actual==expected,(actual,expected)
for t in expected:assert sum(f.endswith('/src/layout/style_lookup_box.cpp') for f in groups[t])==1,t
support=groups['aether_hit_oom_private'];assert len(support)==3 and {f.split('/native/')[1] for f in support}=={'src/layout/style_lookup_box.cpp','src/css/frozen_style.cpp','src/rendering/stacking.cpp'}
report=dict(state='PASS_STATIC_CONSUMER_GATE',mode=mode,layout_targets=sorted(expected),support_sources=support)
(O/(mode+'-consumer-gate-report.json')).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

# Same-stage test copy-initialization correction

Source-only incremental recovery: one test file and its repository-relative patch. Restore against the exact before hash in SOURCE_HASHES.json. Apply candidate.patch from repository root, or replace the named file; verify the after hash. No other source change is included.

The test creates a separate missing_inputs object by copy initialization instead of assigning to the previously altered missing object. This preserves separate checks for missing prepared evidence and missing inputs. No product code or expected assertion is changed.

This archive contains no execution evidence or claim that compilation/tests pass. Packaging checks cover stable bytes, hashes, patch restoration and archive integrity only. No private records, internal paths, environment/session data, logs or binaries are included. The file is not a complete repository; restore the earlier matching C3 sources separately.

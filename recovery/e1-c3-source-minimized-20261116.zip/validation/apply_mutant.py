#!/usr/bin/env python3
"""Materialize exactly one reviewed recipe in a NEW copy. Does not build/run.
Requires explicit per-mutant approved materialization plan and exact source hash.
"""
import argparse,hashlib,json,pathlib,shutil
p=argparse.ArgumentParser();p.add_argument('--approved-plan',required=True);p.add_argument('--recipes',required=True);p.add_argument('--mutant',required=True);p.add_argument('--source',required=True);p.add_argument('--output',required=True);a=p.parse_args()
plan=json.loads(pathlib.Path(a.approved_plan).read_text());assert plan['approval_reference']
assert plan['review_status']=='APPROVED_FOR_MATERIALIZATION' and a.mutant in plan['allowed_mutants']
recipes=json.loads(pathlib.Path(a.recipes).read_text());recipe=next(x for x in recipes['mutants'] if x['id']==a.mutant)
assert recipe['status']=='IMPLEMENTED_NOT_RUN','manual recipe requires further implementation/review'
source=pathlib.Path(a.source).resolve();output=pathlib.Path(a.output).resolve()
assert source.is_dir() and not output.exists() and source not in output.parents and output not in source.parents
edits={}
for edit in recipe['edits']:
    rel=pathlib.Path(edit['path']);assert not rel.is_absolute() and '..' not in rel.parts
    file=source/rel;raw=file.read_bytes();assert hashlib.sha256(raw).hexdigest()==plan['source_hashes'][str(rel)]
    text=edits.get(str(rel),raw.decode());assert text.count(edit['old'])==edit['count']
    edits[str(rel)]=text.replace(edit['old'],edit['new'])
shutil.copytree(source,output,symlinks=False)
for rel,text in edits.items():(output/rel).write_text(text)

# Evidence files are siblings, not inside the hashed source tree (no recursive
# self-hash or unlisted receipt file in the build's source closure).
def source_manifest(root):
    return {'schema':'aether-source-tree-v1','root':str(root),
            'files':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest()
                     for p in sorted(root.rglob('*')) if p.is_file()}}
def write_new(path,data):
    assert not path.exists()
    path.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
    return hashlib.sha256(path.read_bytes()).hexdigest()
base_manifest=output.parent/(output.name+'.base-source.json')
mutant_manifest=output.parent/(output.name+'.mutant-source.json')
receipt=output.parent/(output.name+'.materialization.json')
base_sha=write_new(base_manifest,source_manifest(source))
mutant_sha=write_new(mutant_manifest,source_manifest(output))
write_new(receipt,{'schema':'aether-materialization-v1','mutant':a.mutant,
    'recipes_sha256':hashlib.sha256(pathlib.Path(a.recipes).read_bytes()).hexdigest(),
    'base_source_manifest_sha256':base_sha,'mutated_source_manifest_sha256':mutant_sha,
    'base_source_manifest':str(base_manifest),'mutated_source_manifest':str(mutant_manifest),
    'bindings':recipe['bindings'],'status':'NOT_BUILT_NOT_RUN'})

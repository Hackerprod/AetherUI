#!/usr/bin/env python3
"""Offline, fail-closed consistency checker. Does not run builds/tests/mutants.
Receipts must come from the approved trusted supervisor; JSON cannot authenticate
its author. Hash validation binds the files, never fabricates missing evidence.
"""
import argparse, hashlib, json, pathlib, sys
PFX='AETHER_ASSERT_V1'
def sha(p): return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def load(p): return json.loads(pathlib.Path(p).read_text())
def require(v,m):
    if not v: raise ValueError(m)
def artifact(a):
    p=pathlib.Path(a['path']).resolve();require(p.is_file(),'missing artifact '+str(p));require(sha(p)==a['sha256'],'hash mismatch '+str(p));return p

def inspect_receipt(path,case,variant,mutant,recipe_sha,target):
    run=load(path);require(run['schema']=='aether-mutation-run-v1','run schema')
    require(run['supervisor_reference'] and run['approval_reference'],'missing trusted-supervisor/approval references')
    build_path=artifact(run['build_receipt']);build=load(build_path)
    require(build['schema']=='aether-mutation-build-v1' and build['exit_code']==0,'build not successful')
    require(build['variant']==variant and build['mutant']==mutant,'wrong build variant')
    require(build['target']==target,'wrong test target')
    require(build['recipes_sha256']==recipe_sha,'recipe mismatch')
    artifact(build['build_log']);artifact(build['compile_commands'])
    binary=artifact(build['binary']);require(run['binary_sha256']==sha(binary),'run binary mismatch')
    require(run['argv'] and pathlib.Path(run['argv'][0]).resolve()==binary,'wrong executable argv')
    require(run['environment']['AETHER_ASSERT_CASE']==case,'wrong selected case')
    manifest=load(artifact(build['source_manifest']));root=pathlib.Path(manifest['root']).resolve()
    require(manifest['schema']=='aether-source-tree-v1' and manifest['files'],'missing source closure')
    actual={str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file()}
    require(actual==manifest['files'],'source closure mismatch or unlisted files')
    stdout=artifact(run['stdout']);artifact(run['stderr'])
    require(run['complete'] is True,'partial run receipt')
    require(run['termination']=='exit' and run['signal'] is None and not run['timed_out'] and not run['resource_killed'],'crash/timeout/resource termination')
    lines=stdout.read_text().splitlines();events=[]
    for line in lines:
        if line.startswith(PFX):
            cols=line.split('\t');require(len(cols)==5,'malformed protocol event');events.append(cols[1:])
    require(events and events[0]==['BEGIN',case,'none','none'],'missing/wrong case begin')
    begun=False;ended=False;suite=False;failed=None;assertions=set()
    for i,(kind,cid,aid,result) in enumerate(events):
        require(not failed,'protocol after failure')
        if kind=='BEGIN':
            require(not begun and i==0,'multiple/nested cases');begun=True
        elif kind in ('ASSERT','PRECONDITION'):
            require(begun and not ended and cid==case,'assert outside selected case')
            require(result in ('PASS','FAIL'),'bad assertion status')
            if kind=='ASSERT':assertions.add(aid)
            if result=='FAIL':failed=(kind,aid);require(i==len(events)-1,'failure not terminal')
        elif kind=='END':
            require(begun and not ended and cid==case and aid=='none' and result=='PASS','invalid end');ended=True
        elif kind=='SUITE_END':
            require(ended and not suite and cid=='none' and aid=='none' and result=='1' and i==len(events)-1,'invalid suite completion');suite=True
        else: raise ValueError('unknown/protocol-error event')
    if failed:
        required=86 if failed[0]=='ASSERT' else 87
        require(run['exit_code']==required,'failure exit mismatch')
    else:require(run['exit_code']==0 and ended and suite,'incomplete case or exit mismatch')
    return {'failure':failed,'assertions':assertions,'completed':not failed and ended and suite,'source_manifest_sha256':build['source_manifest']['sha256'],'binary_sha256':sha(binary),'run':run,'source_root':root,'source_files':actual}

def main():
    p=argparse.ArgumentParser();p.add_argument('--recipes',required=True);p.add_argument('--mutant',required=True);p.add_argument('--case',required=True);p.add_argument('--control-receipt',required=True);p.add_argument('--mutant-receipt',required=True);a=p.parse_args()
    recipes=load(a.recipes);recipe=next(x for x in recipes['mutants'] if x['id']==a.mutant)
    binding=next(x for x in recipe['bindings'] if x['case']==a.case)
    digest=sha(a.recipes)
    control=inspect_receipt(a.control_receipt,a.case,'control',None,digest,binding['target'])
    require(control['completed'],'clean control case must complete first')
    required_complete=set(binding['assertions'])|set(binding.get('required_completion',[]))
    require(required_complete.issubset(control['assertions']),'control omitted a bound/completion assertion')
    variant='control' if recipe.get('expected')=='SURVIVE' else 'mutant'
    tested=inspect_receipt(a.mutant_receipt,a.case,variant,None if variant=='control' else a.mutant,digest,binding['target'])
    if variant=='mutant':
        provenance=load(artifact(tested['run']['materialization_receipt']))
        require(provenance['mutant']==a.mutant and provenance['recipes_sha256']==digest,'materialization mismatch')
        require(provenance['base_source_manifest_sha256']==control['source_manifest_sha256'],'wrong control source')
        require(provenance['mutated_source_manifest_sha256']==tested['source_manifest_sha256'],'wrong mutant source')
    if variant=='mutant':
        expected=dict(control['source_files']);edited={}
        for edit in recipe['edits']:
            rel=edit['path'];text=edited.get(rel,(control['source_root']/rel).read_text())
            require(text.count(edit['old'])==edit['count'],'recipe anchor mismatch in clean control')
            edited[rel]=text.replace(edit['old'],edit['new'])
        for rel,text in edited.items():expected[rel]=hashlib.sha256(text.encode()).hexdigest()
        require(expected==tested['source_files'],'mutant differs from exact reviewed recipe')
    else:
        require(tested['source_files']==control['source_files'] and tested['binary_sha256']==control['binary_sha256'],'survivor control changed source or binary')
    failure=tested['failure']
    if failure:
        require(failure[0]=='ASSERT' and failure[1] in binding['assertions'],'unrelated assertion/precondition failure')
        require(recipe.get('expected')!='SURVIVE','expected survivor failed')
        classification='KILLED_BY_BOUND_ASSERTION'
    else:
        require(tested['completed'] and required_complete.issubset(tested['assertions']),'survivor case incomplete')
        classification='EXPECTED_SURVIVOR_COMPLETE' if recipe.get('expected')=='SURVIVE' else 'SURVIVED_COMPLETE_CASE'
    print(json.dumps({'classification':classification,'mutant':a.mutant,'case':a.case,'bound_assertions':binding['assertions'],'binary_sha256':tested['binary_sha256'],'recipes_sha256':digest,'execution_performed_by_checker':False},indent=2))
if __name__=='__main__':
    try: main()
    except (ValueError,KeyError,StopIteration,OSError,TypeError,json.JSONDecodeError) as e:
        print(json.dumps({'classification':'INCONCLUSIVE','reason':str(e),'execution_performed_by_checker':False}),file=sys.stdout);sys.exit(2)

// Build unchanged against baseline and candidate. This executable never adds P.
// Two separate binaries: AETHER_RESOURCE_ALLOCATOR=1 and =0 (RSS-only).
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <cstdlib>
#include <cstdio>
#include <limits>
#include <new>
#include <memory_resource>
#include <string>
#include <vector>
#include <sys/resource.h>
#include <unistd.h>
#ifndef AETHER_RESOURCE_ALLOCATOR
#error Define AETHER_RESOURCE_ALLOCATOR explicitly (1 allocation probe, 0 RSS-only).
#endif
#ifndef AETHER_RESOURCE_CANDIDATE
#error Define AETHER_RESOURCE_CANDIDATE explicitly (1 candidate, 0 baseline).
#endif
#if AETHER_POST09_OBSERVER || AETHER_EFFECT_CAPTURE || AETHER_REUSABLE_PAYLOAD_CAPTURE || AETHER_HOVER_PROBE || AETHER_SAME_STAGE_TEST_HOOKS
#error Resource builds must disable every diagnostic and test hook in core too.
#endif
namespace allocation_probe {
struct Counts {std::atomic<size_t> calls{},bytes{},live{},peak{},aligned_calls{};};
static Counts counts;
#if AETHER_RESOURCE_ALLOCATOR
struct Header {void* raw;size_t size;};
static void* alloc(size_t size,size_t alignment,bool aligned) {
    if(alignment<alignof(Header))alignment=alignof(Header);
    if((alignment&(alignment-1)) || size>SIZE_MAX-sizeof(Header)-alignment)throw std::bad_alloc();
    void* raw=std::malloc((size?size:1)+sizeof(Header)+alignment-1);
    if(!raw)throw std::bad_alloc();
    auto address=(reinterpret_cast<uintptr_t>(raw)+sizeof(Header)+alignment-1)&~uintptr_t(alignment-1);
    auto* h=reinterpret_cast<Header*>(address)-1;h->raw=raw;h->size=size;
    ++counts.calls;counts.bytes+=size;if(aligned)++counts.aligned_calls;
    auto live=counts.live.fetch_add(size)+size;auto peak=counts.peak.load();
    while(live>peak&&!counts.peak.compare_exchange_weak(peak,live)){}
    return reinterpret_cast<void*>(address);
}
static void free(void* p) noexcept {if(p){auto* h=static_cast<Header*>(p)-1;counts.live-=h->size;std::free(h->raw);}}
#endif
}
#if AETHER_RESOURCE_ALLOCATOR
void* operator new(size_t n){return allocation_probe::alloc(n,alignof(std::max_align_t),false);}
void* operator new[](size_t n){return ::operator new(n);}
void* operator new(size_t n,std::align_val_t a){return allocation_probe::alloc(n,size_t(a),true);}
void* operator new[](size_t n,std::align_val_t a){return ::operator new(n,a);}
void operator delete(void* p) noexcept {allocation_probe::free(p);}
void operator delete[](void* p) noexcept {allocation_probe::free(p);}
void operator delete(void* p,size_t) noexcept {allocation_probe::free(p);}
void operator delete[](void* p,size_t) noexcept {allocation_probe::free(p);}
void operator delete(void* p,std::align_val_t) noexcept {allocation_probe::free(p);}
void operator delete[](void* p,std::align_val_t) noexcept {allocation_probe::free(p);}
void operator delete(void* p,size_t,std::align_val_t) noexcept {allocation_probe::free(p);}
void operator delete[](void* p,size_t,std::align_val_t) noexcept {allocation_probe::free(p);}
void* operator new(size_t n,const std::nothrow_t&) noexcept {try{return ::operator new(n);}catch(...){return nullptr;}}
void* operator new[](size_t n,const std::nothrow_t&) noexcept {try{return ::operator new[](n);}catch(...){return nullptr;}}
void* operator new(size_t n,std::align_val_t a,const std::nothrow_t&) noexcept {try{return ::operator new(n,a);}catch(...){return nullptr;}}
void* operator new[](size_t n,std::align_val_t a,const std::nothrow_t&) noexcept {try{return ::operator new[](n,a);}catch(...){return nullptr;}}
void operator delete(void* p,const std::nothrow_t&) noexcept {allocation_probe::free(p);}
void operator delete[](void* p,const std::nothrow_t&) noexcept {allocation_probe::free(p);}
void operator delete(void* p,std::align_val_t,const std::nothrow_t&) noexcept {allocation_probe::free(p);}
void operator delete[](void* p,std::align_val_t,const std::nothrow_t&) noexcept {allocation_probe::free(p);}
#endif
#include <aether/aether.h>
#include <aether/aether_contextual_style.h>
// Resolve these private headers via each build's native/src include directory.
#include "css/computed_style_handle.h"
#include "dom/dom_types.h"
#include "style_runtime/typography_record.h"
static void require(bool b,const char* what){if(!b){std::fprintf(stderr,"ASSERT resource: %s\n",what);std::exit(2);}}
static void ok(aether_status_t s){require(s==AETHER_OK,"API success");}
static size_t number(const char* s){char* end{};auto n=std::strtoull(s,&end,10);require(s[0]&&end&&!*end&&s[0]!='-'&&n<=SIZE_MAX,"integer parameter");return size_t(n);}
static void snapshot(const char* phase,size_t n,size_t r) {
    rusage usage{};require(getrusage(RUSAGE_SELF,&usage)==0,"getrusage");
    // Linux ru_maxrss is KiB. It is not allocator bytes and is never subtracted
    // from requested bytes. Allocator-phase RSS is explicitly not a cost oracle.
    std::printf("{\"phase\":\"%s\",\"candidate\":%d,\"allocator_probe\":%d,\"nodes\":%zu,\"retained_revisions\":%zu,\"calls\":%zu,\"requested_total_bytes\":%zu,\"requested_live_bytes\":%zu,\"requested_peak_bytes\":%zu,\"aligned_calls\":%zu,\"process_peak_rss_kib\":%ld}\n",phase,AETHER_RESOURCE_CANDIDATE,AETHER_RESOURCE_ALLOCATOR,n,r,allocation_probe::counts.calls.load(),allocation_probe::counts.bytes.load(),allocation_probe::counts.live.load(),allocation_probe::counts.peak.load(),allocation_probe::counts.aligned_calls.load(),usage.ru_maxrss);
    std::fflush(stdout);
}
static void inspect(aether_style_revision_t r,size_t expected_source,bool limited) {
    for(int i=0;i<aether_style_revision_style_count(r);++i){
        aether_node_t node{};aether_computed_style_handle_t h{};uint32_t impact{};
        ok(aether_style_revision_get_style(r,i,&node,&h,&impact));
        auto t=h->record->typography();require(t&&t->inputs,"published F/A");
        if(i==0)std::printf("{\"accounting\":true,\"record_count\":%d,\"source_bytes\":%zu,\"declarations\":%zu,\"rules\":%zu,\"compiled_rules\":%zu,\"expanded_declarations\":%zu,\"compiled_bytes\":%zu,\"losses\":%u,\"inputs_accounted\":%d,\"external_pending\":%d}\n",aether_style_revision_style_count(r),t->inputs->source_bytes,t->inputs->declarations,t->inputs->rules,t->inputs->compiled_rules,t->inputs->expanded_declarations,t->inputs->compiled_bytes,t->inputs->losses,int(t->inputs->inputs_accounted),int(t->inputs->external_pending));
#if AETHER_RESOURCE_CANDIDATE
        require(bool(t->prepared_evidence),"candidate published P");
#endif
        // Near-limit profiles exercise source accounting saturation, not a
        // guessed typography-gap oracle. Every node shares final accounting.
        if(limited){require(t->inputs->losses&uint32_t(style_source_loss::budget),"budget loss");require(!t->inputs->inputs_accounted,"budget incomplete");}
        if(expected_source!=SIZE_MAX)require(t->inputs->source_bytes==expected_source,"exact source bytes");
        aether_computed_style_handle_destroy(h);
    }
}
int main(int argc,char** argv){
    require(argc==7,"usage: resource_probe N family_bytes retained_R source_padding expect_limited expected_source_bytes");
    const size_t n=number(argv[1]),family=number(argv[2]),revisions=number(argv[3]),padding=number(argv[4]);
    const bool limited=number(argv[5])!=0;const size_t expected_source=number(argv[6]);require(n&&revisions,"positive N/R");
#if AETHER_RESOURCE_ALLOCATOR
    // Explicitly qualify whether actual default PMR reaches this executable's
    // ordinary/aligned hooks. No hidden assumption about the STL implementation.
    auto before=allocation_probe::counts.calls.load();auto aligned=allocation_probe::counts.aligned_calls.load();
    void* p=std::pmr::new_delete_resource()->allocate(257,alignof(char));
    require(allocation_probe::counts.calls.load()==before+1,"PMR intercepted once");
    std::printf("{\"pmr_family\":\"%s\"}\n",allocation_probe::counts.aligned_calls.load()==aligned?"ordinary":"aligned");
    std::pmr::new_delete_resource()->deallocate(p,257,alignof(char));
#endif
    snapshot("process_start",n,0);
    aether_doc_t doc{};aether_style_runtime_t runtime{};ok(aether_doc_create(&doc));
    std::string html="<html><body>";
    for(size_t i=0;i<n;++i)html+="<div id='n"+std::to_string(i)+"'></div>";
    html+="</body></html>";ok(aether_doc_parse_html(doc,html.c_str()));
    ok(aether_style_runtime_create(nullptr,nullptr,nullptr,nullptr,&runtime));
    std::vector<aether_style_revision_t> retained;retained.reserve(revisions);
    std::string source="font-family:'"+std::string(family,'a')+"';";
    // Spaces are input bytes but don't create a typography declaration/provenance.
    source+=std::string(padding,' ');
    for(size_t i=0;i<n;++i)ok(aether_element_set_attribute(aether_doc_get_element_by_id(doc,("n"+std::to_string(i)).c_str()),"style",source.c_str()));
    for(size_t i=0;i<revisions;++i){
        // Distinct revisions keep independently owned P even with identical input.
        aether_style_transaction_t tx{};ok(aether_style_runtime_prepare_revision(runtime,doc,nullptr,&tx));
        snapshot(i?"candidate_prepared":"first_prepared",n,retained.size());
        aether_style_revision_t r{};ok(aether_style_runtime_commit_revision(runtime,tx,&r));
        snapshot("committed_tx_retained",n,retained.size()+1);
        aether_style_transaction_destroy(tx);retained.push_back(r);
        inspect(r,expected_source,limited);snapshot(i?"revision_published":"baseline_published",n,retained.size());
    }
    aether_style_transaction_t abandoned{};ok(aether_style_runtime_prepare_revision(runtime,doc,nullptr,&abandoned));
    snapshot("abandoned_prepared",n,retained.size());aether_style_transaction_destroy(abandoned);
    snapshot("after_abort",n,retained.size());aether_style_runtime_destroy(runtime);
    snapshot("runtime_destroyed_snapshots_retained",n,retained.size());
    for(auto r:retained)aether_style_revision_destroy(r);retained.clear();
    snapshot("snapshots_released",n,0);aether_doc_destroy(doc);
    // Fixture strings/vector capacity are intentionally still live here, same
    // on both sides; the final scope below permits reporting actual release.
    std::string().swap(html);std::string().swap(source);std::vector<aether_style_revision_t>().swap(retained);
    snapshot("fixture_released",n,0);
}

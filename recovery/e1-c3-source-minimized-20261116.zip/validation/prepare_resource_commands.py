#!/usr/bin/env python3
"""Read approved finite plan, verify supplied artifacts, write commands. NEVER RUNS THEM.
This validates shape, not the authority of approval or resource enforcement.
An independently approved supervisor must enforce all stated limits at execution.
"""
import argparse, hashlib, json, pathlib
p=argparse.ArgumentParser();p.add_argument('--approved-plan',required=True);p.add_argument('--output',required=True);a=p.parse_args()
plan=json.loads(pathlib.Path(a.approved_plan).read_text())
assert plan['review_status']=='APPROVED_FOR_EXECUTION'
assert plan['approval_reference'] and plan['supervisor_contract_reference']
for k in ('concurrency','ram_bytes','disk_bytes','cpu_seconds_per_process','wall_seconds_per_process','wall_seconds_total','max_oom_positions','max_mutants'):
    assert type(plan['limits'][k]) is int and plan['limits'][k]>0,k
assert plan['timeout_kill_policy'] and plan['cleanup_policy']
assert plan['acceptance_mode'] in ('exploratory','thresholds')
if plan['acceptance_mode']=='thresholds': assert plan['acceptance_thresholds']
assert plan['cases'] and plan['artifacts']
commands=[]
for artifact in plan['artifacts']:
    assert artifact['side'] in ('baseline','candidate') and artifact['phase'] in ('allocator','rss')
    binary=pathlib.Path(artifact['binary']).resolve();assert binary.is_file()
    assert hashlib.sha256(binary.read_bytes()).hexdigest()==artifact['sha256']
    # This proof file must be independently reviewed. Its existence alone does
    # not prove OFF: retain compile commands/macro dumps/object-symbol outputs.
    proof=pathlib.Path(artifact['off_proof']).resolve();assert proof.is_file()
    assert hashlib.sha256(proof.read_bytes()).hexdigest()==artifact['off_proof_sha256']
    assert artifact['toolchain_config_identity']==plan['toolchain_config_identity']
    assert bool(artifact['candidate_P'])==(artifact['side']=='candidate')
    for case in plan['cases']:
        for key in ('N','family_bytes','R','source_padding','expected_source_bytes'):
            assert type(case[key]) is int and case[key]>=0
        assert case['N']>0 and case['R']>0 and type(case['expect_limited']) is bool
        commands.append({'case':case['name'],'side':artifact['side'],'phase':artifact['phase'],
          'argv':[str(binary),str(case['N']),str(case['family_bytes']),str(case['R']),str(case['source_padding']),str(int(case['expect_limited'])),str(case['expected_source_bytes'])],
          'limits':plan['limits'],'requires_supervisor':plan['supervisor_contract_reference'], 'status':'NOT_RUN'})
expected={(s,p) for s in ('baseline','candidate') for p in ('allocator','rss')}
assert {(x['side'],x['phase']) for x in plan['artifacts']}==expected
out=pathlib.Path(a.output);assert not out.exists();out.write_text(json.dumps({'commands':commands,'execution_performed':False},indent=2)+'\n')

# Same-stage typography correction: minimized C3 source snapshot

Technical source-only snapshot. Contains the 12 changed candidate source/build-definition files, two baseline diagnostic-disable source changes, path-normalized patches, and six validation/mutation/resource source/configuration files. No private reviews, operational recipes, sessions, environment observations, logs, binary outputs or execution results are included.

Both native directories are overlays, not full repositories. SOURCE_BASELINES.json provides historical, baseline-off and candidate hashes for affected files. Restore matching historical source first. Apply baseline.patch (or baseline/native overlay) to create the comparison baseline. For the candidate, start from that baseline and apply candidate.patch or candidate/native overlay. Patch headers use only repository-relative native paths and contain no original machine paths or timestamps. Verify source hashes before and after restoration.

The candidate persists authentic prepared typography evidence and performs conservative same-stage and finalized-validity comparison. Its accompanying tests cover repeat/selectivity, runtime/coverage/consumer behavior, retained payloads and allocation failure. Mutation definitions and resource probes are source specifications, not evidence that any test or mutant ran or passed. Build and execution permissions must be established separately; no product acceptance or performance result is asserted.

Validation tools take local paths/configuration and may write instrumented copies or build commands. Review their contracts and run only within a newly authorized validation environment. The package omits private execution authority records; do not reconstruct or infer authorization from archived code.

Packaging checks only: stable reads, expected source hashes, Python syntax, archive CRC and archive-entry hashes. No checkout changes, compilation or product execution were performed for this backup.

#pragma once
#include "typography_evidence.h"
#include "style_source_accounting.h"
#include "../rendering/text/native_paragraph_diagnostic.h"
#include <cstdint>
namespace aether::style {
// Owned by the immutable revision's node record. Never authorizes rendering.
struct TypographyRecord {
    // Authentic post-discard/computed, pre-final-accounting evidence.
    // Owned by this immutable record, independently of optional diagnostics.
    TypographyEvidenceRef prepared_evidence;
    TypographyEvidence evidence;
    std::shared_ptr<const style_source_accounting_s> inputs;
    aether::rendering::text::ParagraphDiagnosticRef text_diagnostic;
    // Independent prerequisites, not alternatives. Neither is established here.
    const bool context_unproven=true, font_unresolved=true;
    uint64_t generation=0, document_identity=0, input_epoch=0, structure_epoch=0,
        style_tree_epoch=0, sheet_epoch=0, registry_version=1;
};
// Same-stage production comparators. Missing proof is conservative. Counters
// are deliberately absent here, not from publication or budget enforcement.
inline bool prepared_typography_changed(const TypographyRecord* previous,
                                        const TypographyEvidence& next) {
    return !previous || !previous->prepared_evidence ||
        *previous->prepared_evidence != next;
}
inline bool final_typography_changed(const TypographyRecord* previous,
                                     const TypographyEvidence& next,
                                     const style_source_accounting_s& inputs) {
    return !previous || !previous->inputs || previous->evidence != next ||
        previous->inputs->losses != inputs.losses ||
        previous->inputs->inputs_accounted != inputs.inputs_accounted ||
        previous->inputs->external_pending != inputs.external_pending;
}
using TypographyRecordRef=std::shared_ptr<const TypographyRecord>;
}

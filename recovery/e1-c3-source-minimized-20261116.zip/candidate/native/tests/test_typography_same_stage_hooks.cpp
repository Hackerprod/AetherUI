// Standalone TU: private hooks do not enter the ordinary core library.
#define AETHER_SAME_STAGE_TEST_HOOKS 1
#include <cstdlib>
#include <new>
static bool fail_next=false, delivered=false;
static size_t ordinary_test_calls=0,ordinary_test_failures=0;
void* operator new(std::size_t n){++ordinary_test_calls;if(fail_next){fail_next=false;delivered=true;++ordinary_test_failures;throw std::bad_alloc();}if(auto p=std::malloc(n?n:1))return p;throw std::bad_alloc();}
void* operator new[](std::size_t n){return ::operator new(n);}
void operator delete(void* p) noexcept{std::free(p);} void operator delete[](void* p) noexcept{std::free(p);}
void operator delete(void* p,std::size_t) noexcept{std::free(p);} void operator delete[](void* p,std::size_t) noexcept{std::free(p);}
void* operator new(std::size_t n,const std::nothrow_t&) noexcept{try{return ::operator new(n);}catch(...){return nullptr;}}
void* operator new[](std::size_t n,const std::nothrow_t&) noexcept{try{return ::operator new(n);}catch(...){return nullptr;}}
void operator delete(void* p,const std::nothrow_t&) noexcept{std::free(p);}void operator delete[](void* p,const std::nothrow_t&) noexcept{std::free(p);}
#define AETHER_TEST_ALIGNED_REJECT() (fail_next ? (fail_next=false, true) : false)
#define fault_delivered delivered
#include "fault_inject_aligned.h"
#undef fault_delivered
#include "../src/style_runtime/style_runtime_core.cpp"
#include <cstdio>
#include "same_stage_assertions.h"
#define CHECK(x) SS_PRECONDITION("setup-or-precondition",(x))
static void ok(aether_status_t s){CHECK(s==AETHER_OK);}
static bool same_a(const style_source_accounting_s& a,const style_source_accounting_s& b){return a.source_bytes==b.source_bytes&&a.declarations==b.declarations&&a.rules==b.rules&&a.compiled_rules==b.compiled_rules&&a.expanded_declarations==b.expanded_declarations&&a.compiled_bytes==b.compiled_bytes&&a.losses==b.losses&&a.inputs_accounted==b.inputs_accounted&&a.external_pending==b.external_pending;}
struct Hooks {
    struct Row {aether_node_s* node{};uint32_t own{},inherited{};std::weak_ptr<const TypographyEvidence> p;};
    Row rows[16]{};size_t count=0,created=0;
    size_t style_source_accounting_s::*counter=nullptr;size_t value=0;
    enum Mode{none,p_oom,post_p_oom,freeze_reject,freeze_oom}mode=none;
    size_t target=0,ordinal=0;const char* armed=nullptr;
    SameStageTestHooks api;
    Hooks(){api.context=this;api.accounting=[](void* v,auto& a){auto& h=*static_cast<Hooks*>(v);if(h.counter)a.*h.counter=h.value;};
        api.base=[](void* v,auto* n,uint32_t own,uint32_t inherited){auto& h=*static_cast<Hooks*>(v);CHECK(h.count<16);h.rows[h.count++]={n,own,inherited,{}};};
        api.before_p=[](void* v,auto*){auto& h=*static_cast<Hooks*>(v);if(h.mode==p_oom&&h.ordinal++==h.target){h.armed="make_shared<P>";fail_next=true;}};
        api.after_p=[](void* v,auto* n,const auto& p){auto& h=*static_cast<Hooks*>(v);for(size_t i=0;i<h.count;++i)if(h.rows[i].node==n)h.rows[i].p=p;++h.created;if(h.mode==post_p_oom&&h.created==h.target+1){h.armed="after<P>";fail_next=true;}};
        api.before_freeze=[](void* v,auto*){auto& h=*static_cast<Hooks*>(v);if(h.created==h.target+1){if(h.mode==freeze_reject){h.armed="freeze rejection seam";require_style_status(AETHER_ERROR_INVALID_STATE);}if(h.mode==freeze_oom){h.armed="freeze allocation";fail_next=true;}}};
    }
    void reset(){for(auto& r:rows)r={};count=created=ordinal=0;armed=nullptr;delivered=false;CHECK(!fail_next);}
    const Row& at(aether_node_s* n)const{for(size_t i=0;i<count;++i)if(rows[i].node==n)return rows[i];std::abort();}
    void expired()const{for(size_t i=0;i<count;++i)CHECK(rows[i].p.expired());}
};
struct Fixture {
    aether_doc_t d{};aether_style_runtime_t rt{};Hooks hooks;
    Fixture(){ok(aether_doc_create(&d));ok(aether_doc_parse_html(d,"<html><body><div id='parent'><div id='target'><div id='child' style='font-size:16px'></div></div><div id='sibling' style='font-size:16px'></div></div></body></html>"));ok(aether_style_runtime_create(nullptr,nullptr,nullptr,nullptr,&rt));rt->same_stage_test_hooks=&hooks.api;}
    ~Fixture(){if(rt)aether_style_runtime_destroy(rt);aether_doc_destroy(d);}
    aether_node_s* node(const char* id){return aether_doc_get_element_by_id(d,id);}
    aether_style_transaction_t prepare(){hooks.reset();aether_style_transaction_t tx{};ok(aether_style_runtime_prepare_revision(rt,d,nullptr,&tx));return tx;}
    void commit(aether_style_transaction_t tx){aether_style_revision_t r{};auto calls=ordinary_test_calls+aligned_test_calls;ok(aether_style_runtime_commit_revision(rt,tx,&r));CHECK(calls==ordinary_test_calls+aligned_test_calls);aether_style_revision_destroy(r);}
    void resolve(){auto tx=prepare();commit(tx);aether_style_transaction_destroy(tx);}
};
static void check_impacts(const FrozenNodeRef& record,const Hooks::Row& base,uint32_t own_add,uint32_t inherited_add,uint32_t entry){
    SS_CHECK("impact.own",record->declared_impact()==(base.own|own_add));
    SS_CHECK("impact.inherited",record->declared_inherited_impact()==(base.inherited|inherited_add));
    SS_CHECK("impact.inherited_change",record->inherited_change_impact()==(base.inherited|inherited_add));
    SS_CHECK("impact.entry",entry==(base.own|own_add));
}
static void counters(){
 const char* names[]={"source_bytes","declarations","rules","compiled_rules","expanded_declarations","compiled_bytes"};size_t index=0;
 for(auto member:{&style_source_accounting_s::source_bytes,&style_source_accounting_s::declarations,&style_source_accounting_s::rules,&style_source_accounting_s::compiled_rules,&style_source_accounting_s::expanded_declarations,&style_source_accounting_s::compiled_bytes}){
    const std::string case_name=std::string("counter-")+names[index];if(!ss::selected(case_name.c_str())){++index;continue;}ss::Case scope(case_name.c_str());
    Fixture f;f.resolve();auto natural=f.rt->states;auto natural_revision=f.rt->revision;
    std::unordered_map<aether_node_s*,TypographyEvidence> natural_p,natural_f;for(auto& [n,r]:natural){natural_p.emplace(n,*r->typography()->prepared_evidence);natural_f.emplace(n,r->typography()->evidence);}
    auto natural_a=*natural.begin()->second->typography()->inputs;auto substituted_a=natural_a;substituted_a.*member+=13;
    decltype(natural) substituted;StyleRevisionRef substituted_revision;
    const char* phases[]={"set","repeat","restore"};
    for(int pass=0;pass<3;++pass){

        f.hooks.counter=pass==2?nullptr:member;f.hooks.value=substituted_a.*member;
        const auto& expected_a=pass==2?natural_a:substituted_a;
        auto previous=f.rt->states;auto generation=f.rt->generation;auto tx=f.prepare();
        SS_CHECK("updates.empty",tx->updates.empty());f.commit(tx);
        SS_CHECK("publication.generation",f.rt->generation==generation+1);
        std::shared_ptr<const style_source_accounting_s> shared;
        for(const auto& entry:f.rt->revision->entries()){
            auto n=entry.node();auto now=entry.record()->typography();auto original=natural.at(n)->typography();
            SS_CHECK("publication.new_record",entry.record()!=previous.at(n));
            SS_CHECK("publication.counter",same_a(*now->inputs,expected_a));
            SS_CHECK("publication.P",*now->prepared_evidence==natural_p.at(n));
            SS_CHECK("publication.F",now->evidence==natural_f.at(n));
            SS_CHECK("snapshot.natural",same_a(*original->inputs,natural_a));
            SS_CHECK("snapshot.natural.P",*original->prepared_evidence==natural_p.at(n));SS_CHECK("snapshot.natural.F",original->evidence==natural_f.at(n));
            if(shared)SS_CHECK("publication.shared_A",now->inputs==shared);else shared=now->inputs;
            SS_CHECK("base.own",f.hooks.at(n).own==0);SS_CHECK("base.inherited",f.hooks.at(n).inherited==0);
            check_impacts(entry.record(),f.hooks.at(n),0,0,entry.impact());
            if(!substituted.empty()){
                auto retained=substituted.at(n)->typography();
                SS_CHECK("snapshot.substituted",same_a(*retained->inputs,substituted_a));
                SS_CHECK("snapshot.substituted.P",*retained->prepared_evidence==natural_p.at(n));
                SS_CHECK("snapshot.substituted.F",retained->evidence==natural_f.at(n));
            }
        }
        if(pass==0){substituted=f.rt->states;substituted_revision=f.rt->revision;}
        aether_style_transaction_destroy(tx);
        const std::string complete=std::string("transition.")+phases[pass]+".complete";SS_CHECK(complete.c_str(),true);
    }
    ++index;
 }
}
struct SavedEvidence {
    aether_node_s* node;FrozenNodeRef record;TypographyEvidence p,f;style_source_accounting_s a;
};
static std::vector<SavedEvidence> save(aether_style_runtime_t rt){std::vector<SavedEvidence> v;for(auto& [n,r]:rt->states){auto t=r->typography();CHECK(t&&t->prepared_evidence&&t->inputs);v.push_back({n,r,*t->prepared_evidence,t->evidence,*t->inputs});}return v;}
static void unchanged(aether_style_runtime_t rt,const std::vector<SavedEvidence>& v){for(const auto& e:v){CHECK(rt->states.at(e.node)==e.record);auto t=e.record->typography();CHECK(*t->prepared_evidence==e.p&&t->evidence==e.f&&same_a(*t->inputs,e.a));}}
static void failures(){
 for(auto mode:{Hooks::p_oom,Hooks::post_p_oom,Hooks::freeze_reject,Hooks::freeze_oom})for(size_t target:{size_t(0),size_t(1)}){
    const std::string label=(mode==Hooks::freeze_oom&&target==1)?"lifetime-freeze-late":("lifetime-fault-"+std::to_string(int(mode))+"-"+std::to_string(target));if(!ss::selected(label.c_str()))continue;ss::Case scope(label.c_str());
    Fixture f;f.resolve();auto old=f.rt->states;auto saved=save(f.rt);auto generation=f.rt->generation;
    f.hooks.mode=mode;f.hooks.target=target;f.hooks.reset();aether_style_transaction_t tx=reinterpret_cast<aether_style_transaction_t>(1);
    auto status=aether_style_runtime_prepare_revision(f.rt,f.d,nullptr,&tx);CHECK(!fail_next&&f.hooks.armed);
    CHECK(status==(mode==Hooks::freeze_reject?AETHER_ERROR_INVALID_STATE:AETHER_ERROR_OUT_OF_MEMORY));
    CHECK(mode==Hooks::freeze_reject?!delivered:delivered);SS_CHECK("publication.unchanged",tx==nullptr&&f.rt->generation==generation&&f.rt->states==old);unchanged(f.rt,saved);f.hooks.expired();
 }
 for(int kind=0;kind<3;++kind){
    const char* names[]={"lifetime-abort","lifetime-stale","lifetime-success"};if(!ss::selected(names[kind]))continue;ss::Case scope(names[kind]);
    Fixture f;f.resolve();auto old=f.rt->states;auto saved=save(f.rt);auto generation=f.rt->generation;auto tx=f.prepare();
    for(size_t i=0;i<f.hooks.count;++i)CHECK(!f.hooks.rows[i].p.expired());
    if(kind==1){ok(aether_element_set_attribute(f.node("target"),"data-stale","1"));aether_style_revision_t r=reinterpret_cast<aether_style_revision_t>(1);CHECK(aether_style_runtime_commit_revision(f.rt,tx,&r)==AETHER_ERROR_INVALID_STATE);CHECK(r==nullptr&&f.rt->generation==generation&&f.rt->states==old);unchanged(f.rt,saved);for(size_t i=0;i<f.hooks.count;++i)CHECK(!f.hooks.rows[i].p.expired());}
    if(kind==2){f.commit(tx);auto revision=f.rt->revision;auto handle_record=f.rt->states.at(f.node("target"));aether_style_runtime_destroy(f.rt);f.rt=nullptr;CHECK(!f.hooks.at(f.node("target")).p.expired());revision.reset();handle_record.reset();CHECK(!f.hooks.at(f.node("target")).p.expired());}
    if(kind==0)unchanged(f.rt,saved);
    aether_style_transaction_destroy(tx);f.hooks.expired();
 }
}
static void selectivity(bool inherited){
 const char* id=inherited?"selectivity-inherited":"selectivity-local";if(!ss::selected(id))return;ss::Case scope(id);Fixture f;
 // Constants derive from authored px, the inheritance branch and field policy,
 // not a recorded candidate run. All nodes have an absolute 24px line-height.
 auto root=aether_doc_get_document_element(f.d),body=aether_doc_get_body(f.d);
 std::array<aether_node_s*,6> nodes{root,body,f.node("parent"),f.node("target"),f.node("child"),f.node("sibling")};
 for(auto n:nodes)ok(aether_element_set_attribute(n,"style","font-size:16px;line-height:24px"));
 if(inherited)ok(aether_element_set_attribute(f.node("child"),"style","line-height:24px"));
 f.resolve();auto old=f.rt->states;
 for(auto n:nodes){const auto& p=*old.at(n)->typography()->prepared_evidence;
    CHECK(p.size_state==TypographyFieldState::known&&p.size_px==16);
    CHECK(p.size_dependencies==(inherited&&n==f.node("child")?16u:0u));
    CHECK(p.line_height_state==TypographyFieldState::known&&p.line_height_kind==TypographyLineHeightKind::absolute_css_px);
    CHECK(p.line_height_value==24&&p.line_height_used_px==24&&p.line_height_dependencies==0);
    CHECK(p.provenance[3].accepted_source=="16px"&&p.provenance[3].resolved_source=="16px");
    CHECK(p.provenance[3].inherited==(inherited&&n==f.node("child")));
    CHECK(p.coverage_gaps==1&&!p.coverage_complete);
 }
 ok(aether_element_set_attribute(f.node("target"),"style","font-size:20px;line-height:24px"));auto tx=f.prepare();f.commit(tx);aether_style_transaction_destroy(tx);
 for(const auto& entry:f.rt->revision->entries()){
    auto n=entry.node();bool changed=n==f.node("target")||(inherited&&n==f.node("child"));
    auto before=old.at(n)->typography();auto now=entry.record()->typography();
    auto expected_p=*before->prepared_evidence;
    if(changed){expected_p.size_px=20;expected_p.provenance[3].accepted_source="20px";expected_p.provenance[3].resolved_source="20px";}
    auto expected_f=expected_p;if(before->inputs->losses||!before->inputs->inputs_accounted)expected_f.coverage_gaps|=4;
    SS_CHECK("publication.P",*now->prepared_evidence==expected_p);
    SS_CHECK("publication.F",now->evidence==expected_f);
    SS_CHECK("publication.counter",same_a(*before->inputs,*now->inputs));
    const auto& m=entry.record()->measures()->scalars();
    SS_CHECK("typography.values",now->prepared_evidence->size_px==(changed?20:16)&&entry.record()->style_view().scalars().font_size==(changed?20:16)&&m.self_font_size==(changed?20:16)&&m.line_height_kind==FrozenLineHeightKind::absolute_css_px&&m.line_height_value==24);
    SS_CHECK("typography.parent_size",m.parent_font_size==(n==f.node("child")?20:16));
    SS_CHECK("base.own",f.hooks.at(n).own==(changed?83u:0u));
    SS_CHECK("base.inherited",f.hooks.at(n).inherited==(changed?83u:0u));
    check_impacts(entry.record(),f.hooks.at(n),changed?19:0,changed?19:0,entry.impact());
 }
 auto changed_records=f.rt->states;tx=f.prepare();SS_CHECK("updates.empty",tx->updates.empty());f.commit(tx);aether_style_transaction_destroy(tx);
 for(const auto& entry:f.rt->revision->entries()){
    auto n=entry.node();auto previous=changed_records.at(n)->typography(),now=entry.record()->typography();
    SS_CHECK("repeat.P",*now->prepared_evidence==*previous->prepared_evidence);SS_CHECK("repeat.F",now->evidence==previous->evidence);SS_CHECK("repeat.A",same_a(*now->inputs,*previous->inputs));
    SS_CHECK("repeat.base",f.hooks.at(n).own==0&&f.hooks.at(n).inherited==0);check_impacts(entry.record(),f.hooks.at(n),0,0,entry.impact());
 }
}
static void local_noninherited(){
 if(!ss::selected("selectivity-width"))return;ss::Case scope("selectivity-width");Fixture f;ok(aether_element_set_attribute(f.node("target"),"style","width:16px"));f.resolve();auto old=f.rt->states;
 ok(aether_element_set_attribute(f.node("target"),"style","width:17px"));auto tx=f.prepare();f.commit(tx);aether_style_transaction_destroy(tx);
 for(const auto& entry:f.rt->revision->entries()){
    auto n=entry.node();auto before=old.at(n)->typography();auto now=entry.record()->typography();
    CHECK(*before->prepared_evidence==*now->prepared_evidence&&before->evidence==now->evidence);
    CHECK(same_a(*before->inputs,*now->inputs));
    check_impacts(entry.record(),f.hooks.at(n),0,0,entry.impact());
    if(n==f.node("target")){SS_CHECK("base.own",f.hooks.at(n).own==7);SS_CHECK("base.inherited",f.hooks.at(n).inherited==0);SS_CHECK("width.exact",entry.record()->style_view().scalars().width.value==17&&entry.record()->style_view().scalars().width.unit==AETHER_CSS_UNIT_PX);}
    else CHECK(f.hooks.at(n).own==0&&f.hooks.at(n).inherited==0);
 }
 auto changed=f.rt->states;tx=f.prepare();SS_CHECK("updates.empty",tx->updates.empty());f.commit(tx);aether_style_transaction_destroy(tx);
 for(const auto& entry:f.rt->revision->entries()){
    auto n=entry.node();auto now=entry.record()->typography(),before=changed.at(n)->typography();
    SS_CHECK("repeat.P",*now->prepared_evidence==*before->prepared_evidence);SS_CHECK("repeat.F",now->evidence==before->evidence);SS_CHECK("repeat.A",same_a(*now->inputs,*before->inputs));
    SS_CHECK("repeat.base",f.hooks.at(n).own==0&&f.hooks.at(n).inherited==0);check_impacts(entry.record(),f.hooks.at(n),0,0,entry.impact());
    if(n==f.node("target"))SS_CHECK("repeat.width.exact",entry.record()->style_view().scalars().width.value==17&&entry.record()->style_view().scalars().width.unit==AETHER_CSS_UNIT_PX);
 }
}
int main(){counters();failures();selectivity(false);selectivity(true);local_noninherited();return ss::finish();}

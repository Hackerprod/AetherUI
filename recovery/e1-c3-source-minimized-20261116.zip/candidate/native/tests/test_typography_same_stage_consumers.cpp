#include "../src/style_runtime/style_runtime_core.cpp"
#include "same_stage_assertions.h"
// Consumer guards, not another publication oracle. Synthetic variants below
// isolate consumer predicates; natural cases use actual committed records.
#include <aether/aether.h>
#include <aether/aether_contextual_style.h>
#include "../src/dom/dom_types.h"
#include "../src/css/computed_style_handle.h"
#include "../src/rendering/text/document_html_capture.h"
#include "../src/style_runtime/ua_stylesheet.h"
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <string>
using namespace aether::style;
using namespace aether::rendering;
using namespace aether::rendering::text;
#define CHECK(...) SS_REQUIRE(__VA_ARGS__)
static void ok(aether_status_t s){CHECK(s==AETHER_OK);}
namespace aether::layout {
class DocumentTextTestAccess {public:
 static auto drawing(DocumentFontCatalog fonts,DocumentTextBudget& b,bool drawing=true){auto p=DocumentTextProvider::create(std::move(fonts),b,nullptr);p->drawing_=drawing;return p;}
};
}
static auto load(const char* path){std::ifstream in(path,std::ios::binary);CHECK(in.good());std::vector<uint8_t> bytes((std::istreambuf_iterator<char>(in)),{});CHECK(!bytes.empty());return std::make_shared<const FontSource>(std::move(bytes),path);}
struct Fixture {
 aether_doc_t doc{};aether_style_runtime_t runtime{};aether_node_t target{};
 Fixture(){ok(aether_doc_create(&doc));ok(aether_doc_parse_html(doc,"<html><body><p id='p'>A</p></body></html>"));target=aether_doc_get_element_by_id(doc,"p");ok(aether_style_runtime_create(nullptr,nullptr,nullptr,nullptr,&runtime));ok(aether_style_runtime_add_stylesheet(runtime,web_capture_defaults_css(),0,"consumer",nullptr,nullptr));}
 ~Fixture(){aether_style_runtime_destroy(runtime);aether_doc_destroy(doc);}
 FrozenNodeRef resolve(uint32_t* bits=nullptr){aether_style_transaction_t tx{};aether_style_revision_t rev{};ok(aether_style_runtime_prepare_revision(runtime,doc,nullptr,&tx));ok(aether_style_runtime_commit_revision(runtime,tx,&rev));aether_style_transaction_destroy(tx);FrozenNodeRef out;
 for(int i=0;i<aether_style_revision_style_count(rev);++i){aether_node_t n{};aether_computed_style_handle_t h{};uint32_t b{};ok(aether_style_revision_get_style(rev,i,&n,&h,&b));if(n==target){out=h->record;if(bits)*bits=b;}aether_computed_style_handle_destroy(h);}aether_style_revision_destroy(rev);CHECK(out);return out;}
};
static FrozenNodeRef variant(const FrozenNodeRef& r,TypographyRecordRef t){
 NodeRecordInput in;in.origin=r->origin();in.node=r->node();in.style=r->style();in.measures=r->measures();in.typography=std::move(t);in.custom_properties=r->custom_properties();in.color_references=r->color_references();in.document_identity=r->document_identity();in.node_identity=r->node_identity();in.node_lifetime=r->node_lifetime();in.document_lifetime=r->document_lifetime();FrozenNodeRef out;ok(freeze_node_record(in,out));return out;
}
static void rejected(DocumentFontCatalog fonts,const FrozenNodeRef& r,bool drawing,bool policy){
 aether::layout::DocumentTextBudget budget;auto p=aether::layout::DocumentTextTestAccess::drawing(fonts,budget,drawing);bool caught=false;
 try{p->validate_style(r,aether::layout::BoxStyleSnapshot(r->style(),r->measures()));}
 catch(const std::invalid_argument& e){caught=policy&&std::string(e.what())=="DOCUMENT_BREAK_POLICY_UNPROVEN";}
 catch(truetype::RunError e){caught=!policy&&e==truetype::RunError::unsupported;}
 CHECK(caught);CHECK(p->work.typography_incomplete);CHECK(p->work.requests==0);
}
// Real successful capture contract. This observes returned product fields,
// NOT textual/UI warning emission (that remains NOT_COVERED).
static void capture_contract(DocumentFontCatalog fonts){
 std::shared_ptr<const DocumentCaptureFrame> retained;
 for(int pass=0;pass<2;++pass){
  aether::layout::DocumentTextBudget budget;
  auto requests=DocumentScrollRequests::prepare({},budget);
  auto result=capture_document_drawing_diagnostic(
   "<html><body><p>A</p></body></html>",fonts,100,100,requests,budget);
  // A rejection is not evidence of an incomplete SUCCESSFUL frame.
  auto frame=std::get_if<std::shared_ptr<const DocumentCaptureFrame>>(&result);
  SS_PRECONDITION("capture.success",frame&&*frame);
  SS_CHECK("coverage.incomplete",!(*frame)->coverage_complete);
  SS_CHECK("provider.incomplete",(*frame)->work.provider.typography_incomplete);
  SS_PRECONDITION("provider.requests",(*frame)->work.provider.requests>0);
  if(retained){
   SS_CHECK("retained.coverage.incomplete",!retained->coverage_complete);
   SS_CHECK("retained.provider.incomplete",retained->work.provider.typography_incomplete);
   SS_PRECONDITION("retained.provider.requests",retained->work.provider.requests>0);
  }
  retained=*frame;
 }
}
int main(int argc,char** argv){
 ss::run("consumer-capture-contract",[&]{
  CHECK(argc==3);
  DocumentFontCatalog fonts{load(argv[1]),load(argv[2])};
  capture_contract(fonts);
 });
 ss::run("consumer-guards",[&]{
 CHECK(argc==3);DocumentFontCatalog fonts{load(argv[1]),load(argv[2])};Fixture f;
 auto clean=f.resolve();CHECK(clean->typography()->inputs->losses==0);
 CHECK(clean->typography()->evidence.break_policy.fields[0].known&&clean->typography()->evidence.break_policy.fields[1].known);
 {aether::layout::DocumentTextBudget b;auto p=aether::layout::DocumentTextTestAccess::drawing(fonts,b);p->validate_style(clean,aether::layout::BoxStyleSnapshot(clean->style(),clean->measures()));CHECK(p->work.typography_incomplete);CHECK(!clean->typography()->evidence.coverage_complete);}
 // Isolated guard predicates call the real provider, without mutating immutable
 // runtime records or pretending these variants were published by the runtime.
 for(int i=0;i<6;++i){auto t=std::make_shared<TypographyRecord>(*clean->typography());auto a=std::make_shared<style_source_accounting_s>(*t->inputs);
  if(i==0)t->inputs.reset();
  if(i==1){a->inputs_accounted=false;t->inputs=a;}
  if(i==2){a->external_pending=true;t->inputs=a;}
  if(i==3){a->losses=0x80000000u;t->inputs=a;}
  if(i==4)t->evidence.break_policy.fields[0].known=false;
  if(i==5)++t->evidence.break_policy.fields[1].computed;
  rejected(fonts,variant(clean,t),true,true);
 }
 ok(aether_element_set_attribute(f.target,"style","unknown-property:1"));auto loss=f.resolve();uint32_t bits{};auto loss_noop=f.resolve(&bits);CHECK(bits==0);CHECK(loss_noop->typography()->inputs->losses!=0);rejected(fonts,loss_noop,true,true);rejected(fonts,loss,true,true);
 ok(aether_element_set_attribute(f.target,"style","word-spacing:1px"));auto discarded=f.resolve();CHECK(discarded->typography()->evidence.coverage_gaps&2u);rejected(fonts,discarded,false,false);
 // Capture's own drawing coverage guard remains operative independently of
 // provider validation and no-op classification.
 aether::layout::DocumentTextBudget b;auto requests=DocumentScrollRequests::prepare({},b);
 auto result=capture_document_drawing_diagnostic("<html><body><p style='unknown-property:1'>A</p></body></html>",fonts,100,100,requests,b);
 auto failure=std::get_if<SelectedCaptureFailure>(&result);CHECK(failure);CHECK(failure->code==truetype::HtmlTextError::unsupported);CHECK(failure->reason=="DOCUMENT_BREAK_POLICY_UNPROVEN");
 });
 return ss::finish();
}

// A2 production-comparator units. No observer or reusable-payload dependency.
#include "../src/style_runtime/typography_record.h"
#include <cstdio>
#include <cstdlib>
#include "same_stage_assertions.h"
using namespace aether::style;
#define CHECK(x) SS_REQUIRE(x)
static void broad_units() {
    TypographyEvidence p; style_source_accounting_s a;
    TypographyRecord old;
    old.prepared_evidence=std::make_shared<const TypographyEvidence>(p);
    old.evidence=p; old.inputs=std::make_shared<const style_source_accounting_s>(a);
    CHECK(!prepared_typography_changed(&old,p));
    CHECK(!final_typography_changed(&old,p,a));
    CHECK(prepared_typography_changed(nullptr,p));
    CHECK(final_typography_changed(nullptr,p,a));
    auto missing=old; missing.prepared_evidence.reset();
    CHECK(prepared_typography_changed(&missing,p));
    missing=old;missing.inputs.reset();CHECK(final_typography_changed(&missing,p,a));
#define CHANGE(...) {auto next=p;__VA_ARGS__;CHECK(prepared_typography_changed(&old,next));CHECK(final_typography_changed(&old,next,a));}
    CHANGE(next.family_state=TypographyFieldState::known);
    CHANGE(next.style_state=TypographyFieldState::unsupported);
    CHANGE(next.spacing_state=TypographyFieldState::known);
    CHANGE(next.size_state=TypographyFieldState::known);
    CHANGE(next.weight_state=TypographyFieldState::known);
    CHANGE(next.line_height_state=TypographyFieldState::known);
    CHANGE(next.families={{"A",false},{"serif",true}});
    CHANGE(next.font_style="italic"); CHANGE(next.spacing_normal=true);
    CHANGE(next.spacing_px=1); CHANGE(next.size_px=20); CHANGE(next.weight=700);
    CHANGE(next.line_height_kind=TypographyLineHeightKind::number);
    CHANGE(next.line_height_value=2); CHANGE(next.line_height_used_px=32);
    CHANGE(next.size_dependencies=1); CHANGE(next.line_height_dependencies=1);
    CHANGE(next.coverage_complete=true); CHANGE(next.coverage_gaps=3);
    CHANGE(next.coverage_gaps=0x80000001u);
    for(int i=0;i<6;++i) {CHANGE(next.provenance[i].accepted_source="retained");}
    for(int i=0;i<2;++i) {
        CHANGE(next.break_policy.fields[i].known=true);
        CHANGE(next.break_policy.fields[i].computed=1);
        CHANGE(next.break_policy.fields[i].reason=BreakPolicyReason::source_limit);
        CHANGE(next.break_policy.fields[i].authored_property="alias");
        CHANGE(next.break_policy.fields[i].provenance.inherited=true);
    }
    for(auto member:{&TypographyEvidence::family_state,&TypographyEvidence::style_state,
        &TypographyEvidence::spacing_state,&TypographyEvidence::size_state,
        &TypographyEvidence::weight_state,&TypographyEvidence::line_height_state}) {
        for(auto state:{TypographyFieldState::unknown,TypographyFieldState::known,TypographyFieldState::unsupported}) {
            auto prior=p;prior.*member=state;auto record=old;
            record.prepared_evidence=std::make_shared<const TypographyEvidence>(prior);record.evidence=prior;
            for(auto next_state:{TypographyFieldState::unknown,TypographyFieldState::known,TypographyFieldState::unsupported}) {
                auto next=prior;next.*member=next_state;
                CHECK(prepared_typography_changed(&record,next)==(state!=next_state));
                CHECK(final_typography_changed(&record,next,a)==(state!=next_state));
            }
        }
    }
    for(int i=0;i<6;++i) {
        CHANGE(next.provenance[i].declaration=true);CHANGE(next.provenance[i].inherited=true);
        CHANGE(next.provenance[i].important=true);CHANGE(next.provenance[i].inline_style=true);
        CHANGE(next.provenance[i].layer=1);CHANGE(next.provenance[i].source_order=1);
        CHANGE(next.provenance[i].declaration_order=1);CHANGE(next.provenance[i].resolved_source="x");
    }
    // Equal used_px is not equal semantic line-height or future dependency.
    auto lh=p;lh.size_px=16;lh.line_height_used_px=32;lh.line_height_kind=TypographyLineHeightKind::number;lh.line_height_value=2;
    auto lh_old=old;lh_old.prepared_evidence=std::make_shared<const TypographyEvidence>(lh);lh_old.evidence=lh;
    auto px=lh;px.line_height_kind=TypographyLineHeightKind::absolute_css_px;px.line_height_value=32;
    CHECK(prepared_typography_changed(&lh_old,px));CHECK(final_typography_changed(&lh_old,px,a));
    px=lh;px.line_height_dependencies=1;CHECK(prepared_typography_changed(&lh_old,px));CHECK(final_typography_changed(&lh_old,px,a));
    auto families=p;families.families={{"A",false},{"serif",true}};
    auto family_old=old;family_old.prepared_evidence=std::make_shared<const TypographyEvidence>(families);
    auto changed=families;std::swap(changed.families[0],changed.families[1]);
    CHECK(prepared_typography_changed(&family_old,changed));
    changed=families;changed.families[0].generic=true;CHECK(prepared_typography_changed(&family_old,changed));
    // F equality cannot erase a P difference masked by final OR 4.
    old.evidence.coverage_gaps=5;auto masked=p;masked.coverage_gaps=5;
    CHECK(prepared_typography_changed(&old,masked));
    CHECK(!final_typography_changed(&old,masked,a));
    for(auto member : {&style_source_accounting_s::source_bytes,&style_source_accounting_s::declarations,
        &style_source_accounting_s::rules,&style_source_accounting_s::compiled_rules,
        &style_source_accounting_s::expanded_declarations,&style_source_accounting_s::compiled_bytes}) {
        auto next=a;next.*member=13;
        CHECK(!final_typography_changed(&old,masked,next));

    }
    auto validity=a;validity.losses=2;
    old.inputs=std::make_shared<const style_source_accounting_s>(validity);
    validity.losses=8;CHECK(final_typography_changed(&old,masked,validity));
    validity.losses=0x80000002u;CHECK(final_typography_changed(&old,masked,validity));
    validity=*old.inputs;validity.inputs_accounted=false;CHECK(final_typography_changed(&old,masked,validity));
    validity=*old.inputs;validity.external_pending=true;CHECK(final_typography_changed(&old,masked,validity));
    old.inputs=std::make_shared<const style_source_accounting_s>(a);
    validity=a;validity.external_pending=true;CHECK(final_typography_changed(&old,masked,validity));
    validity=a;validity.add(validity.source_bytes,style_source_accounting_s::max_source_bytes,style_source_accounting_s::max_source_bytes);
    CHECK(!final_typography_changed(&old,masked,validity));
    validity.add(validity.source_bytes,1,style_source_accounting_s::max_source_bytes);
    CHECK(validity.source_bytes==style_source_accounting_s::max_source_bytes);
    CHECK(final_typography_changed(&old,masked,validity));
    old.inputs=std::make_shared<const style_source_accounting_s>(validity);
    CHECK(!final_typography_changed(&old,masked,validity));
}

// Discriminant cases run independently through AETHER_ASSERT_CASE, so an
// unrelated earlier assertion cannot be misclassified as the intended kill.
static void named_units() {
 ss::run("unit-p-masked",[]{
    TypographyEvidence p;TypographyRecord old;style_source_accounting_s a;
    old.prepared_evidence=std::make_shared<const TypographyEvidence>(p);
    old.evidence=p;old.evidence.coverage_gaps=5;
    old.inputs=std::make_shared<const style_source_accounting_s>(a);
    auto next=p;next.coverage_gaps=5;
    SS_PRECONDITION("F-identical",old.evidence==next);
    SS_CHECK("P-change",prepared_typography_changed(&old,next));
    SS_CHECK("F-no-change",!final_typography_changed(&old,next,a));
 });
 const char* ids[]={"unit-loss-reason","unit-accounted","unit-pending"};
 for(int kind=0;kind<3;++kind)ss::run(ids[kind],[&]{
    TypographyRecord old;style_source_accounting_s a;
    if(kind==0)a.losses=2;
    old.inputs=std::make_shared<const style_source_accounting_s>(a);
    auto next=a;if(kind==0)next.losses=8;else if(kind==1)next.inputs_accounted=false;else next.external_pending=true;
    SS_CHECK("validity-change",final_typography_changed(&old,old.evidence,next));
 });
 ss::run("unit-used-px",[]{
    TypographyRecord old;style_source_accounting_s a;TypographyEvidence p;
    p.size_px=16;p.line_height_used_px=32;p.line_height_kind=TypographyLineHeightKind::number;p.line_height_value=2;
    old.prepared_evidence=std::make_shared<const TypographyEvidence>(p);old.evidence=p;
    old.inputs=std::make_shared<const style_source_accounting_s>(a);
    auto next=p;next.line_height_kind=TypographyLineHeightKind::absolute_css_px;next.line_height_value=32;
    SS_PRECONDITION("used-px-equal",next.line_height_used_px==p.line_height_used_px);
    SS_CHECK("P-kind-change",prepared_typography_changed(&old,next));
    SS_CHECK("F-kind-change",final_typography_changed(&old,next,a));
 });
}
int main(){ss::run("unit-broad",broad_units);named_units();return ss::finish();}

# Test-only observed hooks correction

Source-only incremental recovery: candidate and baseline versions of one test file, plus repository-relative patch and source hashes. The baseline is the immediately preceding diagnostic test variant, not necessarily the previously published C3 test. Verify the before hash before applying the patch. The included baseline file permits exact isolated patch restoration; neither overlay is a complete repository.

The test replaces fixed hook-row assumptions with observed DOM-bound node identity and lifecycle tracking, checks prepared/final/frozen observations and validates failure prefixes. No product source is included or modified. This archive does not assert compilation, behavioral correctness, complete coverage or test success.

Restore compatible remaining C3 sources separately. Treat the candidate as unvalidated until independently reviewed and tested under a separately authorized workflow. No execution permission is conveyed.

Packaging checks cover stable bytes, hashes, exact patch restoration and archive integrity only. No private records, internal machine paths, environment/session data, logs or binaries are included.

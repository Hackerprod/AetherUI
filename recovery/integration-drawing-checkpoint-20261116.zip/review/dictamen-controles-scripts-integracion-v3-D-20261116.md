# D: PASS de corrección estática y controles de scripts únicamente

2026-11-16. Complementa, sin sustituir, `dictamen-integracion-local-dibujo-v3-D-20261116.md`. Los dos hallazgos de scripts quedan corregidos en el delta revisado. **Build funcional integrado sigue BLOCKED; CMake/C++/renderer NOT_RUN.**

Propuesta C `1fe9ab4710056ea026c6fb37ec2947ee76f604cb74806fe6ff879d5061d8b0ec` revisada y aprobada antes de materializar. Acta de materialización `80bee2a1ab00f8b032ed258ea198565a37f576d13bdfd909fddc25af85f26782` y parche corregido `f4f9bcec4a60e5034835b3305fc2c00a636f0285d8c89338ca72da862f2a20a2` verificados. D comprobó delta exacto de 12 archivos respecto al sello previo: mapeo contractual cerrado, caso A-B y documentación. Expected/renderer/helper/CMake/defaults intactos. Fixtures nuevas idénticas a A-A, recursos idénticos a exact-B. PASS previo a tests comunicado a coordinación.

## Evidencia de pruebas revisada

Acta C de tests SHA256 `e3411e210263786784a194de67cc74fb578d6e4f66fd0473dc6bb96234ee837e` confirmado. Conductor `e194c4833bdae9891c0be3827c56baa7d0506ef2e3ef473c2832005b2ab2228c` leído; usa exclusivamente stubs Python copiando referencias, nunca un binario renderer.

Manifiesto final `3b1e3cbe6185dd0e86f57b5b9d22984d28a262bda43c8bbd30bf322750613b75`: 171/171 archivos verificados; manifiesto interior: 168/168. Árbol materializado: 61/61 hashes intactos después de tests.

Los 17 procesos/checks reportados contienen 6 éxitos y 11 fallos negativos esperados. D leyó stderr: fallos de longitud, comparación íntegra o argumento inválido ocurren donde corresponde, no por archivos o ejecutables ausentes. Los tres contratos pasan con su fixture propio, detectan truncado y mutación; v2 rechaza v1. Argumentos inválidos no dejan marcador de invocación de stub.

Demo correcta: cinco casos, siete outputs primarios A/B y seis expected únicos. D comparó nuevamente buffers completos con expected y retained/missing. Mutaciones A.B y B.B alteran exactamente un byte de su buffer y fallan respectivamente en A-B y A-B sequence B. OFF conserva comparación fraccional diferenciada, sin declararse exacto. AST y diff-check reportados PASS.

**PASS_SCRIPT_CONTROL_ONLY.** Prueba detección/ruteo de scripts, no HTML/layout/snapshot/prepare/raster, exactitud ni velocidad del renderer. Los outputs son simulaciones desde expected y no constituyen oráculo independiente nuevo. PNG generado tampoco es validación visual/numeral del renderer.

No repetir estos checks por ritual. Próximo gate útil sigue siendo disponer de CMake bajo autorización vigente, ejecutar builds normales separados OFF/ON, verificar fuentes/flags/objetos y completar regresiones/corpus pertinente/operacional pendientes. Sin autorización implícita para instalar, publicar, activar defaultON o aceptar producto.

D sólo leyó/comparó evidencia y escribió este dictamen; no repitió tests ni ejecutó build/render. Sin cambios productivos, red, GitHub, Actions, otra PC o instalación. Se conservan límites y fallos históricos del dictamen anterior.

# D: integración parcial BLOCKED; aceptación FAIL, ejecución NOT_RUN

2026-11-16. Revisión independiente del delta local C. **No PASS de integración.** El bloqueo de CMake es real y la entrega conserva honestamente los resultados dinámicos como NOT_RUN. Además hay dos defectos estáticos de cobertura/referencia que deben corregirse antes del cierre.

## Identidad y custodia verificadas

Checkout `aetherui-drawing-integration-C-20261116-01`, rama `local/drawing-exact-v3`, HEAD `22fba13df2dc7775d4e091dac432c3e4b2960c46`, confirmados mediante Git local. Sin consulta del remoto.

Acta C SHA256 `9d2ba456f004a2e3e7138c3d0282d73e1889820f1b8c4be55f1a0f449e433660` confirmado. Parche `e8b4b65e6d9fa4aad80e469fa3b04ad9132ac7e829f18570db5fcdca6c31a771` coincide byte por byte con `git diff --binary` actual. Manifiesto de outputs verificado: 10/10 archivos; manifiesto de cambios: 53/53. `git diff --check` limpio.

D reconstruyó por separado las dos selecciones retirando únicamente los cuatro guards nuevos. OFF coincide literalmente con renderer S1-I (`4214ccd03e118f265de913d9ee641a4a26985293c0313091499ac9f8ba18265c`); ON con candidato revisado (`a9dfae109b9b588064dd42824469276c5f1afce3cfd5ecec8557612884da2a1d`). Esto demuestra identidad de fuente seleccionada, no identidad de objetos, flags efectivos ni ejecución.

## Revisión estática

PASS acotado: dos opciones OFF por defecto; selección exacta scoped al target privado; un renderer, no engine HTML nuevo; pipeline real y recursos locales; no cambio de expected observado ni xfail genérico. `aether_core` no incorpora el renderer: el cambio integra un target privado opt-in, no convierte el producto instalado en renderer funcional. Esta distinción está documentada.

ON exige detección unsigned128 y error de configuración si falta. El selector no128 sólo comprueba el helper con macro ausente, no compila el renderer completo ni valida MSVC/ARM. Configuración real ON sin unsigned128 sigue NOT_RUN. No se admite extrapolar portabilidad. La copia estática recompila fuentes, por lo que la literalidad no autoriza reusar campañas de otros objetos.

### Hallazgos adicionales

1. **Referencia v2 incorrecta en el comprobador genérico.** `native/tests/drawing_exact_v3/check_contract.py:7` selecciona referencia v1 para toda versión distinta de 3, incluida 2. D confirmó que v1 y v2 congelados difieren. No afecta las selecciones CTest actuales (sólo 1/3), pero invalida usar el wrapper con v2 y hace engañoso su mensaje de versión. Corregir mapeo explícito 1/2/3 y rechazar versiones desconocidas, sin cambiar referencias.
2. **Demo F parcial frente a referencias empaquetadas.** `native/examples/drawing_exact/run_demo.py:15-21` comprueba A.A, B.A, exact.A y exact.B; la secuencia adicional vuelve a B.A. No ejecuta ni compara A.B/B.B, aunque ambas referencias viajan en el paquete. No declarar restaurada la matriz completa A/B de recursos por incluir sus buffers. Añadir los casos faltantes con recursos locales y comparación completa, o delimitar explícitamente esta demo como subconjunto y completar la matriz en la campaña requerida. La suite actual no puede dar evidencia de esos dos casos.

No se modificó producto para arreglar estos hallazgos. Son defectos estáticos identificados, no fallos runtime observados.

## Bloqueo y matriz de aceptación

D comprobó `command -v cmake` sin resultado y leyó el fallo de configuración `/bin/bash: line 34: cmake: command not found`. No ejecutó instalación ni reemplazó CMake con compilación manual. El fallo 127 ocurre antes de configurar: no demuestra defecto sintáctico de CMake ni fallo del renderer.

- Build normal default/core: NOT_RUN.
- OFF build, smoke y contrato v1: NOT_RUN.
- ON build, helper/count, v3 y demo F: NOT_RUN.
- Detección efectiva y configuración no128: NOT_RUN.
- 28 C++ + 28 HTML, corpus pertinente, éxito/cancelación operacional: NOT_RUN; aún no empaquetados en este delta.
- V1/V2 contra ON: FAIL histórico preservado, no nuevos ensayos.
- Integración aceptada: **FAIL por gates no satisfechos / BLOCKED por herramienta ausente**, no FAIL numérico observado.

CMake disponible no bastará por sí solo para cerrar: corregir los hallazgos, configurar OFF/ON en directorios separados, construir y ejecutar, registrar fuentes/flags/objetos efectivos y completar campaña final. Ningún reuso de resultados dinámicos queda aprobado por D. No instalar bajo el plan vigente: hace falta entorno preaprovisionado o revisión autorizada de esa restricción.

Se conserva la decisión posterior: aceptar bytes v3 y fallback documentado para plataformas realmente verificadas, o mantener contrato antiguo. No perpetuar experimental por exigir exactitud universal, pero tampoco promover un diff aún no construido. Sin aceptación main/defaultON/producto/release.

coverage_complete=false; fuera de dominio y PERFORMANCE/HOST_ISOLATION/REAL_WORKLOAD/PERF_BUDGET NOT_VERIFIED; Windows/MSVC/ARM NOT_VERIFIED; Direct2D NOT_RUN/NOT_VERIFIED; LSan NO GO histórico.

Trabajo D: lecturas locales, hashes, reducción textual y checks Git. Única escritura: este dictamen. Sin build/render/test dinámico, red, GitHub, Actions, push, PR, instalación, otra PC, cambios de permisos ni cambios productivos.

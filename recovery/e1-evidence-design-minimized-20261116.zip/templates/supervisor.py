#!/usr/bin/env python3
"""Ordinary E1 candidate. NOT_RUN. No isolation or hermeticity claim."""
import time
START=time.monotonic()
import resource,signal
for which,wanted in ((resource.RLIMIT_AS,2147483648),(resource.RLIMIT_CORE,0)):
 soft,hard=resource.getrlimit(which);n=min([wanted]+[v for v in (soft,hard) if v!=resource.RLIM_INFINITY]);resource.setrlimit(which,(n,n))
def alarm(*unused):raise RuntimeError('OUTER_ABSOLUTE_DEADLINE')
signal.signal(signal.SIGALRM,alarm);signal.setitimer(signal.ITIMER_REAL,max(.001,START+4800-time.monotonic()))
import argparse,hashlib,importlib.util,json,os,subprocess,sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
PYTHON='/RELOCATE/python3'
def require(ok,why):
 if not ok:raise RuntimeError(why)
def bootstrap_hash(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  while True:
   require(time.monotonic()<START+120,'BOOTSTRAP_DEADLINE');require(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024<=268435456,'BOOTSTRAP_RSS')
   b=f.read(1048576)
   if not b:break
   h.update(b)
 return h.hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--manifest-sha256',required=True);ap.add_argument('--worker',action='store_true');ap.add_argument('--origin',type=float);args=ap.parse_args()
 require(bootstrap_hash(HERE/'manifest.json')==args.manifest_sha256,'MANIFEST_CHANGED');manifest=json.loads((HERE/'manifest.json').read_text())
 require({p.name for p in HERE.iterdir()}==set(manifest['files'])|{'manifest.json'},'PACKAGE_SET')
 for name,h in manifest['files'].items():
  q=HERE/name;require(q.is_file() and not q.is_symlink() and bootstrap_hash(q)==h,'PACKAGE_CHANGED:'+name)
 spec=importlib.util.spec_from_file_location('limits_support',HERE/'limits_support.py');a=importlib.util.module_from_spec(spec);spec.loader.exec_module(a)
 origin=args.origin if args.worker else START;require(origin is not None,'ORIGIN');a.DEADLINE=origin+4500
 recipe=a.read_json(HERE/'recipe.json');lim=recipe['limits'];root=Path(recipe['run_root'])
 # Preparation bytes are intentionally not runnable until a fresh reviewed gate.
 require(recipe['execution_ready'] is True and recipe['state']=='APPROVED_ORDINARY_ONE_RUN','EXECUTION_NOT_AUTHORIZED')
 require(recipe['driver_invocations']==1 and recipe['driver_resolves']==6 and recipe['retries']==0,'SCOPE')
 require([x['id'] for x in recipe['phases']]==['configure','build','E1','analyze'],'PHASE_SET')
 inputs=a.read_json(HERE/'selected-inputs.json');source=Path(recipe['source_root'])
 def custody(unused=None):
  for name,h in manifest['files'].items():a.check(a.digest(HERE/name)==h,'PACKAGE_CHANGED:'+name)
  a.check(a.tree_digest(source)==recipe['source_tree_sha256'],'SOURCE_CHANGED')
  for rec in inputs['files']:a.check(str(Path(rec['path']).resolve(strict=True))==rec['canonical'] and a.digest(rec['path'])==rec['sha256'],'SELECTED_INPUT_CHANGED')
 a.custody=custody
 for sig in (signal.SIGTERM,signal.SIGINT,signal.SIGHUP):signal.signal(sig,a.cancel)
 a.subreaper();custody();a.safe_chain(root.parent)
 def config_check(record=True):
  values={}
  for line in (root/'build/CMakeCache.txt').read_text().splitlines():
   if line and not line.startswith(('#','//')) and ':' in line and '=' in line:values[line.split(':',1)[0]]=line.split('=',1)[1]
  expected={arg[2:].split('=',1)[0]:arg.split('=',1)[1] for arg in recipe['phases'][0]['argv'] if arg.startswith('-D')}
  expected.update(CMAKE_GENERATOR='Unix Makefiles',CMAKE_HOME_DIRECTORY=str(source))
  for k,v in expected.items():a.check(values.get(k)==v,'EFFECTIVE_CONFIG:'+k)
  for k in ('CMAKE_TOOLCHAIN_FILE','CMAKE_C_COMPILER_LAUNCHER','CMAKE_CXX_COMPILER_LAUNCHER'):a.check(not values.get(k),'UNEXPECTED_LAUNCHER_TOOLCHAIN:'+k)
  commands=a.read_json(root/'build/compile_commands.json',16777216)
  rows=[x for x in commands if x['file'].endswith(('style_runtime_core.cpp','test_typography_e1_capture.cpp','e1_capture.cpp'))]
  a.check(len(rows)==3,'DIAGNOSTIC_COMPILE_SET')
  for row in rows:
   cmd=row.get('command','');a.check('-DAETHER_DIAGNOSTIC_E1=1' in cmd and '-DNDEBUG' not in cmd and '-fplugin' not in cmd and '-include' not in cmd,'DIAGNOSTIC_FLAGS')
  if record:a.atomic_json(root/'effective-config.json',expected)
 frozen={};link_records=[]
 def library_check(first=False):
  nonlocal frozen,link_records
  build=root/'build';policy=recipe['soname_policy'];links=[a.soname_link(build/name,build,policy) for name in policy['links']]
  paths=[build/'aether_typography_e1_capture',build/policy['regular_target']]
  current={str(p):a.digest(p) for p in paths}
  for p in paths:a.check(p.is_file() and not p.is_symlink(),'BUILD_FILE_TYPE')
  interp,needed,search=a.elf(paths[0])
  a.check('libaether_core.so.0' in needed,'CORE_NEEDED_MISSING')
  expanded=[v.replace('${ORIGIN}',str(build)).replace('$ORIGIN',str(build)) for v in search]
  a.check(str(build) in expanded and all('$' not in v for v in expanded),'CORE_SEARCH_PATH')
  if first:
   frozen=current;link_records=links;a.atomic_json(root/'built-library.json',dict(files=frozen,links=links,needed=needed,search=search,scope='SELECTED_CORE_NOT_DEPENDENCY_CLOSURE'))
  else:a.check(current==frozen and links==link_records,'BUILT_LIBRARY_CHANGED')
 def core_maps(rows):
  if not frozen:return
  for row in rows:
   if not a.same(row):continue
   try:lines=Path('/proc',str(row['pid']),'maps').read_text().splitlines()
   except FileNotFoundError:continue
   for line in lines:
    parts=line.split(None,5)
    if len(parts)==6 and 'libaether_core.so' in parts[5]:a.check(parts[5]==str(root/'build'/recipe['soname_policy']['regular_target']),'WRONG_CORE_MAPPING')
 a.maps_observer=core_maps
 marker_sequence=0
 def mark_phase(phase,active):
  nonlocal marker_sequence
  marker_sequence+=1
  value=dict(sequence=marker_sequence,phase_id=phase,active=active,run_root=str(root))
  data=json.dumps(value,separators=(',',':')).encode();a.check(len(data)<=1024,'PHASE_MARKER_QUOTA')
  temp=root/'phase-marker.pending';fd=os.open(temp,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
  with os.fdopen(fd,'wb') as f:f.write(data);f.flush();os.fsync(f.fileno())
  os.replace(temp,root/'phase-marker.json')
 marker_seen=None
 def announced_phase():
  nonlocal marker_seen
  path=root/'phase-marker.json'
  try:value=a.read_json(path,1024)
  except FileNotFoundError:return None
  except Exception:return None # Invalid/unavailable marker never enables tolerance.
  phases=['configure','build','E1','analyze'];seq=value.get('sequence');pid=value.get('phase_id');active=value.get('active')
  if type(seq) is not int or not 1<=seq<=8 or type(active) is not bool or value.get('run_root')!=str(root):return None
  if pid!=phases[(seq-1)//2] or active!=(seq%2==1):return None
  if marker_seen is not None:
   if seq<marker_seen['sequence'] or (seq==marker_seen['sequence'] and value!=marker_seen):return None
  marker_seen=value
  return pid if active and pid in ('configure','build') else None
 if args.worker:
  a.safe_chain(root);known={};primary=None;phases=[];latch=None;secondary=[];phase_marker_inactive_error=None
  try:
   for phase in recipe['phases']:
    a.DEADLINE=origin+lim['absolute_work_seconds'];a.checkpoint()
    if phase['id']=='E1':config_check(False);library_check(True);latch=time.monotonic()+900
    if phase['id']=='analyze':
     library_check();capture=root/'E1.bin';a.check(capture.stat().st_size<=3145728,'CAPTURE_SIZE');capture_sha=a.digest(capture)
     a.check((root/'E1.stdout').read_bytes()==b'E1_CAPTURE_WRITTEN_NOT_PRODUCT_PASS\n','DRIVER_MARKER')
    mark_phase(phase['id'],True)
    invoke_error=None;invoke_traceback=None
    try:result=a.invoke(phase,recipe,{}, {},origin,latch,args.manifest_sha256)
    except BaseException as ex:invoke_error=ex;invoke_traceback=ex.__traceback__
    # Exactly one inactive attempt. Its failure cannot replace invoke's cause.
    inactive_sequence=marker_sequence+1
    try:mark_phase(phase['id'],False)
    except BaseException as ex:
     raw=str(ex).encode('utf-8','backslashreplace')
     phase_marker_inactive_error=dict(component='phase_marker_inactive',phase=phase['id'],sequence_attempted=inactive_sequence,error_type=type(ex).__name__,message=raw[:4096].decode('utf-8','backslashreplace'),message_truncated=len(raw)>4096,message_original_bytes=len(raw),role='secondary' if invoke_error is not None else 'primary_cause')
    if invoke_error is not None:raise invoke_error.with_traceback(invoke_traceback)
    if phase_marker_inactive_error is not None:raise a.Stop('PHASE_FINALIZATION_FAILED')
    phases.append(result)
    if phase['id']=='configure':config_check()
    if phase['id']=='E1':library_check()
    if phase['id']=='analyze':
     library_check();a.check(a.digest(root/'E1.bin')==capture_sha,'CAPTURE_MUTATED');answer=a.read_json(root/'analysis.json',262144);a.check(answer.get('status')=='CAPTURE_ORACLE_VALID_NOT_PRODUCT_PASS','ORACLE_STATUS')
  except BaseException as ex:primary=type(ex).__name__+':'+str(ex)
  a.DEADLINE=origin+4800;closure=a.cleanup(os.getpid(),known,min(origin+4800,time.monotonic()+10))
  try:
   a.check(not closure['remaining'] and not a.discover(os.getpid(),known),'FINAL_TREE_WRITERS')
   a.check(a.size_tree(root/'build',recipe['soname_policy'],observed_by='worker',tree='build')+a.size_tree(root/'tmp',observed_by='worker',tree='tmp')<=2147483648,'FINAL_TREE_QUOTA')
   custody()
  except BaseException as ex:secondary.append(dict(error=str(ex),special_file=getattr(ex,'descriptor',None)))
  ok=primary is None and not secondary and not closure['remaining'] and len(phases)==4
  a.atomic_json(root/'worker-final.json',dict(status='CAPTURE_ORACLE_VALID_NOT_PRODUCT_PASS' if ok else 'NOT_PROVEN',primary=primary,secondary=secondary,phase_marker_inactive_error=phase_marker_inactive_error,closure=closure,phase_ids=[x['id'] for x in phases],tree_samples=a.sample_state('worker'),network_isolation='NOT_PROVEN',hermeticity='NOT_PROVEN',noninterference='NOT_PROVEN'))
  return 0 if ok else 2
 # Ordinary preflight, no network isolation or attempt to obtain denied capability.
 a.check(not root.exists() and not root.is_symlink(),'ROOT_EXISTS')
 fs=os.statvfs(root.parent);a.check(fs.f_bavail*fs.f_frsize>=lim['free_disk_preflight_bytes'],'DISK_PREFLIGHT')
 mem=dict(line.split(':',1) for line in Path('/proc/meminfo').read_text().splitlines());a.check(int(mem['MemAvailable'].split()[0])*1024>=lim['memavailable_preflight_bytes'],'MEMORY_PREFLIGHT')
 root.mkdir(mode=0o700)
 for name in ('build','tmp','home'):(root/name).mkdir()
 stdout=open(root/'worker.stdout','xb',buffering=0);stderr=open(root/'worker.stderr','xb',buffering=0)
 worker=subprocess.Popen([PYTHON,'-I','-B',str(HERE/'supervisor.py'),'--manifest-sha256',args.manifest_sha256,'--worker','--origin',str(origin)],cwd=root,env=recipe['environment'],stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,close_fds=True)
 known={};error=None;special_primary=None;special_secondary=None;summary=dict(samples=0,max_aggregate_rss=0,max_worker_rss=0,max_interval=0);last=None
 closing=False
 def observe():
  nonlocal last
  a.checkpoint();rows=a.discover(os.getpid(),known);unique={}
  for saved in rows+[a.proc(os.getpid())]:
   if saved is None:continue
   live=a.proc(saved['pid'])
   if live and live['start']==saved['start']:unique[(live['pid'],live['start'])]=live
  a.check(len(unique)<=64,'PROCESS_LIMIT');rss=sum(x['rss'] for x in unique.values());a.check(rss<=3221225472,'AGGREGATE_RSS')
  w=a.proc(worker.pid)
  if w:a.check(w['rss']<=268435456,'WORKER_RSS');summary['max_worker_rss']=max(summary['max_worker_rss'],w['rss'])
  phase=announced_phase() if not closing else None
  # During cleanup writers may still exist; avoid claiming a strict final sample until reaped.
  if not closing:a.check(a.size_tree(root/'build',recipe['soname_policy'],phase=phase,observed_by='runner',tree='build',mutable=phase is not None)+a.size_tree(root/'tmp',phase=phase,observed_by='runner',tree='tmp',mutable=phase is not None)<=2147483648,'DISK_QUOTA')
  a.check((root/'worker.stdout').stat().st_size+(root/'worker.stderr').stat().st_size<=4194304,'WORKER_STREAM_QUOTA')
  now=time.monotonic();summary['max_aggregate_rss']=max(summary['max_aggregate_rss'],rss);summary['samples']+=1
  if last is not None:summary['max_interval']=max(summary['max_interval'],now-last)
  last=now
 try:
  while worker.poll() is None:observe();time.sleep(.1)
 except BaseException as ex:error=str(ex);special_primary=getattr(ex,'descriptor',None)
 a.DEADLINE=origin+4800;closing=True
 def closing_observer():
  nonlocal error,special_secondary
  try:observe()
  except BaseException as ex:
   if special_secondary is None:special_secondary=getattr(ex,'descriptor',None)
   if error is None:error=str(ex)
 closure=a.cleanup(os.getpid(),known,min(origin+4800,time.monotonic()+10),observer=closing_observer)
 raw=closure.get('reaped_statuses',{}).get(str(worker.pid))
 if raw is not None:worker.returncode=os.waitstatus_to_exitcode(raw)
 rc=worker.poll();stdout.close();stderr.close();secondary=[]
 try:
  a.check(rc is not None and not closure['remaining'] and not a.discover(os.getpid(),known),'FINAL_TREE_WRITERS')
  a.check(a.size_tree(root/'build',recipe['soname_policy'],observed_by='runner',tree='build')+a.size_tree(root/'tmp',observed_by='runner',tree='tmp')<=2147483648,'FINAL_TREE_QUOTA')
  custody()
 except BaseException as ex:secondary.append(dict(error=str(ex),special_file=getattr(ex,'descriptor',None)))
 a.atomic_json(root/'runner-final.json',dict(worker_rc=rc,primary=error,secondary=secondary,special_file_primary=special_primary,special_file_closure=special_secondary,closure=closure,worker_reaped=rc is not None,rss_summary=summary,tree_samples=a.sample_state('runner'),network_isolation='NOT_PROVEN',hermeticity='NOT_PROVEN',noninterference='NOT_PROVEN',pre_runner_coverage='NOT_PROVEN'))
 return 0 if rc==0 and error is None and not secondary and not closure['remaining'] else 2
if __name__=='__main__':sys.exit(main())

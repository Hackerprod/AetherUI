# Selected reviewed limits/closure utilities, not operationally certified.
import ctypes,hashlib,json,os,resource,selectors,signal,stat,struct,subprocess,time
from pathlib import Path
MAX_META=65536
DEADLINE=float('inf')
CANCEL=False
class Stop(RuntimeError):pass
class SpecialFileStop(Stop):
 def __init__(self,descriptor):
  super().__init__('OUTPUT_TREE_SPECIAL_FILE');self.descriptor=descriptor
def special_descriptor(path,root,st,phase,observed_by,tree):
 raw=str(path.relative_to(root)).encode('utf-8','surrogateescape')
 prefix=raw[:4096].decode('utf-8','backslashreplace')
 kind=stat.S_IFMT(st.st_mode)
 names={stat.S_IFIFO:'fifo',stat.S_IFSOCK:'socket',stat.S_IFCHR:'character_device',stat.S_IFBLK:'block_device'}
 return dict(code='OUTPUT_TREE_SPECIAL_FILE',phase=phase,phase_status='EXPLICIT_SPEC_ID' if phase is not None else ('NOT_TRACKED_BY_RUNNER' if observed_by=='runner' else 'NOT_ASSOCIATED_WITH_ACTIVE_PHASE'),observed_by=observed_by,tree=tree,relative_path=prefix,path_truncated=len(raw)>4096,path_original_bytes=len(raw),st_mode=st.st_mode,file_type_bits=kind,file_type=names.get(kind,'unknown'),st_dev=st.st_dev,st_ino=st.st_ino)

def check(ok,why):
 if not ok:raise Stop(why)
def mono():return time.monotonic()
def checkpoint(*,rss_provider=None):
 check(mono()<DEADLINE,'PROTECTED_IO_DEADLINE')
 check(not globals().get('CANCEL',False),'CANCELLED')
 # Self RSS is checked during custody as well as workload monitoring. Linux
 # ru_maxrss catches a peak between checkpoints; this is observation, not AS.
 if rss_provider is None:
  peak=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024;row=proc(os.getpid());current=row['rss'] if row else None
 else:peak,current=rss_provider()
 check(peak<=268435456,'SUPERVISOR_RSS_PEAK_STOP')
 check(current is not None and current<=268435456,'SUPERVISOR_RSS_STOP')
def digest(path):
 h=hashlib.sha256()
 with open(path,'rb') as f:
  while True:
   checkpoint();b=f.read(1048576)
   if not b:break
   h.update(b)
 return h.hexdigest()
def unique(items):
 d={}
 for k,v in items:
  check(k not in d,'DUPLICATE_JSON_KEY');d[k]=v
 return d
def read_json(path,limit=MAX_META):
 checkpoint();p=Path(path);s=p.lstat();check(stat.S_ISREG(s.st_mode) and s.st_size<=limit,'JSON_TYPE_QUOTA')
 with p.open('rb') as f:value=json.loads(f.read(limit+1),object_pairs_hook=unique)
 checkpoint();return value
def safe_chain(path):
 p=Path(path);check(p.is_absolute(),'ABSOLUTE_REQUIRED')
 for x in reversed([p,*p.parents]):
  s=x.lstat();check(not stat.S_ISLNK(s.st_mode),'UNAPPROVED_PATH_SYMLINK')
 return p
def atomic_json(path,value,limit=MAX_META):
 raw=json.dumps(value,sort_keys=True,separators=(',',':')).encode()+b'\n';check(len(raw)<=limit,'METADATA_QUOTA')
 p=Path(path);tmp=p.with_name(p.name+'.tmp');fd=os.open(tmp,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 try:
  with os.fdopen(fd,'wb') as f:f.write(raw);f.flush();os.fsync(f.fileno())
  check(not p.exists(),'OUTPUT_ALREADY_EXISTS');os.rename(tmp,p)
 finally:
  # No deletion of evidence, even when a partial temporary remains.
  pass

def bounded_walk(root,ordered=False):
 # Avoid unbounded comprehensions during authority scans. Check per entry.
 entries=[]
 for item in Path(root).rglob('*'):
  checkpoint();check(len(entries)<100000,'TREE_ENTRY_QUOTA');entries.append(item)
 if ordered:entries.sort(key=lambda p:str(p.relative_to(root)))
 checkpoint();return entries

def tree_digest(root):
 p=safe_chain(root);h=hashlib.sha256()
 for f in bounded_walk(p,ordered=True):
  checkpoint();s=f.lstat();check(not stat.S_ISLNK(s.st_mode),'SOURCE_SYMLINK')
  if stat.S_ISREG(s.st_mode):h.update(str(f.relative_to(p)).encode()+b'\0'+digest(f).encode()+b'\n')
  else:check(stat.S_ISDIR(s.st_mode),'SOURCE_SPECIAL_FILE')
 return h.hexdigest()
def proc(pid):
 try:
  raw=Path('/proc',str(pid),'stat').read_text();v=raw[raw.rfind(')')+2:].split()
  return dict(pid=int(pid),ppid=int(v[1]),start=v[19],state=v[0],rss=int(v[21])*os.sysconf('SC_PAGE_SIZE'))
 except (FileNotFoundError,ProcessLookupError):return None
def same(row):
 p=proc(row['pid']);return bool(p and p['start']==row['start'])
def discover(root,known):
 rows={}
 for p in Path('/proc').iterdir():
  if p.name.isdigit():
   x=proc(int(p.name))
   if x:rows[x['pid']]=x
 ids={root};change=True
 while change:
  change=False
  for pid,x in rows.items():
   if x['ppid'] in ids and pid not in ids:ids.add(pid);change=True
 for pid in ids-{root}:known[(pid,rows[pid]['start'])]=rows[pid]
 return [x for x in known.values() if same(x)]
def send_verified(row,sig):
 if not same(row):return False
 try:fd=os.pidfd_open(row['pid'])
 except ProcessLookupError:return False
 try:
  if same(row):signal.pidfd_send_signal(fd,sig,None,0);return True
 except ProcessLookupError:return False
 finally:os.close(fd)
 return False

def subreaper():
 libc=ctypes.CDLL(None,use_errno=True);check(libc.prctl(36,1,0,0,0)==0,'SUBREAPER_UNAVAILABLE')
def tighten(which,wanted):
 soft,hard=resource.getrlimit(which)
 values=[wanted]+[x for x in (soft,hard) if x!=resource.RLIM_INFINITY]
 target=min(values);resource.setrlimit(which,(target,target));return target

def soname_link(path,build_root,policy):
 root=Path(build_root);p=Path(path);check(p.parent==root,'SONAME_LOCATION')
 allowed=policy['links'];check(p.name in allowed,'SONAME_NOT_ALLOWED')
 observed=[];seen=set();current=p
 for _ in range(policy['max_chain']):
  checkpoint();check(current not in seen,'SONAME_CYCLE');seen.add(current)
  check(current.parent==root,'SONAME_PARENT_ESCAPE');safe_chain(root)
  st=current.lstat()
  if stat.S_ISREG(st.st_mode):
   check(current.name==policy['regular_target'],'SONAME_FINAL_NAME')
   return dict(path=str(p),chain=observed,resolved=str(current),device=st.st_dev,inode=st.st_ino)
  check(stat.S_ISLNK(st.st_mode),'SONAME_FINAL_NOT_REGULAR')
  target=os.readlink(current)
  check(current.name in allowed and target==allowed[current.name],'SONAME_TARGET_NOT_ALLOWED')
  check(target and not Path(target).is_absolute() and Path(target).name==target and target not in ('.','..'),'SONAME_TARGET_PATH')
  observed.append(dict(path=str(current),target=target,device=st.st_dev,inode=st.st_ino))
  current=root/target
 raise Stop('SONAME_CHAIN_LIMIT')

SAMPLE_STATE={}
def sample_state(observer):
 return SAMPLE_STATE.setdefault(observer,dict(vanished_total=0,omitted_details=0,details=[],trees={},fifo_observations=0,fifo_identities=[],fifo_max_per_sample=0,non_regular_observed=False))
def size_tree(root,soname_policy=None,*,phase=None,observed_by="runner",tree=None,mutable=False):
 # Only lstat of a yielded child may tolerate ENOENT. Enumeration/root errors fatal.
 import errno
 root=Path(root);checkpoint();before=root.lstat()
 check(stat.S_ISDIR(before.st_mode) and not stat.S_ISLNK(before.st_mode),'SAMPLE_ROOT_TYPE')
 state=sample_state(observed_by);name=tree or root.name
 ts=state['trees'].setdefault(name,dict(vanished_total=0,incomplete_streak=0,samples=0,last_complete=None,max_observed_bytes=0))
 total=0;missing=0;entries=0;fifo_count=0
 def walk(directory):
  nonlocal total,missing,entries,fifo_count
  with os.scandir(directory) as iterator:
   for entry in iterator:
    checkpoint();entries+=1;check(entries<=100000,'TREE_ENTRY_QUOTA');p=Path(entry.path)
    try:st=p.lstat()
    except FileNotFoundError as ex:
     if not (mutable and phase in ('configure','build') and ex.errno==errno.ENOENT):raise
     missing+=1;state['vanished_total']+=1;ts['vanished_total']+=1
     raw=str(p.relative_to(root)).encode('utf-8','surrogateescape')
     if len(state['details'])<8:state['details'].append(dict(tree=name,phase=phase,phase_source='EXPLICIT_SPEC_ID' if observed_by=='worker' else 'WORKER_ANNOUNCED',relative_path=raw[:256].decode('utf-8','backslashreplace'),path_truncated=len(raw)>256,path_original_bytes=len(raw),errno=2))
     else:state['omitted_details']+=1
     check(state['vanished_total']<=64,'MUTABLE_SAMPLE_ENOENT_BUDGET');continue
    if stat.S_ISLNK(st.st_mode):
     check(soname_policy is not None,'TMP_SYMLINK_FORBIDDEN');soname_link(p,root,soname_policy)
    elif stat.S_ISREG(st.st_mode):total+=st.st_size
    elif stat.S_ISDIR(st.st_mode):walk(p)
    elif stat.S_ISFIFO(st.st_mode) and mutable and phase=='build' and name=='tmp':
     # Metadata only: never open/read/write/hash/unlink this FIFO.
     state['non_regular_observed']=True;state['fifo_observations']+=1;fifo_count+=1
     state['fifo_max_per_sample']=max(state['fifo_max_per_sample'],fifo_count)
     check(state['fifo_observations']<=4096,'TMP_FIFO_OBSERVATION_BUDGET')
     raw=str(p.relative_to(root)).encode('utf-8','surrogateescape')
     path_hash=hashlib.sha256(raw).hexdigest() # Hash of path text, NOT object contents.
     identity=next((x for x in state['fifo_identities'] if x['st_dev']==st.st_dev and x['st_ino']==st.st_ino),None)
     if identity is None:
      check(len(state['fifo_identities'])<8,'TMP_FIFO_OBSERVATION_BUDGET')
      identity=dict(relative_path=raw[:256].decode('utf-8','backslashreplace'),path_truncated=len(raw)>256,path_original_bytes=len(raw),first_path_text_sha256=path_hash,st_mode=st.st_mode,file_type_bits=stat.S_IFMT(st.st_mode),file_type='fifo',st_dev=st.st_dev,st_ino=st.st_ino,phase=phase,phase_source='EXPLICIT_SPEC_ID' if observed_by=='worker' else 'WORKER_ANNOUNCED',observed_by=observed_by,encounters=0,path_different_from_first_count=0)
      state['fifo_identities'].append(identity)
     identity['encounters']+=1
     if identity['first_path_text_sha256']!=path_hash:identity['path_different_from_first_count']+=1
     # Neither identity nor filename proves producer or object continuity.
    else:raise SpecialFileStop(special_descriptor(p,root,st,phase if observed_by=='worker' else None,observed_by,name))
 walk(root);after=root.lstat()
 check(stat.S_ISDIR(after.st_mode) and not stat.S_ISLNK(after.st_mode) and (before.st_dev,before.st_ino)==(after.st_dev,after.st_ino),'SAMPLE_ROOT_REPLACED')
 ts['samples']+=1;ts['last_complete']=missing==0;ts['max_observed_bytes']=max(ts['max_observed_bytes'],total)
 # Each tree updates its streak once per whole traversal, not once per entry.
 ts['incomplete_streak']=ts['incomplete_streak']+1 if missing else 0
 check(ts['incomplete_streak']<=10,'MUTABLE_SAMPLE_INCOMPLETE_STREAK')
 checkpoint();return total

def cleanup(root,known,deadline,grace=5,*,observer=None):
 signals=[];reaped_statuses={};remaining=discover(root,known)
 for row in remaining:
  if send_verified(row,signal.SIGTERM):signals.append([row['pid'],row['start'],'TERM'])
 end=min(mono()+grace,deadline)
 while mono()<end:
  if observer is not None:observer()
  remaining=discover(root,known)
  for row in remaining:
   try:
    got,wait_status=os.waitpid(row['pid'],os.WNOHANG)
    if got:reaped_statuses[str(got)]=wait_status
   except (ChildProcessError,ProcessLookupError):pass
  if not any(same(r) for r in remaining):break
  time.sleep(.1)
 for row in discover(root,known):
  if send_verified(row,signal.SIGKILL):signals.append([row['pid'],row['start'],'KILL'])
 end=min(mono()+5,deadline)
 while mono()<end:
  if observer is not None:observer()
  for row in discover(root,known):
   try:
    got,wait_status=os.waitpid(row['pid'],os.WNOHANG)
    if got:reaped_statuses[str(got)]=wait_status
   except (ChildProcessError,ProcessLookupError):pass
  if not discover(root,known):break
  time.sleep(.1)
 return dict(signals=signals,remaining=discover(root,known),reaped_statuses=reaped_statuses)

CANCEL=False
def cancel(*unused):
 global CANCEL;CANCEL=True

def invoke(spec,recipe,pinned,outputs,origin,latch,approved_hash):
 custody_check=lambda: custody(approved_hash)
 maps_check=lambda rows: maps_observer(rows) # Selected core only; no exhaustive custody.
 # No retry. All output paths are exclusive and only within this new run root.
 global DEADLINE
 root=Path(recipe['run_root']);lim=recipe['limits']
 deadline=min(origin+lim['absolute_work_seconds'],mono()+spec['cap_seconds'],latch or float('inf'))
 DEADLINE=deadline;custody_check()
 check(not CANCEL and mono()<deadline,'SPAWN_STOP_OR_DEADLINE')
 stdout=root/spec['stdout_file'];stderr=root/spec['stderr_file']
 check(stdout.parent==root and stderr.parent==root,'OUTPUT_PATH')
 handles=[open(stdout,'xb',buffering=0),open(stderr,'xb',buffering=0)]
 applied={}
 for name,which,wanted in (('AS',resource.RLIMIT_AS,spec['rlimit_as_bytes']),('CORE',resource.RLIMIT_CORE,lim['rlimit_core_bytes']),('NOFILE',resource.RLIMIT_NOFILE,lim['rlimit_nofile']),('FSIZE',resource.RLIMIT_FSIZE,lim['rlimit_fsize_bytes'])):
  soft,hard=resource.getrlimit(which);applied[name]=dict(inherited_soft=soft,inherited_hard=hard,selected=min([wanted]+[x for x in (soft,hard) if x!=resource.RLIM_INFINITY]))
 atomic_json(root/(spec['id']+'.limits-plan.json'),applied)
 def child_limits():
  # Never raise inherited soft/hard limits. No shared-UID RLIMIT_NPROC changes.
  tighten(resource.RLIMIT_AS,spec['rlimit_as_bytes'])
  tighten(resource.RLIMIT_CORE,lim['rlimit_core_bytes']);tighten(resource.RLIMIT_NOFILE,lim['rlimit_nofile']);tighten(resource.RLIMIT_FSIZE,lim['rlimit_fsize_bytes'])
 tails=[b'',b''];known={};p=None;sel=selectors.DefaultSelector();rc=None;error=None;original_error=None;error_site=None;special_file=None;site='spawn';total=0;counts=[0,0];streams_closed=False
 try:
  p=subprocess.Popen(spec['argv'],cwd=spec['cwd'],env=recipe['environment'],stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,close_fds=True,preexec_fn=child_limits)
  for i,pipe in enumerate((p.stdout,p.stderr)):os.set_blocking(pipe.fileno(),False);sel.register(pipe,selectors.EVENT_READ,i)
  while True:
   site='phase_loop';check(not CANCEL,'CANCELLED');check(mono()<origin+lim['absolute_work_seconds'],'GLOBAL_WORK_DEADLINE');check(mono()<deadline,'PHASE_DEADLINE')
   rows=discover(os.getpid(),known);check(len(rows)<=lim['identified_processes_max'],'PROCESS_QUOTA')
   check(sum((proc(r['pid']) or {}).get('rss',0) for r in rows)+(proc(os.getpid()) or {}).get('rss',0)<=lim['aggregate_rss_stop_bytes'],'RSS_STOP')
   site='size_tree';check(size_tree(root/'build',recipe['soname_policy'],phase=spec['id'],observed_by='worker',tree='build',mutable=spec['id'] in ('configure','build'))+size_tree(root/'tmp',phase=spec['id'],observed_by='worker',tree='tmp',mutable=spec['id'] in ('configure','build'))<=lim['build_and_tmp_stop_bytes'],'BUILD_DISK_STOP')
   site='maps_check';maps_check(rows)
   site='stream_select'
   for key,_ in sel.select(.1):
    index=key.data;chunk=os.read(key.fileobj.fileno(),65536)
    if not chunk:sel.unregister(key.fileobj);key.fileobj.close();continue
    total+=len(chunk);counts[index]+=len(chunk)
    check(total<=lim['stdout_stderr_combined_per_phase_bytes'],'STREAM_OVERFLOW')
    if spec['id']=='analyze' and index==0:check(counts[0]<=lim['analysis_stdout_bytes'],'ANALYSIS_QUOTA')
    handles[index].write(chunk)
    window=tails[index]+chunk
    check(not any(x in window.lower() for x in (b'downloading',b'permission denied',b'operation not permitted',b'could not resolve host',b'performing download step',b'please enter password')),'UNEXPECTED_DOWNLOAD_PERMISSION_OR_DENIAL')
    tails[index]=window[-8192:]
   rc=p.poll()
   if rc is not None:
    check(rc==0,'PHASE_RC:'+str(rc))
    for row in rows:
     if row['pid']!=p.pid:
      try:os.waitpid(row['pid'],os.WNOHANG)
      except ChildProcessError:pass
    check(not discover(os.getpid(),known),'DESCENDANTS_AFTER_MAIN_EXIT')
    if not sel.get_map():streams_closed=True;break
  check(rc==0,'PHASE_RC:'+str(rc))
 except BaseException as ex:
  original_error=('Stop' if isinstance(ex,SpecialFileStop) else type(ex).__name__)+':'+str(ex);error_site=site;error=original_error
  special_file=getattr(ex,'descriptor',None)
  if isinstance(ex,Stop) and str(ex)=='PROTECTED_IO_DEADLINE':
   now=mono()
   if now>=origin+lim['absolute_work_seconds']:error='Stop:GLOBAL_WORK_DEADLINE'
   elif DEADLINE==deadline and now>=deadline:error='Stop:PHASE_DEADLINE'
 finally:
  closure=cleanup(os.getpid(),known,min(origin+lim['absolute_total_seconds'],mono()+10)) if error else dict(signals=[],remaining=[])
  if p is not None:
   raw=closure.get('reaped_statuses',{}).get(str(p.pid))
   if raw is not None:p.returncode=os.waitstatus_to_exitcode(raw)
   rc=p.poll()
  discarded_after_failure=0
  # Observe EOF after stopping identified children. Bytes after a rejected
  # capture are discarded with an explicit count, never reported as complete.
  close_deadline=min(origin+lim['absolute_total_seconds'],mono()+1)
  while error and sel.get_map() and mono()<close_deadline and discarded_after_failure<=1048576:
   for key,_ in sel.select(.05):
    chunk=os.read(key.fileobj.fileno(),65536)
    if not chunk:sel.unregister(key.fileobj);key.fileobj.close()
    else:discarded_after_failure+=len(chunk)
  if error:streams_closed=not bool(sel.get_map())
  for key in list(sel.get_map().values()):
   sel.unregister(key.fileobj);key.fileobj.close()
  sel.close()
  for h in handles:h.close()
 DEADLINE=min(origin+lim['absolute_total_seconds'],mono()+10)
 tree_closure_error=None
 try:
  check(rc is not None and not closure['remaining'] and not discover(os.getpid(),known),'TREE_CLOSURE_WRITERS_NOT_REAPED')
  check(size_tree(root/'build',recipe['soname_policy'],phase=spec['id'],observed_by='worker',tree='build')+size_tree(root/'tmp',phase=spec['id'],observed_by='worker',tree='tmp')<=lim['build_and_tmp_stop_bytes'],'BUILD_DISK_STOP')
 except BaseException as ex:tree_closure_error=dict(error=type(ex).__name__+':'+str(ex),special_file=getattr(ex,'descriptor',None))
 result=dict(tree_closure_error=tree_closure_error,tree_samples=json.loads(json.dumps(sample_state('worker'))),id=spec['id'],rc=rc,error=error,original_error=original_error,error_site=error_site,special_file=special_file,EOF=streams_closed,counts=counts,closure=closure,limits_plan=applied,discarded_after_failure=discarded_after_failure,capture_rejected=error is not None)
 # Post-phase custody is closure work: retain its own bounded deadline even
 # when the phase deliberately timed out. Preserve the recorded primary error.
 DEADLINE=min(origin+lim['absolute_total_seconds'],mono()+10)
 try:custody_check()
 except BaseException as ex:
  result['post_custody_error']=type(ex).__name__+':'+str(ex)
 atomic_json(root/(spec['id']+'.status.json'),result)
 check(error is None and streams_closed and not closure['remaining'] and not result.get('post_custody_error') and tree_closure_error is None,'PHASE_FAILED:'+str(error) if error is not None else 'PHASE_FINALIZATION_FAILED')
 return result

def elf(path):
 p=Path(path);check(p.stat().st_size<=134217728,'ELF_INSPECTION_QUOTA');b=p.read_bytes()
 check(b[:6]==b'\x7fELF\x02\x01' and len(b)>=64,'ELF64_LE_REQUIRED')
 phoff=struct.unpack_from('<Q',b,32)[0];phent,phnum=struct.unpack_from('<HH',b,54)
 check(phent==56 and phnum<=256 and phoff+phent*phnum<=len(b),'ELF_PHDR')
 loads=[];dynamic=None;interpreter=None
 for i in range(phnum):
  typ,flags,off,va,pa,filesz,memsz,align=struct.unpack_from('<II6Q',b,phoff+i*phent)
  check(off+filesz<=len(b),'ELF_SEGMENT')
  if typ==1:loads.append((va,filesz,off))
  elif typ==2:dynamic=(off,filesz)
  elif typ==3:interpreter=b[off:off+filesz].rstrip(b'\0').decode('ascii')
 check(dynamic is not None,'ELF_DYNAMIC_REQUIRED')
 tags=[]
 for off in range(dynamic[0],dynamic[0]+dynamic[1],16):
  check(off+16<=len(b),'ELF_DYNAMIC_RANGE');tag,value=struct.unpack_from('<qQ',b,off)
  if tag==0:break
  tags.append((tag,value))
 addresses=[v for t,v in tags if t==5];sizes=[v for t,v in tags if t==10]
 check(len(addresses)==len(sizes)==1,'ELF_STRTAB')
 table=[(o+addresses[0]-v) for v,n,o in loads if v<=addresses[0]<v+n]
 check(len(table)==1 and table[0]+sizes[0]<=len(b),'ELF_STRTAB_RANGE')
 def string(index):
  check(index<sizes[0],'ELF_STRING_INDEX');start=table[0]+index;end=b.find(b'\0',start,table[0]+sizes[0]);check(end>=0,'ELF_STRING_END');return b[start:end].decode('ascii')
 needed=[string(v) for t,v in tags if t==1];paths=[string(v) for t,v in tags if t in (15,29)]
 check(len(paths)<=1,'ELF_RPATH_RUNPATH_AMBIGUOUS')
 return interpreter,needed,paths[0].split(':') if paths else []


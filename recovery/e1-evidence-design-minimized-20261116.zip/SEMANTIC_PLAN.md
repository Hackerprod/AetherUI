# Technical proposal: conservative same-stage typography comparison

Technical synopsis of the revised proposal, not an implementation or an execution authorization. This is not a copy of private planning/review records.

## Observed mechanism and scope

The archived E1 analysis contains six resolves, 27 node/call rows and 18 repeated rows. On repeated rows, own/inherited base impact is 0/0 and final impact is 19/19. Prepared-stage and accounting comparisons are equal; the heterogeneous previous-final/current-prepared comparison differs only in coverage_gaps, 5 to 1. This supports the mechanism for the two tested fixtures, not all typography failures, non-interference, or product acceptance.

## Proposed contract

- Retain complete TypographyEvidence equality, including coverage, provenance and break policy. Do not erase evidence or reconstruct prepared evidence by clearing bit 4 from finalized evidence.
- Store authentic prepared evidence P after discard and computed break-policy handling, before final accounting OR 4. Associate it immutably with the published typography record, independently of diagnostic macros or optional reusable-payload capture.
- Compare previous/current P at the same stage. Missing or unauthenticated prior P conservatively contributes TEXT_LAYOUT|LAYOUT|PAINT (19).
- After complete document accounting is finalized, compare finalized evidence F and exact validity projection: losses bitmask, inputs_accounted and external_pending. Missing prior inputs conservatively contribute 19.
- Publish all six accounting counters exactly, but differences solely in source_bytes, declarations, rules, compiled_rules, expanded_declarations or compiled_bytes contribute no impact. Counter saturation and budget transitions must still affect real losses/accounted status. Existing metadata-only and percentage expectations 0/7 must remain, not become 19/23.
- Per-node impact is base OR prepared contribution OR final contribution, including inherited destinations consistently. Repeated equal P/F/validity with zero base yields no impact or updates while preserving gaps=5 and complete=false.
- Keep full typography provenance comparison conservative in this first correction. A more selective semantic projection is a separate optimization, not established by this experiment.

## Ownership and atomicity

Own P in the immutable record; allocate/copy or move only during preparation. Final accounting remains shared and immutable. Do not publish partial P/F/accounting before commit. Retained revisions, stale commits, allocation failure and cancelled transactions must preserve prior records and generations. Commit must retain its no-fallible-allocation boundary. Added ownership has persistent O(N+B) cost for N nodes and dynamic evidence bytes B, accumulating across retained revisions; no resource overhead acceptance has been established.

## Required future checks

1. Repeat the original fixtures without altering completeness, coverage or accounting; verify successful generation publication, zero repeated updates, and exact final fields.
2. Exercise true prepared/final changes, missing prior evidence, losses-reason changes, accounted and pending independently, document-order and late-loss effects.
3. Test all six counter-only updates with zero added impact and exact new publication; preserve historical 0/7 contracts and budget behavior.
4. Check retained revisions, rollback, allocation-failure coverage and diagnostic-macros-off operation.
5. Preserve provider/capture rejection, authenticity and old/foreign-context checks. No no-op result authorizes drawing.
6. Keep the separate line-height expectation 81 unresolved rather than changing it to 83 for a green test. Equal used pixels do not imply equal kind/value/dependencies.

Not acceptable: removing coverage from equality, forced completeness, clearing accounting, comparing only aggregate validity or used pixels, relying on optional capture as product state, or weakening tests. No complete-suite success is claimed.

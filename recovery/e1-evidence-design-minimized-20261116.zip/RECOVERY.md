# Minimized E1 evidence and semantic-design snapshot

The exact analysis JSON contains only synthetic fixture/node/call data, comparison results and source accounting. Its six-call, 27-row dataset has 18 repeated rows. It is derived analysis, not a replacement for the excluded raw binary capture or a proof of independent oracle correctness. Capture validity is not product acceptance or non-interference.

The two design documents are deliberately minimized technical synopses of the revised conservative proposal and its review. They omit private planning, coordination, environment, session and process records. They are not exact copies and do not grant execution permission. The design is not a tested implementation.

The analyzer is preserved as source. Supervisor/support sources are templates; the interpreter path is /RELOCATE/python3. Recipes, authority manifests, environment observations and operational state are absent. Reconstruct configuration and obtain independent validation before use. No binaries, build artifacts or logs are included. Packaging checks include stable reads, hashes, CRC and Python syntax only.

The earlier minimized E1 source snapshot supplies the isolated native instrumentation. No currently changing same-stage implementation is included here.

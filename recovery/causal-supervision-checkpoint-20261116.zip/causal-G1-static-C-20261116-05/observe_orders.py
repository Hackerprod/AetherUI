#!/usr/bin/env python3
"""Static-prepared v5 discriminating fixture; not executed during preparation.
Imports unchanged v4 guard functions only. No product or supervisor campaign.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import select
import signal
import subprocess
import sys
import time

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
START=time.monotonic()
OUTPUT=HERE.parent/'causal-G1-observation-C-20261116-05'
SIGTERM_BIT=1 << (int(signal.SIGTERM)-1)

class NonDiscriminating(RuntimeError):pass

def require(ok,reason):
    if not ok:raise NonDiscriminating(reason)
def digest(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for block in iter(lambda:f.read(1048576),b''):h.update(block)
    return h.hexdigest()
def save(path,value):
    path=Path(path);tmp=path.with_suffix(path.suffix+'.tmp')
    with open(tmp,'w') as f:json.dump(value,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
    os.replace(tmp,path)
def append(path,value):
    with open(path,'a') as f:f.write(json.dumps(value)+'\n');f.flush();os.fsync(f.fileno())
def identity(pid):
    try:
        fields=Path('/proc',str(pid),'stat').read_text().rsplit(')',1)[1].split()
        return dict(pid=int(pid),ppid=int(fields[1]),start=fields[19],state=fields[0])
    except (FileNotFoundError,ProcessLookupError):return None
def namespaces():return {n:os.readlink('/proc/self/ns/'+n) for n in ('pid','mnt','user')}
def signal_state(pid):
    wanted={'SigBlk','SigIgn','SigCgt'};out={}
    for line in Path('/proc',str(pid),'status').read_text().splitlines():
        key,_,value=line.partition(':')
        if key in wanted:out[key]=value.strip()
    require(set(out)==wanted,'SIGNAL_STATUS_UNAVAILABLE')
    out.update(sigterm_blocked=bool(int(out['SigBlk'],16)&SIGTERM_BIT),sigterm_ignored=bool(int(out['SigIgn'],16)&SIGTERM_BIT),sigterm_caught=bool(int(out['SigCgt'],16)&SIGTERM_BIT))
    return out

def live_children(root):
    rows={}
    for path in Path('/proc').iterdir():
        if path.name.isdigit():
            row=identity(path.name)
            if row:rows[row['pid']]=row
    parents={root};changed=True
    while changed:
        changed=False
        for pid,row in rows.items():
            if row['ppid'] in parents and pid not in parents:parents.add(pid);changed=True
    return [rows[p] for p in parents-{root}]

def emergency(records):
    errors=[]
    for rec in records:
        fd=None
        try:
            before=identity(rec['pid'])
            if not before or before['start']!=rec['start']:continue
            fd=os.pidfd_open(rec['pid'],0);after=identity(rec['pid'])
            if after and after['start']==rec['start']:signal.pidfd_send_signal(fd,signal.SIGKILL,None,0)
        except ProcessLookupError:pass
        except Exception as exc:errors.append(dict(identity=rec,error=type(exc).__name__+':'+str(exc)))
        finally:
            if fd is not None:os.close(fd)
    return errors

def reap(deadline):
    results=[]
    while time.monotonic()<deadline:
        try:
            pid,status=os.waitpid(-1,os.WNOHANG)
            if pid:results.append(dict(pid=pid,status=status,exit_code=os.waitstatus_to_exitcode(status)));continue
        except ChildProcessError:return results,True
        time.sleep(.01)
    return results,False

def approved(expected):
    raw=(HERE/'evidence.sha256.json').read_bytes()
    require(hashlib.sha256(raw).hexdigest()==expected,'MANIFEST_NOT_APPROVED')
    manifest=json.loads(raw)
    for name,h in manifest.items():require((HERE/name).is_file() and not (HERE/name).is_symlink() and digest(HERE/name)==h,'STATIC_FILE_CHANGED:'+name)
    policy=json.loads((HERE/'policy.json').read_text())
    for path,h in policy['references'].items():require(digest(path)==h,'REFERENCE_CHANGED:'+path)
    return manifest,policy

def guard_module(policy):
    path=Path(policy['guard_path'])
    require(digest(path)==policy['guard_sha256'],'GUARD_CHANGED')
    spec=importlib.util.spec_from_file_location('unchanged_guard_v4',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module

def poll_read(fd,deadline,buffer):
    p=select.poll();p.register(fd,select.POLLIN|select.POLLHUP|select.POLLERR)
    while b'\n' not in buffer:
        require(time.monotonic()<deadline,'CHILD_CONFIRMATION_CAP')
        events=p.poll(max(1,int(min(.05,deadline-time.monotonic())*1000)))
        if not events:continue
        require(not any(mask&select.POLLNVAL for _,mask in events),'INVALID_EVENT_FD')
        data=os.read(fd,4096)
        require(bool(data),'CHILD_EVENT_EOF')
        buffer+=data;require(len(buffer)<=16384,'EVENT_OVERFLOW')
    line,buffer=buffer.split(b'\n',1)
    return json.loads(line),buffer

def emit_child(fd,name,phase,**extra):
    value=dict(event=name,pid=os.getpid(),mono=time.monotonic(),phase=phase,**extra)
    data=(json.dumps(value)+'\n').encode()
    if len(data)>4096 or os.write(fd,data)!=len(data):os._exit(91)

def child_body(mode,event_write,control_read,inherited_handler,phase):
    if mode=='restored':signal.signal(signal.SIGTERM,signal.SIG_DFL);phase[0]='DEFAULT_READY'
    inherited=signal.getsignal(signal.SIGTERM) is inherited_handler
    default=signal.getsignal(signal.SIGTERM)==signal.SIG_DFL
    emit_child(event_write,'ready',phase[0],handler_inherited=inherited,handler_default=default,signal_state=signal_state(os.getpid()),identity=identity(os.getpid()),namespace=namespaces())
    if mode=='inherited':
        # No reset before the parent's explicit release, which follows receipt ACK.
        command=os.read(control_read,1)
        if command!=b'R':os._exit(92)
        signal.signal(signal.SIGTERM,signal.SIG_DFL);phase[0]='RESET_DEFAULT'
        emit_child(event_write,'reset_confirmed',phase[0],handler_default=signal.getsignal(signal.SIGTERM)==signal.SIG_DFL,signal_state=signal_state(os.getpid()))
    # Remain blocked. First-order cleanup uses KILL; restored order must exit TERM.
    os.read(control_read,1)
    os._exit(93)

def worker(args,policy):
    path=OUTPUT/args.order;path.mkdir(exist_ok=False)
    g=guard_module(policy);deadline=args.worker_deadline
    observations=dict(order=args.order,events=[],signal_result='UNOBSERVED',handler_receipt='UNOBSERVED',reset='UNOBSERVED',exit='UNOBSERVED',cleanup='UNOBSERVED')
    result=dict(status='NON_DISCRIMINATING',observations=observations,start=time.monotonic(),identity=identity(os.getpid()),namespace=namespaces())
    held=[];fds=[];pid=None;rec=None;buffer=b'';old_handler=signal.getsignal(signal.SIGTERM)
    ledger=g.HandleLedger(emit=lambda event:append(path/'ledger.jsonl',event))
    def alarm(signum,frame):raise NonDiscriminating('WORKER_CAP')
    signal.signal(signal.SIGALRM,alarm);signal.setitimer(signal.ITIMER_REAL,max(.001,deadline-time.monotonic()))
    save(path/'result.json',result)
    try:
        soft,hard=resource.getrlimit(resource.RLIMIT_NOFILE)
        require(soft==resource.RLIM_INFINITY or soft>=1200,'UNCHANGED_RLIMIT_INSUFFICIENT')
        while not held or held[-1]<1100:held.append(os.open('/dev/null',os.O_RDONLY))
        er,ew=os.pipe();cr,cw=os.pipe();fds.extend([er,ew,cr,cw]);os.set_blocking(ew,False)
        phase=['INHERITED_WAIT']
        def inherited_handler(signum,frame):
            # Executed by the child Python handler; actual receipt, not send intent.
            emit_child(ew,'handler_received',phase[0],signal=signum,handler_inherited=signal.getsignal(signal.SIGTERM) is inherited_handler)
        signal.signal(signal.SIGTERM,inherited_handler)
        pid=os.fork()
        if pid==0:
            try:
                os.close(er);os.close(cw);child_body(args.order,ew,cr,inherited_handler,phase)
            except BaseException:os._exit(94)
        signal.signal(signal.SIGTERM,old_handler)
        os.close(ew);fds.remove(ew);os.close(cr);fds.remove(cr)
        info=g.identity(pid);require(info is not None,'CHILD_IDENTITY_MISSING')
        rec=g.pin(pid,info['start'],ledger);require(rec is not None and rec['fd']>1024,'HIGH_PIDFD_NOT_PINNED')
        observations.update(child_identity=info,pidfd=rec['fd'],event_fd=er,control_fd=cw,rlimit=[soft,hard]);save(path/'result.json',result)
        ready,buffer=poll_read(er,min(deadline,time.monotonic()+3),buffer)
        observations['events'].append(ready);append(path/'events.jsonl',ready);save(path/'result.json',result)
        require(ready.get('event')=='ready' and ready.get('pid')==pid,'INVALID_READY')
        require(not ready['signal_state']['sigterm_blocked'] and not ready['signal_state']['sigterm_ignored'],'SIGTERM_NOT_DELIVERABLE_AT_READY')
        if args.order=='inherited':require(ready['handler_inherited'] and ready['signal_state']['sigterm_caught'],'INHERITED_HANDLER_NOT_READY')
        else:require(ready['handler_default'] and not ready['signal_state']['sigterm_caught'],'SIG_DFL_NOT_READY')
        observations['parent_signal_state_before']=signal_state(pid)
        observations['signal_begin']=time.monotonic();save(path/'result.json',result)
        try:observations['signal_result']=g.safe_signal(rec,signal.SIGTERM)
        except BaseException as exc:
            observations['signal_result']=dict(error=type(exc).__name__+':'+str(exc));raise
        finally:
            observations['signal_end']=time.monotonic();observations['ledger_after_signal']=ledger.stats();save(path/'result.json',result)
        require(observations['signal_result'].get('status')=='SENT','SIGNAL_SEND_NOT_CONFIRMED')
        if args.order=='inherited':
            receipt,buffer=poll_read(er,min(deadline,time.monotonic()+3),buffer)
            observations['events'].append(receipt);append(path/'events.jsonl',receipt);save(path/'result.json',result)
            require(receipt.get('event')=='handler_received' and receipt.get('pid')==pid and receipt.get('signal')==int(signal.SIGTERM) and receipt.get('handler_inherited') is True and receipt.get('phase')=='INHERITED_WAIT' and receipt['mono']>=observations['signal_begin'],'HANDLER_RECEIPT_NOT_CONFIRMED')
            observations['handler_receipt']=receipt;observations['release_begin']=time.monotonic();save(path/'result.json',result)
            # This write is unreachable on no/malformed/late receipt.
            require(time.monotonic()<deadline,'NO_RESET_AFTER_CAP');os.write(cw,b'R')
            reset,buffer=poll_read(er,min(deadline,time.monotonic()+3),buffer)
            observations['events'].append(reset);append(path/'events.jsonl',reset);save(path/'result.json',result)
            require(reset.get('event')=='reset_confirmed' and reset.get('pid')==pid and reset['handler_default'] and not reset['signal_state']['sigterm_blocked'] and receipt['mono']<reset['mono'],'RESET_ORDER_NOT_CONFIRMED')
            observations['reset']=reset
            until=min(deadline,time.monotonic()+.3)
            while time.monotonic()<until:
                require(not g.exited(rec),'INHERITED_ORDER_EXITED_UNEXPECTEDLY');time.sleep(.01)
            observations['exit']=dict(observed_alive_after_reset=True,observed_until=time.monotonic())
        else:
            until=min(deadline,time.monotonic()+3)
            while time.monotonic()<until and not g.exited(rec):time.sleep(.005)
            require(g.exited(rec),'RESTORED_ORDER_EXIT_NOT_OBSERVED')
            got,status=os.waitpid(pid,0);observations['exit']=dict(pid=got,wait_status=status,exit_code=os.waitstatus_to_exitcode(status));pid=None
            require(observations['exit']['exit_code']==-int(signal.SIGTERM),'RESTORED_ORDER_NOT_TERM_EXIT')
        result['status']='DISCRIMINATING_ORDER_OBSERVED'
    except BaseException as exc:
        result.update(status='NON_DISCRIMINATING',error=type(exc).__name__+':'+str(exc))
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)
        signal.signal(signal.SIGTERM,old_handler)
        cleanup=dict(signal_result=None,reaped=[],errors=[],complete=False)
        try:
            if pid is not None:
                if rec is not None:cleanup['signal_result']=g.safe_signal(rec,signal.SIGKILL)
                else:
                    info=identity(pid)
                    if info:cleanup['errors']+=emergency([info])
                reaped,complete=reap(min(args.global_deadline,time.monotonic()+2));cleanup.update(reaped=reaped,complete=complete)
            else:cleanup['complete']=True
        except BaseException as exc:cleanup['errors'].append(type(exc).__name__+':'+str(exc))
        for record in list(ledger.records.values()):
            try:g.retire(record,'OBSERVATION_FINALLY',exit_observed=record.get('exit_observed',False))
            except BaseException as exc:cleanup['errors'].append(type(exc).__name__+':'+str(exc))
        for fd in fds+held:
            try:os.close(fd)
            except OSError:pass
        observations['cleanup']=cleanup;observations['ledger_final']=ledger.stats();result['end']=time.monotonic()
        if cleanup['errors'] or not cleanup['complete']:result['status']='NON_DISCRIMINATING'
        save(path/'result.json',result)
    return 0 if result['status']=='DISCRIMINATING_ORDER_OBSERVED' else 2

def controller(args,policy,manifest):
    # Actual function semantics are exercised only inside bounded worker fixtures.
    import ctypes
    require(ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)==0,'SUBREAPER_UNAVAILABLE')
    OUTPUT.mkdir(exist_ok=False);deadline=START+30;work=deadline-4
    matrix=[dict(order=o,status='NOT_RUN') for o in ('inherited','restored')]
    def hard_cap(signum,frame):
        try:emergency(live_children(os.getpid()))
        finally:os._exit(124)
    signal.signal(signal.SIGALRM,hard_cap);signal.setitimer(signal.ITIMER_REAL,max(.001,deadline-time.monotonic()))
    save(OUTPUT/'identity.json',dict(identity=identity(os.getpid()),namespace=namespaces(),start=START,deadline=deadline,manifest=args.manifest_sha256))
    save(OUTPUT/'matrix.json',matrix);save(OUTPUT/'outcome.json',dict(status='RUNNING',cleanup_verified=False))
    results=[]
    try:
        require(hasattr(os,'pidfd_open') and hasattr(signal,'pidfd_send_signal') and hasattr(select,'poll'),'CAPABILITY_UNAVAILABLE')
        for row in matrix:
            require(time.monotonic()<work,'GLOBAL_WORK_CAP')
            stop=min(work,time.monotonic()+10);row['status']='RUNNING';save(OUTPUT/'matrix.json',matrix)
            argv=[sys.executable,str(HERE/'observe_orders.py'),'--manifest-sha256',args.manifest_sha256,'--order',row['order'],'--worker-deadline',str(stop),'--global-deadline',str(deadline)]
            process=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=open(OUTPUT/(row['order']+'.stdout'),'xb'),stderr=open(OUTPUT/(row['order']+'.stderr'),'xb'),start_new_session=True)
            seen={};peak=0
            while process.poll() is None:
                children=live_children(os.getpid());peak=max(peak,len([r for r in children if r['state']!='Z']))
                for r in children:seen[(r['pid'],r['start'])]=r
                require(peak<=4,'DESCENDANT_LIMIT')
                if time.monotonic()>=stop:emergency(list(seen.values()));raise NonDiscriminating('ORDER_CAP')
                time.sleep(.01)
            process.wait();report=json.loads((OUTPUT/row['order']/'result.json').read_text())
            require(not live_children(os.getpid()),'RESIDUES_AFTER_ORDER')
            row.update(status=report['status'],rc=process.returncode,max_descendants=peak);save(OUTPUT/'matrix.json',matrix)
            results.append(dict(order=row['order'],argv=argv,result=report));save(OUTPUT/'results.json',results)
            require(process.returncode==0 and report['status']=='DISCRIMINATING_ORDER_OBSERVED','NON_DISCRIMINATING_ORDER')
        require(digest(HERE/'evidence.sha256.json')==args.manifest_sha256,'MANIFEST_DRIFT')
        require(all(digest(HERE/name)==h for name,h in manifest.items()),'PROGRAM_DRIFT')
        require(all(digest(path)==h for path,h in policy['references'].items()),'REFERENCE_DRIFT')
        save(OUTPUT/'outcome.json',dict(status='CONTROLLED_MECHANISM_OBSERVED_ONLY',historical_cause='UNDETERMINED',wall=time.monotonic()-START,custody_complete=True))
        signal.setitimer(signal.ITIMER_REAL,0);return 0
    except BaseException as exc:
        for row in matrix:
            if row['status']=='RUNNING':row['status']='INTERRUPTED'
        save(OUTPUT/'matrix.json',matrix)
        errors=emergency(live_children(os.getpid()));reaped,complete=reap(min(deadline,time.monotonic()+2))
        save(OUTPUT/'outcome.json',dict(status='NON_DISCRIMINATING_STOP',error=type(exc).__name__+':'+str(exc),cleanup_errors=errors,reaped=reaped,reaping_complete=complete,wall=time.monotonic()-START,historical_cause='UNDETERMINED'))
        signal.setitimer(signal.ITIMER_REAL,0);return 2

def main():
    p=argparse.ArgumentParser();p.add_argument('--manifest-sha256',required=True);p.add_argument('--order',choices=['inherited','restored']);p.add_argument('--worker-deadline',type=float);p.add_argument('--global-deadline',type=float)
    args=p.parse_args();manifest,policy=approved(args.manifest_sha256)
    if args.order:
        require(args.worker_deadline is not None and args.global_deadline is not None and time.monotonic()<args.worker_deadline<=args.global_deadline,'INVALID_WORKER_BUDGET')
        return worker(args,policy)
    return controller(args,policy,manifest)

if __name__=='__main__':sys.exit(main())

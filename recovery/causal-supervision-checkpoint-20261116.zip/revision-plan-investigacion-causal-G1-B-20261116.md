# B · Revisión independiente del plan causal G1

Fecha: 2026-11-16. **PASS · PROPOSAL_ONLY. No autoriza ejecución ni atribución causal.**

Documento revisado: `plan-investigacion-causal-G1-A-20261116.md`, SHA256 `ba0ff7592555c0e9da39ab3a605ab795960ce133ccb098ad2f53da2a85587540`.

## Comprobaciones independientes

Leí el dictamen D y acta C de continuación, la matriz combinada, el diff actual de CMake y su resumen, las definiciones de targets de stylesheet, el test de catálogo y las fases del test adjacent-cache. Recalculé **32/32 hashes** del manifiesto `drawing-cmake-validation-C-20261116-05/continuation-01/evidence.sha256.json`, sin discrepancias. La matriz contiene **266 PASS, 19 FAIL, 1 TIMEOUT, 1 ABORT**. Los 20 nombres de la primera tanda coinciden con todos los no-PASS salvo #159. Los controles smoke y abi-c son PASS históricos. No verifiqué de nuevo los 6357 archivos originales ni toda la custodia viva; no sustituyo el gate futuro D.

## Motivos del PASS

- **Baseline:** H, J y Hc están separados y correctamente nombrados. El plan no presupone que HEAD compila ni que la adaptación preserva semántica. Exige cierre por target, diff/hashes del adaptador y puente aprobado o limitación explícita. Esto evita atribuir preexistencia por archivos sin cambios o por un baseline adaptado presentado como limpio.
- **Confusores reales reconocidos:** el diff de CMake añade `style_lookup_box.cpp` al core y cambia el enlace de consumidores, además de includes privados. El target source-order-runtime toma fuentes del core y sí aparece entre los consumidores reparados con el include privado. Por tanto, no basta excluir z-index/OOM/classifier para suponer comparable todo lo seleccionado. El expediente requerido por A cubre expresamente esta comprobación.
- **Controles y alcance:** dos controles PASS, selección exacta, inventarios locales, herramientas/flags/enlace comparados y árboles sin artefactos compartidos son adecuados para una primera matriz exploratoria. El plan reserva la intervención discriminante para después y no vende coincidencias como causa común.
- **Separación de preguntas:** las seis variantes profundas comparten dos ejecutables, pero sus nombres incluyen modos distintos. CMake confirma esa estructura y el compiler tiene fuentes/define propios. El catálogo aborta en cardinalidad antes de imprimir claves ausentes, como advierte A. #159 contiene differential, reentrant y cuatro llamadas OOM con límite 50000 por barrido; su aislamiento temporal está justificado, no demuestra lentitud inocua.
- **Integridad y seguridad:** preserva evidencia anterior, WIP y archivo no tracked, prohíbe operaciones destructivas/publicación/red y requiere manifiestos nuevos. No permite modificar expected, reducir corpus ni instrumentar sin un gate separado. Límites externos se tratan como censura y no como resultados oficiales.
- **Presupuesto:** 2×120 s configure + 2×1800 s build + 900 s tests = 4740 s, dentro del techo de 4800 s. El techo de pared debe prevalecer también sobre preparación/registro y cierres; no hay margen para ampliar tiempos silenciosamente.

## Condiciones de lectura para C/D

Estas condiciones explicitan el alcance ya requerido por el plan; no abren excepciones ni nuevas ejecuciones:

1. **El PASS es del diseño, no de un par comparable todavía inexistente.** Antes de ejecutar faltan árboles/hashes concretos, adaptador, mapa de dependencias, argv y control de puente o declaración de comparación limitada. Si el puente requiere variantes o ejecuciones adicionales, no queda autorizado dentro de las 44 invocaciones actuales: necesita alcance/presupuesto explícito de D.
2. **Smoke/ABI no validan semántica de todos los grupos.** Su éxito descarta sólo parte de los fallos generales. No basta para declarar inocuo A, para interpretar ausencia de un bit como corrección ni para demostrar causa raíz.
3. **Una observación por árbol y orden fijo no estiman intermitencia ni separan por sí solos deriva temporal.** Cualquier falta de reproducción conserva UNDETERMINED. Una firma común en Hc/J sólo acredita reproducción en baseline adaptado; no excluye una regresión adicional ni demuestra preexistencia en H.
4. El ejecutor debe aplicar los límites globales y terminar/recolectar los grupos de procesos también ante build bloqueado o agotamiento del techo. Al abortar una tanda quedan casos NOT_RUN, no se infiere resultado del árbol pendiente. Ninguna falta de herramientas de control autoriza instalar o improvisar un mecanismo no revisado.
5. El inventario esperado es el inventario local completo conocido; el build focalizado no implica que sólo existan 22 tests registrados. Una diferencia inesperada exige resolución D, no selección oportunista.
6. Para cada assertion posterior a un abort o salida temprana debe figurar **no observada**, no una firma inferida del ejecutable. Valores runtime no expuestos requieren la propuesta de instrumentación aparte prevista por A.

## Dictamen

**PASS para pasar a preparación exclusivamente estática C y revisión/gate D del expediente congelado.** No encontré un defecto bloqueante en el plan como propuesta. No concede autorización de configure, build, tests, profiling, adaptación ejecutada ni reparación. #159 conserva gate separado. **G1 NOT_PASSED, OFF/ON/G2 bloqueados, G3/G4 cerrados, coverage_complete=false.**

B sólo leyó archivos y metadatos Git, recalculó hashes de evidencia y escribió este dictamen. No modificó código, no materializó árboles ni ejecutó builds/tests.

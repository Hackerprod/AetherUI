#!/usr/bin/env python3
"""STATIC-PREPARED, NOT EXECUTED. Minimal independent deadline guard.
No files written, hashes, fsync, subprocesses, product execution or killpg.
A coordinator must wait for the deadline ACK before every watchdog spawn.
Exit status never certifies reaping: only the watchdog/subreaper can reap its children.
"""
import argparse
import errno
import json
import os
from pathlib import Path
import select
import signal
import sys
import time


def identity(pid):
    try:
        text=Path('/proc',str(pid),'stat').read_text()
        fields=text[text.rfind(')')+2:].split()
        return {'pid':int(pid),'ppid':int(fields[1]),'start':fields[19],'state':fields[0]}
    except (FileNotFoundError, ProcessLookupError):
        return None


def pin(pid,start):
    before=identity(pid)
    if before is None or before['start']!=str(start):
        return None
    try:
        fd=os.pidfd_open(pid,0)
    except ProcessLookupError:
        return None
    after=identity(pid)
    if after is None or before['pid']!=after['pid'] or before['start']!=after['start']:
        os.close(fd)
        return None
    return {'pid':pid,'start':str(start),'fd':fd}


def exited(record):
    # A pidfd becomes readable on exit, including an unreaped zombie.
    return bool(select.select([record['fd']],[],[],0)[0])


def safe_signal(record,sig):
    if not exited(record):
        try:
            signal.pidfd_send_signal(record['fd'],sig,None,0)
        except ProcessLookupError:
            pass


class Guard:
    def __init__(self,args):
        if not hasattr(os,'pidfd_open') or not hasattr(signal,'pidfd_send_signal'):
            raise RuntimeError('PIDFD_REQUIRED')
        self.args=args
        self.parent=pin(args.parent[0],args.parent[1])
        self.wd=pin(args.watchdog[0],args.watchdog[1])
        if self.parent is None or self.wd is None:
            raise RuntimeError('INITIAL_IDENTITY_NOT_PRESENT')
        self.known={}
        self.phase_deadline=args.work_deadline
        self.stopping=None
        self.kill_at=None
        self.pipe_open=True
        self.buf=b''
        self.signals=[]
        self.done=False
        self.ackfd=args.ack_fd
        os.set_blocking(args.control_fd,False)
        if self.ackfd is not None:
            os.set_blocking(self.ackfd,False)
        for sig in (signal.SIGINT,signal.SIGTERM,signal.SIGHUP):
            signal.signal(sig,lambda s,f:self.signals.append(s))

    def ack(self,kind,**fields):
        if self.ackfd is None:
            return
        payload=(json.dumps(dict(ack=kind,**fields))+'\n').encode()
        if len(payload)>4096:
            raise RuntimeError('ACK_TOO_LARGE')
        # Atomic small writes only. Failure means no new spawn can be authorized.
        written=os.write(self.ackfd,payload)
        if written!=len(payload):
            raise RuntimeError('ACK_INCOMPLETE')

    def scan(self):
        rows={}
        for entry in Path('/proc').iterdir():
            if entry.name.isdigit():
                row=identity(entry.name)
                if row is not None:
                    rows[row['pid']]=row
        # Never infer ownership through a reused root PID.
        parents=set()
        for rec in [self.wd,*self.known.values()]:
            row=rows.get(rec['pid'])
            if row and row['start']==rec['start'] and not exited(rec):
                parents.add(rec['pid'])
        while True:
            added=False
            for pid,row in rows.items():
                if pid==os.getpid() or pid==self.parent['pid'] or pid in parents:
                    continue
                if row['ppid'] in parents:
                    rec=pin(pid,row['start'])
                    if rec is not None:
                        old=self.known.get(pid)
                        if old is not None:
                            os.close(old['fd'])
                        self.known[pid]=rec
                        parents.add(pid)
                        added=True
            if not added:
                break
        # Keep pidfds for descendants that changed session/group or were reparented.

    def targets(self):
        return [self.wd,*self.known.values()]

    def stop(self,reason,now):
        if self.stopping is None:
            self.stopping=reason
            self.kill_at=min(now+5,self.args.deadline)
            # Freeze the ancestor before inventorying its fork-capable descendants.
            safe_signal(self.wd,signal.SIGSTOP)
            stable=0
            previous=None
            freeze_limit=min(now+1,self.args.deadline)
            while time.monotonic()<freeze_limit:
                self.scan()
                current=set()
                all_stopped=True
                for rec in self.targets():
                    if exited(rec):
                        continue
                    safe_signal(rec,signal.SIGSTOP)
                    row=identity(rec['pid'])
                    if row is None or row['start']!=rec['start']:
                        continue
                    current.add((rec['pid'],rec['start']))
                    if row['state'] not in ('T','t','Z'):
                        all_stopped=False
                stable=stable+1 if all_stopped and current==previous else 0
                previous=current
                if stable>=2:
                    break
                time.sleep(.005)
            # Stable inventory is a containment aid, not a reaping certification.
            # Queue TERM while stopped, then CONT: watchdog signal handler must
            # enter its own stopped state and reap; it must never spawn again.
            for rec in self.targets():
                safe_signal(rec,signal.SIGTERM)
            for rec in self.targets():
                safe_signal(rec,signal.SIGCONT)

    def control(self):
        if not self.pipe_open:
            return
        if not select.select([self.args.control_fd],[],[],0)[0]:
            return
        data=os.read(self.args.control_fd,65536)
        if not data:
            self.pipe_open=False
            self.stop('CONTROL_EOF',time.monotonic())
            return
        self.buf+=data
        if len(self.buf)>65536:
            raise RuntimeError('CONTROL_OVERFLOW')
        while b'\n' in self.buf:
            raw,self.buf=self.buf.split(b'\n',1)
            msg=json.loads(raw)
            if set(msg)=={'deadline'}:
                value=msg['deadline']
                if isinstance(value,bool) or not isinstance(value,(int,float)):
                    raise RuntimeError('BAD_DEADLINE')
                now=time.monotonic()
                if self.stopping or not now<value<=self.args.work_deadline:
                    raise RuntimeError('DEADLINE_OUTSIDE_WORK_BUDGET')
                self.phase_deadline=value
                self.ack('deadline',deadline=value)
            elif msg=={'done':True}:
                # Caller sends only after its final persistent record and WD wait().
                self.scan()
                if any(not exited(x) for x in self.targets()):
                    raise RuntimeError('DONE_WITH_LIVE_IDENTIFIED_WORK')
                self.done=True
                self.ack('done',identified_work_exited=True,reaping='NOT_OBSERVED_BY_GUARD')
            else:
                raise RuntimeError('UNKNOWN_CONTROL')

    def run(self):
        self.scan()
        self.ack('ready',pid=os.getpid(),deadline=self.args.deadline)
        while True:
            now=time.monotonic()
            # The absolute kill check precedes scanning/pipe processing.
            if now>=self.args.deadline:
                for rec in self.targets():
                    safe_signal(rec,signal.SIGKILL)
                safe_signal(self.parent,signal.SIGKILL)
                return 124
            self.scan()
            if exited(self.parent):
                self.stop('PARENT_LOST',now)
            if exited(self.wd) and not self.done:
                self.stop('WATCHDOG_LOST',now)
            if self.signals:
                self.stop('GUARD_SIGNAL',now)
            if now>=min(self.phase_deadline,self.args.work_deadline):
                self.stop('DEADLINE',now)
            if self.stopping:
                # Also signal newly discovered descendants while cancellation propagates.
                sig=signal.SIGKILL if now>=self.kill_at else signal.SIGTERM
                for rec in self.targets():
                    safe_signal(rec,sig)
            try:
                self.control()
            except (Exception,) as exc:
                self.stop(type(exc).__name__,time.monotonic())
                self.pipe_open=False
            if self.done:
                return 0
            if exited(self.parent) and all(exited(x) for x in self.targets()):
                return 124
            # Continue guarding the coordinator even if WD has already exited.
            time.sleep(min(.02,max(0,self.args.deadline-time.monotonic())))


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--parent',nargs=2,required=True,metavar=('PID','STARTTIME'))
    p.add_argument('--watchdog',nargs=2,required=True,metavar=('PID','STARTTIME'))
    p.add_argument('--deadline',type=float,required=True)
    p.add_argument('--work-deadline',type=float,required=True)
    p.add_argument('--control-fd',type=int,required=True)
    p.add_argument('--ack-fd',type=int)
    args=p.parse_args()
    args.parent=(int(args.parent[0]),args.parent[1])
    args.watchdog=(int(args.watchdog[0]),args.watchdog[1])
    if not time.monotonic()<args.work_deadline<args.deadline:
        raise RuntimeError('INVALID_INITIAL_BUDGET')
    guard=Guard(args)
    try:
        return guard.run()
    except BaseException:
        # Unexpected internal failure must not leave known work running.
        for rec in guard.targets():
            safe_signal(rec,signal.SIGKILL)
        safe_signal(guard.parent,signal.SIGTERM)
        # Remain a last-resort absolute guard while the coordinator records stop.
        while time.monotonic()<args.deadline and not exited(guard.parent):
            time.sleep(min(.02,max(0,args.deadline-time.monotonic())))
        safe_signal(guard.parent,signal.SIGKILL)
        raise
    finally:
        for rec in [guard.parent,*guard.targets()]:
            os.close(rec['fd'])


if __name__=='__main__':
    sys.exit(main())

#!/usr/bin/env python3
"""STATIC, NOT EXECUTED. Closed one-shot diagnostic supervisor for D review.
The watchdog owns all commands and is a Linux child subreaper. No shell runs.
"""
import ctypes
import datetime
import fcntl
import hashlib
import json
import os
import pathlib
import select
import signal
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

START = time.monotonic()
HERE = pathlib.Path(__file__).resolve().parent

def utc(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def digest(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1024*1024), b''): h.update(b)
    return h.hexdigest()
def save(p,data):
    p=pathlib.Path(p); tmp=p.with_name(p.name+'.tmp')
    with open(tmp,'w') as f: json.dump(data,f,indent=2); f.write('\n'); f.flush(); os.fsync(f.fileno())
    os.replace(tmp,p)
def event(p, data):
    with open(p,'a') as f: f.write(json.dumps(dict(utc=utc(),mono=time.monotonic(),**data))+'\n');f.flush();os.fsync(f.fileno())
def proc(pid):
    try:
        s=pathlib.Path('/proc',str(pid),'stat').read_text(); r=s[s.rfind(')')+2:].split()
        return dict(pid=int(pid),ppid=int(r[1]),pgid=int(r[2]),start=r[19],state=r[0],rss_bytes=int(r[21])*os.sysconf('SC_PAGE_SIZE'))
    except (FileNotFoundError,ProcessLookupError): return None

def allprocs():
    out={}
    for p in pathlib.Path('/proc').iterdir():
        if p.name.isdigit():
            v=proc(p.name)
            if v: out[int(p.name)]=v
    return out

def same(x):
    v=proc(x['pid']); return v is not None and v['start']==x['start']
def alive(x):
    v=proc(x['pid']);return v is not None and v['start']==x['start'] and v['state']!='Z'
def owned(me,known):
    ps=allprocs(); ids={me}; change=True
    while change:
        change=False
        for pid,p in ps.items():
            if p['ppid'] in ids and pid not in ids: ids.add(pid);change=True
    for pid in ids-{me}:known[pid]=ps[pid]
    return [x for x in known.values() if same(x)]
def send_signal(x,sig):
    # pidfd pins the target identity; never signal a reusable integer PID/PGID.
    if not same(x):return
    try:fd=os.pidfd_open(x['pid'],0)
    except ProcessLookupError:return
    try:
        if same(x):signal.pidfd_send_signal(fd,sig,None,0)
    except ProcessLookupError:pass
    finally:os.close(fd)

def resources(root):
    mem={a:int(b.split()[0])*1024 for a,b in (line.split(':',1) for line in pathlib.Path('/proc/meminfo').read_text().splitlines())}
    d=os.statvfs(root)
    return dict(available_bytes=d.f_bavail*d.f_frsize,mem_available_bytes=mem['MemAvailable'],load=os.getloadavg())
def resource_ok(x): return x['available_bytes']>=12*1024**3 and x['mem_available_bytes']>=4*1024**3

def subreaper():
    libc=ctypes.CDLL(None,use_errno=True)
    if libc.prctl(36,1,0,0,0)!=0: raise OSError(ctypes.get_errno(),'PR_SET_CHILD_SUBREAPER failed')

def watchdog(rfd,wfd,deadline,work_deadline,parent_pid,parent_start,root,guardfd,ackfd):
    """Owns subprocesses; watches deadlines even if coordinator is blocked."""
    subreaper(); os.set_blocking(rfd,False)
    run=pathlib.Path(root)/'run'; log=run/'watchdog.jsonl'
    active=None; known={}; buf=b''; stopped=None; stop_at=None; last_resource=0; main_open=True
    sigstate=[]
    for sig in [signal.SIGINT,signal.SIGTERM,signal.SIGHUP]: signal.signal(sig,lambda s,f:sigstate.append(s))
    def reply(x):
        try:os.write(wfd,(json.dumps(x)+'\n').encode())
        except BrokenPipeError:pass
    def cleanup(reason):
        nonlocal stopped,stop_at
        if stopped is None:
            stopped=reason;stop_at=time.monotonic();event(log,dict(action='stop',reason=reason))
            for x in owned(os.getpid(),known):
                if alive(x):
                    try:
                        send_signal(x,signal.SIGTERM)
                        event(log,dict(action='TERM',identity=x))
                    except ProcessLookupError:pass
    reply(dict(type='ready',pid=os.getpid()))
    while True:
        now=time.monotonic()
        p=proc(parent_pid)
        if not p or p['start']!=parent_start:main_open=False;cleanup('PARENT_LOST')
        if now>=work_deadline:cleanup('GLOBAL_WORK_CAP')
        if active and now>=active['effective_deadline']:cleanup('DIAGNOSTIC_CAP')
        if sigstate:cleanup('WATCHDOG_SIGNAL_'+str(sigstate[0]))
        if now-last_resource>=1:
            last_resource=now
            try:
                sample=resources(root);sample['owned']=owned(os.getpid(),known)
                event(run/'resources.jsonl',sample)
                if not resource_ok(sample):cleanup('RESOURCE_PRESSURE')
            except Exception as e:cleanup('RESOURCE_READ_ERROR:'+type(e).__name__)
        if stopped:
            survivors=owned(os.getpid(),known)
            if now>=min(stop_at+5,deadline-2):
                for x in survivors:
                    if alive(x) and same(x):
                        try:send_signal(x,signal.SIGKILL);event(log,dict(action='KILL',identity=x))
                        except ProcessLookupError:pass
        if active:
            rc=active['p'].poll()
            # Popen reaps direct child. Adopted grandchildren are reaped separately.
            if rc is not None:
                reaped_all=False
                while True:
                    try:
                        pid,status=os.waitpid(-1,os.WNOHANG)
                        if not pid:break
                        event(log,dict(action='reaped_adopted',pid=pid,status=status))
                    except ChildProcessError:reaped_all=True;break
                rest=[x for x in owned(os.getpid(),known) if alive(x)]
                if rest and not stopped:cleanup('DESCENDANTS_AFTER_PARENT_EXIT')
                if not owned(os.getpid(),known) and reaped_all:
                    result={k:v for k,v in active.items() if k not in ['p','handles']}
                    result.update(rc=rc,signal=(-rc if rc<0 else None),end_utc=utc(),end_mono=now,termination_reason=stopped,cleanup_verified=True)
                    for f in active['handles']:f.close()
                    result['stdout_sha256']=digest(result['stdout']);result['stderr_sha256']=digest(result['stderr'])
                    save(run/(result['id']+'.json'),result);reply(dict(type='result',result=result));active=None
                    # No command running; retain prior cap until next deadline is acknowledged.
                    # Reset with ACK so guard cannot falsely cap coordinator's next phase.
                    os.write(guardfd,(json.dumps(dict(deadline=work_deadline))+'\n').encode())
                    reset_ack=b''
                    while b'\n' not in reset_ack:
                        ready_reset,_,_=select.select([ackfd],[],[],max(0,deadline-time.monotonic()))
                        if not ready_reset:raise RuntimeError('GUARD_RESET_TIMEOUT')
                        piece=os.read(ackfd,4096)
                        if not piece:raise RuntimeError('GUARD_LOST')
                        reset_ack+=piece
                    if json.loads(reset_ack.split(b'\n')[0])!={'ack':'deadline','deadline':work_deadline}:raise RuntimeError('GUARD_RESET_ACK')
        if now>=deadline:
            remaining=[x for x in owned(os.getpid(),known) if alive(x)]
            event(log,dict(action='HARD_DEADLINE',remaining=remaining,cleanup_verified=not remaining))
            if p and p['start']==parent_start:
                try:send_signal(p,signal.SIGKILL)
                except ProcessLookupError:pass
            os._exit(124)
        if stopped and active is None:
            reply(dict(type='stopped',reason=stopped));return 124
        ready,_,_=select.select([rfd],[],[],0.05)
        if not ready:continue
        data=os.read(rfd,65536)
        if not data:main_open=False;cleanup('CONTROL_EOF');continue
        buf+=data
        while b'\n' in buf:
            line,buf=buf.split(b'\n',1);msg=json.loads(line)
            if msg['type']=='stop':cleanup(msg.get('reason','CANCELLED'));continue
            if msg['type']=='close':
                if active or owned(os.getpid(),known):cleanup('CLOSE_WITH_CHILDREN');continue
                reply(dict(type='closed',cleanup_verified=True));return 0
            if msg['type']!='run' or active or stopped:cleanup('PROTOCOL_ERROR');continue
            spec=msg['spec']; eff=min(now+spec['cap_seconds'],work_deadline,msg.get('tests_deadline',work_deadline))
            if eff<=time.monotonic():cleanup('NO_BUDGET');continue
            os.write(guardfd,(json.dumps(dict(deadline=eff))+'\n').encode())
            ack=b''
            while b'\n' not in ack:
                readable,_,_=select.select([ackfd],[],[],max(0,work_deadline-time.monotonic()))
                if not readable:raise RuntimeError('GUARD_ACK_TIMEOUT')
                data=os.read(ackfd,4096)
                if not data:raise RuntimeError('GUARD_LOST')
                ack+=data
            if json.loads(ack.split(b'\n')[0])!={'ack':'deadline','deadline':eff}:raise RuntimeError('GUARD_ACK_MISMATCH')
            stdout=run/(spec['id']+'.stdout');stderr=run/(spec['id']+'.stderr')
            handles=[open(stdout,'xb'),open(stderr,'xb')]
            # Handlers only append a flag; no exception interrupts spawn/registration.
            old=None
            try:
                child=subprocess.Popen(spec['argv'],cwd=spec['cwd'],env=msg['env'],stdin=subprocess.DEVNULL,stdout=handles[0],stderr=handles[1],start_new_session=True)
                ident=proc(child.pid)
                if ident:known[child.pid]=ident
                active=dict(id=spec['id'],stage=spec['stage'],tree=spec.get('tree'),argv=spec['argv'],cwd=spec['cwd'],environment=msg['env'],start_utc=utc(),start_mono=now,effective_deadline=eff,pid=child.pid,identity=ident,stdout=str(stdout),stderr=str(stderr),p=child,handles=handles)
                event(log,dict(action='spawn',id=spec['id'],identity=ident,effective_deadline=eff))
                reply(dict(type='started',id=spec['id'],pid=child.pid,effective_deadline=eff))
            finally:pass

class Coordinator:
    def __init__(self,policy):
        self.policy=policy;self.root=pathlib.Path(policy['root']);self.run=self.root/'run';self.run.mkdir(exist_ok=False)
        self.deadline=START+4800;self.work_deadline=START+4770;self.buf=b'';self.matrix=json.loads((self.root/'matrix-NOT_RUN.json').read_text());self.tests_deadline=None;self.gate=False
        self.lock=open(self.root.parent/'.causal-G1-campaign.lock','a+')
        fcntl.flock(self.lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        r,w=os.pipe();rr,ww=os.pipe();gr,gw=os.pipe();ar,aw=os.pipe();os.set_blocking(gw,False);self.guardfd=gw;self.guardack=ar;parent=proc(os.getpid())
        self.wd=subprocess.Popen([sys.executable,str(HERE/'supervisor.py'),'--watchdog',str(r),str(ww),str(self.deadline),str(self.work_deadline),str(os.getpid()),parent['start'],str(self.root),str(gw),str(ar)],pass_fds=(r,ww,gw,ar),stdin=subprocess.DEVNULL,stdout=open(self.run/'watchdog.stdout','xb'),stderr=open(self.run/'watchdog.stderr','xb'),start_new_session=True)
        os.close(r);os.close(ww);self.sendfd=w;self.readfd=rr
        wd_identity=proc(self.wd.pid)
        self.guard=subprocess.Popen([sys.executable,str(HERE/'guard_deadlines.py'),'--parent',str(os.getpid()),parent['start'],'--watchdog',str(self.wd.pid),wd_identity['start'],'--deadline',str(self.deadline),'--work-deadline',str(self.work_deadline),'--control-fd',str(gr),'--ack-fd',str(aw)],pass_fds=(gr,aw),stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=open(self.run/'guard.stderr','xb'),start_new_session=True)
        os.close(gr);os.close(aw)
        ready_guard=b''
        while b'\n' not in ready_guard:
            rd,_,_=select.select([ar],[],[],max(0,self.work_deadline-time.monotonic()))
            if not rd:raise RuntimeError('GUARD_START_TIMEOUT')
            piece=os.read(ar,4096)
            if not piece:raise RuntimeError('GUARD_START_FAILED')
            ready_guard+=piece
        if json.loads(ready_guard.split(b'\n')[0]).get('ack')!='ready':raise RuntimeError('GUARD_START_PROTOCOL')
        self.env={k:os.environ[k] for k in policy['environment_whitelist'] if k in os.environ}
        save(self.run/'matrix.json',self.matrix)
        for sig in [signal.SIGINT,signal.SIGTERM,signal.SIGHUP]:signal.signal(sig,self.cancel)
        if self.receive()['type']!='ready':raise RuntimeError('WATCHDOG_NOT_READY')
    def cancel(self,sig,frame):
        self.send(dict(type='stop',reason='COORDINATOR_SIGNAL_'+str(sig)));raise RuntimeError('CANCELLED')
    def send(self,x):os.write(self.sendfd,(json.dumps(x)+'\n').encode())
    def receive(self):
        while b'\n' not in self.buf:
            if time.monotonic()>=self.work_deadline:raise RuntimeError('GLOBAL_WORK_CAP')
            ready,_,_=select.select([self.readfd],[],[],0.1)
            if ready:
                d=os.read(self.readfd,65536)
                if not d:raise RuntimeError('WATCHDOG_LOST')
                self.buf+=d
        line,self.buf=self.buf.split(b'\n',1);return json.loads(line)
    def invoke(self,spec):
        if spec['stage']=='test' and not self.gate:raise RuntimeError('COMPARABILITY_NOT_PASS')
        if spec['stage']=='test' and self.tests_deadline is None:self.tests_deadline=time.monotonic()+900
        self.send(dict(type='run',spec=spec,env=self.env,tests_deadline=self.tests_deadline or self.work_deadline))
        while True:
            reply=self.receive()
            if reply['type']=='result':
                r=reply['result']
                if r['id']!=spec['id']:raise RuntimeError('RESULT_ID_MISMATCH')
                if r['termination_reason']:
                    if spec['stage']=='test':
                        row=next(x for x in self.matrix if x['invocation_id']==spec['id'])
                        row.update(status='DIAGNOSTIC_CAP' if 'CAP' in r['termination_reason'] else 'INTERRUPTED',termination_reason=r['termination_reason'],executable_signal='UNOBSERVED')
                        save(self.run/'matrix.json',self.matrix)
                    raise RuntimeError(r['termination_reason'])
                return r
            if reply['type']!='started':raise RuntimeError(str(reply))
            if spec['stage']=='test':
                row=next(x for x in self.matrix if x['invocation_id']==spec['id']);row.update(status='RUNNING',start_monotonic=time.monotonic())
                save(self.run/'matrix.json',self.matrix)
    def custody(self):
        s=self.policy['source_root'];live=pathlib.Path(self.policy['live']);expected=json.loads((pathlib.Path(s)/'custody-before.json').read_text())
        def git(*args):
            spec=dict(id='custody-'+str(time.monotonic_ns()),stage='custody',cap_seconds=10,cwd=str(live),argv=[self.policy['tools']['git']['path'],'--no-optional-locks','-C',str(live),*args])
            result=self.invoke(spec)
            if result['rc']!=0:raise RuntimeError('GIT_CUSTODY_READ_FAILED')
            return pathlib.Path(result['stdout']).read_bytes()
        ix=pathlib.Path(git('rev-parse','--git-path','index').decode().strip());ix=ix if ix.is_absolute() else live/ix
        got=dict(head=git('rev-parse','HEAD').decode().strip(),branch=git('branch','--show-current').decode().strip(),index_sha256=digest(ix),patch_sha256=hashlib.sha256(git('diff','--binary')).hexdigest(),status=git('status','--porcelain=v1','--untracked-files=all').decode(),cached_bytes=len(git('diff','--cached')))
        got['status_entries']=len(got['status'].splitlines())
        if got!=expected:raise RuntimeError('LIVE_CUSTODY_DIVERGENCE')
        for rel,h in json.loads((pathlib.Path(s)/'live-files-before.json').read_text()).items():
            if digest(live/rel)!=h:raise RuntimeError('LIVE_FILE_DIVERGENCE:'+rel)
        return got
    def preflight(self):
        for k in self.policy['forbidden_environment']:
            if os.environ.get(k):raise RuntimeError('UNAPPROVED_ENVIRONMENT:'+k)
        for p,h in json.loads((self.root/'evidence.sha256.json').read_text()).items():
            if digest(self.root/p)!=h:raise RuntimeError('V2_HASH_DIVERGENCE:'+p)
        for p,h in self.policy['references'].items():
            if digest(p)!=h:raise RuntimeError('REFERENCE_DIVERGENCE:'+p)
        old=pathlib.Path(self.policy['source_root'])
        for p,h in json.loads((old/'evidence.sha256.json').read_text()).items():
            if digest(old/p)!=h:raise RuntimeError('V1_HASH_DIVERGENCE:'+p)
        for t in self.policy['tools'].values():
            if digest(t['path'])!=t['sha256']:raise RuntimeError('TOOL_DIVERGENCE')
        for name,t in self.policy['tool_aliases'].items():
            effective=shutil.which(name,path=self.env.get('PATH',''))
            if not effective or str(pathlib.Path(effective).resolve())!=t['resolved'] or digest(effective)!=t['sha256'] or digest(t['path'])!=t['sha256']:raise RuntimeError('TOOL_ALIAS_DIVERGENCE:'+name)
        for p in self.policy['builds'].values():
            if pathlib.Path(p).exists() or pathlib.Path(p).is_symlink():raise RuntimeError('BUILD_EXISTS')
        sample=resources(self.root)
        if not resource_ok(sample):raise RuntimeError('INSUFFICIENT_RESOURCES')
        mine={os.getpid(),self.wd.pid,self.guard.pid};ps=allprocs();parent=ps.get(os.getpid(),{}).get('ppid')
        if parent:mine.add(parent)
        campaigns=[]
        for pid,p in ps.items():
            if pid in mine:continue
            try:
                comm=pathlib.Path('/proc',str(pid),'comm').read_text().strip()
                cmd=pathlib.Path('/proc',str(pid),'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
                if comm in self.policy['campaign_process_names'] or any(x in cmd for x in self.policy['campaign_command_markers']):campaigns.append(dict(pid=pid,comm=comm))
            except FileNotFoundError:pass
            except PermissionError:raise RuntimeError('CANNOT_EXCLUDE_CONCURRENT_CAMPAIGN')
        if campaigns:raise RuntimeError('CONCURRENT_CAMPAIGN:'+json.dumps(campaigns))
        loc=self.invoke(dict(id='locales',stage='preflight',cap_seconds=10,cwd=str(self.root),argv=[self.policy['tools']['locale']['path'],'-a']))
        if loc['rc']!=0:raise RuntimeError('LOCALE_DISCOVERY_FAILED')
        if os.uname().machine!=self.policy['architecture']:raise RuntimeError('ARCHITECTURE_DIFFERENCE')
        save(self.run/'preflight.json',dict(status='PASS',architecture=os.uname().machine,uname=list(os.uname()),environment=self.env,resources=sample,custody=self.custody(),utc=utc()))
    def observe_test(self,spec,r):
        # CTest JUnit is explicitly requested; it records observed one-test status.
        xml=pathlib.Path(spec['junit']);root=ET.parse(xml).getroot();cases=root.findall('.//testcase')
        if len(cases)!=1 or cases[0].get('name')!=spec['name']:raise RuntimeError('TEST_NOT_EXACTLY_ONE')
        c=cases[0]
        if c.find('skipped') is not None:raise RuntimeError('UNEXPECTED_SKIP')
        if c.find('error') is not None:raise RuntimeError('TEST_INFRASTRUCTURE_ERROR')
        fail=c.find('failure');text='' if fail is None else ET.tostring(fail,encoding='unicode')
        if c.get('status','run').lower() in ['notrun','disabled'] or any(x in text for x in ['Not Run','Unable to find executable','Failed to change working directory']):raise RuntimeError('TEST_NOT_EXECUTED')
        status='PASS' if fail is None else ('TIMEOUT' if 'Timeout' in text else ('ABORT' if 'Subprocess aborted' in text or 'Exception' in text else 'FAIL'))
        if r['rc'] not in [0,8] or (status=='PASS')!=(r['rc']==0):raise RuntimeError('CTEST_RC_STATUS_MISMATCH')
        row=next(x for x in self.matrix if x['tree']==spec['tree'] and x['name']==spec['name'])
        row.update(status=status,ctest_rc=r['rc'],ctest_signal=r['signal'],executable_signal='UNOBSERVED',assertions_not_emitted='UNOBSERVED',junit=str(xml),junit_sha256=digest(xml),stdout=r['stdout'],stderr=r['stderr'])
        save(self.run/'matrix.json',self.matrix)
        if spec['name'] in ['aether.smoke','aether.abi-c'] and status!='PASS':raise RuntimeError('CONTROL_FAILED')
    def execute(self):
        self.preflight()
        for spec in json.loads((self.root/'argv.json').read_text()):
            r=self.invoke(spec)
            if spec['stage']=='test':self.observe_test(spec,r)
            elif r['rc']!=0:raise RuntimeError('STAGE_FAILED:'+spec['id'])
            if spec['stage'] in ['inventory-gate','comparability']:
                result=json.loads(pathlib.Path(spec['output']).read_text())
                if result.get('status')!='PASS':raise RuntimeError('GATE_NOT_PASS')
                if spec['stage']=='comparability':self.gate=True
        save(self.run/'custody-after.json',self.custody())
        self.send(dict(type='close'))
        if self.receive()['type']!='closed':raise RuntimeError('CLEANUP_NOT_VERIFIED')
        self.wd.wait(timeout=max(.1,self.deadline-time.monotonic()))
        save(self.run/'outcome.json',dict(status='DIAGNOSTIC_COMPLETED_NOT_CERTIFICATION',end=utc(),wall=time.monotonic()-START))
        os.write(self.guardfd,b'{"done":true}\n')
        self.guard.wait(timeout=max(.1,self.deadline-time.monotonic()))
    def stop(self,error):
        try:self.send(dict(type='stop',reason=str(error)))
        except OSError:pass
        save(self.run/'outcome.json',dict(status='STOPPED',reason=str(error),end=utc(),wall=time.monotonic()-START,cleanup_verified=False))
        # Pending rows remain NOT_RUN; a started capped test is separately marked.
        for p in self.run.glob('test-*.json'):
            r=json.loads(p.read_text())
            if r.get('termination_reason'):
                for row in self.matrix:
                    if row.get('invocation_id')==r['id']:row.update(status='DIAGNOSTIC_CAP' if 'CAP' in r['termination_reason'] else 'INTERRUPTED',termination_reason=r['termination_reason'])
        save(self.run/'matrix.json',self.matrix)
        try:
            live=pathlib.Path(self.policy['live']);old=pathlib.Path(self.policy['source_root'])
            mismatches=[p for p,h in json.loads((old/'live-files-before.json').read_text()).items() if not (live/p).is_file() or digest(live/p)!=h]
            save(self.run/'custody-stop.json',dict(file_mismatches=mismatches,git_metadata='UNOBSERVED_AFTER_STOP',status='INCOMPLETE_CUSTODY_CHECK'))
        except Exception as e:event(self.run/'errors.jsonl',dict(custody_stop_error=type(e).__name__))
        try:self.wd.wait(timeout=max(.1,self.deadline-time.monotonic()-1))
        except subprocess.TimeoutExpired:pass
        if self.wd.poll() is not None:
            os.write(self.guardfd,b'{"done":true}\n')
            self.guard.wait(timeout=max(.1,self.deadline-time.monotonic()))

if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='--watchdog':
        try:sys.exit(watchdog(int(sys.argv[2]),int(sys.argv[3]),float(sys.argv[4]),float(sys.argv[5]),int(sys.argv[6]),sys.argv[7],sys.argv[8],int(sys.argv[9]),int(sys.argv[10])))
        except BaseException:
            # No new work after unexpected watchdog failure. Kill owned descendants.
            known={}
            for x in owned(os.getpid(),known):
                if same(x):
                    try:send_signal(x,signal.SIGKILL)
                    except ProcessLookupError:pass
            raise
    if len(sys.argv)!=1:raise SystemExit('No bypass/resume options supported')
    c=None
    try:
        c=Coordinator(json.loads((HERE/'policy.json').read_text()));c.execute()
    except BaseException as e:
        if c is not None:c.stop(e)
        raise

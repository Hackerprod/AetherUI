#!/usr/bin/env python3
"""STATIC-PREPARED, NOT EXECUTED. Closed comparison gate, never executes product.
All subprocesses are readelf/ldconfig only and remain in the supervisor's group.
The caller must enforce the effective phase/global deadline and kill the group.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shlex
import subprocess
import sys
import time

class Blocked(RuntimeError):
    pass

def require(ok, reason):
    if not ok:
        raise Blocked(reason)

def sha(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

class Gate:
    def __init__(self, policy):
        self.policy = policy
        self.old = Path(policy['source_root']).resolve()
        self.root = Path(policy['run_root']).resolve()
        self.inputs = {}
        self.checks = []
        self.elf_records = {}
        self.tools_log = []
        self.historical_source = str(self.old.parent / 'aetherui-drawing-integration-C-20261116-01')
        self.historical_build = str(self.old.parent / 'drawing-cmake-validation-C-20261116-05/default')
        self.selected = self.read_json(self.old / 'selected-targets.json')
        self.closure = self.selected + ['aether_core', 'aether_flex_text_test_core']
        self.names = self.read_text(self.old / 'selection-exact.txt').splitlines()
        require(len(self.selected) == 18 and len(self.names) == 22, 'Selection cardinality')
        self.lookup_targets = {'aether_core','aether_flex_text_test_core',
                               'aether_stylesheet_source_order_runtime_test'}
        self.lookup = 'src/layout/style_lookup_box.cpp'

    def read_text(self, path):
        path = Path(path)
        before = sha(path)
        text = path.read_text()
        require(before == sha(path), 'Input changed while reading: '+str(path))
        self.inputs[str(path)] = before
        return text

    def read_json(self, path):
        return json.loads(self.read_text(path))

    def norm(self, value, tree=None, historical=False):
        if isinstance(value, list):
            return [self.norm(v,tree,historical) for v in value]
        if isinstance(value, dict):
            return {k:self.norm(v,tree,historical) for k,v in value.items()}
        if not isinstance(value, str):
            return value
        if historical:
            pairs = [(self.historical_source,'<SOURCE>'),(self.historical_build,'<BUILD>')]
        else:
            require(tree in ('Hc','J'), 'Normalization tree')
            pairs = [(str(self.old/tree),'<SOURCE>'),(str(self.root/('build-'+tree)),'<BUILD>')]
        for origin, replacement in pairs:
            value = value.replace(origin,replacement)
        return value

    def testfile(self, path):
        tests = {}
        properties = {}
        for raw in self.read_text(path).splitlines():
            line = raw.strip()
            if not line or line.startswith('#'):
                continue
            m = re.fullmatch(r'(add_test|set_tests_properties)\((.*)\)',line)
            require(m is not None,'Unsupported generated test metadata: '+line[:140])
            words = shlex.split(m.group(2),posix=True)
            require(bool(words),'Empty generated command')
            name = words[0]
            if m.group(1) == 'add_test':
                require(name not in tests and len(words)>1,'Duplicate/empty test')
                tests[name] = words[1:]
            else:
                require(len(words)>1 and words[1]=='PROPERTIES' and len(words[2:])%2==0,
                        'Unsupported properties syntax')
                require(name not in properties,'Duplicate property declaration')
                properties[name] = dict(zip(words[2::2],words[3::2]))
                # Source line coordinates are non-semantic and deliberately not compared.
                properties[name].pop('_BACKTRACE_TRIPLES',None)
        require(len(tests)==287 and set(properties)==set(tests),'Generated inventory count/set')
        return {name:{'command':cmd,'properties':properties[name]} for name,cmd in tests.items()}

    def inventories(self, built=False):
        expected = self.read_json(self.old/'historical-default-inventory.stdout')['tests']
        require(len(expected)==287 and len({t['name'] for t in expected})==287,'Historical inventory')
        oldmeta = self.testfile(self.root/'references/historical-CTestTestfile.cmake')
        oldnames = [t['name'] for t in expected]
        require(list(oldmeta)==oldnames,'Historical CTest metadata ordering mismatch')
        unresolved = {}
        for tree in ('Hc','J'):
            inv = self.read_json(self.policy['inventories'][tree])['tests']
            require([t['name'] for t in inv]==oldnames,tree+' inventory names/order differ')
            meta = self.testfile(self.root/('build-'+tree)/'CTestTestfile.cmake')
            require(self.norm(meta,tree)==self.norm(oldmeta,historical=True),tree+' generated test metadata differs')
            unresolved[tree] = []
            for before,after in zip(expected,inv):
                name = before['name']
                require(self.norm(before.get('properties',[]),historical=True)==
                        self.norm(after.get('properties',[]),tree),tree+' test properties differ: '+name)
                # Missing commands before build are not silently accepted: require exact generated command.
                require(self.norm(oldmeta[name]['command'],historical=True)==
                        self.norm(before['command'],historical=True), 'Historical command disagreement: '+name)
                if 'command' in after:
                    require(self.norm(after['command'],tree)==self.norm(before['command'],historical=True),
                            tree+' command differs: '+name)
                else:
                    require(built or not Path(meta[name]['command'][0]).exists(),tree+' missing command despite existing executable')
                    unresolved[tree].append(name)
                if built and name in self.names:
                    executable = Path(meta[name]['command'][0])
                    require(executable.is_file() and os.access(executable,os.X_OK),tree+' selected executable missing: '+name)
                    require(executable.parent.resolve()==(self.root/('build-'+tree)).resolve(),tree+' selected executable outside build')
                    require(executable.name in self.selected,tree+' executable not in target list')
                    self.inputs[str(executable)] = sha(executable)
        self.checks.append({'check':'inventory_287_metadata_and_properties','status':'PASS',
                            'unresolved_before_build':unresolved,'selected_built':built})

    def compile_map(self, path, tree=None, historical=False):
        data = self.read_json(path)
        mapped = {}
        for row in data:
            argv = row.get('arguments') or shlex.split(row['command'])
            require('-o' in argv and '-c' in argv,'Unsupported compile command')
            obj = argv[argv.index('-o')+1]
            m = re.search(r'(?:^|/)CMakeFiles/([^/]+)\.dir/(.*)\.o$',obj)
            require(m is not None,'Unsupported object path')
            target,rel = m.groups()
            if target not in self.closure:
                continue
            key = (target,rel)
            require(key not in mapped,'Duplicate compile entry '+str(key))
            source = Path(row['file'])
            sourcebase = Path(self.historical_source) if historical else self.old/tree
            require(source == sourcebase/'native'/rel,'Compile file/object mismatch '+str(key))
            directory = Path(row['directory'])
            expected_dir = Path(self.historical_build) if historical else self.root/('build-'+tree)
            require(directory==expected_dir,'Compile directory mismatch')
            mapped[key] = self.norm(argv,tree,historical)
        return mapped

    def compile_and_link(self):
        historic = self.compile_map(self.old/'historical-compile_commands.json',historical=True)
        actual = {t:self.compile_map(self.root/('build-'+t)/'compile_commands.json',t) for t in ('Hc','J')}
        require(actual['J']==historic,'J compile command closure differs from frozen historical J')
        # J's lookup TU is the ONLY allowed extra compile command; flags must equal layout_box TU.
        reduced = dict(actual['J'])
        for target in self.lookup_targets:
            key = (target,self.lookup)
            require(key in reduced,'Missing approved lookup TU')
            old = reduced[(target,'src/layout/layout_box.cpp')]
            new = [v.replace(self.lookup,'src/layout/layout_box.cpp') for v in reduced.pop(key)]
            require(new==old,'Lookup TU has additional compile flags')
        require(actual['Hc']==reduced,'Hc/J compile flags/source order differs beyond lookup')
        for tree in ('Hc','J'):
            manifest = self.read_json(self.old/('manifest-'+tree+'.json'))
            declared = self.read_json(self.old/('target-map-'+tree+'.json'))
            for target in self.closure:
                expected_sources = {s for s in declared[target]['sources'] if not s.startswith('$<')}
                observed = {s for t,s in actual[tree] if t==target}
                require(expected_sources==observed,'Source closure mismatch '+tree+'/'+target)
                for source in observed:
                    p = self.old/tree/'native'/source
                    require(sha(p)==manifest['native/'+source],'Source content drift '+str(p))
                    self.inputs[str(p)] = sha(p)
            for target in self.closure:
                flagfile=self.root/('build-'+tree)/'CMakeFiles'/(target+'.dir')/'flags.make'
                historicflag=self.old/'historical-target-artifacts'/target/'flags.make'
                require(self.norm(self.read_text(flagfile),tree)==self.norm(self.read_text(historicflag),historical=True),
                        tree+' flags.make differs '+target)
        for target in self.closure:
            oldpath=self.old/'historical-target-artifacts'/target/'link.txt'
            if not oldpath.exists():
                require(target=='aether_flex_text_test_core','Missing historical link '+target)
                continue
            expected=shlex.split(self.read_text(oldpath))
            links={}
            for tree in ('Hc','J'):
                path=self.root/('build-'+tree)/'CMakeFiles'/(target+'.dir')/'link.txt'
                links[tree]=self.norm(shlex.split(self.read_text(path)),tree)
            require(links['J']==self.norm(expected,historical=True),'J linker drift '+target)
            permitted=[]
            if target in self.lookup_targets:
                permitted=['CMakeFiles/'+target+'.dir/'+self.lookup+'.o']
            if target=='aether_style_diff_catalog_test':
                permitted=['CMakeFiles/aether_flex_text_test_core.dir/'+self.lookup+'.o']
            reduced=[x for x in links['J'] if x not in permitted]
            require(all(links['J'].count(x)==1 for x in permitted),'Expected lookup link object missing/duplicate')
            require(reduced==links['Hc'],'Link order/options differ beyond lookup '+target)
        self.checks.append({'check':'compile_sources_flags_link_order','status':'PASS',
                            'only_allowed_extra_source':self.lookup,'targets':sorted(self.lookup_targets)})

    def tool(self,name,args):
        entry=self.policy['tools'][name]
        path=Path(entry['path'])
        require(sha(path)==entry['sha256'],'Inspection tool hash changed '+name)
        require(name in ('readelf','ldconfig'),'Forbidden tool')
        start=time.monotonic()
        # Inherit the supervisor process group: its watchdog owns this child too.
        p=subprocess.run([str(path),*args],capture_output=True,text=True,timeout=15,
                         env={'PATH':'/usr/bin:/usr/sbin:/bin','LC_ALL':'C'})
        self.tools_log.append({'argv':[str(path),*args],'start_monotonic':start,
                               'end_monotonic':time.monotonic(),'rc':p.returncode,
                               'stdout':p.stdout,'stderr':p.stderr})
        require(p.returncode==0,'Inspection tool failure '+name)
        return p.stdout

    def elf(self,path):
        path=Path(path).resolve()
        if str(path) in self.elf_records:
            return self.elf_records[str(path)]
        require(path.is_file(),'ELF missing '+str(path))
        h=self.tool('readelf',['-h',str(path)])
        require('ELF64' in h and 'Advanced Micro Devices X86-64' in h,'Unsupported ELF architecture')
        dynamic=self.tool('readelf',['-d',str(path)])
        program=self.tool('readelf',['-l',str(path)])
        needed=re.findall(r'\(NEEDED\).*?\[(.*?)\]',dynamic)
        paths={k:re.findall(r'\('+k+r'\).*?\[(.*?)\]',dynamic) for k in ('RPATH','RUNPATH')}
        require(len(paths['RPATH'])<=1 and len(paths['RUNPATH'])<=1,'Multiple ELF search tags')
        require(not paths['RPATH'],'DT_RPATH inheritance not supported; cannot prove loader resolution')
        require(not re.search(r'\((?:AUDIT|DEPAUDIT|FILTER|AUXILIARY)\)',dynamic),'Loader redirection tag')
        require('NODEFLIB' not in dynamic,'NODEFLIB unsupported')
        interpreter=re.findall(r'Requesting program interpreter:\s*([^\]]+)',program)
        require(len(interpreter)<=1,'Multiple interpreters')
        rec={'sha256':sha(path),'needed':needed,'runpath':paths['RUNPATH'][0].split(':') if paths['RUNPATH'] else [],
             'interpreter':interpreter[0] if interpreter else None}
        self.elf_records[str(path)]=rec
        self.inputs[str(path)]=rec['sha256']
        return rec

    def dependencies(self):
        for name in ('LD_PRELOAD','LD_LIBRARY_PATH','LD_AUDIT','GLIBC_TUNABLES'):
            require(not os.environ.get(name),'Unexpected loader environment '+name)
        require(not Path('/etc/ld.so.preload').exists() or not Path('/etc/ld.so.preload').read_text().strip(),
                'System preload prevents proof')
        cache_path=Path('/etc/ld.so.cache')
        require(cache_path.is_file(),'Loader cache unavailable')
        self.inputs[str(cache_path)]=sha(cache_path)
        cache_text=self.tool('ldconfig',['-p'])
        cache={}
        for line in cache_text.splitlines():
            m=re.match(r'\s*(\S+)\s+\(([^)]+)\)\s+=>\s+(\S+)\s*$',line)
            if m and 'x86-64' in m.group(2):
                cache.setdefault(m.group(1),[]).append(Path(m.group(3)))
        require(cache,'Empty loader cache')
        systems={}
        for tree in ('Hc','J'):
            build=(self.root/('build-'+tree)).resolve()
            queue=[build/t for t in self.selected]
            queue.append(build/'libaether_core.so.0.1.0')
            visited=set(); system={}; edges=[]
            while queue:
                file=queue.pop(0).resolve()
                if file in visited:continue
                visited.add(file)
                rec=self.elf(file)
                dirs=[]
                for directory in rec['runpath']:
                    require(directory and not any(c in directory for c in ('$LIB','$PLATFORM')),'Unsupported runpath expansion')
                    directory=directory.replace('${ORIGIN}',str(file.parent)).replace('$ORIGIN',str(file.parent))
                    require('$' not in directory and Path(directory).is_absolute(),'Unproven ELF search path')
                    directory=Path(directory).resolve()
                    require(directory==build,'Non-own-build RUNPATH: '+str(directory))
                    dirs.append(directory)
                for needed in rec['needed']:
                    require('/' not in needed,'NEEDED path is not soname')
                    candidates=[d/needed for d in dirs if (d/needed).exists()]
                    if candidates:
                        resolved=candidates[0].resolve()
                    else:
                        candidates=cache.get(needed,[])
                        # Refuse ambiguous/hwcap cache instead of guessing loader priority.
                        require(len(candidates)==1,'Unproved/ambiguous system resolution '+needed)
                        require('glibc-hwcaps' not in str(candidates[0]),'HWCAP resolution not approved')
                        resolved=candidates[0].resolve()
                    require(resolved.is_file(),'Unresolved needed '+needed)
                    if needed.startswith('libaether_core'):
                        require(resolved.parent==build,'Cross-tree core resolution')
                    elif resolved.parent==build:
                        raise Blocked('Unexpected locally resolved library '+needed)
                    else:
                        require(str(resolved).startswith(('/usr/lib/','/lib/')),'Unexpected library origin '+str(resolved))
                        system[str(resolved)]=sha(resolved)
                    edges.append({'object':str(file),'needed':needed,'resolved':str(resolved),'sha256':sha(resolved)})
                    queue.append(resolved)
                if rec['interpreter']:
                    loader=Path(rec['interpreter']).resolve()
                    require(str(loader).startswith(('/usr/lib/','/lib/')),'Unapproved interpreter')
                    system[str(loader)]=sha(loader);queue.append(loader)
            systems[tree]=system
            self.checks.append({'check':'ELF_resolution_'+tree,'status':'PASS','edges':edges,
                                'objects':[str(x) for x in sorted(visited)]})
        require(systems['Hc']==systems['J'],'System library/interpreter paths or hashes differ')
        self.checks.append({'check':'identical_system_dependencies','status':'PASS','libraries':systems['Hc']})

    def unchanged(self):
        for path,h in self.inputs.items():
            require(sha(path)==h,'Gate input mutated: '+path)


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--phase',required=True,choices=['inventory','comparability'])
    parser.add_argument('--policy',required=True)
    parser.add_argument('--output',required=True)
    args=parser.parse_args()
    report={'status':'BLOCKED','phase':args.phase,'attribution':'UNDETERMINED'}
    gate=None
    try:
        policy=json.loads(Path(args.policy).read_text())
        gate=Gate(policy)
        gate.inputs[str(Path(args.policy).resolve())]=sha(args.policy)
        gate.inventories(built=args.phase=='comparability')
        if args.phase=='comparability':
            gate.compile_and_link()
            gate.dependencies()
        gate.unchanged()
        report['status']='PASS'
    except Exception as exc:
        report['error']=type(exc).__name__+': '+str(exc)
    finally:
        if gate is not None:
            report.update(inputs=gate.inputs,checks=gate.checks,elf=gate.elf_records,tool_invocations=gate.tools_log)
        output=Path(args.output)
        temporary=output.with_suffix(output.suffix+'.tmp')
        with open(temporary,'x') as f:
            json.dump(report,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
        os.replace(temporary,output)
    return 0 if report['status']=='PASS' else 2

if __name__=='__main__':
    sys.exit(main())

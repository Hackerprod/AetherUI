# C · Materialización estática v2 · 2026-11-16

**STATIC_PREPARATION_ONLY. EXECUTION_NOT_AUTHORIZED.** Preparada tras PASS de revision-propuesta-correccion-causal-G1-D-v2-20261116.md. Requiere revisión D de estos bytes/hashes y nueva apertura explícita. No se ejecutaron, importaron, compilaron ni probaron supervisor.py o verify_comparability.py. Tampoco configure, build, CTest, producto ni pruebas sintéticas. Se usó Python sólo para escribir JSON, editar texto y calcular hashes, nunca para cargar los programas nuevos.

## Archivos y referencias

- supervisor.py: coordinador de máquina de estados y watchdog independiente. El watchdog es dueño de los subprocesses y Linux child subreaper, también recoge descendientes adoptados. Los subprocesses del verificador permanecen bajo su supervisión.
- guard_deadlines.py: guardia mínima independiente del IO del watchdog, sin hashes/fsync/logs; conoce deadlines efectivos con ACK previo a spawn. Mantiene techo absoluto también después de finalizar el watchdog y hasta último registro del coordinador.
- verify_comparability.py: gates cerrados de inventario y comparabilidad. Metadatos 287, fuentes/flags/enlace y ELF transitivo read-only con readelf/ldconfig. No usa ldd ni ejecuta producto.
- policy.json: raíces exactas, referencias/hashes, herramientas, whitelist y variables prohibidas, límites y exclusión de campañas.
- argv.json: orden concreto y argumentos. Ambos configure/inventarios, gate inventario, builds seriales Hc/J, gate comparativo, sólo entonces 22 tests Hc y 22 J.
- matrix-NOT_RUN.json: 44 pendientes, ninguna atribución causal.
- references/historical-CTestTestfile.cmake: copia del metadato -05, para resolver comandos ausentes antes de build sin inventar igualdad.
- evidence.sha256.json: todos los archivos entregados salvo él mismo. No contiene run/ ni builds porque no existen.

H/Hc/J se referencian desde -01 sin modificarse. Se conserva adaptador A SHA256 4f15fd37f28ec395b16938f55d474621e2370b950161ca35108147ab9221dd39 y manifiesto -01 SHA256 142c35c945ca301d46a9e60bc0394a27845c7619800fb4dc70e716d7314ff2f2. La limitación causal por A aceptada por D continúa; no se afirma equivalencia con HEAD limpio.

## D-1: implementación para revisión

Reloj absoluto desde entrada del supervisor: 4800 s; deadline de trabajo 4770 s; reserva de cierre 30 s dentro del techo. Caps configure 120, build 1800, cada test 120, tests agregados 900. Inventario/verificador 120 cada uno; custodia Git/locales 10. Todos consumen techo, sin reintento. El watchdog recibe cap efectivo por invocación y agregado, además del global. Su bucle no depende de que el coordinador lea resultados. Una tercera guardia mínima, separada de escritura/hash/fsync del watchdog, recibe y confirma el deadline antes de cada spawn y vigila también el cierre del coordinador. En corte congela temporalmente watchdog/descendientes propios mediante pidfd SIGSTOP para inventariar antes de TERM/CONT y KILL; no certifica recolección, que pertenece al watchdog. No intenta modificar ni señalar procesos ajenos. EOF, pérdida de padre, señal, presión o deadline detienen trabajo.

PID/PGID/starttime se registran; señales mediante pidfd fijado y validado, nunca kill/killpg sobre identificadores reutilizables. Los grupos se registran y se contienen a través de sus procesos y descendientes identificados. El watchdog subreaper rastrea y recoge descendientes, incluyendo los que cambian grupo. SIGTERM, hasta 5 s y después SIGKILL dentro del presupuesto restante. Salida de hijo con descendientes vivos es anomalía que detiene. Popen recoge hijo directo, waitpid recoge adoptados hasta ECHILD; no se declara cleanup_verified si quedan identidades propias, incluso zombies. Si no puede demostrarse limpieza, no se declara éxito. El cierre abrupto conserva matriz/logs incrementales; estado RUNNING no equivale a resultado. Inmovilidad del kernel o caída del sistema pueden impedir observación/registro, no se presentan como garantías perfectas.

Preflight comprueba contenido completo congelado -01 y -02, herramientas y aliases efectivos cc/c++/make/python3, arquitectura, variables de inyección ausentes, builds nuevos, exclusión local y procesos ajenos visibles, disco 12 GiB y memoria 4 GiB. Watchdog muestrea recursos cada segundo, incluyendo RSS de procesos propios. Locales se leen con locale -a supervisado; no se instalan. Entorno registrado sólo whitelist. Custodia Git está supervisada también. Tras éxito se repite custodia completa; tras parada se conserva chequeo de hashes posible y se identifica explícitamente metadato Git posterior no observado, sin afirmar custodia final completa cuando el supervisor ya no admite subprocesses.

Por invocación conserva argv/cwd/entorno, UTC/monotónico, rc/señal de subprocess, causa de terminación, stdout/stderr y hashes. CTest no es el ejecutable test: señal real del ejecutable queda UNOBSERVED cuando no está expuesta. Se añade `--output-junit` como salida observacional de CTest, sin cambiar selección, ejecutable, fixtures o timeout. Exige exactamente un testcase con nombre esperado; cero tests, skip/not-run o inconsistencia rc/estado bloquean. D debe revisar esta adición explícita de salida. La clasificación ABORT depende del mensaje disponible; no se inventa número de señal. Assertions no emitidas permanecen UNOBSERVED. Un control fallido detiene; fallos diagnósticos de los otros casos se conservan sin reparar.

## D-2: comparabilidad antes de pruebas

El coordinador no habilita TESTS hasta rc0 y status PASS del reporte comparability.json. Los 287 nombres/orden/props/argumentos se contrastan con el histórico y CTestTestfile generado. Metadatos de ubicación de fuente `_BACKTRACE_TRIPLES` se excluyen de comparación por su naturaleza no semántica, conservando originales; ninguna opción de prueba se elimina. Antes del build, comando ausente requiere evidencia exacta en CTestTestfile; después, los 22 ejecutables deben existir en su build propio.

Compile commands y flags/enlace J deben reproducir el cierre histórico normalizando sólo raíces. Hc/J permiten exactamente los objetos/fuente lookup adicionales en core, flex_text/source-order y consumidor catálogo. No se concede una excepción genérica a CMake ni al resto de archivos. Se conserva orden de argumentos/link. Fuentes se cotejan con manifiestos; los hash de binarios/core se registran por separado, no se exige su igualdad.

ELF: readelf -h/-d/-l y ldconfig -p, ambos con hashes congelados; resolución transitiva y dependencias de sistema idénticas. Sin LD_* o GLIBC_TUNABLES ni preload del sistema. Resolver conservador: DT_RPATH, cache ambiguo/hwcaps, redirección dinámica o ruta no demostrable => BLOCKED. No se relaja para hacer pasar. Gate escribe entradas/hashes originales y reporte; revalida entradas antes de PASS.

## Cómo se usaría, sólo después de nuevo gate D

Entrada única sería el Python exacto de policy invocando supervisor.py sin opciones, cwd este directorio. `run/`, `build-Hc/` y `build-J/` deben ser inexistentes. No hay resume/skip/retry. Los flags internos --watchdog son protocolo privado, no ruta alternativa de campaña. La política conserva NOT_AUTHORIZED_FOR_EXECUTION hasta que exista dictamen externo; no editar bytes para abrir gate, pues invalidaría sus hashes revisados. La autorización debe referenciar este manifiesto exacto.

Una discrepancia bloquea y exige D; no elegir otro procedimiento durante la tanda. No hay ejecución #159, instrumentación, puente adicional ni modificación de producto. Preservar -01 y toda evidencia anterior. Sin publicación/red/instalación/otro equipo/render.

## Estado

Este es código preparado, no validación dinámica del supervisor. Su revisión puede encontrar bloqueos, que deben corregirse en nueva versión explícita antes de ejecutar. No se promete PASS de build o causalidad. **G1 NOT_PASSED; OFF/ON/G2 bloqueados; G3/G4 cerrados; coverage_complete=false.**

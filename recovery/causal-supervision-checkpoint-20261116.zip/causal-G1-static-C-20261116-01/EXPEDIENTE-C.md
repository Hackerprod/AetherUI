# C · Expediente estático causal G1 · 2026-11-16

**PREPARATION_ONLY / EXECUTION_NOT_AUTHORIZED. Para revisión D.**
Se leyeron íntegros plan A y dictamen B. No se invocó CMake, CTest, compilador, binarios, profiling, pruebas ni renders. No publicación/red, instalación, operaciones Git mutantes ni modificación del producto vivo. Las únicas escrituras son copias y evidencia en este directorio.

## Identidades y custodia

H es extracción `git archive` del HEAD 22fba13df2dc7775d4e091dac432c3e4b2960c46. H-head.tar retiene extracción original. J copia los 1442 archivos versionados/no ignorados del checkout vivo, incluyendo native/src/layout/style_lookup_box.cpp. No se copió .git ni cache, objetos o build. Hc es copia H más A; no es HEAD limpio. Manifiestos completos manifest-H/Hc/J.json. Congelación por hashes, sin cambiar permisos del sistema. No modificar estos árboles después de la revisión.

Custodia before/after idéntica: rama local/drawing-exact-v3, índice be7b51333cf41b08f39b6a73c21f8a933daa45cece43b42595cc9f7bc3b49361, parche 40391aa9f6c15926e08c5ec4109f18a3384814a1c19762bded8d4983c1527a08, 64 caminos WIP, cached diff vacío. Verificados 843 hashes fuentes/referencias -05, 64 WIP y 1442 archivos vivos antes/después. No se recalculó todo el inventario de objetos/logs históricos -05; no se escribieron sus directorios. Su auditoría histórica D/B no se sustituye aquí.

## Adaptador A exacto

`adapter-A.patch`: dos hunks exclusivamente en native/CMakeLists.txt. Añaden el include privado src/rendering/preparation/include a:
1. aether_stylesheet_source_order_runtime_test: incorpora fuentes de core salvo runtime/compiler, más dos TUs de prueba; estas incluyen los originales con predicado de límite reducido a 128 bytes, sin modificarlo.
2. aether_flex_text_test_core: objeto de core completo usado por aether.style-diff-catalog. No omitir este cierre por excluir classifier.

Ambos cierres contienen src/rendering/document_scroll_requests.cpp, cuyo include aether/rendering/preparation/detail/utf8.hpp requiere ese directorio; core ya lo tiene privado, pero los consumidores de fuentes no lo heredan. El directorio y header existen idénticos en H y J. Los hunks no cambian fuentes, lógica, expectativas, fixtures, defines, inventario ni flags semánticos. J contiene los mismos includes a través de foreach. No se propone soporte OOM, frozen_style para z-index ni guard classifier, porque no pertenecen al cierre seleccionado. La extracción style_lookup_box de J NO forma parte de A.

**Comparación expresamente limitada por A, pendiente aceptación D:** no se presume inocuidad semántica de cambiar resolución de includes. No se solicita control puente adicional dentro de las 44 ejecuciones. Si D requiere un puente, necesita nuevo alcance y presupuesto. No se podrá afirmar preexistencia en H; sólo reproducción en Hc. Si el baseline queda bloqueado, BASELINE_BLOCKED / CAUSAL_UNRESOLVED, sin reparación automática.

## Mapa comparable y delta

selection-historical.json enlaza 22 nombres exactos con comandos y modos del inventario histórico. selected-targets.json contiene 18 targets. Se mantienen closed/open/mixed para los dos ejecutables EOF, profundidad 10000 sin cambiar. #159 excluido.

Los tres target-map-*.json detallan fuentes/hash, declaraciones, defines/includes/enlace. Incluyen core y flex_text; foreach de readers agrega seis fuentes a transform-origin-dispatch y foreach Linux agrega los includes de J. Las declaraciones conservan también ramas MSVC inactivas: el mapa es estático, no una evaluación CMake ni compile_commands nuevos.

Cierre: 16 targets seleccionados enlazan AetherUI::Core (incluido compiler EOF, hook y semantic diff); source-order-runtime compila core propio sin enlazar shared; catálogo consume objetos flex_text sin shared. aether_core tiene 80 fuentes en H/Hc y 81 en J por style_lookup_box. El objeto flex_text y source-order heredan esa diferencia. transform-origin-dispatch contiene registro privado, AETHER_CSS_NUMERIC_ONLY y en Linux AETHER_OPACITY_LOCALE_WRAPPERS, con --wrap=newlocale,freelocale,strtod_l,strtod,strtof. flex-number-pipeline añade CMAKE_DL_LIBS. EOF compiler tiene AETHER_CSS_NUMERIC_ONLY. Source-order y flex_text tienen AETHER_EXPORTS. Core usa visibilidad hidden; todos heredan C++20/PIC, Debug -g, los tests y core -ffp-contract=off. ABI-C mantiene C11. Las banderas -Wall/-Wextra/-pedantic sólo donde CMake las asigna; no homogeneizarlas artificialmente.

`delta-J-minus-H.json` clasifica los 64 caminos; `J-minus-H-tracked.patch` más `J-new-style_lookup_box.cpp` conserva todo el cambio. CMake es mixto: extracción/enlace, reparación includes/OOM/z-index, include DrawingExample. layout_box/style_lookup_box es confusor runtime real dentro de los cierres, no dibujo descartable. software_renderer pertenece al dibujo fuera de core seleccionado; classifier es cobertura fuera del cierre. Ejemplos, contratos y documentación se mantienen completos en J sin ejecutarlos. Ni ausencia de un archivo en cierre ni coincidencia de assertions demuestran causa.

## Invocaciones propuestas y condiciones para D

`argv-proposal-NOT-RUN.json` contiene argv/cwd y caps de configure, inventario, build y cada nombre; es dato, no script ejecutado. Rutas build-Hc y build-J son nuevas y aún inexistentes. Orden propuesto Hc completo y después J, tests en orden histórico de los 20 y luego smoke/abi-c. Debe detenerse antes de pruebas si configure/build falla. No all, reintentos ni variantes.

CMake/CTest exactos 4.4.5 según registros -05; GCC/G++ 14.2.0 y herramientas locales conservadas en historical-tools.sha256.json. Opciones exactamente -DCMAKE_BUILD_TYPE=Debug -DCMAKE_EXPORT_COMPILE_COMMANDS=ON -DAETHERUI_BUILD_TESTS=ON, drawing no definido/default OFF. historical-target-artifacts contiene flags.make/link.txt/DependInfo.cmake y historical-compile_commands.json conserva mediciones anteriores, NO mediciones de Hc/J. Inventario completo esperado 287 nombres/argumentos según historical-default-inventory.stdout, con prefijos de árbol/build sustituidos solamente. Inventarios nuevos NOT_RUN. Diferencia inesperada exige D, no filtrar para hacerla desaparecer.

Antes de una eventual tanda: revalidar todos los manifiestos y custodia, herramientas, máquina/arquitectura, entorno relevante sin secretos, locale y locales disponibles, memoria >=4 GiB, disco >=12 GiB, carga y ausencia de otra campaña. Las condiciones de recursos son preflight futuro, no una autorización actual. Tras configure comparar compile_commands y link líneas normalizando sólo prefijos, verificar dependencias/RPATH/hash de bibliotecas del árbol correcto antes de ejecutar. Cualquier diferencia no aprobada suspende.

Límites rectores: 2 configure a 120 s, builds seriales 1800 s cada uno --parallel 2 --verbose; tests -j1 una vez/nombre/árbol, 44 máximo, 120 s externos/test, 900 s agregado tests, 4800 s techo absoluto incluyendo registros/cierre. No cambiar TIMEOUT histórico. El inventario también consume el techo global. DIAGNOSTIC_CAP detiene tanda y deja pendientes NOT_RUN. El ejecutor futuro necesita supervisor revisado que registre argv/cwd/inicio/fin/rc/señal, use grupos de procesos y termine/recolecte descendientes también en cancelación/cap global. **No se adjunta ni se autoriza un runner dinámico en este gate estático; D debe exigir su revisión antes de ejecutar si el mecanismo existente no cubre estos caps.**

No hay flags/link/dependencias nuevos ni matriz runtime: quedan NOT_RUN. No hay instrumentación. Assertions posteriores a abort quedan no observadas; todas las atribuciones UNDETERMINED. No se inició protocolo #159. D debe decidir aceptación de custodia, mapas, adaptador y limitación por A antes de abrir ejecución, y resolver cualquier carencia sin improvisación.

**G1 NOT_PASSED; OFF/ON/G2 bloqueados; G3/G4 cerrados; coverage_complete=false.** Este expediente no certifica los 287 tests ni producto, rendimiento, plataformas o LSan.

import pathlib,subprocess,json,hashlib,shutil,tarfile,io,os,difflib,re
R=pathlib.Path.cwd(); E=R/'causal-G1-static-C-20261116-01'; L=R/'aetherui-drawing-integration-C-20261116-01'; OLD=R/'drawing-cmake-validation-C-20261116-05'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def out(n,x): (E/n).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
def git(*a): return subprocess.check_output(['git','-C',str(L),*a],env={**os.environ,'GIT_OPTIONAL_LOCKS':'0'})
def manifest(root): return {str(p.relative_to(root)):sha(p) for p in sorted(root.rglob('*')) if p.is_file()}
def custody():
 patch=git('diff','--binary'); status=git('status','--porcelain=v1','--untracked-files=all'); index=pathlib.Path(git('rev-parse','--git-path','index').decode().strip()); index=index if index.is_absolute() else L/index
 return dict(head=git('rev-parse','HEAD').decode().strip(),branch=git('branch','--show-current').decode().strip(),patch_sha256=hashlib.sha256(patch).hexdigest(),index_sha256=sha(index),status_entries=len(status.splitlines()),cached_bytes=len(git('diff','--cached')),status=status.decode())
before=custody(); out('custody-before.json',before)
expect=json.loads((OLD/'before.json').read_text())
for k in ['head','branch','patch_sha256','index_sha256','status_entries','cached_bytes']: assert before[k]==expect[k],k
oldfiles=json.loads((OLD/'native-sources-references.sha256.json').read_text()); assert all(sha(L/p)==h for p,h in oldfiles.items())
changed=json.loads((OLD/'before.changed.json').read_text()); assert all(sha(L/p)==h for p,h in changed.items())
paths=git('ls-files','-z','--cached','--others','--exclude-standard').decode().split('\0'); paths=sorted(set(filter(None,paths)))
live={p:sha(L/p) for p in paths if (L/p).is_file()}; out('live-files-before.json',live)
(E/'H').mkdir(); tar=git('archive','HEAD'); (E/'H-head.tar').write_bytes(tar)
with tarfile.open(fileobj=io.BytesIO(tar)) as t: t.extractall(E/'H',filter='data')
(E/'J').mkdir()
for p in live:
 dst=E/'J'/p; dst.parent.mkdir(parents=True,exist_ok=True); shutil.copy2(L/p,dst)
shutil.copytree(E/'H',E/'Hc')
p=E/'Hc/native/CMakeLists.txt'; base=p.read_text(); needle='    target_include_directories(aether_stylesheet_source_order_runtime_test PRIVATE include)'; assert base.count(needle)==1
new=base.replace(needle,needle+'\n    target_include_directories(aether_stylesheet_source_order_runtime_test PRIVATE\n        "${CMAKE_CURRENT_SOURCE_DIR}/src/rendering/preparation/include")'); p.write_text(new)
(E/'adapter-A.patch').write_text(''.join(difflib.unified_diff(base.splitlines(True),new.splitlines(True),fromfile='a/native/CMakeLists.txt',tofile='b/native/CMakeLists.txt')))
for tree in ['H','Hc','J']: out('manifest-'+tree+'.json',manifest(E/tree))
(E/'J-minus-H-tracked.patch').write_bytes(git('diff','HEAD','--binary')); shutil.copy2(L/'native/src/layout/style_lookup_box.cpp',E/'J-new-style_lookup_box.cpp')
for n in ['default-inventory.stdout','tools.sha256.json','default-configure.json','native-sources-references.sha256.json']: shutil.copy2(OLD/n,E/('historical-'+n))
inv=json.loads((OLD/'default-inventory.stdout').read_text()); ids=[20,71,76,80,120,125,128,134,137,146,147,148,149,150,151,155,192,203,226,227]
names=[t['name'] for i,t in enumerate(inv['tests'],1) if i in ids]+['aether.smoke','aether.abi-c']; assert len(set(names))==22
selection=[next(t for t in inv['tests'] if t['name']==n) for n in names]; out('selection-historical.json',selection); (E/'selection-exact.txt').write_text('\n'.join(names)+'\n')
targets=list(dict.fromkeys(pathlib.Path(t['command'][0]).name for t in selection)); out('selected-targets.json',targets)
# Static CMake statement extraction, not evaluation; retained raw statements expose conditionals to D.
for tree in ['H','Hc','J']:
 text=(E/tree/'native/CMakeLists.txt').read_text(); stmts=re.findall(r'(?m)^\s*(\w+\([^\n]*(?:\n[^\n]*)*?\))',text) if False else re.findall(r'\b(add_executable|add_library|target_include_directories|target_compile_definitions|target_compile_options|target_link_libraries|set_target_properties)\s*\((.*?)\)',text,re.S)
 core=next(body.split()[2:] for cmd,body in stmts if cmd=='add_library' and body.split()[0]=='aether_core'); mapped={}
 for target in targets+['aether_core']:
  entries=[{'command':cmd,'body':body.strip()} for cmd,body in stmts if body.split() and body.split()[0]==target]
  decl=next(x for x in entries if x['command'] in ['add_library','add_executable']); sources=decl['body'].split()[1:]; sources=[x for x in sources if x not in ['SHARED','STATIC','OBJECT']]
  if '${source_order_runtime_sources}' in sources: sources=sources[:-1]+[x for x in core if x not in ['src/style_runtime/style_runtime_core.cpp','src/style_runtime/style_source_compiler.cpp']]
  mapped[target]={'sources':sources,'statements':entries,'source_sha256':{x:sha(E/tree/'native'/x) for x in sources if (E/tree/'native'/x).is_file()}}
 out('target-map-'+tree+'.json',mapped)
# Proposed argv only, no invocation.
tools=json.loads((OLD/'tools.sha256.json').read_text()); cm=tools['cmake']['path']; ct=tools['ctest']['path']; commands=[]
for tree in ['Hc','J']:
 build=str(E/('build-'+tree)); cwd=str(E/tree)
 commands.append(dict(stage='configure',tree=tree,cwd=cwd,cap_seconds=120,argv=[cm,'-S',str(E/tree/'native'),'-B',build,'-DCMAKE_BUILD_TYPE=Debug','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DAETHERUI_BUILD_TESTS=ON']))
 commands.append(dict(stage='inventory',tree=tree,cwd=cwd,argv=[ct,'--test-dir',build,'--show-only=json-v1']))
 commands.append(dict(stage='build',tree=tree,cwd=cwd,cap_seconds=1800,argv=[cm,'--build',build,'--target',*targets,'--parallel','2','--verbose']))
 for name in names: commands.append(dict(stage='test',tree=tree,cwd=cwd,cap_seconds=120,argv=[ct,'--test-dir',build,'-j1','-R','^'+re.escape(name)+'$','--output-on-failure']))
out('argv-proposal-NOT-RUN.json',commands)
out('custody-after.json',custody()); assert before==custody(); assert live=={p:sha(L/p) for p in live}
out('verification-static.json',{'historical_source_reference_hashes_verified':len(oldfiles),'historical_WIP_hashes_verified':len(changed),'live_complete_files_verified':len(live),'custody_unchanged':True,'configure_build_tests':'NOT_RUN','adapter_sha256':sha(E/'adapter-A.patch')})
# Logical immutability: frozen content manifests; no chmod security/permission changes.

#include "layout_types.h"

namespace aether::layout {
ComputedStyleReadView StyleLookup::lookup_box(const aether_layout_box_s& box, BoxStylePolicy policy) const noexcept {
    if (policy == BoxStylePolicy::effective_map && box.element) {
        if (const auto found = lookup_node(box.element)) return *found;
    }
    return box.style.view();
}
} // namespace aether::layout

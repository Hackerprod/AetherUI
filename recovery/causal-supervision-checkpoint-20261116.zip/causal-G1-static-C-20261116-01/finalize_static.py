exec(open('causal-G1-static-C-20261116-01/prepare_static.py').read().split('before=custody()')[0])
p=E/'Hc/native/CMakeLists.txt'; base=(E/'H/native/CMakeLists.txt').read_text(); new=base
for target in ['aether_stylesheet_source_order_runtime_test','aether_flex_text_test_core']:
 needle='    target_include_directories('+target+' PRIVATE '+('include' if 'source_order' in target else 'include src')+')'; assert new.count(needle)==1
 new=new.replace(needle,needle+'\n    target_include_directories('+target+' PRIVATE\n        "${CMAKE_CURRENT_SOURCE_DIR}/src/rendering/preparation/include")')
p.write_text(new); (E/'adapter-A.patch').write_text(''.join(difflib.unified_diff(base.splitlines(True),new.splitlines(True),fromfile='a/native/CMakeLists.txt',tofile='b/native/CMakeLists.txt'))); out('manifest-Hc.json',manifest(E/'Hc'))
for tree in ['H','Hc','J']:
 text=(E/tree/'native/CMakeLists.txt').read_text(); stmts=re.findall(r'\b(add_executable|add_library|target_sources|target_include_directories|target_compile_definitions|target_compile_options|target_link_libraries|target_link_options|set_target_properties)\s*\((.*?)\)',text,re.S)
 m=json.loads((E/('target-map-'+tree+'.json')).read_text()); core=m['aether_core']['sources']
 target='aether_flex_text_test_core'; m[target]={'sources':core.copy(),'statements':[dict(command=c,body=b.strip()) for c,b in stmts if b.split()[0]==target]}
 for t,v in m.items():
  v['statements']=[dict(command=c,body=b.strip()) for c,b in stmts if b.split()[0]==t]
  if t=='aether_transform_origin_dispatch_test':
   extra='src/css/computed_style.cpp src/css/frozen_style.cpp src/css/frozen_c_string.cpp src/css/frozen_measure_read.cpp src/css/style_freeze.cpp src/style_runtime/frozen_runtime_metadata.cpp'.split(); v['sources']+=extra; v['foreach_additional_sources']=extra
  if tree=='J' and t in ['aether_flex_text_test_core','aether_stylesheet_source_order_runtime_test']: v['foreach_include']='${CMAKE_CURRENT_SOURCE_DIR}/src/rendering/preparation/include'
  v['source_sha256']={x:sha(E/tree/'native'/x) for x in v['sources'] if (E/tree/'native'/x).is_file()}
 out('target-map-'+tree+'.json',m)
# Compare sources/modes, enumerate full candidate delta, including untracked.
h=json.loads((E/'manifest-H.json').read_text()); j=json.loads((E/'manifest-J.json').read_text()); delta=[]
for p in sorted(h.keys()|j.keys()):
 if h.get(p)==j.get(p):continue
 cat='drawing'
 if p=='native/CMakeLists.txt':cat='mixed-build-link-and-drawing-see-hunks'
 elif p in ['native/src/layout/layout_box.cpp','native/src/layout/style_lookup_box.cpp']:cat='build-link-extraction-runtime-confounder'
 elif p=='native/tests/test_style_diff_classifier.cpp':cat='test-coverage-outside-selected-closure'
 elif '/tests/' in p:cat='drawing-test-coverage'
 elif p.endswith('.md'):cat='documentation'
 delta.append(dict(path=p,H=h.get(p),J=j.get(p),category=cat))
out('delta-J-minus-H.json',delta)
v=json.loads((E/'verification-static.json').read_text());v['adapter_sha256']=sha(E/'adapter-A.patch');out('verification-static.json',v)
out('custody-after.json',custody()); assert json.loads((E/'custody-before.json').read_text())==custody()

#!/usr/bin/env python3
"""STATIC-PREPARED, NOT EXECUTED. Minimal independent deadline guard.
No files written, hashes, fsync, subprocesses, product execution or killpg.
A coordinator must wait for the deadline ACK before every watchdog spawn.
Exit status never certifies reaping: only the watchdog/subreaper can reap its children.
"""
import argparse
import errno
import json
import math
import os
from pathlib import Path
import select
import signal
import sys
import time


def identity(pid):
    try:
        text=Path('/proc',str(pid),'stat').read_text()
        fields=text[text.rfind(')')+2:].split()
        return {'pid':int(pid),'ppid':int(fields[1]),'start':fields[19],'state':fields[0]}
    except (FileNotFoundError, ProcessLookupError):
        return None


def pin(pid,start):
    before=identity(pid)
    if before is None or before['start']!=str(start):
        return None
    try:
        fd=os.pidfd_open(pid,0)
    except ProcessLookupError:
        return None
    after=identity(pid)
    if after is None or before['pid']!=after['pid'] or before['start']!=after['start']:
        os.close(fd)
        return None
    return {'pid':pid,'start':str(start),'fd':fd}


def exited(record):
    # A pidfd becomes readable on exit, including an unreaped zombie.
    return bool(select.select([record['fd']],[],[],0)[0])


def safe_signal(record,sig):
    if not exited(record):
        try:
            signal.pidfd_send_signal(record['fd'],sig,None,0)
        except ProcessLookupError:
            pass


class Guard:
    def __init__(self,args):
        if not hasattr(os,'pidfd_open') or not hasattr(signal,'pidfd_send_signal'):
            raise RuntimeError('PIDFD_REQUIRED')
        self.args=args
        self.parent=pin(args.parent[0],args.parent[1])
        self.wd=pin(args.watchdog[0],args.watchdog[1])
        if self.parent is None or self.wd is None:
            raise RuntimeError('INITIAL_IDENTITY_NOT_PRESENT')
        self.known={}
        self.phase_deadline=None
        self.phase="BEFORE_TESTS"
        self.tests_start=None
        self.tests_deadline=None
        self.tests_session=None
        self.stopping=None
        self.kill_at=None
        self.pipe_open=True
        self.buf=b''
        self.signals=[]
        self.done=False
        self.ackfd=args.ack_fd
        os.set_blocking(args.control_fd,False)
        if self.ackfd is not None:
            os.set_blocking(self.ackfd,False)
        for sig in (signal.SIGINT,signal.SIGTERM,signal.SIGHUP):
            signal.signal(sig,lambda s,f:self.signals.append(s))

    def ack(self,kind,cutoff=None,**fields):
        if self.ackfd is None:
            return
        payload=(json.dumps(dict(ack=kind,**fields))+'\n').encode()
        if len(payload)>4096:
            raise RuntimeError('ACK_TOO_LARGE')
        # Atomic small writes only. Failure means no new spawn can be authorized.
        if cutoff is not None and time.monotonic()>=cutoff:
            raise RuntimeError('ACK_DEADLINE_EXPIRED')
        written=os.write(self.ackfd,payload)
        if written!=len(payload):
            raise RuntimeError('ACK_INCOMPLETE')
        if cutoff is not None and time.monotonic()>=cutoff:
            raise RuntimeError('ACK_CROSSED_DEADLINE')

    def scan(self):
        rows={}
        for entry in Path('/proc').iterdir():
            if entry.name.isdigit():
                row=identity(entry.name)
                if row is not None:
                    rows[row['pid']]=row
        # Never infer ownership through a reused root PID.
        parents=set()
        for rec in [self.wd,*self.known.values()]:
            row=rows.get(rec['pid'])
            if row and row['start']==rec['start'] and not exited(rec):
                parents.add(rec['pid'])
        while True:
            added=False
            for pid,row in rows.items():
                if pid==os.getpid() or pid==self.parent['pid'] or pid in parents:
                    continue
                if row['ppid'] in parents:
                    rec=pin(pid,row['start'])
                    if rec is not None:
                        old=self.known.get(pid)
                        if old is not None:
                            os.close(old['fd'])
                        self.known[pid]=rec
                        parents.add(pid)
                        added=True
            if not added:
                break
        # Keep pidfds for descendants that changed session/group or were reparented.

    def targets(self):
        return [self.wd,*self.known.values()]

    def stop(self,reason,now):
        if self.stopping is None:
            self.stopping=reason
            self.phase="STOPPED"
            self.kill_at=min(now+5,self.args.deadline)
            # Freeze the ancestor before inventorying its fork-capable descendants.
            safe_signal(self.wd,signal.SIGSTOP)
            stable=0
            previous=None
            freeze_limit=min(now+1,self.args.deadline)
            while time.monotonic()<freeze_limit:
                self.scan()
                current=set()
                all_stopped=True
                for rec in self.targets():
                    if exited(rec):
                        continue
                    safe_signal(rec,signal.SIGSTOP)
                    row=identity(rec['pid'])
                    if row is None or row['start']!=rec['start']:
                        continue
                    current.add((rec['pid'],rec['start']))
                    if row['state'] not in ('T','t','Z'):
                        all_stopped=False
                stable=stable+1 if all_stopped and current==previous else 0
                previous=current
                if stable>=2:
                    break
                time.sleep(.005)
            # Stable inventory is a containment aid, not a reaping certification.
            # Queue TERM while stopped, then CONT: watchdog signal handler must
            # enter its own stopped state and reap; it must never spawn again.
            for rec in self.targets():
                safe_signal(rec,signal.SIGTERM)
            for rec in self.targets():
                safe_signal(rec,signal.SIGCONT)
            # One notification, pinned by the existing pidfd, interrupts coordinator
            # JUnit/hash/fsync work when possible. Do not repeatedly reenter its
            # signal handler during evidence closure; absolute KILL remains at 4800.
            if reason in ('DEADLINE','TESTS_AGGREGATE_CAP','GUARD_SIGNAL') and not exited(self.parent):
                safe_signal(self.parent,signal.SIGTERM)

    def effective_deadline(self):
        limits=[self.args.work_deadline]
        if self.phase_deadline is not None:
            limits.append(self.phase_deadline)
        if self.phase=='TESTS':
            if self.tests_deadline is None:
                raise RuntimeError('MISSING_TESTS_LATCH')
            limits.append(self.tests_deadline)
        return min(limits)

    @staticmethod
    def finite_clock(value):
        return not isinstance(value,bool) and isinstance(value,(int,float)) and math.isfinite(value)

    def control(self):
        if not self.pipe_open:
            return
        if not select.select([self.args.control_fd],[],[],0)[0]:
            return
        data=os.read(self.args.control_fd,65536)
        if not data:
            self.pipe_open=False
            self.stop('CONTROL_EOF',time.monotonic())
            return
        self.buf+=data
        if len(self.buf)>65536:
            raise RuntimeError('CONTROL_OVERFLOW')
        while b'\n' in self.buf:
            raw,self.buf=self.buf.split(b'\n',1)
            msg=json.loads(raw)
            if not isinstance(msg,dict):
                raise RuntimeError('CONTROL_NOT_OBJECT')
            if set(msg)=={'deadline'}:
                value=msg['deadline']
                now=time.monotonic()
                if self.stopping or self.phase=='STOPPED' or now>=self.effective_deadline():
                    raise RuntimeError('DEADLINE_ALREADY_EXPIRED')
                if value is not None and (not self.finite_clock(value) or not now<value<=self.args.work_deadline):
                    raise RuntimeError('DEADLINE_OUTSIDE_WORK_BUDGET')
                # None clears the individual invocation only. The TESTS latch
                # remains immutable and independently participates in the minimum.
                self.phase_deadline=value
                self.ack('deadline',cutoff=self.effective_deadline(),deadline=value)
            elif msg.get('type')=='tests_begin':
                if set(msg)!={'type','tests_start','tests_deadline','session'}:
                    raise RuntimeError('BAD_TESTS_BEGIN_FIELDS')
                start=msg['tests_start'];deadline=msg['tests_deadline'];session=msg['session']
                now=time.monotonic()
                if self.stopping or self.phase!='BEFORE_TESTS' or self.tests_deadline is not None:
                    raise RuntimeError('TESTS_BEGIN_DUPLICATE_OR_STOPPED')
                if not self.finite_clock(start) or not self.finite_clock(deadline):
                    raise RuntimeError('BAD_TESTS_CLOCK')
                if start<0 or start>now or deadline-start!=900 or not now<min(deadline,self.effective_deadline()):
                    raise RuntimeError('INVALID_TESTS_BEGIN_BUDGET')
                if not isinstance(session,str) or not session or len(session)>256:
                    raise RuntimeError('INVALID_TESTS_SESSION')
                # Store once before ACK/other work: a blocked handshake is covered.
                self.tests_start=start;self.tests_deadline=deadline;self.tests_session=session
                self.phase='TESTS'
                self.ack('tests_begin',cutoff=self.effective_deadline(),phase='TESTS',
                         tests_start=start,tests_deadline=deadline,session=session)
            elif msg.get('type')=='tests_end':
                if set(msg)!={'type','tests_deadline','session','completed','last_id'}:
                    raise RuntimeError('BAD_TESTS_END_FIELDS')
                now=time.monotonic()
                if self.stopping or self.phase!='TESTS' or now>=self.effective_deadline():
                    raise RuntimeError('TESTS_END_LATE_OR_STOPPED')
                if msg['session']!=self.tests_session or msg['tests_deadline']!=self.tests_deadline:
                    raise RuntimeError('TESTS_END_LATCH_MISMATCH')
                if type(msg['completed']) is not int or msg['completed']!=44 or msg['last_id']!='test-J-22':
                    raise RuntimeError('TESTS_END_NOT_FULL_SEQUENCE')
                # The watchdog independently proves no active child and all 44
                # completed/reaped results. Guard only accepts its exact protocol.
                cutoff=self.effective_deadline()
                self.ack('tests_end',cutoff=cutoff,phase='AFTER_TESTS',
                         tests_deadline=self.tests_deadline,session=self.tests_session,
                         completed=44,last_id='test-J-22')
                # ACK is emitted under TESTS deadline, including its post-write check.
                # A failed/late ACK never releases the latch or allows another begin.
                self.phase='AFTER_TESTS'
            elif msg=={'done':True}:
                # Caller sends only after its final persistent record and WD wait().
                # A live TESTS phase cannot be silently completed using generic done.
                if self.phase=='TESTS':
                    raise RuntimeError('DONE_WITHOUT_TESTS_END')
                self.scan()
                if any(not exited(x) for x in self.targets()):
                    raise RuntimeError('DONE_WITH_LIVE_IDENTIFIED_WORK')
                self.ack('done',cutoff=self.args.deadline,identified_work_exited=True,
                         reaping='NOT_OBSERVED_BY_GUARD')
                self.done=True
            else:
                raise RuntimeError('UNKNOWN_CONTROL')

    def run(self):
        self.scan()
        self.ack('ready',pid=os.getpid(),deadline=self.args.deadline)
        while True:
            now=time.monotonic()
            # The absolute kill check precedes scanning/pipe processing.
            if now>=self.args.deadline:
                for rec in self.targets():
                    safe_signal(rec,signal.SIGKILL)
                safe_signal(self.parent,signal.SIGKILL)
                return 124
            self.scan()
            if exited(self.parent):
                self.stop('PARENT_LOST',now)
            if exited(self.wd) and not self.done:
                self.stop('WATCHDOG_LOST',now)
            if self.signals:
                self.stop('GUARD_SIGNAL',now)
            # Re-read after /proc scanning: aggregation includes all inter-test IO.
            now=time.monotonic()
            if self.phase=='TESTS' and now>=self.tests_deadline:
                self.stop('TESTS_AGGREGATE_CAP',now)
            if now>=self.effective_deadline():
                self.stop('DEADLINE',now)
            if self.stopping:
                # Also signal newly discovered descendants while cancellation propagates.
                sig=signal.SIGKILL if now>=self.kill_at else signal.SIGTERM
                for rec in self.targets():
                    safe_signal(rec,sig)
            try:
                self.control()
            except (Exception,) as exc:
                self.stop(type(exc).__name__,time.monotonic())
                self.pipe_open=False
            if self.done:
                return 0
            if exited(self.parent) and all(exited(x) for x in self.targets()):
                return 124
            # Continue guarding the coordinator even if WD has already exited.
            time.sleep(min(.02,max(0,self.args.deadline-time.monotonic())))


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--parent',nargs=2,required=True,metavar=('PID','STARTTIME'))
    p.add_argument('--watchdog',nargs=2,required=True,metavar=('PID','STARTTIME'))
    p.add_argument('--deadline',type=float,required=True)
    p.add_argument('--work-deadline',type=float,required=True)
    p.add_argument('--control-fd',type=int,required=True)
    p.add_argument('--ack-fd',type=int,required=True)
    args=p.parse_args()
    args.parent=(int(args.parent[0]),args.parent[1])
    args.watchdog=(int(args.watchdog[0]),args.watchdog[1])
    if not time.monotonic()<args.work_deadline<args.deadline:
        raise RuntimeError('INVALID_INITIAL_BUDGET')
    guard=Guard(args)
    try:
        return guard.run()
    except BaseException:
        # Unexpected internal failure must not leave known work running.
        for rec in guard.targets():
            safe_signal(rec,signal.SIGKILL)
        safe_signal(guard.parent,signal.SIGTERM)
        # Remain a last-resort absolute guard while the coordinator records stop.
        while time.monotonic()<args.deadline and not exited(guard.parent):
            time.sleep(min(.02,max(0,args.deadline-time.monotonic())))
        safe_signal(guard.parent,signal.SIGKILL)
        raise
    finally:
        for rec in [guard.parent,*guard.targets()]:
            os.close(rec['fd'])


if __name__=='__main__':
    sys.exit(main())

# C · Materialización estática v3 · 2026-11-16

**STATIC_PREPARATION_ONLY / EXECUTION_NOT_AUTHORIZED.** Preparada tras PASS D de propuesta v3 comunicado por coordinación. Requiere nueva revisión de código/hashes antes de ejecutar. No se ejecutó/importó/compiló ninguno de estos programas, ni configure/build/tests/producto o pruebas sintéticas. -01/-02 y H/Hc/J permanecen intactos.

## Correcciones materializadas

- `supervisor.py`: fase TESTS persistente, deadline único de 900 s, comprobación incluso sin active, protocolo tests_begin/tests_end con ACK exactos, contador watchdog de invocaciones recolectadas y contador coordinador de resultados validados/persistidos. Rechaza nuevos tests después del cierre y exige secuencia 44 exacta terminada en test-J-22.
- `guard_deadlines.py`: guarda separadamente deadline individual y agregado inmutable. `{deadline:null}` sólo limpia el individual, nunca el agregado. Sigue vigilando entre invocaciones y durante ACK/IO del watchdog o coordinador. Cambia AFTER_TESTS sólo después de emitir ACK de tests_end bajo el cutoff todavía activo, comprobando vencimiento antes/después del envío.
- `frozen_custody.py`: autoridad de manifiestos/referencias fijada una vez y verificada, conjuntos exactos/tipos/hashes de H/Hc/J y expedientes, configuración v3, herramientas/aliases y entradas del gate comparativo. Reportes incrementales por componente. Autoridad no se recarga al terminar. El SHA256 del manifiesto v3 debe provenir del dictamen D y pasarse obligatoriamente en --manifest-sha256, fuera del documento autorreferente; se valida antes de aceptar policy y antes del snapshot. Se comparan también directorios vacíos/extras, tipos y procedencia lstat/resolve de entradas del gate. `sys.dont_write_bytecode=True` evita que la importación posterior cree __pycache__ entre las fuentes congeladas.
- `verify_comparability.py` no cambia respecto a -02.
- `argv.json` sólo cambia raíces de salidas -02→-03; conserva selección, orden, opciones y caps. `matrix-NOT_RUN.json` es idéntica a -02, con 44 pendientes.
- `policy.json` sólo adapta raíces y añade referencias congeladas a propuesta v3 y manifiesto -02.
- `delta-v2-v3.patch` identifica cambios de código/configuración; el helper nuevo se incluye íntegro. La documentación nueva complementa el README de -02, cuya custodia se verifica, sin sobrescribirlo.

## Protocolo y tabla de estados

| Actor/estado | Entrada válida | Condiciones | Salida |
|---|---|---|---|
| Coordinador BEFORE_TESTS | Primer test tras gate PASS | Cero resultados; fija start y start+900 una sola vez | Envia tests_begin y espera ACK exacto |
| Watchdog BEFORE_TESTS | tests_begin | No hijo/cero tests/no parada/session exacta, duración900, futuro | Guarda latch antes de comunicar a guardia |
| Guardia BEFORE_TESTS | tests_begin | Primera entrada, clocks finitos, deadline futuro | Guarda latch TESTS; ACK con start/deadline/session |
| Todos TESTS | run/test y resultado | Orden fijo; cap mínimo individual/global/agregado | Resultado persistido; limpiar sólo individual |
| Coordinador TESTS | Último JUnit y matriz persistidos | 44 observados, último test-J-22, no fallo de control/cap | Solicita tests_end sin borrar latch |
| Watchdog TESTS | tests_end | 44 recolectados, mismo último id, sin active/parada, aún antes de cutoff | Solicita ACK guardia; comprueba reloj otra vez |
| Guardia TESTS | tests_end | Mismo session/deadline, completed44, último id, aún antes de cutoff | ACK AFTER_TESTS validado temporalmente; libera agregado |
| Coordinador AFTER_TESTS | ACK watchdog válido, reloj no vencido | Ningún lanzamiento test posterior | Custodia final bajo techo global |
| Cualquiera STOPPED | Cap/error/cancelación | Irreversible, sin nuevos tests ni reset | Cierre incompleto explícito dentro techo absoluto |

Watchdog y guardia no dependen de que vuelva a lanzarse un test para detectar agregado vencido. El reset a work_deadline de -02 ya no existe: queda `deadline:null`, con latch independiente. Los 900 s incluyen observación/serialización/persistencia de cada resultado hasta tests_end. Custodia final sólo se inicia tras handshake AFTER_TESTS confirmado. Ningún deadline se amplía ni reinicia al pasar a J. En cap la guardia notifica una vez al coordinador con SIGTERM por pidfd, para que entre en cierre también si estaba entre tests, sin esperar otro receive. La terminación absoluta sigue a4800; no se confunde cierre normal de watchdog con cap.

### Punto explícito de cierre a revisar D

Se sigue literalmente v3: la aceptación/emisión del ACK tests_end por guardia es el punto en que ella pasa AFTER_TESTS; watchdog y coordinador exigen además recibirlo antes del cutoff y rechazan recepción tardía. Si un receptor se bloquea después de emitido ese ACK, la guardia ya protege por techo global, no900, aunque el receptor aún no haya actualizado su estado local. No se oculta este borde: si D exige mantener900 hasta confirmación global de todos los receptores, se necesitaría una nueva propuesta de commit adicional antes de materializarlo. No se afirma haber aprobado esa interpretación.

## Custodia final

Tras tests_end y antes de declarar finalización se comprueban conjuntos exactos, tipos y hashes de H/Hc/J, manifiestos y -01; referencias aceptadas; archivos estáticos v3 ejecutados; herramientas/aliases; entradas originales del PASS de comparabilidad y el propio reporte. Run/builds son salidas expresamente separadas, no excepciones dentro de las fuentes. Se repite también custodia Git/1442 archivos vivos usando la autoridad capturada al preflight, no un manifiesto recargado.

Cada componente empieza NOT_OBSERVED, informa esperado/verificado/extras/ausentes y sólo termina PASS tras comprobación completa. Las lecturas y logs consumen techo global protegido por guardia. `custody_complete=true` requiere completar frozen-check y Git/vivo. Divergencia suspende; no se repara ni se infiere causa favorable.

Ante parada, outcome queda STOPPED/INCOMPLETE_CUSTODY con custody_complete=false. Los reportes incrementales identifican lo verificado; lo restante no se infiere. El chequeo best-effort del vivo declara Git posterior UNOBSERVED si el watchdog ya no puede ejecutar lecturas. No se llama a esta situación finalización diagnóstica completa.

## Invariantes conservados y entrada eventual

Caps: configure120, build1800, test120, tests900, techo4800 con trabajo hasta4770 y reserva30 dentro del techo. Ambos configure/inventarios/builds preceden a gate de comparabilidad; nada se prueba sin PASS. Recursos, exclusión, pidfds/subreaper/guardia, bibliotecas ELF, 287 inventario, 22 nombres/18 targets por árbol y --output-junit se conservan. #159 no participa. No se modifica A, producto, expected, corpus, profundidad, flags, fixtures ni contratos.

Sólo después de nueva revisión D, la entrada eventual sería Python exacto de policy ejecutando `supervisor.py --manifest-sha256 SHA256_APROBADO_POR_D` desde -03. Es una comprobación obligatoria de identidad, no una opción de bypass; el valor exacto se proporciona fuera del expediente autorreferente en el dictamen/entrega. Requiere run/ y build-Hc/J inexistentes. No ejecutar esta instrucción como parte de la revisión estática. No hay resume/retry/skip. Una divergencia requiere D y nueva versión.

**G1 NOT_PASSED; OFF/ON/G2 bloqueados; G3/G4 cerrados; coverage_complete=false. Todas las atribuciones UNDETERMINED.** Este documento no afirma validación dinámica de los programas.

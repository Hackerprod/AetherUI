# C · Propuesta v3: deadline agregado persistente y custodia final

2026-11-16. **PROPOSAL_ONLY / EXECUTION_NOT_AUTHORIZED. Requiere PASS D antes de materializar.**

Base: dictamen final D sobre -02, recibido por coordinación: FAIL por D-3 y control de custodia pendiente; integridad 9/9 de -02 y 4294/4294 de -01 aceptada, D-2 corregido. Se conserva -02 íntegro, incluido manifiesto SHA256 f7afb5eca31a725d379e81823388e2f19ead8419e05f06b96487fd1d1ab69414. Esta propuesta no modifica candidato, árboles ni programas existentes, y no ejecuta nada.

## 1. D-3: invariante que faltaba

Desde el inicio del primer CTest hasta la confirmación explícita de fin de la fase, **tests_deadline es único, persistente, no ampliable y vigilado aunque active sea None**. Incluye parsing JUnit, escrituras/fsync, hashes y toda separación entre tests. Ninguna respuesta de invocación ni mensaje genérico `deadline` puede borrarlo o aumentarlo.

En coordinador, watchdog y guardia habrá estado de fase `BEFORE_TESTS → TESTS → AFTER_TESTS`, o `STOPPED` irreversible. En TESTS:

`effective_deadline = min(global_work_deadline, tests_deadline, command_deadline si existe)`.

Fuera de TESTS se omite únicamente tests_deadline. El reloj absoluto de 4800 s y reserva de cierre de 30 s permanecen en todos los estados. No se cambia presupuesto ni selección.

### Entrada a TESTS

1. Tras PASS de comparabilidad, inmediatamente antes del primer CTest, el coordinador fija una sola vez `tests_start = monotonic()` y `tests_deadline = tests_start + 900`.
2. Envía `tests_begin` al watchdog con ambos valores, sesión e identidad de campaña. Watchdog exige BEFORE_TESTS, cero tests lanzados, sin hijo activo, deadline futuro y duración exactamente 900; lo almacena antes de hacer otra operación y lo vigila en cada iteración, independientemente de active.
3. Watchdog comunica `tests_begin` a la guardia. La guardia exige BEFORE_TESTS, fija la misma pareja y responde ACK con fase y deadline exactos. Durante esta transición rige también el techo global; no se puede lanzar primer CTest antes de recibir ACK idéntico en watchdog y coordinador.
4. No existe segunda entrada, reinicio ni nueva asignación del agregado. Mensajes duplicados o incoherentes detienen.

### Durante y entre invocaciones

- Los mensajes de deadline individual conservan su ACK antes del spawn. La guardia calcula el mínimo con su tests_deadline persistente: no confía en que el emisor ya lo haya incluido.
- Al terminar una invocación, watchdog conserva tests_deadline aunque borre active. El reset actual a work_deadline se reemplaza por actualización del deadline individual a None, **sin cambiar el estado TESTS ni su deadline**. Guardia calcula entonces min(work_deadline, tests_deadline).
- Watchdog verifica el agregado fuera del bloque de hijo activo; guardia hace lo mismo aunque watchdog esté bloqueado en IO o coordinador en JUnit/fsync. Al alcanzarlo, registra/propaga `DIAGNOSTIC_CAP / TESTS_AGGREGATE_CAP` cuando es observable, detiene nuevos lanzamientos y sigue su política de terminación. No se espera al próximo test para detectarlo.
- Se conservan caps individuales de 120 s, agregado 900 s y techo absoluto; no se amplía un deadline al cambiar de Hc a J.

### Salida inequívoca a AFTER_TESTS

Sólo puede solicitarla el coordinador después de procesar y persistir el último resultado JUnit y matriz final de los 44 casos, sin control fallido, error de infraestructura o cap. Fallos diagnósticos ordinarios permitidos no impiden completar la fase.

1. Coordinador envía `tests_end` con número de resultados observados 44 y secuencia final de invocación. Su contador se incrementa únicamente tras validar exactamente un testcase y persistir el resultado. Todavía no borra su deadline.
2. Watchdog exige TESTS, no active, 44 invocaciones test completadas/recolectadas y secuencia final exacta, ninguna parada y reloj estrictamente anterior a min(tests_deadline, work_deadline). Coteja su contador de ejecuciones con el del coordinador.
3. Watchdog pide `tests_end` a la guardia. La guardia exige TESTS, mismo deadline persistente, transición no repetida y reloj no vencido; responde ACK exacto de AFTER_TESTS. La petición no concede tiempo extra: si vence antes de aceptar, STOPPED, no ACK de salida.
4. Sólo tras recibir ACK cambia watchdog a AFTER_TESTS y confirma al coordinador. Sólo tras esa confirmación cambia el coordinador. Desde ese momento puede ejecutarse custodia final bajo el techo global restante, fuera del agregado de pruebas.

Si el coordinador se bloquea antes de solicitar tests_end, sigue protegido por 900 s. Si se bloquea durante el handshake y no se recibió aceptación antes del vencimiento, no se concede salida. Una parada anticipada no utiliza tests_end para liberar presupuesto: permanece STOPPED y el cierre sólo puede registrar evidencias dentro del techo absoluto. No hay reanudación ni segunda tanda.

## 2. Custodia final de árboles y configuración efectivamente ejecutada

Se propone función de custodia congelada compartida conceptualmente por preflight y cierre, con resultados detallados por componente. No sustituye el control Git del vivo.

### Objetos de comprobación

- Árboles H, Hc y J completos: enumeración de todos los caminos, tipos y hashes de contenido frente a manifest-H/Hc/J.json; exigir conjunto exacto sin extras o ausentes. Rechazar symlinks nuevos o cambios de tipo; no seguir una sustitución de raíz por symlink. Verificar identidad/hash de los propios manifiestos frente a las referencias aprobadas.
- Expediente -01 completo frente a su evidence.sha256.json y hash aprobado de ese manifiesto, incluido A, mapas, inventarios y referencias. No reinterpretar un manifiesto alterado como nueva autoridad.
- Programas/configuración v3 efectivamente ejecutados: supervisor, guardia, verificador, policy, argv, matriz inicial y referencias estáticas, con su conjunto cerrado y hashes en evidence.sha256.json de v3. `run/` y builds son salidas esperadas separadas, nunca parte de la allowlist de fuentes congeladas; no se usa el manifiesto para prohibir esas salidas ni para tolerar extras dentro de H/Hc/J.
- Herramientas y aliases efectivos, junto a entradas congeladas de comparabilidad: preservar y cotejar los hashes registrados antes de pruebas. Los ejecutables y bibliotecas del build usados en la tanda se contrastan contra el reporte comparativo; logs, JUnit y salidas documentadas de tests no se confunden con binarios/configuración inmutables.
- Checkout vivo: HEAD/rama/índice/parche/status/cached diff y los 1442 hashes ya controlados. El expediente acepta que no se reauditan todos los objetos/logs históricos -05 no incluidos en las referencias actuales.

El preflight guardará una instantánea de los hashes aprobados en memoria y reporte; la comprobación final no recarga autoridad de archivos potencialmente cambiados. Las rutas se resuelven y verifican contra las raíces aprobadas, sin ampliar el ámbito ni acceder a secretos.

### Momento, límites y resultado

- Tras ACK AFTER_TESTS, antes de declarar finalización diagnóstica, repetir las comprobaciones anteriores. La guardia mantiene el techo absoluto durante hashes, enumeración, custodia Git y escrituras finales. No hay prórroga por cierre.
- Un componente sólo recibe PASS al terminar todas sus lecturas/verificaciones. Hash diferido/no leído queda NOT_OBSERVED; un error o deadline no se convierte en igualdad. Registrar inicio/fin y número esperado/verificado por componente, extras/ausentes/divergencias y referencias exactas.
- Si todo coincide, `custody_complete=true` y sólo entonces puede registrarse finalización diagnóstica, que sigue sin certificar G1.
- Si aparece divergencia, `CUSTODY_DIVERGENCE`, detener y remitir a D para decisión de invalidez/reuso. No corregir archivo ni emitir conclusiones causales favorables.
- Ante cap, cancelación o error que impida completar custodia, guardar incrementalmente `custody_complete=false`, componentes verificados y restantes NOT_OBSERVED. El estado general queda STOPPED/INCOMPLETE_CUSTODY, nunca DIAGNOSTIC_COMPLETED con custodia implícita. El cierre best-effort no autoriza nuevas ejecuciones fuera de presupuesto.
- Si la parada ya cerró el watchdog y no puede repetirse Git supervisado, conservar explícitamente ese componente no observado, aunque algunos hashes sí puedan verificarse. No equiparar custodia del checkout vivo con custodia de los árboles usados.

## 3. Materialización y revisión separadas

1. D revisa este Markdown. Un PASS autoriza únicamente materialización estática nueva en `causal-G1-static-C-20261116-03/`.
2. C copiaría allí los programas/configuración y aplicaría solamente las correcciones descritas, adaptando raíces de salidas -02→-03. H/Hc/J permanecen en -01 intactos. Entregaría diff v2→v3, protocolo/tabla de estados, argv ordenados, matriz 44 NOT_RUN, referencias y manifiesto completo. No ejecutar/importar/py_compile los scripts ni correr pruebas sintéticas o producto.
3. D revisa código y hashes exactos de v3 antes de cualquier apertura de ejecución. La aprobación de esta propuesta no abre el gate. No se ejecuta -02 ni se modifica su manifiesto.

## 4. Condiciones no modificadas

Se conservan D-2, adaptación A limitada, 287 casos de inventario, 22 nombres/18 targets por árbol, 44 invocaciones máximas, orden fijo, controles, selección exacta, ausencia de #159, sin instrumentación ni variantes. --output-junit y exclusión únicamente de _BACKTRACE_TRIPLES siguen la aceptación D. No cambian expected, corpus, profundidad, flags, contratos, producto vivo ni presupuestos.

Sin publicación/red/instalación, otra PC, render o pruebas adicionales. **G1 NOT_PASSED; OFF/ON/G2 bloqueados; G3/G4 cerrados; coverage_complete=false.** Toda atribución permanece UNDETERMINED.

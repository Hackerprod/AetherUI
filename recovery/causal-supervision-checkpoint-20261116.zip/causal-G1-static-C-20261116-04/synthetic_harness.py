#!/usr/bin/env python3
"""STATIC-PREPARED, NOT EXECUTED. Separate one-shot infrastructure validation.
Uses actual guard_deadlines and supervisor code after approved-manifest checks.
Internal fixtures never invoke CMake/CTest/product. No changed resource limits.
"""
import argparse
import ctypes
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import select
import signal
import subprocess
import sys
import time

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
START=time.monotonic()
OUTPUT=HERE.parent/'causal-G1-synthetic-C-20261116-04'
MAX_SECONDS=240
PROGRAMS=('synthetic_harness.py','guard_deadlines.py','supervisor.py','frozen_custody.py','synthetic_cases.json')

class Failure(RuntimeError):pass
class Blocked(Failure):pass

def require(ok,reason):
    if not ok:raise Failure(reason)
def sha(p):
    h=hashlib.sha256()
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()
def write(p,value):
    p=Path(p);tmp=p.with_suffix(p.suffix+'.tmp')
    with open(tmp,'w') as f:json.dump(value,f,indent=2);f.write('\n');f.flush();os.fsync(f.fileno())
    os.replace(tmp,p)
def event(p,value):
    with open(p,'a') as f:f.write(json.dumps(dict(mono=time.monotonic(),**value))+'\n');f.flush()
def approved(digest):
    raw=(HERE/'evidence.sha256.json').read_bytes()
    require(hashlib.sha256(raw).hexdigest()==digest,'APPROVED_MANIFEST_MISMATCH')
    m=json.loads(raw)
    for name,h in m.items():
        p=HERE/name
        require(not p.is_symlink() and p.is_file() and sha(p)==h,'FROZEN_FILE_MISMATCH:'+name)
    require(all(n in m for n in PROGRAMS),'PROGRAM_NOT_MANIFESTED')
    return dict(m)
def modules():
    out=[]
    for name in ('guard_deadlines','supervisor'):
        spec=importlib.util.spec_from_file_location(name,HERE/(name+'.py'))
        mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);out.append(mod)
    return out

def wait_json(fd,deadline,buffer=b'',telemetry=None,on_telemetry=None):
    poll=select.poll();poll.register(fd,select.POLLIN|select.POLLHUP|select.POLLERR)
    if telemetry is not None:poll.register(telemetry,select.POLLIN|select.POLLHUP|select.POLLERR)
    while b'\n' not in buffer:
        if time.monotonic()>=deadline:raise Failure('JSON_ACK_TIMEOUT')
        ready=poll.poll(max(1,int((deadline-time.monotonic())*1000)))
        if not ready:continue
        ids={x[0] for x in ready}
        if telemetry is not None and telemetry in ids:
            if on_telemetry(telemetry) is False:poll.unregister(telemetry);telemetry=None
        if fd not in ids:continue
        chunk=os.read(fd,65536)
        if not chunk:raise Failure('JSON_ACK_EOF')
        buffer+=chunk
    line,rest=buffer.split(b'\n',1)
    return json.loads(line),rest

def send(fd,obj):os.write(fd,(json.dumps(obj)+'\n').encode())
def identity(pid):
    try:
        fields=Path('/proc',str(pid),'stat').read_text().rsplit(')',1)[1].split()
        return dict(pid=int(pid),ppid=int(fields[1]),start=fields[19],state=fields[0])
    except (FileNotFoundError,ProcessLookupError):return None

def namespace():return os.readlink('/proc/self/ns/pid')
def children_of(root):
    rows={}
    for p in Path('/proc').iterdir():
        if p.name.isdigit():
            r=identity(p.name)
            if r:rows[r['pid']]=r
    owned={root};changed=True
    while changed:
        changed=False
        for pid,row in rows.items():
            if row['ppid'] in owned and pid not in owned:owned.add(pid);changed=True
    return [rows[p] for p in owned-{root}]

def emergency(records):
    # Fixture cleanup only. Pins identity before signaling, attempts every record.
    errors=[]
    for rec in records:
        fd=None
        try:
            before=identity(rec['pid'])
            if not before or before['start']!=rec['start']:continue
            fd=os.pidfd_open(rec['pid'],0);after=identity(rec['pid'])
            if after and after['start']==rec['start']:signal.pidfd_send_signal(fd,signal.SIGKILL,None,0)
        except ProcessLookupError:pass
        except Exception as exc:errors.append(type(exc).__name__+':'+str(exc))
        finally:
            if fd is not None:os.close(fd)
    return errors

def reap_all(deadline):
    reaped=[]
    while time.monotonic()<deadline:
        try:
            pid,status=os.waitpid(-1,os.WNOHANG)
            if pid:reaped.append(dict(pid=pid,status=status));continue
        except ChildProcessError:return reaped,True
        time.sleep(.01)
    return reaped,False

def child_held():
    r,w=os.pipe();pid=os.fork()
    if pid==0:
        os.close(w);signal.signal(signal.SIGTERM,signal.SIG_DFL);signal.signal(signal.SIGINT,signal.SIG_DFL)
        try:os.read(r,1)
        finally:os._exit(0)
    os.close(r);return pid,w

class Case:
    def __init__(self,args):
        self.args=args;self.path=Path(args.case_dir);self.path.mkdir(exist_ok=False)
        self.g,self.s=modules();self.deadline=float(args.case_deadline);self.known=[];self.fds=[];self.signal_events=[];self.telemetry_fd=None;self.telemetry_buffer=b'';self.telemetry_events=[];self.fixture_index=0
        self.s.subreaper()
        signal.signal(signal.SIGTERM,lambda signum,frame:self.signal_events.append(dict(signal=signum,mono=time.monotonic())))
        def timeout(signum,frame):raise Failure('WORKER_LOCAL_CAP')
        signal.signal(signal.SIGALRM,timeout);signal.setitimer(signal.ITIMER_REAL,max(.001,self.deadline-time.monotonic()))
        write(self.path/'identity.json',dict(pid=os.getpid(),identity=identity(os.getpid()),namespace=namespace(),deadline=self.deadline))
    def read(self,fd,deadline,buffer=b''):
        return wait_json(fd,deadline,buffer,self.telemetry_fd,self.drain)
    def pin(self,pid,ledger=None):
        i=self.g.identity(pid);require(i is not None,'CHILD_DISAPPEARED_BEFORE_PIN')
        rec=self.g.pin(pid,i['start'],ledger=ledger);require(rec is not None,'PIN_FAILED');self.known.append(i);return rec
    def wait_exit(self,rec,seconds=3):
        limit=min(self.deadline,time.monotonic()+seconds)
        while time.monotonic()<limit:
            if self.g.exited(rec):return
            time.sleep(.001)
        raise Failure('CHILD_EXIT_NOT_OBSERVED')
    def fixture(self,mode,pass_fds=(),extra=()):
        self.fixture_index+=1;prefix='fixture-'+str(self.fixture_index).zfill(2)+'-'+mode
        p=subprocess.Popen([sys.executable,str(HERE/'synthetic_harness.py'),'--manifest-sha256',self.args.manifest_sha256,'--fixture',mode,*extra],pass_fds=pass_fds,stdin=subprocess.DEVNULL,stdout=open(self.path/(prefix+'.stdout'),'xb'),stderr=open(self.path/(prefix+'.stderr'),'xb'),start_new_session=True)
        i=identity(p.pid)
        if i:self.known.append(i)
        return p
    def cleanup(self):
        signal.setitimer(signal.ITIMER_REAL,0)
        records={r['pid']:r for r in [*self.known,*children_of(os.getpid())]}
        errors=emergency(list(records.values()));reaped,complete=reap_all(min(self.deadline,time.monotonic()+2))
        for fd in self.fds:
            try:os.close(fd)
            except OSError:pass
        return dict(errors=errors,reaped=reaped,no_children=complete,namespace=namespace())
    def rotation_1500(self):
        events=[];ledger=self.g.HandleLedger(emit=events.append);fd_before=len(list(Path('/proc/self/fd').iterdir()))
        for n in range(1500):
            require(time.monotonic()<self.deadline,'ROTATION_CAP')
            pid,w=child_held();rec=self.pin(pid,ledger);os.close(w);self.wait_exit(rec)
            got,status=os.waitpid(pid,0);require(got==pid and os.waitstatus_to_exitcode(status)==0,'CHILD_NOT_REAPED_ZERO')
            self.g.retire(rec,'synthetic_rotation_reaped')
            require(rec.get('fd') is None and ledger.stats()['live']==0,'HANDLE_NOT_RETIRED')
        fd_after=len(list(Path('/proc/self/fd').iterdir()))
        require(fd_after<=fd_before,'FD_ACCUMULATION')
        write(self.path/'ledger-events.json',events)
        return dict(children=1500,fd_before=fd_before,fd_after=fd_after,ledger=ledger.stats())
    def high_descriptors(self):
        soft,hard=resource.getrlimit(resource.RLIMIT_NOFILE)
        if soft!=resource.RLIM_INFINITY and soft<1200:raise Blocked('UNCHANGED_RLIMIT_TOO_LOW_FOR_HIGH_FD')
        held=[];events=[];ledger=self.g.HandleLedger(emit=events.append)
        try:
            while not held or held[-1]<1100:held.append(os.open('/dev/null',os.O_RDONLY))
            pid,w=child_held();rec=self.pin(pid,ledger);require(rec['fd']>1024,'PIDFD_NOT_HIGH')
            original_fd=rec['fd']
            require(not self.g.exited(rec),'LIVE_CHILD_REPORTED_EXITED')
            r,q=os.pipe();self.fds.extend([r,q]);require(r>1024 and q>1024,'PIPE_NOT_HIGH')
            os.write(q,b'x');require(r in self.s.wait_readable([r],1),'REAL_SUPERVISOR_HIGH_PIPE_FAILED');os.read(r,1)
            result=self.g.safe_signal(rec,signal.SIGTERM);self.wait_exit(rec);os.close(w)
            _,status=os.waitpid(pid,0);require(os.waitstatus_to_exitcode(status)==-signal.SIGTERM,'SIGNAL_NOT_OBSERVED')
            self.g.retire(rec,'synthetic_high_reaped')
            sentinel=os.open('/dev/null',os.O_RDONLY)
            if sentinel!=original_fd:os.dup2(sentinel,original_fd)
            try:
                again=self.g.safe_signal(rec,signal.SIGKILL);os.fstat(original_fd)
                require(again.get('status')=='RETIRED_NO_SIGNAL','STALE_RECORD_SIGNALED_REUSED_FD')
            finally:
                os.close(original_fd)
                if sentinel!=original_fd:os.close(sentinel)
            require(rec.get('fd') is None,'RETIRED_HANDLE_REUSED')
            return dict(pidfd=original_fd,signal_result=result,retired_signal_result=again,ledger=ledger.stats(),soft_limit=soft)
        finally:
            for fd in held:os.close(fd)
    def guard_setup(self,with_descendant=True,telemetry_enabled=True):
        cr,cw=os.pipe();ar,aw=os.pipe();tr,tw=os.pipe();ir,iw=os.pipe();self.fds.extend([cw,ar,tr,ir])
        wd=self.fixture('wd',pass_fds=(iw,),extra=('--identity-fd',str(iw),'--with-descendant',str(int(with_descendant))))
        os.close(iw);info,_=self.read(ir,min(self.deadline,time.monotonic()+3))
        parent=self.g.identity(os.getpid());wdi=self.g.identity(wd.pid)
        for rec in info.get('children',[]):self.known.append(rec)
        deadline=min(self.deadline-2,time.monotonic()+16);work=deadline-3
        guard=subprocess.Popen([sys.executable,str(HERE/'guard_deadlines.py'),'--parent',str(os.getpid()),parent['start'],'--watchdog',str(wd.pid),wdi['start'],'--deadline',str(deadline),'--work-deadline',str(work),'--control-fd',str(cr),'--ack-fd',str(aw),*(['--telemetry-fd',str(tw)] if telemetry_enabled else [])],pass_fds=(cr,aw,tw) if telemetry_enabled else (cr,aw),stdin=subprocess.DEVNULL,stdout=open(self.path/'guard.stdout','xb'),stderr=open(self.path/'guard.stderr','xb'),start_new_session=True)
        self.known.append(identity(guard.pid));os.close(cr);os.close(aw);os.close(tw);os.set_blocking(tr,False);self.telemetry_fd=tr if telemetry_enabled else None
        ack,_=self.read(ar,min(self.deadline,time.monotonic()+3));require(ack['ack']=='ready','GUARD_NOT_READY');write(self.path/'guard-ready.json',ack)
        return wd,guard,cw,ar,tr,info
    def drain(self,tr):
        chunks=[];opened=True
        while True:
            try:b=os.read(tr,65536)
            except BlockingIOError:break
            if not b:opened=False;break
            chunks.append(b)
        if chunks:
            data=b''.join(chunks)
            with open(self.path/'telemetry.jsonl','ab') as f:f.write(data);f.flush()
            self.telemetry_buffer+=data
            while b'\n' in self.telemetry_buffer:
                line,self.telemetry_buffer=self.telemetry_buffer.split(b'\n',1);entry=json.loads(line);self.telemetry_events.append(entry)
                require(not entry.get('stats',{}).get('evidence_incomplete',False),'GUARD_TELEMETRY_INCOMPLETE')
        if not opened:
            require(not self.telemetry_buffer,'PARTIAL_TELEMETRY_LINE')
            self.telemetry_fd=None
        return opened
    def capped_guard(self,aggregate=False):
        wd,guard,cw,ar,tr,info=self.guard_setup(True)
        if aggregate:
            end=time.monotonic()+.75;begin=end-900
            send(cw,dict(type='tests_begin',tests_start=begin,tests_deadline=end,session='synthetic-preaged'))
            ack,_=self.read(ar,end);require(ack.get('phase')=='TESTS','TESTS_BEGIN_ACK')
            send(cw,dict(deadline=None));ack,_=self.read(ar,end);require(ack==dict(ack='deadline',deadline=None),'NULL_COMMAND_ACK')
        else:
            end=time.monotonic()+.75;send(cw,dict(deadline=end));ack,_=self.read(ar,end);require(ack.get('deadline')==end,'INDIVIDUAL_ACK')
        # Deliberately no next invocation: real guard must act between commands.
        until=min(self.deadline,time.monotonic()+8)
        while wd.poll() is None and time.monotonic()<until:self.drain(tr);time.sleep(.02)
        require(wd.poll() is not None,'WATCHDOG_FIXTURE_NOT_TERMINATED');self.drain(tr)
        require(self.signal_events,'COORDINATOR_NOT_NOTIFIED')
        child=info['children'][0];observed=identity(child['pid'])
        require(observed is None or observed['start']!=child['start'],'SETSID_DESCENDANT_REMAINS')
        send(cw,dict(telemetry_snapshot=True));snap,_=self.read(ar,min(self.deadline,time.monotonic()+2));require(snap=={'ack':'telemetry_snapshot'},'SNAPSHOT_ACK');self.drain(tr);require(any(x.get('event')=='final_snapshot' for x in self.telemetry_events),'FINAL_SNAPSHOT_NOT_PERSISTED')
        send(cw,dict(done=True));ack,_=self.read(ar,min(self.deadline,time.monotonic()+2));require(ack['ack']=='done','DONE_ACK')
        rc=guard.wait(timeout=max(.1,min(2,self.deadline-time.monotonic())));require(rc==0,'GUARD_FINAL_RC')
        self.drain(tr)
        return dict(watchdog_rc=wd.returncode,guard_rc=rc,coordinator_signals=self.signal_events,descendant=child,phase_deadline=end,preaged_900=aggregate)
    def group_individual_cap(self):return self.capped_guard(False)
    def aggregate_idle_cap(self):return self.capped_guard(True)
    def guard_control_eof(self):
        wd,guard,cw,ar,tr,info=self.guard_setup(False,telemetry_enabled=False)
        os.close(cw);self.fds.remove(cw)
        until=min(self.deadline,time.monotonic()+7)
        while wd.poll() is None and time.monotonic()<until:self.drain(tr);time.sleep(.02)
        require(wd.poll() is not None,'EOF_DID_NOT_STOP_WORK');self.drain(tr)
        # This EOF case uses the real optional no-telemetry path so parent loss
        # does not deliberately add an unrelated unread telemetry-pipe error.
        # Full production telemetry is covered in real_watchdog and cap cases.
        # EOF leaves guard waiting for parent loss; worker exits normally. Outer
        # controller is subreaper and verifies adopted guard exits124 promptly.
        return dict(expected_adopted_guard=identity(guard.pid),expected_guard_rc=124,watchdog_rc=wd.returncode,expected_worker_exit_without_guard_done=True)
    def real_watchdog(self):
        root=self.path/'watchdog-root';(root/'run').mkdir(parents=True)
        cr,cw=os.pipe();rr,rw=os.pipe();gr,gw=os.pipe();ar,aw=os.pipe();tr,tw=os.pipe()
        self.fds.extend([cw,rr,gw,ar,tr]);parent=self.g.identity(os.getpid());end=min(self.deadline-2,time.monotonic()+18);work=end-3
        wd=subprocess.Popen([sys.executable,str(HERE/'supervisor.py'),'--watchdog',str(cr),str(rw),str(end),str(work),str(os.getpid()),parent['start'],str(root),str(gw),str(ar)],pass_fds=(cr,rw,gw,ar),stdin=subprocess.DEVNULL,stdout=open(self.path/'real-wd.stdout','xb'),stderr=open(self.path/'real-wd.stderr','xb'),start_new_session=True)
        self.known.append(identity(wd.pid));wdi=self.g.identity(wd.pid)
        guard=subprocess.Popen([sys.executable,str(HERE/'guard_deadlines.py'),'--parent',str(os.getpid()),parent['start'],'--watchdog',str(wd.pid),wdi['start'],'--deadline',str(end),'--work-deadline',str(work),'--control-fd',str(gr),'--ack-fd',str(aw),'--telemetry-fd',str(tw)],pass_fds=(gr,aw,tw),stdin=subprocess.DEVNULL,stdout=open(self.path/'real-guard.stdout','xb'),stderr=open(self.path/'real-guard.stderr','xb'),start_new_session=True)
        self.known.append(identity(guard.pid))
        for fd in [cr,rw,gr,aw,tw]:os.close(fd)
        os.set_blocking(tr,False);self.telemetry_fd=tr;ready,_=self.read(ar,work);require(ready['ack']=='ready','REAL_GUARD_READY');write(self.path/'guard-ready.json',ready);msg,buf=self.read(rr,work);require(msg['type']=='ready','REAL_WD_READY')
        spec=dict(id='synthetic-noop',stage='synthetic',cap_seconds=3,cwd=str(root),argv=[sys.executable,str(HERE/'synthetic_harness.py'),'--manifest-sha256',self.args.manifest_sha256,'--fixture','noop'])
        send(cw,dict(type='run',spec=spec,env={'PATH':os.environ.get('PATH','/usr/bin:/bin')},tests_deadline=work))
        while True:
            msg,buf=self.read(rr,work,buf);self.drain(tr)
            if msg['type']=='result':break
            require(msg['type']=='started','UNEXPECTED_REAL_WD_REPLY')
        require(msg['result']['rc']==0 and msg['result']['cleanup_verified'],'REAL_WD_CHILD_RESULT')
        send(cw,dict(type='stop',reason='SYNTHETIC_EXPECTED_STOP'))
        reply,buf=self.read(rr,work,buf);require(reply['type']=='stopped','EXPECTED_WD_STOP_REPLY')
        require(wd.wait(timeout=2)==124,'EXPECTED_WD_STOP_RC')
        send(gw,dict(telemetry_snapshot=True));snap,_=self.read(ar,work);require(snap=={'ack':'telemetry_snapshot'},'REAL_SNAPSHOT_ACK');self.drain(tr);require(any(x.get('event')=='final_snapshot' for x in self.telemetry_events),'REAL_FINAL_SNAPSHOT_NOT_PERSISTED')
        send(gw,dict(done=True));ack,_=self.read(ar,work);require(ack['ack']=='done','REAL_GUARD_DONE')
        require(guard.wait(timeout=2)==0,'REAL_GUARD_RC');self.drain(tr)
        return dict(result=msg['result'],watchdog_rc=124,guard_rc=0)
    def broken_pipe_stop(self):
        # Direct fixture for the actual method, not a reimplementation. It does
        # not invoke Coordinator.__init__/preflight/configure/product.
        obj=self.s.Coordinator.__new__(self.s.Coordinator)
        obj._stopping=False;obj.telemetry_open=False;obj.telemetry_buffer=b'';obj.final_snapshot_seen=False
        obj.root=self.path;obj.run=self.path/'stop-run';obj.run.mkdir();obj.matrix=[];obj.tests_phase='BEFORE_TESTS';obj.deadline=min(self.deadline,time.monotonic()+5);obj.live_expected={};obj.policy={'live':str(self.path),'source_root':str(self.path)}
        a,b=os.pipe();os.close(a);obj.sendfd=b;self.fds.append(b)
        a,b=os.pipe();os.close(a);obj.guardfd=b;self.fds.append(b)
        obj.wd=self.fixture('noop');obj.guard=self.fixture('noop');obj.wd.wait(timeout=2);obj.guard.wait(timeout=2)
        # Optional telemetry member used by the real v4 Coordinator.stop.
        a,b=os.pipe();os.close(b);obj.telemetryfd=a;self.fds.append(a);obj.guardack=a
        obj.stop(RuntimeError('SYNTHETIC_PRIMARY_ERROR'))
        outcome=json.loads((obj.run/'outcome.json').read_text())
        require(outcome.get('reason')=='SYNTHETIC_PRIMARY_ERROR','PRIMARY_ERROR_OVERWRITTEN')
        require(outcome.get('custody_complete') is False and 'STOPPED' in outcome.get('status',''),'FALSE_SUCCESS_AFTER_BROKEN_PIPE')
        require(any('BrokenPipe' in p.read_text() or 'broken' in p.read_text().lower() for p in obj.run.glob('*.json*')),'SECONDARY_CHANNEL_ERROR_NOT_RECORDED')
        return dict(outcome=outcome)


def fixture(args):
    if args.fixture=='noop':return 0
    g,s=modules();s.subreaper();terminated=[]
    signal.signal(signal.SIGTERM,lambda n,f:terminated.append(n))
    children=[]
    if args.with_descendant=='1':
        rr,ww=os.pipe();pid=os.fork()
        if pid==0:
            os.close(rr);signal.signal(signal.SIGTERM,signal.SIG_DFL);os.setsid();os.write(ww,b'1');os.close(ww)
            while True:time.sleep(1)
        os.close(ww);require(os.read(rr,1)==b'1','SETSID_READY');os.close(rr)
        rec=g.identity(pid);rec['pgid']=os.getpgid(pid);require(rec['pgid']==pid,'DESCENDANT_DID_NOT_CHANGE_GROUP');children.append(rec)
    send(args.identity_fd,dict(watchdog=g.identity(os.getpid()),namespace=namespace(),children=children));os.close(args.identity_fd)
    while not terminated:time.sleep(.02)
    for rec in children:
        pinned=g.pin(rec['pid'],rec['start'])
        if pinned:
            g.safe_signal(pinned,signal.SIGTERM);g.retire(pinned,'fixture_cleanup')
    _,complete=reap_all(time.monotonic()+2)
    return 0 if complete else 2


def run_case(args):
    case=Case(args);result={'id':args.case,'status':'FAIL','start':time.monotonic()};preserve_guard=False
    try:
        result['observations']=getattr(case,args.case)();result['status']='PASS'
        preserve_guard=bool(result['observations'].get('expected_worker_exit_without_guard_done'))
    except Blocked as exc:result.update(status='BLOCKED',error=str(exc))
    except BaseException as exc:result.update(status='FAIL',error=type(exc).__name__+':'+str(exc))
    finally:
        signal.setitimer(signal.ITIMER_REAL,0)
        if preserve_guard:
            # The outer subreaper/controller will collect the real guard after
            # observing this worker's exit. Do not misreport local cleanup.
            result['cleanup']={'handoff_to_outer_subreaper':True,'cleanup_verified':False}
        else:
            result['cleanup']=case.cleanup()
            if result['cleanup']['errors'] or not result['cleanup']['no_children']:result.update(status='FAIL',cleanup_failure=True)
        result['end']=time.monotonic();result['signals']=case.signal_events
        write(case.path/'result.json',result)
    return 0 if result['status']=='PASS' else 2


def controller(args,manifest):
    g,s=modules();s.subreaper();OUTPUT.mkdir(exist_ok=False)
    policy=json.loads((HERE/'synthetic_cases.json').read_text());results=[];matrix=json.loads((HERE/'synthetic-matrix-NOT_RUN.json').read_text());budget=START+240;work=budget-10
    def hard_cap(signum,frame):
        try:emergency(children_of(os.getpid()))
        finally:os._exit(124)
    signal.signal(signal.SIGALRM,hard_cap);signal.setitimer(signal.ITIMER_REAL,max(.001,budget-time.monotonic()))
    write(OUTPUT/'outcome.json',dict(status='RUNNING',cleanup_verified=False,program_custody_complete=False,deadline=budget))
    write(OUTPUT/'identity.json',dict(identity=identity(os.getpid()),namespace=namespace(),start=START,deadline=budget,work_deadline=work,approved_manifest=args.manifest_sha256))
    write(OUTPUT/'matrix.json',matrix)
    primary=None
    try:
        if time.monotonic()<=900:raise Blocked('SYNTHETIC_PREAGED_CLOCK_UNAVAILABLE')
        sample=s.resources(OUTPUT)
        if not s.resource_ok(sample):raise Blocked('SYNTHETIC_RESOURCES')
        if not hasattr(os,'pidfd_open') or not hasattr(signal,'pidfd_send_signal') or not hasattr(select,'poll'):raise Blocked('PIDFD_POLL_UNAVAILABLE')
        write(OUTPUT/'preflight.json',dict(resources=sample,namespace=namespace(),status='PASS'))
        for item in policy['cases']:
            require(time.monotonic()<work,'TOTAL_SYNTHETIC_CAP')
            deadline=min(work,time.monotonic()+item['cap_seconds']);case_dir=OUTPUT/item['id']
            row=next(r for r in matrix if r['id']==item['id']);row['status']='RUNNING';write(OUTPUT/'matrix.json',matrix)
            argv=[sys.executable,str(HERE/'synthetic_harness.py'),'--manifest-sha256',args.manifest_sha256,'--case',item['id'],'--case-dir',str(case_dir),'--case-deadline',str(deadline)]
            process=subprocess.Popen(argv,stdin=subprocess.DEVNULL,stdout=open(OUTPUT/(item['id']+'.stdout'),'xb'),stderr=open(OUTPUT/(item['id']+'.stderr'),'xb'),start_new_session=True)
            initial=identity(process.pid);seen={};max_live=0;last_sample=0
            while process.poll() is None:
                if time.monotonic()-last_sample>=1:
                    last_sample=time.monotonic();sample=s.resources(OUTPUT);event(OUTPUT/'resources.jsonl',sample)
                    require(s.resource_ok(sample),'SYNTHETIC_RESOURCE_PRESSURE')
                rows=children_of(os.getpid());max_live=max(max_live,len([r for r in rows if r['state']!='Z']))
                for r in rows:seen[(r['pid'],r['start'])]=r
                require(max_live<=4,'FOUR_DESCENDANT_LIMIT')
                if time.monotonic()>=deadline:
                    errors=emergency(list(seen.values()));primary='CASE_CAP';break
                time.sleep(.02)
            if primary:process.wait(timeout=max(.1,budget-time.monotonic()))
            else:process.wait()
            # Parent-loss EOF scenario may leave the real guard adopted briefly.
            exit_until=min(work,time.monotonic()+2)
            adopted=[]
            while time.monotonic()<exit_until:
                rows=children_of(os.getpid())
                if not rows:break
                try:
                    pid,status=os.waitpid(-1,os.WNOHANG)
                    if pid:adopted.append(dict(pid=pid,rc=os.waitstatus_to_exitcode(status)));continue
                except ChildProcessError:break
                time.sleep(.01)
            remaining=children_of(os.getpid())
            if remaining:
                emergency(remaining);reaped,complete=reap_all(min(budget,time.monotonic()+2));primary=primary or 'RESIDUES_AFTER_CASE'
            record=dict(id=item['id'],argv=argv,rc=process.returncode,max_live_descendants=max_live,adopted=adopted,remaining=remaining)
            if (case_dir/'result.json').exists():record['result']=json.loads((case_dir/'result.json').read_text())
            else:primary=primary or 'RESULT_MISSING'
            if item['id']=='guard_control_eof' and not any(x['rc']==124 for x in adopted):primary=primary or 'EOF_GUARD_EXIT_NOT_OBSERVED'
            results.append(record);write(OUTPUT/'results.json',results)
            row['status']=record.get('result',{}).get('status','INTERRUPTED')
            if process.returncode!=0 and row['status']=='PASS':row['status']='FAIL'
            if remaining:row['status']='FAIL'
            write(OUTPUT/'matrix.json',matrix)
            if record.get('result',{}).get('status')=='BLOCKED':primary=primary or 'BLOCKED_CASE:'+item['id']
            elif process.returncode!=0 or record.get('result',{}).get('status')!='PASS':primary=primary or 'UNEXPECTED_CASE_RESULT'
            if primary:break
        if primary and primary.startswith('BLOCKED_CASE:'):raise Blocked(primary)
        require(primary is None,primary or 'FAIL')
        require(len(results)==len(policy['cases']),'PARTIAL_SELECTION')
        require(sha(HERE/'evidence.sha256.json')==args.manifest_sha256,'MANIFEST_CHANGED_DURING_SYNTHETIC')
        changed=[name for name,h in manifest.items() if sha(HERE/name)!=h]
        require(not changed,'FROZEN_PROGRAM_DRIFT')
        write(OUTPUT/'outcome.json',dict(status='PASS_SYNTHETIC_ONLY',results=len(results),wall=time.monotonic()-START,program_custody_complete=True,namespace=namespace()))
        signal.setitimer(signal.ITIMER_REAL,0)
        return 0
    except BaseException as exc:
        for row in matrix:
            if row['status']=='RUNNING':row['status']='INTERRUPTED'
        write(OUTPUT/'matrix.json',matrix)
        leftovers=children_of(os.getpid());errors=emergency(leftovers);reaped,complete=reap_all(min(budget,time.monotonic()+2))
        write(OUTPUT/'outcome.json',dict(status='BLOCKED' if isinstance(exc,Blocked) else 'STOPPED',error=type(exc).__name__+':'+str(exc),results=len(results),cleanup_errors=errors,reaped=reaped,reaping_complete=complete,wall=time.monotonic()-START))
        signal.setitimer(signal.ITIMER_REAL,0)
        return 2


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--manifest-sha256',required=True)
    modes=parser.add_mutually_exclusive_group();modes.add_argument('--case');modes.add_argument('--fixture',choices=['noop','wd'])
    parser.add_argument('--case-dir');parser.add_argument('--case-deadline',type=float);parser.add_argument('--identity-fd',type=int);parser.add_argument('--with-descendant',choices=['0','1'],default='0')
    args=parser.parse_args();manifest=approved(args.manifest_sha256)
    if args.fixture:return fixture(args)
    if args.case:
        cases=json.loads((HERE/'synthetic_cases.json').read_text())['cases'];require(args.case in {x['id'] for x in cases},'UNFROZEN_CASE')
        require(Path(args.case_dir)==OUTPUT/args.case,'CASE_OUTPUT_PATH');require(args.case_deadline and time.monotonic()<args.case_deadline,'CASE_BUDGET')
        return run_case(args)
    return controller(args,manifest)

if __name__=='__main__':sys.exit(main())

# C · Materialización estática -04 y harness sintético

2026-11-16. **STATIC_PREPARATION_ONLY. Síntesis y producto NOT_AUTHORIZED / NOT_RUN.**

Preparado tras PASS de diseño v4 comunicado por D/coordinación, sobre propuesta SHA256 e79d4ce813015f4414dacdc72fe4cab7adec302d331677cf09ef87d7d7b81012. No se ejecutaron/importaron/compilaron los programas nuevos, ni casos sintéticos ni producto. -01/-02/-03 y residuos de la tanda interrumpida siguen intactos.

## Corrección del fallo observado

- `guard_deadlines.py` usa poll para pidfds y pipes, sin dependencia de FD_SETSIZE. Registro HandleLedger por token/identidad: PINNED → salida observada → RETIRED; fd se sustituye por None antes de close. Repetir retire no cierra un número que pudiera haberse reutilizado. Los metadatos permanecen, los handles no.
- `safe_signal` usa directamente pidfd_send_signal, sin invocar la consulta que pudo fallar. ESRCH/EBADF y otros errores se tratan por registro, sin abortar intentos sobre los siguientes. La retirada no se presenta como recolección: ésta pertenece al dueño/subreaper.
- `supervisor.py` usa poll también para pipes, mantiene identidades conocidas ante una excepción del watchdog y separa fallo de descubrimiento de intentos individuales de terminación. No reinicia known antes de cleanup.
- Guardia emite por pipe NONBLOCK métricas opened/live/retired/peak, errores e identidades con namespace real. El coordinador drena y persiste fuera de la guardia mínima. Pipe lleno/roto o evidencia truncada/identidad incorrecta detiene, no se oculta. El snapshot final se emite y persiste antes de done, mientras sigue protegida la escritura por el techo absoluto.
- Coordinador conserva causa primaria y errores de cierre secundarios en archivos separados. Un BrokenPipe al cerrar no sobrescribe el motivo principal ni se considera éxito. Se ignoran notificaciones repetidas de cancelación cuando ya se está cerrando, sin quitar el techo externo.
- La salida previa a done es deliberadamente `DIAGNOSTIC_RESULTS_RECORDED_CLOSURE_PENDING`, con cleanup_verified=false. El proceso sólo puede retornar0 después del ACK done exacto y rc0 de la guardia. No hay IO obligatorio posterior a su salida ni se guarda una certificación de cierre antes de verificarlo. El resultado provisional y rc externo deben leerse juntos; no afirmar limpieza completa a partir de la mera ausencia de canal.

Se conservan agregado900 persistente entre pruebas, transición tests_end aceptada por D, caps120/1800/120, global4800 y reserva30, custodia final y comparación estricta. No se cambian adaptador A, producto, flags, expected, corpus, profundidad, selección o presupuestos.

## Archivos y futura entrada de producto

`supervisor.py`, `guard_deadlines.py`, `frozen_custody.py`, `verify_comparability.py`, `policy.json`, `argv.json`, `matrix-NOT_RUN.json`, referencias y manifiesto componen la nueva versión. Verificador y matriz inicial se conservan. El helper de custodia sólo cambia la etiqueta de versión a executed_v4. Policy añade referencias a evidencia/propuesta anterior y reconoce campañas sintéticas para evitar concurrencia.

La entrada eventual de producto sería Python exacto de policy con `supervisor.py --manifest-sha256 SHA256_APROBADO_POR_D`, cwd -04. **No autorizada por esta entrega ni por un eventual PASS sintético.** Requiere gate D separado, run/build-Hc/build-J inexistentes y todos los preflight. Los builds estarían en -04; nunca se reutilizan objetos/cache/binarios de -03. H/Hc/J siguen referenciados como fuentes congeladas -01.

## Harness sintético congelado para revisión

- `synthetic_harness.py`: controlador externo y workers/fixtures internos, usando los módulos reales de -04, no implementaciones paralelas de la lógica que se prueba.
- `synthetic_cases.json`: siete casos exactos, orden/caps/esperados y clock fixture explícito.
- Salida futura nueva y externa al expediente: `/workspace/scratch/2ac40fb4b2af/causal-G1-synthetic-C-20261116-04`, inexistente ahora. Ningún artefacto de producto en esa carpeta.
- Entrada futura: Python exacto de policy, `synthetic_harness.py --manifest-sha256 SHA256_APROBADO_POR_D`. El hash se aporta desde dictamen D, fuera del manifiesto autorreferente. No usar modos internos como una selección alternativa.
- Una sola tanda, **240 s absolutos**, 10 s de cierre dentro del techo, máximo4 descendientes vivos del controlador incluyendo worker, guardia, watchdog y fixture. Cero red/instalaciones/setrlimit/producto/reintentos. El primer resultado inesperado, capacidad insuficiente o cap detiene. Un fallo esperado sólo pasa si coincide con su comprobación específica y no deja residuos no explicados.

| Caso | Cap | Código real ejercitado | Fixture y límite de inferencia |
|---|---:|---|---|
| rotation_1500 | 80 s | pin/exited/retire y HandleLedger | 1500 hijos triviales secuenciales; no carga de compilador |
| high_descriptors | 20 s | pidfd poll/signal/retire y supervisor.wait_readable | Descriptor/pipes >1024 con /dev/null; límite existente insuficiente => BLOCKED, sin cambiarlo |
| real_watchdog | 25 s | CLI watchdog/guardia real, ACK, resultado y recolección, telemetría | Un hijo trivial; parada explícita esperada rc124 de watchdog, guardia0 |
| group_individual_cap | 30 s | Guardia real y señalización/seguimiento por identidad | Watchdog fixture y descendiente setsid; cap individual, observación de terminación |
| aggregate_idle_cap | 25 s | Guardia real con latch900, deadline:null y aviso al coordinador | Inicio sintético pre-envejecido para vencer en0,75s; monotonic<=900 => BLOCKED; no cambia duración900 ni prueba900s bajo carga real |
| guard_control_eof | 20 s | Guardia real, EOF y pérdida posterior de padre | Sin canal opcional telemetry sólo en este caso, para aislar EOF; telemetría completa en otros casos |
| broken_pipe_stop | 20 s | Coordinator.stop real con estado de fixture | No ejecuta __init__/preflight/producto; exige causa primaria y custodia incompleta pese a pipes rotos |

Los caps suman220s, pero el techo240 incluye preflight/hashes/registros/cierre y prevalece siempre. El controlador comprueba máximos de procesos, recolecta y conserva identidades/namespace; errores de cleanup quedan visibles. La señal real sólo se afirma cuando waitpid/returncode la observa. No confundir poll de pidfd con waitpid.

Este harness no certifica todo el supervisor, los44 tests, comparabilidad, compilación ni carga/plataformas del producto. En particular, high_descriptors ejercita señal normal y registro retirado con descriptor reutilizado, pero no inyecta EBADF/poll-error para probar todas las ramas de emergencia; su aislamiento también queda sujeto a revisión estática. No afirmar que todos los caminos de cleanup fueron verificados. Los fixtures son estímulos controlados; la lógica observada proviene de los módulos reales. Un PASS sólo será evidencia sintética limitada para que D decida el siguiente gate.

## Revisión requerida

D debe verificar diff, hashes, lifecycle de handles, señales sobre identidades fijadas, telemetría, selección exacta, caps, tratamiento de fallos esperados y custodia antes de autorizar síntesis. Se entregan matriz sintética inicial NOT_RUN y argv de entrada como datos; no se ejecutaron.

Después de una eventual síntesis aprobada, revisar sus resultados antes de plantear producto. No saltar de esta entrega a otra tanda de builds.

**G1 NOT_PASSED; OFF/ON/G2 bloqueados; G3/G4 cerrados; coverage_complete=false. Atribuciones UNDETERMINED.**

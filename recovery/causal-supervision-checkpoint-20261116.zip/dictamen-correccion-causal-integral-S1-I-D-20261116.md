# D CL: causa integral y propuesta numérica S1-I

2026-11-16. **PASS de las233 cadenas diagnósticas y de la dirección matemática. FAIL del gate para materializar una corrección de producto: faltan diseño cerrado y prueba de coste/capacidad sobre el dominio admitido.** No nuevo build/run autorizado.

Propuesta revisada: `propuesta-correccion-causal-integral-S1-I-C-20261115.md`, SHA-256 `08269eb5fa0fcce6bb44f5d727cb5b3bf783460cf2c49a5e9ee77a61a41f01df` comprobado. También se revisaron propuesta numérica auxiliar, analyze.py, summary.json,233-trace-chains.json, inputs.sha256.json y validaciones del renderer/snapshot originales.

## 1. Causa: PASS acotado a la ejecución diagnóstica

Verifiqué los8 hashes de entrada y reproduje únicamente las aserciones de análisis Fraction/texto del script, cortándolo antes de la primera escritura. El resultado coincide exactamente con el artefacto233-trace-chains.json. Añadí comprobaciones de233 claves únicas, una contribución registrada por fila, igualdad de la suma de errores de representación y aritmética con el error interpolado total, y enlace explícito entre salida de imagen y capa observada de grupo.

Resultado: I01=76,I04=57,I05=21,I06=3,I07=76;97 UV nearest-binary64 ya inexactos y136 con al menos una coordenada distinta del nearest. Todas las interpolaciones discrepantes están por debajo del ideal antes de /255. Cobertura, taps literales y propagación concuerdan con los datos capturados. I04/I05 usan equivalencia afín exacta entre recorte contractual y full-source con clip, no sustituyen expected por salida observada. I07 observa errores previos al grupo, que los propaga conforme a su composición entera.

Se acepta que el mecanismo causal explica las233 diferencias de la ejecución instrumentada, sin extrapolar de igualdad raw. No se promueve la campaña histórica de4/229 ni se afirma identidad de sus intermedios. La auditoría abarca posiciones discrepantes y sus dibujos, no frames completos corregidos, todos los solapamientos posibles ni dominio general. `unused_contributing_draws=0` tiene ese alcance local, no significa completitud de todos los dibujos de cada frame.

## 2. Dirección matemática: PASS, no parche de precisión

Acepto como invariante local de Image: calcular el racional exacto desde los operandos geométricos admitidos en esa frontera, antes de división, y cuantizar half-up una sola vez por canal en la etapa existente. Conservar composición BGRA8 por draw/capa, RGB≤alpha, grupo y clip count. Esta dirección elimina el mecanismo probado; quitar /255 aisladamente, epsilon o long double sin cota no lo hacen.

La frontera representada es una especificación local del helper, no una redefinición global del contrato HTML/CSS. No recupera pérdidas anteriores de layout/matriz/extremos ni demuestra membresía geométrica exacta cerca de curvas. El contrato global y expected permanecen intactos. Si una regresión revela divergencia anterior a esa frontera, se reporta y se aborda aparte, no se redefine expected para hacerla desaparecer.

Precisar la API interna con entradas exactas identificadas: extremos source/destino efectivo, centro, opacity, extremos b y rama/count; no recibir sólo UV o coverage ya redondeados. El producto puede preservar la fórmula matemática mientras cambia taps cerca de una frontera entera respecto al cálculo double previo: esos cambios deben probarse contractualmente, no rechazarse o aceptarse sólo porque coincidan con fixtures actuales.

## 3. Por qué no autorizo todavía materialización de producto

La propuesta reconoce correctamente que8192 bits es capacidad candidata y que falta el algoritmo concreto. Esas reservas son bloqueos reales, no condiciones que puedan resolverse pasando30 casos.

### Capacidad y validez

La derivación conservadora tiene una base plausible para la fórmula factorizada, pero no es todavía prueba del helper. Debe fijar representación, signos, normalización, suma/multiplicación/división y máximo bit-length de CADA temporal, incluidos productos de comparación, shifts, carries, quotient/remainder y cálculo2N+D. No hereda la cota una clase rational genérica ni una multiplicación que reserve/interprete tamaños dobles sin demostrarlo.

Las restricciones actuales incluyen source con anchura/altura al menos1 en renderer y StrictCrop con extremos enteros; deben conservarse, no ampliarse por accidente. Destination efectivo vacío no se dibuja: demostrar denominadores positivos para toda entrada que alcance el helper, incluyendo transformaciones y colapso por redondeo. Taps, clamp y floor deben conservar índices legales para recursos1×1 y extremos admitidos. Fast path exige overflow comprobado antes de perder bits y fallback exacto, no aproximación o nuevo rechazo de entradas válidas.

### Coste, presupuesto y cancelación

El cargo16/píxel y max_work50M existentes no acotan las nuevas operaciones anchas. Un respaldo8192 con128 limbs puede necesitar16384 productos de limbs por multiplicación escolar, más división y múltiples canales. 1KiB es por entero, no por llamada. Falta máximo de temporales simultáneos/pila y cota completa de trabajo.

No aceptar que fallback será raro: una imagen repetida con empate o coordenadas difíciles puede activarlo en TODOS los píxeles de TODOS los draws. Exigir un caso adversarial admitido y una cota para ese caso, además del camino común. La contabilidad debe ser conservadora y compatible con las obligaciones vigentes; no aumentar presupuesto, renombrar unidades ni introducir nuevos rechazos silenciosos para cubrir la regresión. Precisar latencia máxima de cancelación y ubicación de comprobaciones: trabajo ancho dentro de un píxel también cuenta, sin comprometer atomicidad.

No escojo todavía filtro de intervalos como obligación: puede reducir coste medio, pero no elimina la obligación de acotar el peor caso exacto. Si se propone, requiere prueba outward de TODAS las operaciones/ramas, subnormales, overflow y contracción, y fallback ante cualquier ambigüedad. Sin esa prueba no es alternativa aprobada.

## 4. Regresiones exigidas, además de las233 cadenas

Mantener el plan heredado de HTML original completo y gates. El diseño debe incluir antes/después con expected independientes de la implementación para:

- Empates y ambos lados a distancia racional menor que1ulp, con valores aleatorios/adversariales del dominio admitido, no sólo las30 claves actuales.
- Enteros de UV/taps, clamps, negativos, source parcial, StrictCrop/FullResource, recursos degenerados válidos y destino efectivo extremadamente estrecho.
- Opacity de imagen no1 distinta de opacity de grupo, alpha parcial y RGB≤alpha, múltiples imágenes superpuestas sobre destino NO cero; los233 casos auditados tienen destino previo0 y no demuestran esta generalidad.
- Cobertura fraccional no sólo1/2, ramas central/grid, clip membership cerca de curvas y transforms representados. La corrección exacta de la multiplicación no certifica count geométrico.
- Límites de capacidad/carries/signos/cero; transición fast→wide sin truncamiento y equivalencia de caminos; máximo stack/trabajo/cancelación/fallback sostenido.
- Focal/controles, ownership/ciclos A/B, N10-N13 y N04/N05/OOM conservando identidad, presupuestos, índices y atomicidad. Visual backend y tiempo/memoria después de gates autorizados; sanitizers con autorización específica.

Los tests sintéticos complementan las pruebas algebraicas y los frames HTML, nunca las sustituyen. Medir rendimiento antes/después es necesario pero una muestra favorable tampoco demuestra cota universal.

## 5. Decisión operativa

Continuar con **un diseño cerrado del mismo delta**, sin otra campaña causal: API/frontera exacta, algoritmo factorizado, pruebas de capacidad y coste, memoria/cancelación y matriz de regresión. D podrá revisar ese diseño antes de materialización; si necesita un prototipo para medir, debe solicitarse como scope separado explícito y no como implementación aprobada por este dictamen.

N11 mantiene preparación harness separada; su corrección por overload está sustentada, pero validación final no instrumentada sigue pendiente. No hace falta reabrir su causa ni inventar otro índice.

Estado conservado: HTML_EXACT=FAIL, coverage_complete=false, S1-I abierto; N12/N13/regresiones/sanitizers NOT_RUN; LSan NO GO histórico. No modificaciones de producto/harness/expected ni ejecución de renderer/compiler/tests/driver en esta revisión. Sólo lectura, aritmética de evidencia y este dictamen nuevo.

# C · Única tanda sintética -04: parada en segundo caso

2026-11-16. **STOPPED, rc externo2. Producto NO EJECUTADO / NO AUTORIZADO.**

Entrada ejecutada exactamente una vez con Python congelado, `synthetic_harness.py --manifest-sha256 92b4840453a4a53b9bd43a78bd0728966353139a3e0bbc6b63842e039b6ec5d0`. Antes del lanzamiento no había salida sintética ni procesos de campañas coincidentes visibles. No hubo reintentos, reparación, cambio de límites, instalación, red ni reutilización de -03.

## Matriz y límites

Duración registrada: **6,492789 s**, dentro de240. Máximo observado: **2 descendientes vivos**, límite4.

| Caso | Estado |
|---|---|
| rotation_1500 | PASS |
| high_descriptors | FAIL: CHILD_EXIT_NOT_OBSERVED |
| real_watchdog | NOT_RUN |
| group_individual_cap | NOT_RUN |
| aggregate_idle_cap | NOT_RUN |
| guard_control_eof | NOT_RUN |
| broken_pipe_stop | NOT_RUN |

La parada fue por resultado inesperado, no agotamiento del techo global. El límite interno de espera del hijo en high_descriptors fue3s; no es un resultado de CTest ni se cambia a TIMEOUT oficial.

### Evidencia positiva limitada

rotation_1500 recorrió1500 hijos triviales y1500 ciclos de pin/salida/retirada; todos se recolectaron con salida0. Ledger: opened1500, retired1500, live0, peak1, error_count0, evidence_incomplete=false. Recuento del proceso worker: fd_before4, fd_after4. Se conserva ledger-events.json completo. Esto valida ese recorrido de funciones reales, no todo el scanner/cleanup ni una carga de compilador.

### Fallo observado y límites de la evidencia

high_descriptors terminó con Failure:CHILD_EXIT_NOT_OBSERVED. La cleanup posterior registró recolección de pid1507 con wait status9 (SIGKILL), sin errores y no_children=true. El controlador registró remaining=[] y reaping_complete=true; no se ejecutaron los otros cinco casos.

Por la ruta del código congelado hasta esa excepción, las comprobaciones precedentes de pidfd/pipe>1024 y wait_readable del pipe habían sido superadas. Esto es una inferencia del flujo de código, no un log con sus valores numéricos. **No quedó persistido el retorno/errno de pidfd_send_signal ni el estado del hijo antes del envío**, porque observations sólo se guarda si el método retorna normalmente. Tampoco se guardó la lista local de eventos del ledger de ese caso al fallar.

Por tanto, no se puede atribuir todavía el fallo a poll, al envío de señal, al fixture o a su temporización. No demuestra que el fallo anterior de select reaparezca: no hay ValueError de select en esta tanda y ese API fue retirado del camino revisado.

## Custodia, procesos y preservación

Salida original intacta: `causal-G1-synthetic-C-20261116-04/`, incluidos outcome/matrix/results, identidades/namespaces, recursos, ledger y stdout/stderr. `synthetic-artifacts.sha256.json` enumera **15 archivos** con hashes/tamaños; segunda pasada sin cambios.

El controlador y workers registraron recolección completa dentro de su namespace. Una inspección posterior independiente no encontró procesos coincidentes en su ámbito visible; se conservan ambos namespaces en process-observation.json. No se confunde esa visibilidad con certificación global de procesos ajenos.

Custodia posterior read-only: **4294/4294 -01, 9/9 -02, 11/11 -03 y 15/15 -04** coinciden; Git y **1442 archivos vivos** intactos. run/build-Hc/build-J de -04 siguen inexistentes. La comprobación posterior se registra separadamente; no convierte el resultado STOPPED del harness en PASS ni en custodia final exitosa de su ruta normal.

## Análisis estático, no causa probada

Existe una carrera posible en el fixture: child_held hace fork de un worker que tiene handler SIGTERM; el hijo restablece SIG_DFL después del fork sin avisar al padre que terminó ese cambio. El padre puede llegar a safe_signal antes de ese restablecimiento. Ese orden permitiría consumir SIGTERM con el handler heredado y después quedar esperando en el pipe.

La posibilidad se deduce del código, pero **no se observó ese orden en esta ejecución**. La falta de retorno/errno y estado de señal impide descartar otras explicaciones. No se propone todavía una reparación causal como si esa hipótesis estuviera demostrada. Se entrega por separado propuesta de observación/discriminación para D.

**G1 NOT_PASSED; OFF/ON/G2 bloqueados; coverage_complete=false.** Ninguna causa de los fallos del producto ha sido investigada por esta síntesis. Producto continúa prohibido.

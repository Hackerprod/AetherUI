# C: cierre diagnóstico de CTest default -05

2026-11-16. **G1 NOT_PASSED. OFF/ON/G2 bloqueados; G3/G4 cerrados.**

## Alcance y ejecución

Tras PASS_PROPOSAL_ONLY diagnóstico D y autorización de coordinación se ejecutó exactamente una continuación `ctest --test-dir .../drawing-cmake-validation-C-20261116-05/default -I 159,287,1 --output-on-failure`. No builds, reconfigure, cambios de código/flags/timeout ni tests por separado. Se permitió terminar con fallos según excepción D. #159 fue reinicio explícitamente aprobado de un intento interrumpido; #160–287 primeros intentos. #1–158 no se repitieron.

Preflight: 6360/6360 hashes de evidencia anterior, 64/64 WIP, fuentes/referencias/toolchain, inventario/artefactos idénticos. Se copió Testing/Temporary histórico y stdout/stderr/inventario/manifiesto antes de ejecutar en `drawing-cmake-validation-C-20261116-05/continuation-01/`.

Nueva invocación: **rc8, 1647.67 s**, 129 resultados: **124 PASS, 3 FAIL, 1 TIMEOUT, 1 ABORT, 0 SKIP**. El timeout #159 fue aplicado por CTest tras 1500.05 s, conservando TimeOut existente de 1500. No se intervino ni reintentó.

## Matriz combinada sin ocultar historia

287 tests con resultado final individual: **266 PASS, 19 FAIL, 1 TIMEOUT, 1 ABORT, 0 SKIP, 0 NOT_RUN pendientes**. Son 21 no-PASS. Los 16 FAIL iniciales se conservan. La primera invocación sigue INTERRUPTED_WITH_FAILURES, no se convierte retrospectivamente en ejecución completa. #159 conserva antecedente interrumpido y resultado posterior TIMEOUT autorizado.

Build default y gates estáticos ABI/OOM/z-index siguen PASS limitados. Default CTest no pasa. OFF/ON/contratos drawing/G2 aún NOT_RUN; ninguna apertura de G1 por completar el inventario.

### Fallos observados, categorías descriptivas, no causas probadas

**Resolución repetida/no-op o actualizaciones inesperadas:**
- #20 `aether.length-locale`: unchanged resolve emite updates.
- #71 `aether.gradient-angle-runtime`: unchanged resolve no retorna cero updates.
- #76 `aether.flex-number-pipeline`: target estable tiene update/impact.
- #120 `aether.has-strict-list`: stable repeat resolution no vacía.
- #125 `aether.forgiving-empty-list`: repeated resolution no-op incumplida.
- #128 `aether.has-pseudo-element`: unchanged resolution sin contenido generado no vacía.
- #134 `aether.selector-identifier-start-runtime`: segunda resolución no estable.
- #137 `aether.selector-multiple-ids`: unchanged subtree no-op incumplido.
- #192 `aether.transform-runtime`: repeat resolve tiene impacto.
- #203 `aether.transition-property-pipeline`: repeat resolution emite updates.

**Cobertura hook:** #80 `aether.transform-origin-dispatch`: exact CSS-wide hook coverage.

**Profundidad/aceptación de stylesheet:** #146 `aether.stylesheet-eof-closed-deep`, #148 `aether.stylesheet-eof-open-deep`, #150 `aether.stylesheet-eof-mixed-deep` fallan add stylesheet. #147 `aether.stylesheet-eof-compiler-closed-deep`, #149 `aether.stylesheet-eof-compiler-open-deep`, #151 `aether.stylesheet-eof-compiler-mixed-deep` fallan deep rule must exist.

**Rechazo controlado:** #155 `aether.stylesheet-source-order-runtime`: controlled add rejection.

**Timeout:** #159 `aether.adjacent-cache-runtime`, 1500.05 s sin resultado positivo.

**Catálogo:** #226 `aether.style-diff-catalog`, ABORT por dependency catalog covers every registered property exactly once.

**Máscara de impacto:** #227 `aether.style-semantic-diff`, line-height:32px;font-size:16px esperaba 81, obtuvo 83.

Todos permanecen **atribución UNDETERMINED**. Categorías por mensaje no demuestran causa común ni preexistencia/regresión; falta comparación causal con baseline bajo condiciones equivalentes. No se corrigieron expectativas ni producto.

## Resultados específicos exigidos por D

Capturados de LastTest.log de esta única continuación, sin ejecuciones adicionales:
- #225 classifier **PASS**: `1740 exact comparisons, zero allocations PASS`. Incluye las 30 comparaciones añadidas, con los límites de cobertura señalados por D; no todo el dominio ni inherited_metadata_changed.
- #242 inline-hanging-oom **PASS**: 19218 checks, 0 failures, 241 injected (88 allocation + 153 atomic subtree).
- #265 inline-units-oom **PASS**: 63471 checks, 0 failures, 831 injected.
- #98 z-index PASS pertenecía al primer segmento y no se repitió.

Los resultados OOM runtime complementan sus prerrequisitos estáticos, no validan otros tests ni integración drawing/producto.

## Evidencia y custodia final

En `drawing-cmake-validation-C-20261116-05/continuation-01/`:
- `ctest.json`, stdout/stderr: argv/cwd/rc/tiempos reales.
- `continuation-results.json`: 129 resultados individuales.
- `combined-results.json`: 287 resultados y estados históricos.
- `original-Testing-Temporary/`, originales de stdout/stderr/manifiesto: copia del segmento previo.
- `final-Testing-Temporary/`, extractos test-225/242/265: evidencia nueva.
- `verification-after.json`: **6357/6357 archivos originales no operativos inalterados**, 12/12 copias preservadas y fuentes/referencias intactas. Los tres logs operativos de Testing/Temporary se excluyen justificadamente de identidad posterior y tienen copia previa verificada.
- `evidence.sha256.json`: 32 archivos, SHA256 **11602e2d22ffaf1838468cd96a5a932fc864ee17a6e0ea8401518e8960dc297b**.

HEAD `22fba13df2dc7775d4e091dac432c3e4b2960c46`, rama `local/drawing-exact-v3`, 64 hashes intactos, índice `be7b51333cf41b08f39b6a73c21f8a933daa45cece43b42595cc9f7bc3b49361`, parche tracked `40391aa9f6c15926e08c5ec4109f18a3384814a1c19762bded8d4983c1527a08`, cached diff vacío.

Detenido para revisión independiente D. Cualquier diagnóstico causal mediante ejecuciones adicionales o reparación requiere nuevo alcance revisado, no está autorizado por este cierre. Sin publicación, Actions/red, instalación, cambio de equipo ni render extra. coverage_complete=false y límites históricos de producto/plataformas/rendimiento/LSan se conservan.

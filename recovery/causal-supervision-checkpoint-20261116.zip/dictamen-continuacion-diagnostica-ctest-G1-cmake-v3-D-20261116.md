# D: cierre de revisión de continuación diagnóstica CTest

2026-11-16. **PASS_EVIDENCE_ONLY; G1 NOT_PASSED.** La ejecución y matriz documentadas son fiables dentro del alcance diagnóstico autorizado. No certifican integración ni producto.

## Evidencia y resultados comprobados independientemente

- Recalculé **32/32** hashes de `continuation-01/evidence.sha256.json`, SHA256 `11602e2d22ffaf1838468cd96a5a932fc864ee17a6e0ea8401518e8960dc297b`; ninguna discrepancia.
- Recalculé **12/12** copias preservadas y **6357/6357** archivos originales no operativos. Los tres logs operativos históricos de Testing/Temporary coinciden con sus copias anteriores por hash. Sus versiones posteriores se conservan separadas; no se destruyó la evidencia inicial.
- Parseé ambos stdout independientemente de las matrices: primer segmento exactamente índices 1–158, continuación exactamente 159–287, sin repetir resultados terminados ni omitir índices. Todos los nombres coinciden con el inventario de 287; cada resultado textual coincide con combined-results.json. Los 129 registros nuevos coinciden con su sección combinada.
- La continuación ejecutó el argv autorizado una sola vez según registros, con rc8 y 1647.67 s. Contiene **124 PASS, 3 FAIL, 1 TIMEOUT y 1 ABORT**. El resumen CTest cuenta cinco fallos incluyendo Timeout y abort; no contradice la clasificación detallada.
- Combinado: **266 PASS, 19 FAIL, 1 TIMEOUT, 1 ABORT, 0 SKIP y 0 pendientes**, total 287, **21 no-PASS**. Se conservan los 16 FAIL originales y el antecedente interrumpido de #159. No existe un único CTest completo exitoso: el primer segmento sigue interrumpido y la continuación rc8.
- DartConfiguration.tcl conserva TimeOut=1500 y está entre los archivos originales intactos; el TIMEOUT #159 de 1500.05 s es congruente, no un límite nuevo ni éxito.

## Custodia y resultados específicos

64/64 hashes WIP vivos coinciden; HEAD `22fba13df2dc7775d4e091dac432c3e4b2960c46`, rama `local/drawing-exact-v3`, índice `be7b51333cf41b08f39b6a73c21f8a933daa45cece43b42595cc9f7bc3b49361`, cached diff vacío. Parche Git vivo idéntico al posterior (`40391aa9f6c15926e08c5ec4109f18a3384814a1c19762bded8d4983c1527a08`). No divergencia observada que invalide el reuso -05 autorizado.

Los tres extractos están contenidos literalmente en LastTest.log posterior y sus resultados son PASS:

- #225 classifier: **1740 comparaciones exactas**, cero allocations durante compare. Incluye las 30 nuevas por el código materializado revisado; conserva sus límites de cobertura.
- #242 inline-hanging-oom: **19218 checks, 0 failures, 241 injected**, desglosados 88+153.
- #265 inline-units-oom: **63471 checks, 0 failures, 831 injected**.

#98 z-index pasó en el segmento inicial y no se repitió. Los resultados OOM complementan los gates estáticos previos; no validan el resto de los fallos ni drawing. Los grupos descriptivos de la acta son útiles, pero la atribución sigue UNDETERMINED: ningún resultado demuestra por sí solo preexistencia, regresión o causa común.

## Estado y siguientes pasos necesarios

1. **Cerrar esta campaña diagnóstica sin más ejecuciones.** Default build/gates estáticos PASS; default CTest FAIL. OFF/ON/G2 continúan bloqueados y NOT_RUN. G3/G4 cerrados. Completar 287 resultados no abre G1 ni equivale a coverage_complete=true.
2. Para avanzar, preparar **nuevo plan causal acotado A, revisión B y gate D antes de nuevos builds/tests**. Debe fijar preguntas por grupo, baseline y deltas por hash, igualdad de toolchain/flags/dependencias, tests seleccionados y límites de recursos. El baseline debe reconocer los bloqueos de compilación originales y cualquier adaptación mínima necesaria; no atribuir todo a base usando sólo archivos limpios o un baseline no comparable.
3. Priorizar discriminación de las resoluciones repetidas, inventario/catalog y máscaras, y analizar separadamente profundidad/aceptación de stylesheet, cobertura hook y timeout. No inferir que un solo arreglo resolverá las 21 incidencias. Para #159, proponer diagnóstico temporal y límites explícitos antes de repetirlo; no elevar timeout automáticamente.
4. Toda reparación posterior requiere propuesta y revisión de alcance/delta. No modificar expected para ocultar resultados, repetir fallos hasta verde ni expandir la campaña silenciosamente. Un nuevo árbol requerirá decisión explícita de invalidación/reuso.

Permanecen límites de producto, plataformas, rendimiento y LSan históricos; sin publicación, red/Actions, instalaciones, otra PC ni renders adicionales. D sólo leyó, verificó hashes/resultados/custodia y escribió este dictamen; no implementó ni ejecutó pruebas.

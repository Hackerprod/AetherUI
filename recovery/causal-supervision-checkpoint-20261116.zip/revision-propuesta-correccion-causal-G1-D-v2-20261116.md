# D · Revisión de la propuesta de corrección C v2

2026-11-16. **PASS · PROPOSAL_ONLY / STATIC_PREPARATION_ONLY. EXECUTION_NOT_AUTHORIZED.**

Documento revisado: propuesta-correccion-expediente-causal-G1-C-v2-20261116.md, SHA256 fcdce44b5c2870e3f89bb927cf5c4d3aa6920a477d0cb794b7f300268a42c143. Se contrasta con revision-expediente-causal-G1-D-20261116.md. Esta revisión no materializa supervisor, verificador, árboles ni argv, ni ejecuta scripts, configure, build, tests o producto.

## Dictamen y alcance

**PASS para materialización exclusivamente estática en causal-G1-static-C-20261116-02/** de los archivos descritos, seguida de revisión D del código exacto y hashes. El expediente -01 y H/Hc/J permanecen intactos. El FAIL anterior de apertura de ejecución continúa vigente hasta el nuevo gate. Este PASS no certifica un supervisor que todavía no existe ni permite validarlo mediante ejecución.

## Razones

- **D-1 queda correctamente abordado como diseño, no subsanado operativamente todavía.** Se especifican máquina de estados cerrada, caps por fase, agregado de tests, reloj absoluto, reserva de cierre, watchdog independiente, grupos de procesos, registro incremental, recursos, custodia y parada sin bypass/reintentos. La siguiente revisión podrá evaluar mecanismos concretos en lugar de una promesa del ejecutor.
- **D-2 queda corregido en el orden propuesto.** Ambos configure/inventarios y builds preceden a COMPARABILITY; ningún test empieza sin su PASS. El fallo de cualquiera de los builds impide todas las pruebas.
- La comparación no concede equivalencia por categoría: normalización limitada, diferencias lookup enumeradas con hashes, conservación del orden semántico de opciones/includes, inventario completo de 287 y resolución explícita de comandos ausentes antes del build. La inspección ELF es read-only, sin ejecutar el objeto ni usar ldd como atajo.
- Se mantienen exactamente 44 invocaciones máximas, 22 nombres por árbol, controles smoke/abi-c, gate separado para #159 y comparación limitada por A. Los presupuestos no se reinician ni amplían y las observaciones incompletas no se convierten en PASS.

## Controles obligatorios de la revisión del código materializado

1. **Deadlines efectivos y watchdog:** verificar que todos los caminos, incluidos preflight, verificación, lectura de pipes, registro y cierre, quedan bajo el reloj absoluto. La implementación debe transmitir al watchdog el deadline efectivo de la invocación y los cambios de estado; vigilar sólo el techo global no basta para asegurar los caps individuales si el padre se bloquea. La reserva de 30 s es parte del techo de 4800, nunca una extensión.
2. **Custodia de procesos:** comprobar protocolo de registro de PID/PGID/starttime, carreras entre spawn/registro/cancelación, descendientes que cambian de grupo y salida del padre. No señalar PIDs reutilizados ni grupos ajenos. Una terminación/recolección no demostrada debe quedar incompleta, jamás cleanup exitoso. Confirmar quién recoge cada hijo y que principal/watchdog no dejan trabajo huérfano.
3. **Resultado real de cada test:** rc de CTest no sustituye señal/estado del ejecutable. Si no se observa la señal real, registrarla UNOBSERVED; diferenciar FAIL/ABORT, cap externo, error de infraestructura y control fallido. Exigir que cada invocación resuelva y observe exactamente un test, no aceptar éxito con cero tests ni selección parcial silenciosa. Los fallos diagnósticos permitidos no eximen los caps ni los errores del supervisor.
4. **Comparabilidad sin excepciones abiertas:** revisar la lista concreta de diferencias permitidas y su aplicación a los cierres seleccionados. No exigir identidad artificial de hashes de core/binarios Hc y J; sí procedencia, flags y bibliotecas de sistema comparables. No usar diferencias de targets no seleccionados como permiso para ignorar diferencias del cierre real. La resolución ELF debe contemplar rutas efectivas, dependencias transitivas y entorno sin ejecutar binarios; incapacidad de demostrarla implica BLOCKED.
5. **Inventario:** comprobar los 287 nombres, propiedades, argumentos y modos; distinguir ausencia previa de binarios de cambios reales mediante metadatos generados. Tras build confirmar la selección y ejecutables antes de cualquier prueba. Si hace falta cambiar este procedimiento, presentarlo antes del gate, no improvisarlo durante ejecución.
6. **Preflight y cierre:** verificar herramientas disponibles y hashes, ausencia de campañas, mínimos de recursos, exclusión no bloqueante, builds nuevos, entorno whitelist y custodia antes/después. Guardar muestras y logs sin secretos. Divergencia suspende. La política conservadora de recursos no debe relajarse automáticamente.
7. **Congelación del expediente nuevo:** manifiesto debe cubrir supervisor, verificador, política, argv, matriz NOT_RUN y referencias verificables a -01; preservar originales e identificar cómo se asegura que lo revisado es exactamente lo ejecutable. No ejecutar los scripts para producir estos archivos. Las pruebas sintéticas del supervisor siguen requiriendo alcance separado.

Estos controles concretan la revisión pendiente; no añaden ejecuciones, árboles de producto, variantes ni permisos a la propuesta. Una implementación que no los satisfaga recibirá FAIL en el gate siguiente.

**G1 NOT_PASSED; OFF/ON/G2 bloqueados; G3/G4 cerrados; coverage_complete=false.** Todas las atribuciones siguen UNDETERMINED.

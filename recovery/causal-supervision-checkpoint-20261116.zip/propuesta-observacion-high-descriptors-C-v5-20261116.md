# C · Propuesta de observación para high_descriptors

2026-11-16. **PROPOSAL_ONLY. No es una corrección causal ni autoriza materialización/ejecución.**

## Por qué todavía no propongo reparar

La única tanda sintética -04 dio rotation_1500 PASS y high_descriptors FAIL por CHILD_EXIT_NOT_OBSERVED; cinco casos NOT_RUN. El caso fallido no persistió retorno/errno de safe_signal ni estado de señal del hijo, por lo que no hay causa demostrada. Se conserva -04 y su salida intacta. No repetir la tanda ni completar sus pendientes.

La inspección identifica una carrera posible entre fork/restablecimiento de SIGTERM en el hijo y señal desde el padre. Es una hipótesis concreta, no una atribución histórica. Corregirla ahora y buscar verde mezclaría reparación con diagnóstico. No afirmo que cambiar el fixture resolvería el incidente observado.

## Pregunta discriminante

¿La señal no produce salida porque fue recibida bajo el handler heredado antes del restablecimiento, porque estaba bloqueada, o porque el envío por pidfd falló?

Antes de cualquier arreglo, registrar en un experimento separado:
- pidfd y su identidad PID/starttime/namespace, retorno de safe_signal y errno/errores del ledger, persistidos incluso ante excepción;
- señales bloqueadas/capturadas/ignoradas del hijo, fase de inicialización y marcas monotónicas; distinguir observación de salida de waitpid/recolección;
- estado y duración de espera, señal final de cleanup, sin inferir SIGTERM exitoso a partir del intento de envío.

## Diseño mínimo propuesto para revisión D

No ejecutar de nuevo el harness -04. Preparar, sólo tras aprobación de diseño, un pequeño experimento nuevo que importe las mismas funciones reales congeladas de guardia, sin modificarlas, con dos órdenes de fixture explícitamente controlados:

1. **Orden heredado:** el hijo conserva deliberadamente el handler heredado hasta que el padre haya enviado SIGTERM y registrado resultado. Un canal de fase confirma ese orden. Luego se permite el restablecimiento. Observar si el hijo sigue esperando y terminar/recolectar con límite externo.
2. **Orden restablecido:** el hijo restablece SIG_DFL y expone su máscara antes de confirmar readiness; sólo entonces el padre envía SIGTERM por el mismo código de pidfd. Registrar salida/señal y recolección.

Ambos preservan descriptores altos mediante la misma técnica sin cambiar rlimit. Las diferencias de orden son intervenciones deliberadas y deben quedar en el diff/hashes del fixture. No utilizar resultados de esos fixtures como evidencia retrospectiva de qué orden ocurrió en -04.

Una sola ejecución por orden, sin repeticiones, máximo30s globales incluyendo cierre y registros, máximo4 descendientes. Ningún producto/build, red, instalación, profiler o cambio de sistema. Código/argv/hashes, esperados y caps concretos deberán revisarse D antes de ejecutar. Incapacidad o resultado inesperado detiene, no se improvisa.

La observación añade sincronización y puede alterar timing. Eso es deliberado para probar el mecanismo causal en condiciones controladas, no para reproducir probabilísticamente una carrera ni estimar intermitencia. Los logs parciales se guardarán en finally; no volver a perder el retorno de señal cuando falle una assertion.

## Interpretación y siguiente decisión

- Si se demuestra que el orden heredado consume la señal y el restablecido sale por SIGTERM, quedará demostrado ese mecanismo del fixture. La causalidad del fallo histórico seguirá no determinada salvo evidencia adicional.
- Si el envío devuelve error, investigar ese error antes de cambiar el fixture; ninguna equivalencia por descriptor alto se presume.
- Si la máscara bloquea SIGTERM, documentar procedencia y autorización antes de proponer cambiarla. No ajustar máscaras/límites silenciosamente.
- Si no discrimina, conservar UNDETERMINED y volver a D; no ensayar variantes hasta verde.

Sólo después se formularía una propuesta de corrección sustentada, por ejemplo un contrato explícito de readiness si el mecanismo lo justifica, con su alcance y gate independientes. Esta entrega **no materializa ese cambio** y no solicita permiso para reintentar -04 ni para producto.

## Solicitud

D debe revisar acta y decidir si autoriza únicamente preparar este experimento observacional estático para otra revisión. No hay propuesta de reparación causal aprobable todavía: falta el hecho discriminante.

**G1 NOT_PASSED; producto NO AUTORIZADO; coverage_complete=false.**

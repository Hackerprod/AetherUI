# D · Revisión independiente del expediente estático causal G1

Fecha: 2026-11-16. **FAIL para apertura del gate de ejecución. Preparación estática aceptable; EXECUTION_NOT_AUTHORIZED.**

## Alcance y evidencia verificada

Revisé íntegramente plan A, revisión B, EXPEDIENTE-C.md, adapter-A.patch y las propuestas/mapas/manifiestos asociados. No ejecuté configure, build, tests, profiling, scripts del expediente ni producto. No modifiqué árboles, código o evidencia C; sólo escribí este dictamen. Las comprobaciones fueron lecturas, hashes y metadatos Git sin bloqueo opcional.

Identidades SHA256:
- Plan A: ba0ff7592555c0e9da39ab3a605ab795960ce133ccb098ad2f53da2a85587540.
- Revisión B: 046f54a11094648a2d9a6a1b23cd7f9eff8b87474860445a940b6ed4ae94146e.
- EXPEDIENTE-C.md: 2bba8a216697bc510f37079c3b11f8488040f70a3846e82dc4db68d9c81bc265.
- adapter-A.patch: 4f15fd37f28ec395b16938f55d474621e2370b950161ca35108147ab9221dd39.
- evidence.sha256.json: 142c35c945ca301d46a9e60bc0394a27845c7619800fb4dc70e716d7314ff2f2.
- argv-proposal-NOT-RUN.json: f1d0f4de07dd40b8b406083a033932853e2aa7bb20ab70ccdcd2cf5ee43d8f90.

## Comprobaciones satisfactorias

1. **Integridad:** recalculados 4294/4294 hashes de evidence.sha256.json, sin discrepancias. No hay archivos fuera del manifiesto salvo el manifiesto mismo. H y Hc tienen 1383 archivos cada uno; J tiene 1442. Los tres manifiestos coinciden con todos sus archivos, sin extras. H coincide con los archivos del tar y el tar coincide por SHA256 con un nuevo git archive leído del HEAD exacto 22fba13df2dc7775d4e091dac432c3e4b2960c46.
2. **Custodia:** before/after y nueva lectura independiente del checkout vivo coinciden: HEAD, rama, índice, parche, 64 entradas de estado y cached diff vacío. Verificados nuevamente 1442/1442 archivos vivos y 843/843 referencias históricas de fuentes. Esto no equivale a reauditar todos los objetos/logs históricos -05.
3. **Adaptación A:** H/Hc difieren exclusivamente en native/CMakeLists.txt. El diff reconstruido coincide byte a byte con adapter-A.patch. Los dos hunks añaden únicamente el include privado a source-order-runtime y flex_text_test_core. La necesidad está sustentada estáticamente por document_scroll_requests.cpp, que incluye aether/rendering/preparation/detail/utf8.hpp, y por ambos cierres que reutilizan fuentes core sin heredar su include privado. El catálogo consume flex_text_test_core. Excluir classifier no excluye esos objetos. No se añadieron OOM, z-index, classifier, extracción lookup ni cambios de expectativas a A.
4. **Selección:** 22 nombres exactos y 18 targets, incluidos smoke y abi-c; #159 excluido. Las 44 expresiones de selección corresponden a un único nombre de la selección cada una. Se preservan closed/open/mixed y las dos variantes EOF. Los 20 mapas por árbol incluyen dependencias core/flex_text; todos los hashes de fuentes declarados en esos mapas coinciden. Son mapas estáticos, no evidencia de flags/enlace realmente producidos.
5. **Causalidad limitada:** acepto expresamente la limitación por A para una futura matriz exploratoria. No exijo aquí un puente extra, pero tampoco concedo equivalencia semántica ni preexistencia en H. Hc/J con firma común significa sólo reproducción en baseline adaptado; PASS Hc/FAIL J significa asociación al delta J−Hc. El movimiento layout_box/style_lookup_box permanece confusor real. Smoke/ABI no demuestran inocuidad del adaptador ni validan todos los grupos.

## Bloqueos para ejecutar

### D-1 · No existe supervisor concreto revisable en el expediente

El expediente declara que no adjunta runner y deja su revisión para después. Los caps escritos en JSON no implementan el control exigido por A y B. Falta identificar y congelar un mecanismo que haga cumplir 120 s/configure, 1800 s/build, 120 s/test, 900 s agregados de tests y 4800 s absolutos, incluyendo inventarios, preflight, registro y cierre. Debe gestionar cancelación, señales, grupos de procesos/descendientes, terminación y recolección, parada sin reintentos y pendientes NOT_RUN. Debe registrar argv/cwd/entorno permitido/inicio/fin/rc/señal y presión de recursos. No basta prometer que el ejecutor futuro lo hará.

**Resolución requerida:** entregar referencia exacta, código y hash del supervisor existente o propuesta estática nueva, con política de watchdog/cierre y medición de recursos. Revisarlo antes de cualquier ejecución. No se autoriza instalar herramientas ni probar el producto para validar el supervisor.

### D-2 · El orden propuesto permite pruebas antes del gate de comparabilidad

argv-proposal-NOT-RUN.json contiene configure/inventory/build Hc, luego los 22 tests Hc, y sólo después configure/inventory/build J. EXPEDIENTE-C.md lo confirma con «Hc completo y después J». Así no pueden compararse los dos compile_commands, líneas de enlace e inventarios nuevos antes de empezar las pruebas. Un fallo posterior de configure/build J tampoco detendría antes de todas las pruebas, como exige el plan.

**Resolución requerida:** nueva propuesta congelada: configurar ambos árboles e inspeccionar inventarios; construir secuencialmente ambos; verificar flags normalizados, fuentes/defines/enlace y procedencia/RPATH/hash de bibliotecas, resolviendo cualquier diferencia no aprobada; sólo entonces iniciar tests Hc y J en orden fijo. Las diferencias esperadas por J−Hc deben enumerarse, no confundirse con desviaciones de entorno. Ningún test antes de aprobar esos checks. Si la inspección de flags se realiza tras build por disponibilidad de compile_commands, sigue siendo obligatorio completarla antes de pruebas.

## Condiciones conservadas para un expediente corregido

- Inventario completo esperado: 287 casos, no sólo los 22 elegidos; cambios inesperados detienen el gate. El inventario previo al build debe distinguir comandos no resolubles por binarios todavía ausentes de cambios reales, sin ocultarlos.
- Preflight futuro obligatorio: herramientas verificadas, arquitectura/entorno/locales, disco >=12 GiB, memoria disponible >=4 GiB, ausencia de campañas concurrentes y builds separados. No he certificado esas condiciones dinámicas ahora.
- La suma nominal 4740 s deja sólo 60 s frente al techo 4800 s. El techo prevalece sobre todos los caps parciales; no se amplía por preparación, inventarios o cierre. El supervisor debe reservar/proteger la terminación y evidencia.
- Fallo de configure/build, control inesperado, recursos insuficientes o diferencias no aprobadas detienen la tanda, sin reparación/reintento ni inferencia sobre casos pendientes. DIAGNOSTIC_CAP no cambia el TIMEOUT histórico. Assertions posteriores a abort/salida temprana quedan no observadas.
- No instrumentación, variantes, puente adicional ni #159 en esta tanda. Cualquier ampliación necesita otro alcance y gate.

## Dictamen

**FAIL del gate de ejecución por D-1 y D-2.** No es un rechazo de integridad de C ni una conclusión sobre producto. Acepto la custodia/materialización, el alcance estático mínimo de A y la comparación explícitamente limitada por A, pero esos aciertos no suplen los bloqueos operativos. Preparar una nueva versión explícita de supervisor/argv y actualizar sus hashes para revisión; conservar este expediente congelado.

**G1 NOT_PASSED; OFF/ON/G2 bloqueados; G3/G4 cerrados; coverage_complete=false.** Ninguna atribución causal ni certificación de los 287 tests/producto queda autorizada.

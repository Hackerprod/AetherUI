from pathlib import Path
import sys,json,hashlib,shutil,subprocess,time
R=Path('/workspace/scratch/2ac40fb4b2af');P=R/'drawing-cmake-validation-C-20261116-05';O=P/'continuation-01';O.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((P/'evidence.sha256.json').read_text());bad=[k for k,v in manifest.items() if sha(P/k)!=v];assert not bad,bad
sys.argv=['execute.py','definitions'];g={'__file__':str(P/'execute.py')};exec((P/'execute.py').read_text(),g);g['O']=O;g['custody']('before-continuation');S=g['S']
for n,base in [('native-sources-references.sha256.json',S),('documents.sha256.json',R)]:
 assert all(sha(base/k)==v for k,v in json.loads((P/n).read_text()).items()),n
for n,d in json.loads((P/'tools.sha256.json').read_text()).items():assert sha(Path(d['path']))==d['sha256'],n
inventory=json.loads((P/'default-inventory.stdout').read_text())['tests'];assert len(inventory)==287 and inventory[158]['name']=='aether.adjacent-cache-runtime' and inventory[286]['name']=='aether.flex-reverse-private'
shutil.copytree(P/'default/Testing/Temporary',O/'original-Testing-Temporary')
for n in ['default-ctest.stdout','default-ctest.stderr','default-inventory.stdout','evidence.sha256.json','ctest-interruption-summary.json']:shutil.copy2(P/n,O/('original-'+n))
(O/'preserved.sha256.json').write_text(json.dumps({str(p.relative_to(O)):sha(p) for p in sorted(O.rglob('*')) if p.is_file()},indent=2)+'\n')
(O/'preflight.json').write_text(json.dumps({'evidence_files_verified':len(manifest),'sources_tools_documents_verified':True,'selection':[159,287,1],'selected_names':[t['name'] for t in inventory[158:]],'inventory_sha256':sha(P/'default-inventory.stdout'),'review_sha256':sha(R/'dictamen-propuesta-continuacion-ctest-G1-cmake-v3-D-20261116.md')},indent=2)+'\n')
args=[str(g['BIN']/'ctest'),'--test-dir',str(P/'default'),'-I','159,287,1','--output-on-failure'];start=time.time()
with (O/'ctest.stdout').open('wb') as out,(O/'ctest.stderr').open('wb') as err:
 result=subprocess.run(args,cwd=S,stdout=out,stderr=err)
(O/'ctest.json').write_text(json.dumps({'argv':args,'cwd':str(S),'rc':result.returncode,'start':start,'end':time.time(),'scope':'diagnostic completion; failures do not open G1'},indent=2)+'\n')
g['custody']('after-continuation')
print('continuation rc',result.returncode,flush=True)

# C · Primera tanda causal -03: parada por infraestructura

2026-11-16. **STOPPED / INCOMPLETE_CUSTODY del supervisor. G1 NOT_PASSED.**

Se lanzó exactamente una vez el supervisor con manifiesto aprobado `1ea2508e35bbb9d1028dc248682735b5448057d097ec90aad51cc6fe3af8958f`, usando Python exacto y `--manifest-sha256`. No hubo reintento, modificación, reparación, variante ni #159.

## Resultado observado

- Preflight y custodia inicial: PASS.
- Configure Hc/J: rc0, cada invocación con cleanup_verified=true.
- Inventarios Hc/J: rc0; gate inventario: rc0/PASS, 287 casos.
- Build Hc: iniciado, interrumpido/incompleto. No existe resultado final build-Hc.json; no se atribuye rc de build ni PASS/FAIL de producto.
- Build J: NOT_RUN (su directorio contiene configuración, no implica build).
- Gate de comparabilidad: NOT_RUN.
- **Pruebas ejecutadas: 0. Matriz: 44 NOT_RUN.** CTest sólo se utilizó para mostrar inventarios.

A los **214,5248 s** el coordinador registró WATCHDOG_LOST, STOPPED/INCOMPLETE_CUSTODY, cleanup_verified=false y custody_complete=false. La llamada de lanzamiento terminó con exit1. El intento de cierre produjo adicionalmente BrokenPipeError al escribir al pipe de la guardia.

## Fallo de infraestructura comprobado

`-03/run/guard.stderr` contiene ValueError: `filedescriptor out of range in select()`, en `exited()` al consultar un pidfd desde `scan()`. El manejador de excepción volvió a fallar por la misma llamada a `select()` durante `safe_signal`, por lo que **no se da por verificada su limpieza de emergencia**. `watchdog.stderr` está vacío. El coordinador perdió el watchdog; no se convierte ese hecho en un fallo semántico de Hc.

La inspección estática muestra que la guardia retiene pidfds de descendientes terminados en known hasta cierre/reutilización de PID. Esa retención es un mecanismo plausible para aumentar los números de descriptor durante un build con muchos procesos; no se midió retrospectivamente el número exacto abierto ni el descriptor que disparó la excepción. La traza sí prueba la incompatibilidad del descriptor observado con select(). No se modificó código para investigarlo.

La última muestra disponible registró ~25,8 GB libres y ~8,8 GB MemAvailable; no se observó un cap de recursos/tiempo como causa registrada. Esto no reemplaza los logs ni demuestra condiciones después del fallo.

## Preservación, procesos y custodia posterior separada

- Evidencia original intacta en `causal-G1-static-C-20261116-03/run/` y `build-Hc/`, `build-J/`. No se limpiaron ni reutilizaron.
- `runtime-artifacts.sha256.json` enumera **6049 archivos** de esas salidas con hash/tamaño y symlink target cuando procede. Segunda lectura sin cambios en `runtime-artifacts-second-pass.json`.
- `process-observation.json`: no se observaron procesos coincidentes en el ámbito visible de la inspección posterior. Se registra namespace de inspección. **No equivale a demostrar recolección de todos los descendientes del watchdog anterior.** No se señalaron ni mataron procesos ajenos y no hubo procesos remanentes identificados sobre los que actuar.
- `custody-post-stop-independent.json`: comprobación read-only posterior, fuera de la tanda detenida. Revalida **4294/4294 de -01, 9/9 de -02 y 11/11 de -03**, árboles H/Hc/J con conjuntos exactos/directorios/tipos sin symlinks inesperados y hashes intactos; Git y **1442 archivos vivos** coinciden. Esta evidencia complementa, pero no reescribe, el resultado custody_complete=false del supervisor.

La verificación posterior sólo leyó archivos, hashes y metadatos Git/procesos. No ejecutó supervisor de nuevo, builds, pruebas ni herramientas de producto.

## Alcance del cierre

No hay matriz causal runtime ni inferencia de preexistencia, regresión o causa común. Todas las atribuciones UNDETERMINED. Se entrega propuesta separada de corrección del mecanismo de supervisión para D; no se implementa aquí.

**G1 NOT_PASSED; OFF/ON/G2 bloqueados; G3/G4 cerrados; coverage_complete=false.** Sin publicación/red/instalación ni otro equipo/render.

# C · Propuesta v4 tras fallo de infraestructura en tanda -03

2026-11-16. **PROPOSAL_ONLY. No autoriza materialización ni ejecución.**

Fuentes: `causal-G1-execution-report-C-20261116-03/ACTA-C.md`, `-03/run/guard.stderr`, `outcome.json`, logs/watchdog y custodia posterior independiente. La única tanda se detuvo durante build Hc, antes de build J y de cualquier test. No repetir, reparar ni continuar -03. Conservar todos sus bytes y salidas.

## 1. Diagnóstico acotado

La traza prueba `ValueError: filedescriptor out of range in select()` al consultar un pidfd. También el fallback de emergencia usa esa consulta y falla. El diseño retiene pidfds de descendientes terminados; puede elevar los números de descriptor al generar muchos procesos durante un build. No afirmar número exacto de fd ni otra causa sin evidencia. El fallo es de infraestructura, no resultado del producto.

## 2. Corrección estática propuesta, sólo tras PASS D

Materializar -04 nuevo, referenciando los mismos H/Hc/J congelados. Diff acotado a supervisión/cierre y raíces de nuevas salidas; mantener selección, adaptador A, flags, presupuestos y gates.

1. Sustituir consultas de vida con `select.select` sobre pidfds por mecanismo Linux `poll`/selector que no dependa del límite de FD_SETSIZE. Aplicar también a cualquier pipe que pudiera obtener número alto. Fallar cerrado si capacidad no está disponible; no aumentar límites del sistema ni instalar herramientas.
2. Establecer ciclo de vida explícito para cada pidfd: fijación/identidad validada → seguimiento vivo → salida observada → cierre exactamente una vez y retirada. Conservar sólo metadatos inmutables de terminados para evidencia, no handles abiertos indefinidamente. No reutilizar fd cerrado ni confundir PID reciclado. La retirada no autoriza abandonar descendientes aún vivos; conservar relaciones/identidades necesarias y el subreaper dueño de su recolección.
3. El camino de señal de emergencia debe usar directamente pidfd_send_signal con errores ESRCH/EBADF tratados y registrados, sin volver a depender de la consulta de vida que acaba de fallar. Procesar todos los registros aunque falle uno. No matar por integer PID/PGID reutilizable.
4. Manejo independiente de errores en cleanup: un fallo de la guardia nunca puede impedir intentar terminar otros procesos propios conocidos. No afirmar cleanup/reaping completo si no se demostró. Guardar causa primaria y errores secundarios separados, sin sobreescribir uno con otro.
5. Coordinador: registrar BrokenPipe/EOF de la guardia al cerrar como fallo de canal, no lanzar una excepción secundaria que oculte el resultado principal. Persistir estado STOPPED, matriz pendiente y custodia incompleta. No transformar la ausencia de canal en cierre exitoso.
6. Mantener vigilancia independiente de deadlines de comando, agregado900, techo4800 y reserva30, incluido hashing/ACK/persistencia. Retener el punto de cierre tests_end aceptado por D, contadores44, tests_begin único y prohibición de relanzamiento. No ampliar presupuestos para compensar el fallo.
7. Registrar recuentos de pidfds vivos/retirados y máximo simultáneo observado, identidades y cierres, con IO fuera de la guardia mínima para no debilitar deadlines. Fallo de registro implica evidencia incompleta, no permiso para continuar a ciegas.

El expediente -04 incluiría código exacto, diff, manifiesto, protocolo de estados/handles, argv y matriz44 NOT_RUN. D debe revisar bytes/hashes antes de cualquier ejecución.

## 3. Validación sintética separada propuesta a D

**No está autorizada por los gates anteriores y no se ejecutó.** Antes de gastar otro build, se propone un gate independiente para validar sólo infraestructura local, nunca producto. D debe aceptar código/argv/hashes y presupuesto concretos del harness antes de lanzarlo; esta sección es diseño, no permiso.

Propuesta de alcance: una única tanda sintética nueva, máximo240 s de pared, máximo4 hijos simultáneos, cero red/instalaciones/cambios de límites del sistema. Usa Python/biblioteca estándar disponibles, temporales nuevos y logs. Preflight de recursos y capacidad de pidfd/poll; si no hay capacidad, BLOCKED sin sustituir mecanismo. No ejecutar simulaciones improvisadas desde -03.

Casos que el harness posterior deberá concretar y congelar:
- Rotación de al menos1500 hijos triviales secuenciales, verificando recolección y cierre de handles; no crecimiento acumulativo de pidfds vivos tras cada salida.
- Descriptor deliberadamente superior al límite clásico de select mediante handles de /dev/null dentro del proceso sintético; comprobar consultas/señales/cierre sin ValueError. Sólo si límite ya disponible lo permite, sin alterarlo; de otro modo BLOCKED.
- Un hijo persistente, descendiente que cambia grupo y pausa del coordinador entre comandos; verificar terminación acotada y nunca señalar un PID reutilizado. Señales sólo a procesos creados por ese harness.
- Error/EOF de guardia y cierre con pipe roto: debe conservar causa primaria y estado incompleto, sin reintentos ni ejecución posterior.
- Deadline individual y agregado persistente entre invocaciones, incluyendo bloqueo simulado del receptor/IO. No cambiar los900 de la campaña real. Cualquier reloj/aceleración de fixture sintético debe ser explícito, simétrico y revisado; un test sintético no certifica el cumplimiento bajo carga real.

No se requieren todos los casos dentro de un mismo proceso si eso los mezcla, pero sí una sola tanda presupuestada con selección cerrada. Un fallo termina la validación; ningún reintento hasta otra decisión D. Matriz sintética y señales observadas/no observadas se conservarán completas.

## 4. Nueva campaña de producto, sólo mediante gate posterior

Tras revisión estática y, si D lo aprueba, validación sintética, D decide si abre una **nueva** primera tanda de producto -04 con builds nuevos y presupuesto original. No se continúa build-Hc parcial ni se reutilizan objetos/cache/binarios de -03. Si se quisiera reusar algo, requeriría decisión D explícita de reuso y alcance revisado; esta propuesta no lo solicita.

Preflight y hashes completos de nuevo; ambos configure/inventarios/builds y comparabilidad antes de tests. Una sola invocación por nombre/árbol, sin #159, variantes, reparación, reducción de corpus ni modificación de expected. La historia -03 permanece intento detenido, no se borra ni se llama PASS.

## 5. Solicitud

D debe decidir sobre esta propuesta. Un PASS de diseño autorizaría sólo preparar estáticamente -04 y, por separado, el diseño/harness sintético con sus comandos concretos para nueva revisión. **No autoriza ejecutar síntesis ni producto todavía.**

**G1 NOT_PASSED; OFF/ON/G2 bloqueados; G3/G4 cerrados; coverage_complete=false. Todas las atribuciones UNDETERMINED.**

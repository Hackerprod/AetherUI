# C · Propuesta v2 para resolver D-1 y D-2

2026-11-16. **PROPOSAL_ONLY. Requiere validación D antes de materializar esta corrección. No autoriza ejecución.**

Leído íntegramente `revision-expediente-causal-G1-D-20261116.md`. Se aceptan ambos bloqueos. El expediente `causal-G1-static-C-20261116-01/` queda congelado, sin reemplazos ni cambios de hashes. La aceptación de custodia y la limitación causal por A se conservan, pero no abren el gate.

## 1. Secuencia de autorizaciones

1. D revisa este Markdown. Un PASS sólo autorizaría preparar estáticamente la versión nueva descrita aquí.
2. C materializa después, en directorio nuevo `causal-G1-static-C-20261116-02/`, código del supervisor y verificador, política de comparación, argv corregidos, matriz inicial NOT_RUN y manifiesto SHA256. Sin ejecutar esos scripts, configure, build ni tests. Los árboles H/Hc/J ya aceptados se referencian por rutas y hashes, no se alteran ni se duplican innecesariamente. Los builds futuros serían `build-Hc` y `build-J` nuevos dentro de -02.
3. D lee código exacto y hashes de -02, verifica ambos bloqueos y concede o deniega por separado la apertura de ejecución. No basta la aprobación de este Markdown. C espera ese dictamen y la instrucción de coordinación antes de cualquier ejecución.

## 2. D-1: supervisor concreto que se propone materializar

Entregar `supervisor.py`, `verify_comparability.py`, `policy.json`, `argv.json`, `README-operacion.md` y `evidence.sha256.json`. Sólo biblioteca estándar Python disponible y herramientas locales ya inventariadas. No instalar, descargar, ejecutar experimentos auxiliares ni producto para probar el supervisor. El código se revisará estáticamente; cualquier validación sintética ejecutable requerirá alcance separado aprobado D, nunca se confundirá con esta preparación.

### Máquina de estados y prohibición de bypass

`PREFLIGHT → CONFIGURE_Hc → INVENTORY_Hc → CONFIGURE_J → INVENTORY_J → BUILD_Hc → BUILD_J → COMPARABILITY → TESTS_Hc → TESTS_J → CLOSE`.

Cada transición valida rc, resultado estructurado y reloj. `COMPARABILITY` debe emitir PASS con hashes de entradas idénticos a los inspeccionados. No habrá opción `--skip-checks`, reanudación, reparación automática, nueva selección ni reintento. Cualquier error termina en `STOPPED`, con pasos pendientes NOT_RUN. Los fallos diagnósticos de los 20 casos se registran y permiten seguir; fallo de smoke/abi-c detiene la tanda. Un fallo inesperado del supervisor/verificador también detiene, nunca interpreta evidencia parcial como PASS.

### Relojes, watchdog y cierre protegido

- Inicio absoluto mediante `time.monotonic()` en la entrada del supervisor, antes de preflight/lecturas. 4800 s totales, incluyendo preflight, inventarios, verificaciones, logs y cierre. Registrar además UTC de pared.
- Reservar 30 s finales de cierre: no lanzar trabajo si el presupuesto restante es <=30 s. Deadline de trabajo absoluto en t0+4770. No constituye ampliar ningún cap; puede reducir ejecuciones respecto a los máximos nominales.
- Cada subprocess tiene deadline `min(inicio+cap_etapa, deadline_global_trabajo, deadline_tests_si_aplica)`: configure 120 s, build 1800 s, test 120 s. Inventarios y verificador comparten techo global, con cap individual conservador 120 s propuesto; alcanzar cualquiera detiene, sin reintento.
- El reloj agregado de pruebas inicia inmediatamente antes del primer CTest y vence tras 900 s de pared, incluyendo separación, inspección y registros entre pruebas. No se reinicia al pasar de Hc a J. El deadline global siempre prevalece.
- Proceso supervisor principal y watchdog local independiente: el watchdog recibe por pipe registros de grupos activos y el deadline monotónico; comprueba EOF del padre y límite global aunque el padre se bloquee. No mantiene viva una campaña si pierde al padre. No usa red ni servicios externos.
- Subprocess lanzado con `start_new_session=True`, stdout/stderr directos a archivos nuevos. Registrar PID/PGID y starttime Linux de `/proc` para evitar PID reutilizado. Sólo grupos/procesos propios del supervisor; jamás matar campañas ajenas.
- En cap, presión de recursos, excepción, SIGINT o SIGTERM: registrar causa, bloquear nuevos lanzamientos, SIGTERM al grupo activo, esperar hasta 5 s dentro del presupuesto de cierre, luego SIGKILL si persiste, `wait()` para recolectar hijo. Inspeccionar `/proc` para descendientes identificados y grupos sobrevivientes de la invocación. Registrar cada señal/resultado y cualquier imposibilidad de terminar o recolectar. El watchdog usa la misma política acotada. Las señales no se entregarán a PIDs cuya identidad no coincida.
- Al alcanzar t0+4800 el watchdog fuerza terminación de grupos propios supervivientes y del principal si sigue vivo. Persistir por adelantado matriz NOT_RUN y logs incrementales para que un cierre forzado no dependa de escribir un informe final. No prometer garantías frente a caída total del sistema o proceso en estado no interrumpible: registrarlo como terminación no verificada/incompleta si es observable, nunca como limpieza exitosa.

### Recursos, custodia y registro

Preflight: manifiestos H/Hc/J, adaptador, checkout vivo (HEAD/rama/índice/parche/cached vacío), herramientas SHA256, arquitectura, flags relevantes de entorno y locales. Sólo whitelist de entorno de compilación/locale, sin credenciales ni volcado completo de env. Registrar ausencia de variables de inyección como LD_PRELOAD/LD_LIBRARY_PATH o bloquear si están presentes sin aprobación. Comprobar directorios build nuevos, sin symlinks/artefactos previos ni reutilización de caché.

Verificar >=12 GiB de disco y >=4 GiB MemAvailable al inicio. Muestrear cada segundo mediante statvfs y /proc/meminfo, carga y memoria de procesos propios; detener ante descenso bajo esos mínimos, fallo de lectura o presión observada que impida custodia. Guardar muestras incrementales. El umbral de parada conservador se declara antes, no se relaja durante ejecución.

No campañas concurrentes: exclusión local mediante lock exclusivo no bloqueante en el ámbito de esta campaña y comprobación read-only de procesos de compilación/pruebas presentes. Si no puede excluirse otra campaña, BLOCKED; no matar procesos ajenos. El lock por sí solo no demuestra ausencia de campañas externas.

Por invocación: argv exacto, cwd, whitelist de entorno, fase, UTC/monotónico inicial/final, rc y señal real, causa de terminación, cap aplicado, stdout/stderr completos, muestreo recursos y estado de recolección. Guardar por reemplazo atómico y flush de eventos críticos. Campos desconocidos quedan null/UNOBSERVED, no inventados. Hash incremental al cerrar cada log; matriz inicial 44 NOT_RUN, actualización tras cada resultado. Cualquier divergencia de custodia suspende y remite a D.

## 3. D-2: orden corregido y gate previo a toda prueba

`argv.json` mantendrá exactamente las opciones/targets/nombres de -01, sustituyendo sólo paths de builds a -02 y orden:

1. Preflight.
2. Configure Hc; inventario Hc.
3. Configure J; inventario J.
4. Comprobar ambos inventarios completos y correspondencia estática.
5. Build Hc seleccionado; build J seleccionado, secuenciales, --parallel 2 --verbose.
6. Verificar ambos compile_commands, flags/defines/includes, fuentes, link lines y bibliotecas/RPATH/procedencia. No tests si cualquiera de los builds falló o cualquier check no es PASS.
7. Sólo después, 22 nombres Hc y 22 J en orden idéntico a selection-exact.txt de -01. Controles smoke/abi-c conservan su posición; cualquier fallo suyo detiene. #159 excluido, sin instrumentación.

### Inventarios y comparación verificable, no concesión genérica

- Exigir 287 casos con nombres, argumentos, propiedades/timeout y modos esperados del histórico, normalizando únicamente raíces conocidas. Preservar originales. Antes del build, ausencia de ejecutables puede afectar `command` de CTest; se registra como unresolved-before-build y se cruza con CTestTestfile.cmake generado y mapa exacto nombre→target/args. No se ignora un cambio de inventario ni se trata automáticamente un nombre no resuelto como igual. Después del build se vuelve a resolver únicamente la selección y sus archivos ejecutables mediante metadatos generados, sin ejecutar pruebas ni binarios; no un segundo configure/build.
- Enumerar como diferencias esperadas de fuentes Hc/J únicamente extracción de lookup: Hc tiene lookup_box en layout_box.cpp; J conserva layout_box.cpp modificado y añade style_lookup_box.cpp. Aplicable a core, flex_text y source-order-runtime. Cada fuente se vincula al hash ya aceptado. El código restante de los cierres debe coincidir por hash. Ninguna diferencia nueva se aprueba por coincidir en categoría.
- Includes privados de A deben aparecer en ambos cierres correspondientes; las diferencias de sintaxis CMake (hunks Hc frente a foreach J) no permiten diferencias de flags efectivos. Comparar conjuntos ordenados donde el orden es semántico (includes, flags/link); no ordenar indiscriminadamente para ocultar precedencia.
- Permitir únicamente sustitución de raíces absolutas Hc/J y build-Hc/build-J por marcadores comunes, y los objetos explícitos de style_lookup_box donde proceda. No borrar macros, opciones, nombres de objetos, RPATH o dependencias discrepantes.
- Conservar el enlace dl de flex-number, wrappers de transform-origin, fuentes adicionales de su registro, defines de compiler EOF, límite reducido de source-order y todos los parámetros documentados. Los mapas de -01 y CMake íntegro son entradas, no el parser regex como autoridad exclusiva.
- Verificar binarios y bibliotecas por lecturas ELF con herramienta local disponible y SHA256, sin ejecutar binarios ni usar `ldd` de forma que pueda ejecutar el objeto. Identificar NEEDED/RUNPATH/RPATH y resolver bibliotecas de sistema a rutas reales mediante mecanismo read-only explícito implementado y revisado D. Confirmar core propio de cada build y ausencia de referencias a -05/otro árbol. Los hashes de core Hc y J no tienen por qué ser iguales: exigir procedencia correcta y registrar ambos; bibliotecas de sistema y toolchain deben coincidir. Si no puede demostrarse resolución con las herramientas disponibles, BLOCKED.
- Guardar `comparability.json` con cada check, originales/hashes, normalización y lista cerrada de diferencias admitidas. Sólo PASS integral habilita estado TESTS; cualquier desviación exige decisión D y nueva versión, no aprobación improvisada en mitad del reloj.

## 4. Alcance de la materialización posterior

No cambiar A ni H/Hc/J. No tocar código vivo, fuentes, expectativas, corpus, profundidad, flags semánticos ni límites CTest. No ejecutar comandos de prueba del supervisor en este gate. No publicación, red, instalaciones, otra PC, renders ni variante/puente nuevo. Todos los 44 resultados permanecen NOT_RUN y todas las atribuciones UNDETERMINED.

D ya aceptó comparación limitada por A, no equivalencia con HEAD limpio. Una firma común sólo permite reproducción en Hc; diferencias de firma no son mismo fallo. Assertions posteriores a abort siguen no observadas. No se reinicia presupuesto, no se continúa tras cap ni se reutilizan resultados para certificar un árbol cambiado sin decisión explícita D.

**Solicitud a D:** validar o corregir esta propuesta de diseño. Si PASS, autorizar únicamente su materialización estática en -02 y revisión posterior de código/hashes. **G1 NOT_PASSED; OFF/ON/G2 bloqueados; G3/G4 cerrados; coverage_complete=false.**

# A · Plan de investigación causal de los 21 no-PASS de G1

Fecha: 2026-11-16. Estado: **PROPUESTA PARA B; NO AUTORIZA EJECUCIÓN**.

## 1. Punto de partida y propósito

Fuentes rectoras: `dictamen-continuacion-diagnostica-ctest-G1-cmake-v3-D-20261116.md`, `acta-continuacion-diagnostica-ctest-G1-cmake-v3-C-20261116.md` y `drawing-cmake-validation-C-20261116-05/continuation-01/`. Se leyeron además los registros configure/build, la matriz combinada y los antecedentes de parada -01, -02 y -04, y se inspeccionaron el diff vivo y tests relevantes sin ejecutar compilación ni pruebas.

El cierre aceptó la evidencia, no G1: **266 PASS, 19 FAIL, 1 TIMEOUT, 1 ABORT**. La campaña anterior queda cerrada. No se tocarán ni reutilizarán sus directorios operativos. Ninguna categoría descriptiva constituye una causa. Cada uno de los 21 casos parte con atribución **UNDETERMINED**.

Objetivo: distinguir reproducción en base comparable, asociación al delta integrado, defecto de prueba/contrato, problema de entorno y ausencia de evidencia suficiente. No elegir un arreglo de antemano. Investigar una causa común es una hipótesis, no un objetivo de convergencia forzada.

## 2. Custodia y separación de árboles

Referencia viva observada: checkout `aetherui-drawing-integration-C-20261116-01`, HEAD `22fba13df2dc7775d4e091dac432c3e4b2960c46`, rama `local/drawing-exact-v3`, índice `be7b51333cf41b08f39b6a73c21f8a933daa45cece43b42595cc9f7bc3b49361`, parche tracked `40391aa9f6c15926e08c5ec4109f18a3384814a1c19762bded8d4983c1527a08`, 64 caminos WIP. El archivo no tracked `native/src/layout/style_lookup_box.cpp` debe incluirse: el parche Git por sí solo no representa el candidato.

Antes de ejecutar, C entregará un expediente de materialización para revisión B/D con:

- **H**: extracción limpia del HEAD exacto, inmutable, sin asumir que compila.
- **J**: copia exacta del candidato WIP final -05, con manifiesto completo de fuentes, archivos nuevos y referencias.
- **Hc**: H más un adaptador de compilación mínimo **A**, si realmente es necesario para los targets seleccionados. Nunca llamar a Hc «HEAD limpio». Identificar cada hunk, razón, alcance y hash.
- Delta **J − H** descompuesto en dibujo, reparación de build/enlace y cobertura de test. La inspección actual muestra cambios en CMake, layout_box/extracción lookup, renderer y classifier, además de ejemplos/contratos/documentación; comprobar el cierre real de cada target, no inferir inocuidad por el nombre de un archivo.

No ejecutar `reset`, `checkout`, `clean`, `stash`, stage ni commits en el checkout vivo. Copias nuevas y builds fuera del árbol, sin objetos/cache/binarios compartidos. Registrar hashes antes/después, índice y diff cached vacío del vivo. Una divergencia suspende la campaña hasta decisión explícita D de reuso/invalidación.

### Baseline que no oculta los bloqueos conocidos

Los antecedentes contienen: include privado de preparación ausente en consumidores; soporte privado OOM no enlazado; frozen_style requerido por z-index; guard de classifier 19 frente a 25 sidecars. No se aplicará automáticamente todo el paquete a H. Primero inspeccionar CMake y dependencias para los targets elegidos.

La primera comparación compila **sólo esos targets y sus dependencias**, no `all`: permite no requerir las adaptaciones de OOM/z-index/classifier si no pertenecen a ese cierre. Esto no demuestra que el build completo H pase. Si el include de preparación u otra adaptación sigue siendo imprescindible, presentar el diff exacto y verificar que no modifica lógica de producto, expectativas, fixtures, inventario de casos ni flags semánticos. Un supuesto «arreglo de build» que cambia código/enlace de ejecución es un confusor a estudiar, no una equivalencia concedida.

Para cualquier adaptación A no idéntica en ambos cierres, D debe aprobar un control de puente concreto o declarar la comparación limitada por A. Si no puede construirse un par comparable sin tocar la semántica estudiada, registrar **BASELINE_BLOCKED / CAUSAL_UNRESOLVED** y detener ese grupo. No atribuir preexistencia por ausencia de diff en un archivo.

## 3. Dos gates antes de gastar ejecución

1. **B revisa este plan**: preguntas, independencia de grupos, presupuesto y criterio causal.
2. **C prepara únicamente el expediente estático**: árboles/manifiestos, adaptador propuesto, mapa nombre→target→fuentes/definiciones/enlace, argv exactos y selección exacta. La materialización no autoriza instrumentación ni pruebas.
3. **D abre gate de ejecución sólo sobre ese expediente congelado**. Sin hashes concretos del adaptador y mapas comparables, este documento no basta para lanzar configure/build/tests. Si B/D requieren cambios, nueva versión explícita.

## 4. Condiciones iguales y límites de primera tanda

Mismo equipo y herramientas locales del -05: CMake/CTest 4.4.5, GCC/G++ 14.2.0, Debug, C++20 y flags efectivos originales, tests ON y opciones drawing sin definir/default OFF. Comparar compile_commands y link lines normalizando únicamente prefijos de directorios; conservar originales. Identificar bibliotecas resueltas/RPATH y hashes para impedir enlazar accidentalmente al otro árbol. Registrar dependencias, arquitectura, entorno relevante con secretos omitidos, locale/availability de locales, recursos disponibles y carga. No instalar ni descargar nada.

- Dos configure nuevos, uno por árbol, máximo 120 s cada uno.
- Un build seleccionado por árbol, secuencial entre árboles, `--parallel 2 --verbose`, máximo 1800 s cada uno. Fallo de configure/build: preservar evidencia y parar antes de tests; ningún reintento ni reparación automática.
- Tests con `ctest -j1`, selección por **nombres exactos**, nunca por índices históricos sin resolver el inventario local. Conservar argv, cwd, entorno, rc, señal y tiempo de cada invocación. Una ejecución por nombre por árbol, orden fijo documentado, con fallos esperados permitidos dentro de esta tanda diagnóstica.
- Límite externo 120 s por test y 900 s para toda la tanda de pruebas. El límite externo es censura diagnóstica, no reemplaza TimeOut=1500 ni convierte el resultado histórico. Al agotarse, registrar **DIAGNOSTIC_CAP**, terminar el grupo de procesos y detener la tanda, sin aumentar el presupuesto.
- Techo total de esta primera tanda: 80 minutos de pared, 2 jobs build, 1 proceso test a la vez. Mínimo previo propuesto 12 GiB libres y 4 GiB de memoria disponible; si falta capacidad, BLOCKED, no limpiar evidencia. Vigilar memoria/disco y detener con registro ante presión que comprometa custodia. No ejecutar otras campañas a la vez.

Si los flags efectivos difieren por una razón no aprobada, o aparece un test/nombre adicional, no improvisar correcciones ni selección. D resuelve.

## 5. Matriz primaria y preguntas por grupo

Primera tanda: los **20 no-PASS distintos de #159**, más dos controles históricos PASS `aether.smoke` y `aether.abi-c`: 22 nombres por árbol, máximo 44 ejecuciones. Los índices siguientes sólo permiten enlazar con el historial.

| Grupo | Casos exactos (prefijo `aether.`) | Preguntas y evidencia discriminante |
|---|---|---|
| Resoluciones repetidas | #20 length-locale; #71 gradient-angle-runtime; #76 flex-number-pipeline; #120 has-strict-list; #125 forgiving-empty-list; #128 has-pseudo-element; #134 selector-identifier-start-runtime; #137 selector-multiple-ids; #192 transform-runtime; #203 transition-property-pipeline | ¿Se conserva el mismo estado pero cambian updates/impactos? Separar igualdad de valor, metadatos, invalidación y clasificación. Para cada assertion, identificar entrada, nodo y ruta de producción del update. Comparar firma completa, no sólo rc. Los logs de #192 contienen también impactos incorrectos en mutaciones: no reducirlo sólo a no-op. |
| Inventario/catálogo | #226 style-diff-catalog | La primera assertion compara cardinalidades y aborta antes del listado de claves ausentes. Calcular conjuntos/diferencias, duplicados, aliases y shorthands desde registros/catálogo; distinguir omisión, registro extra y supuesto obsoleto. Una cardinalidad igual no basta para cobertura exacta. |
| Máscara semántica | #227 style-semantic-diff | 81 frente a 83: descomponer bits según enum real y localizar qué comparación activa el bit adicional; estudiar valor computado equivalente frente a procedencia/dependencias. No reemplazar 81 por 83 sin contrato independiente. |
| Hook | #80 transform-origin-dispatch | Obtener diferencia exacta entre propiedades registradas y allowlists de css_wide, inherit_context e inherit_explicit. Decidir intención con contrato y código, no ampliando lista para silenciar el test. No mezclar su causalidad con catálogo por compartir registro. |
| Profundidad | #146 stylesheet-eof-closed-deep; #147 stylesheet-eof-compiler-closed-deep; #148 stylesheet-eof-open-deep; #149 stylesheet-eof-compiler-open-deep; #150 stylesheet-eof-mixed-deep; #151 stylesheet-eof-compiler-mixed-deep | Tests existentes usan profundidad 10000. Separar API pública y compiler, estado retornado, número de reglas y diagnósticos de límite/EOF. No reducir profundidad. Comparar límites/defines y reglas de aceptación antes de proponer barridos. |
| Rechazo | #155 stylesheet-source-order-runtime | Capturar status real frente a INVALID_STATE y relacionarlo con límites/defines de su TU de compiler reducido, preservación transaccional y diagnóstico. No asumir misma causa que profundidad. |

La inspección del código puede identificar posibles conjuntos/bits/rutas; si se necesitan valores runtime no observables en estos binarios, **no añadir prints ni probes aún**. Entregar una propuesta de instrumentación mínima y gate independiente. No reetiquetar la falta de instrumentación como prueba causal.

## 6. #159: protocolo separado y gate temporal propio

No está en la primera tanda. Su historia es intento interrumpido seguido de TIMEOUT a 1500.05 s. El código llama a differential, reentrant y cuatro barridos oom_prepare; cada barrido tiene hasta 50000 puntos. Esto señala zonas de investigación, no demuestra que el timeout sea sólo lentitud ni OOM.

Primero inspeccionar stdout histórico, orden de fases, tamaños y contadores, posibles bucles/reentrancia y condiciones de avance. Presentar después a B/D un protocolo exacto con herramientas ya disponibles. Propuesta de límite máximo: **una ejecución de observación por árbol, serial, 180 s cada una**, corte externo explícito, sin elevar el timeout CTest ni reducir corpus/barridos. Medir CPU/pared/RSS e identificar fase/pila con una herramienta existente sólo si su perturbación y autorización están documentadas. Si no hay observabilidad suficiente, proponer marcas de fase/progreso en copias instrumentadas simétricamente y aprobar sus hashes antes de compilar.

Un corte de 180 s es **CENSORED_DIAGNOSTIC**, nunca nuevo timeout oficial, PASS ni prueba de que terminaría a 1500 s. Avance sostenido, repetición de pila y ausencia de progreso son pistas, no demostraciones aisladas. No ejecutar herramientas no disponibles, sanitizers ni profiler por instalación. Una segunda tanda o completar 1500 s necesita alcance nuevo. Preservar evidencia de cancelación y procesos terminados.

## 7. Reglas de interpretación causal

Para cada assertion y no únicamente cada ejecutable, registrar par de estados y firmas:

- Hc reproduce la misma firma y J la reproduce: **reproducido en baseline adaptado**, no regresión atribuida a dibujo; todavía no prueba causa raíz ni preexistencia en HEAD sin adaptación.
- Hc PASS y J FAIL: **asociado al delta J−Hc** bajo condiciones documentadas; aún no identifica el hunk causal.
- Ambos FAIL con firmas distintas: tratar como divergencia, no «mismo fallo».
- J no reproduce el histórico: **NOT_REPRODUCED / UNDETERMINED**, investigar diferencias sin repetir hasta verde.
- Bloqueo de build, control fallido inesperadamente, límite de recursos o entorno desigual: comparación inválida/incompleta, no conclusión favorable.

Tras la matriz, A propone sólo el siguiente experimento discriminante de menor coste: ablación de un delta, instrumentación simétrica o control de adaptación, con árbol, diff, hashes, casos y presupuesto precisos. **No se autorizan aquí bisecciones, variantes, reparaciones ni reejecuciones.** Demostrar causa requiere predicción verificable, intervención controlada y observación que descarte alternativas pertinentes; la coincidencia de mensajes no basta.

## 8. Entrega verificable y cierre

C entregará acta, matriz por test/assertion, manifests H/Hc/J/A, inventarios, flags/link/dependencias comparados, logs completos y hashes; comandos con inicio/fin/rc/señal y límites; custodia antes/después y qué quedó NOT_RUN. Evidencia nueva en directorio único; evidencia -05 intacta. B revisará inferencias y D verificará custodia/comparabilidad independientemente antes de aceptar atribuciones.

Toda reparación posterior tendrá propuesta separada y revisión del contrato, impacto y alcance. No modificar expected, eliminar assertions/tests, reducir corpus ni añadir tolerancias para volver verde. Cada árbol nuevo invalida resultados dinámicos previos para certificación salvo decisión explícita y justificada de reuso; pruebas históricas quedan históricas.

**G1 sigue NOT_PASSED; OFF/ON/G2 bloqueados; G3/G4 cerrados; coverage_complete=false.** Ninguna tanda focalizada certifica los 287 tests, dibujo o producto. Mantener límites históricos de rendimiento/plataformas/LSan. Sin publicación, commit/push/PR, Actions/red, instalaciones, otra PC ni renders adicionales.

Este trabajo A sólo leyó evidencia/código y escribió este plan. No ejecutó builds/tests, no materializó adaptadores ni modificó código.
